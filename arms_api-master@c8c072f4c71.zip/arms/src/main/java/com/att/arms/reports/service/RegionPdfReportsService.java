package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface RegionPdfReportsService {
	
	public ByteArrayInputStream createPdfForRegionSegment(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createPdfForRegionCustomer(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createPdfForRegionState(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createPdfForRegionSegmentCustomer(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createPdfForRegionStateCustomer(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createPdfForRegionStateSegment(UserDetails userDetails, Map<Object, Object> responseMap);


}

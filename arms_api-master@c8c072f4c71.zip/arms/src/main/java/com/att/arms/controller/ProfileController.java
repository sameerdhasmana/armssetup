package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.ProfileModel;
import com.att.arms.entity.RequestModel;
import com.att.arms.service.ProfileService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class ProfileController {

	@Autowired
	ProfileService profileService;

	@PostMapping("renderManageProfile")
	public ResponseEntity<Object> renderManageProfile(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(requestModel.getUserLoginCd())
				&& StringUtils.isNotEmpty(requestModel.getBusinessGroup())) {
			responseMap = this.profileService.renderManageProfile(requestModel.getUserLoginCd(),
					requestModel.getBusinessGroup(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("populateProfileDetails")
	public ResponseEntity<Object> populateProfileDetails(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(requestModel.getUserLoginCd())) {
			responseMap = this.profileService.populateProfileDetails(requestModel.getUserLoginCd(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("populateProfileCustomers")
	public ResponseEntity<Object> populateProfileCustomers(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = profileService.validatePopulateCustomerQuery(requestModel);
		if (response) {
			responseMap = this.profileService.populateProfileCustomers(requestModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("saveProfile")
	public ResponseEntity<Object> saveProfile(@RequestBody ProfileModel profileModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = profileService.validateSaveManageProfileQuery(profileModel);
		if (response) {
			responseMap = this.profileService.saveManageProfile(profileModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("setDefaultProfile")
	public ResponseEntity<Object> setDefaultProfile(@RequestBody ProfileModel profileModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.profileService.validateDefaultProfileQuery(profileModel);
		if (response) {
			responseMap = this.profileService.setDefaultProfile(profileModel.getUserLoginCd(),
					profileModel.getProfileName(), profileModel.getProfileType(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("deleteProfile")
	public ResponseEntity<Object> deleteProfile(@RequestBody ProfileModel profileModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = profileService.validateDefaultProfileQuery(profileModel);
		if (response) {
			responseMap = this.profileService.deleteProfile(profileModel.getUserLoginCd(),
					profileModel.getProfileName(), profileModel.getProfileType(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("loadProfile")
	public ResponseEntity<Object> loadProfile(@RequestBody ProfileModel profileModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = profileService.validateDefaultProfileQuery(profileModel);
		if (response) {
			responseMap = this.profileService.loadProfile(profileModel.getUserLoginCd(),
					profileModel.getProfileName(), profileModel.getProfileType(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("executeProfile")
	public ResponseEntity<Object> executeProfile(@RequestBody ProfileModel profileModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = profileService.validateDefaultProfileQuery(profileModel);
		if (response) {
			responseMap = this.profileService.executeProfile(profileModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

}
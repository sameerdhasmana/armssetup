package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CashDataDetails;

@Transactional
public interface CashDataDetailsRepository extends JpaRepository<CashDataDetails, String> {

	@Query(value = "exec arms_custqry_agedtl_CashdataEx :accountNumber,:byPayment,:byAdjustment,:originatingSystem", nativeQuery = true)
	public List<CashDataDetails> getCashDataDetails(@Param("accountNumber") String accountNumber,
			@Param("byPayment") Integer byPayment, @Param("byAdjustment") Integer byAdjustment,
			@Param("originatingSystem") String originatingSystem);

}

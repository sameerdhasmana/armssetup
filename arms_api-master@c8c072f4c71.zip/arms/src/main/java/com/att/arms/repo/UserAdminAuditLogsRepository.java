package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.AuditLogDailyGui;

@Transactional
public interface UserAdminAuditLogsRepository extends JpaRepository<AuditLogDailyGui, String> {
	@Query(value = "EXEC arms_useradmin_rpt_security_audit_log_daily_gui ", nativeQuery = true)
	public List<AuditLogDailyGui> getSecurityAuditLogdaily();
}
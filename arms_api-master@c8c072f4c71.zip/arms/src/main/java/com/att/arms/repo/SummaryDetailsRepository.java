package com.att.arms.repo;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.arms.entity.SummaryDetails;

@Repository
@Transactional
public interface SummaryDetailsRepository extends JpaRepository<SummaryDetails, String> {

	@Query(value = "Exec arms_custqry_summary_dtl_for_ACNAQuery_v22 :profile_name, :profile_type, :strStateClause, "
			+ ":strGroup, :strCustomerGrpCd, :strLoginCd, :strBillingPeriod,"
			+ " :strStatusClause, :strAccountStatusClause, :strClassClause, :strSegmentClause, :strOriginatingSystemClause,"
			+ " :strACNACriteriaType, :strACNASubType ,:strACNAValue,:strChildTieCd,:nRollUp", nativeQuery = true)

	public List<SummaryDetails> getSummaryDetails(

			@Param("profile_name") String profileName, @Param("profile_type") String profileType,
			@Param("strStateClause") String strStateClause, @Param("strGroup") String strGroup,
			@Param("strCustomerGrpCd") String strCustomerGrpCd, @Param("strLoginCd") String strLoginCd,
			@Param("strBillingPeriod") String strBillingPeriod, @Param("strStatusClause") String strStatusClause,
			@Param("strAccountStatusClause") String strAccountStatusClause,
			@Param("strClassClause") String strClassClause, @Param("strSegmentClause") String strSegmentClause,
			@Param("strOriginatingSystemClause") String strOriginatingSystemClause,
			@Param("strACNACriteriaType") String strACNACriteriaType, @Param("strACNASubType") String strACNASubType,
			@Param("strACNAValue") String strACNAValue, @Param("strChildTieCd") String strChildTieCd,
			@Param("nRollUp") Integer nRollUp);

	@Query(value = "Exec arms_custqry_account_summary_for_single_customer_new_v22 :profile_name, :profile_type, :strQueryType,:strStateClause, "
			+ ":strGroup, :strCustomerGrpCd, :strUserLoginCod, :strBillingPeriod,"
			+ " :strStatusClause, :strAccountStatusClause, :strClassClause, :strSegmentClause,"
			+ " :strOriginatingSystemClause", nativeQuery = true)

	public List<SummaryDetails> getsingleCustomerSummary(

			@Param("profile_name") String profileName, @Param("profile_type") String profileType,
			@Param("strQueryType") String strQueryType, @Param("strStateClause") String strStateClause,
			@Param("strGroup") String strGroup, @Param("strCustomerGrpCd") String strCustomerGrpCd,
			@Param("strUserLoginCod") String strUserLoginCod, @Param("strBillingPeriod") String strBillingPeriod,
			@Param("strStatusClause") String strStatusClause,
			@Param("strAccountStatusClause") String strAccountStatusClause,
			@Param("strClassClause") String strClassClause, @Param("strSegmentClause") String strSegmentClause,
			@Param("strOriginatingSystemClause") String strOriginatingSystemClause);

	@Query(value = "Exec ARMS_SummaryDtlSQLForBillNameQuery_v22 :strStateClause, "
			+ ":strGroup, :strCustomerGrpCd, :strLoginCd, :strBillingPeriod,"
			+ " :strStatusClause, :strAccountStatusClause, :strClassClause, :strSegmentClause, :strOriginatingSystemClause,"
			+ " :strBillName", nativeQuery = true)

	public List<SummaryDetails> getBillNameSummaryDetails(

			@Param("strStateClause") String strStateClause, @Param("strGroup") String strGroup,
			@Param("strCustomerGrpCd") String strCustomerGrpCd, @Param("strLoginCd") String strLoginCd,
			@Param("strBillingPeriod") String strBillingPeriod, @Param("strStatusClause") String strStatusClause,
			@Param("strAccountStatusClause") String strAccountStatusClause,
			@Param("strClassClause") String strClassClause, @Param("strSegmentClause") String strSegmentClause,
			@Param("strOriginatingSystemClause") String strOriginatingSystemClause,
			@Param("strBillName") String strBillName);

}

package com.att.arms.service;

import java.util.List;
import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface CustomerNotesService {

	Map<Object, Object> populateCustomerNotes(String userLoginCd,String customerGrpCd, Map<Object, Object> responseMap);

	Map<Object, Object> populateCustomerNotesContactInfo(String customerGrpCd, Map<Object, Object> responseMap);

	Map<Object, Object> addCustomerNote(String userLoginCd, String customerGrpCd, Map<Object, Object> responseMap);

	boolean validateNotesQuery(UserDetails userDetails);

	Map<Object, Object> resolveCustomerNotes(String userLoginCd, String notes, Integer noteId,
			Map<Object, Object> responseMap);

	Map<Object, Object> deleteCustomerNotes(List<String> noteIdList, Map<Object, Object> responseMap);

	boolean validateSaveNotesQuery(UserDetails userDetails);

	Map<Object, Object> saveCustomerNote(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> customerPermNotes(String customerGrpCd, Map<Object, Object> responseMap);

	Map<Object, Object> customerNotesHistory(String customerGrpCd, Map<Object, Object> responseMap);


}

package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class AuditLogDailyGui {

	@Id
	@JsonProperty("user_login_cd")
	@Column(name="user_login_cd")
	private String userLoginCd;
	private String fname;
	private String lname;
	@JsonProperty("st_last_login_dt")
	@Column(name="st_last_login_dt")
	private String stLastLoginDt;
	@JsonProperty("st_last_logout_dt")
	@Column(name="st_last_logout_dt")
	private String stLastLogoutDt;
	@JsonProperty("insert_dt")
	@Column(name="insert_dt")
	private String insertDt;
	@JsonProperty("last_update_dt")
	@Column(name="last_update_dt")
	private String lastUpdateDt;
	@JsonProperty("u_last_login_dt")
	@Column(name="u_last_login_dt")
	private String uLastLoginDt;
	@JsonProperty("last_reviewed_by")
	@Column(name="last_reviewed_by")
	private String lastReviewedBy;
	@JsonProperty("last_reviewed_dt")
	@Column(name="last_reviewed_dt")
	private String lastReviewedDt;
	@JsonProperty("status_desc")
	@Column(name="status_desc")
	private String statusDesc;
	@JsonProperty("status_change_dt")
	@Column(name="status_change_dt")
	private String statusChangeDt;
	@JsonProperty("email_id")
	@Column(name="email_id")
	private String emailId;
	@JsonProperty("user_pc_name")
	@Column(name="user_pc_name")
	private String userPcName;
	@JsonProperty("user_pc_ip")
	@Column(name="user_pc_ip")
	private String userPcIp;
	@JsonProperty("user_pc_login_id")
	@Column(name="user_pc_login_id")
	private String userPcLoginId;
	@JsonProperty("times_logged_in")
	@Column(name="times_logged_in")
	private String timesLoggedIn;
	private String applicationname;
	private String environment;

}

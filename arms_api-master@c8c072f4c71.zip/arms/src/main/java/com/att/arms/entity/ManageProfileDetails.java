package com.att.arms.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Entity
@IdClass(ManageProfileDetails.ManageProfileDetailsId.class)
@Data
public class ManageProfileDetails {

	@Id
	private String profileType;
	@Id
	private String profileName;
	private String defaultInd;
	@Column(name = "prfl_id")
	private Integer profileId;
	@JsonIgnore
	@Column(name = "prfl_type")
	private String prflType;
	@JsonIgnore
	@Column(name = "prfl_name")
	private String prflName;
	@Id
	@Column(name = "prfl_owner")
	private String profileOwner;
	@Column(name = "prfl_qry_type")
	private String profileQueryType;
	@Column(name = "customer_legal_nm")
	private String customerLegalNm;
	@Column(name = "prfl_qry_cust_grp_cd")
	private String customerGrpCd;
	@Column(name = "prfl_qry_acna")
	private String profileQueryAcna;
	@Column(name = "prfl_qry_aecn")
	private String profileQueryAecn;
	@Column(name = "prfl_qry_ocn")
	private String profileQueryOcn;
	@Column(name = "prfl_qry_ctc")
	private String profileQueryCtc;
	@Column(name = "prfl_qry_bill_nm")
	private String profileQueryBillName;
	@Column(name = "prfl_excl_incl")
	private String profileExclusions;
	@JsonIgnore
	@Column(name = "prfl_excl_stat")
	private String profileExclusionClass;
	@Transient
	private List<String> exclusionClass;
	@JsonIgnore
	@Column(name = "prfl_orig_sys")
	private String profileOriginatingSystem;
	@Transient
	private List<String> originatingSystem;
	@JsonIgnore
	@Column(name = "prfl_bus_unit")
	private String profileBusinessGroup;
	@Transient
	private List<String> businessGroup;
	@JsonIgnore
	@Column(name = "prfl_acct_stat")
	private String profileStatusClause;
	@Transient
	private List<String> statusClause;
	@JsonIgnore
	@Column(name = "prfl_segment_cd")
	private String profileSegment;
	@Transient
	private List<String> segment;
	@Column(name = "prfl_rutp_ind")
	private Integer rollUpToParent;
	@Column(name = "prfl_brng_up_ref")
	private String bringUpRef;
	@Column(name = "prfl_brng_up_type")
	private String bringUpType;
	@JsonIgnore
	@Column(name = "prfl_flag_act_list")
	private String profileFlagActivity;
	@Transient
	private List<String> flagActivity;
	@JsonIgnore
	@Column(name = "prfl_flag_desc_list")
	private String profileFlagDescList;
	@Transient
	private List<String> flagActivityDesc;
	@Column(name = "prfl_flag_dt_ref")
	private String flagDtRef;
	@Column(name = "prfl_amt_type")
	private String amountOption;
	@Column(name = "prfl_amt_operator")
	private String amountOperator;
	@Column(name = "prfl_amt_value")
	private Double amountValue;
	@Column(name = "prfl_disp_amt_ref")
	private String disputeAmtRef;
	@Column(name = "prfl_ctstd_amt_ref")
	private String contestedAmtRef;
	@Column(name = "prfl_unapp_amt_operator")
	private String unappliedAmtOperator;
	@Column(name = "prfl_unapp_amt_value")
	private Double unappliedAmtValue;
	@Column(name = "prfl_usr_assgnmt_ind")
	private String userAssignmentInd;
	@Column(name = "prfl_sort1_field")
	private String sort1Field;
	@Column(name = "prfl_sort1_order")
	private String sort1Order;
	@Column(name = "prfl_sort2_field")
	private String sort2Field;
	@Column(name = "prfl_sort2_order")
	private String sort2Order;
	@Column(name = "prfl_sort3_field")
	private String sort3Field;
	@Column(name = "prfl_sort3_order")
	private String sort3Order;
	@Column(name = "prfl_sort4_field")
	private String sort4Field;
	@Column(name = "prfl_sort4_order")
	private String sort4Order;
	@Column(name = "prfl_sort5_field")
	private String sort5Field;
	@Column(name = "prfl_sort5_order")
	private String sort5Order;
	@JsonIgnore
	@Column(name = "prfl_h1_logins")
	private String profileH1Logins;
	@Transient
	private List<String> h1Logins;
	@Column(name = "prfl_last_updt")
	private String lastUpdatedDate;
	@Column(name = "prfl_last_updt_uid")
	private String lastUpdateUid;

	@SuppressWarnings("serial")
	@Data
	public static class ManageProfileDetailsId implements Serializable {

		private String profileType;
		private String profileName;
		private String profileOwner;
		
		
	}
}

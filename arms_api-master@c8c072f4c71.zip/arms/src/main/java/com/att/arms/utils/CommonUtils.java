package com.att.arms.utils;

import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.att.arms.entity.UserDetails;

public class CommonUtils {

	public static String getListToCommaSeparatedString(List<String> groupList) {
		String grp = "";
		if (!CollectionUtils.isEmpty(groupList)) {
			grp = groupList.stream().collect(Collectors.joining(","));
		}else {
			return "";
		} 
		return grp;
	}

	public static List<String> getCommaSeparatedStringToList(String str) {
		List<String> list = new ArrayList<>();
		if (StringUtils.isNotEmpty(str)) {
			String[] grp = str.split(",");
			list = Arrays.asList(grp);
		}
		return list;
	}

	public static String getIntegerListToCommaSeparatedString(List<Integer> groupList) {
		String grp = "";
		if (!CollectionUtils.isEmpty(groupList)) {
			grp = groupList.stream().map(String::valueOf).collect(Collectors.joining(","));
		}
		return grp;
	}

	public static UserDetails getCurrentUserDetails(String userLoginCd, String environment, String appName,
			UserDetails userDetails) {
		InetAddress inetAddress;
		String userPcLoginId = System.getProperty("user.name");
		String userPcIp = "";
		String userPcName = "";
		try {
			inetAddress = InetAddress.getLocalHost();
			userPcIp = inetAddress.getHostAddress();
			userPcName = inetAddress.getHostName();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		userDetails.setUserLoginCd(userLoginCd);
		userDetails.setEnvironment(environment);
		userDetails.setAppName(appName);
		userDetails.setUserPcIp(userPcIp);
		userDetails.setUserPcLoginId(userPcLoginId);
		userDetails.setUserPcName(userPcName);

		return userDetails;
	}

	public static boolean deleteFile(String path) {
		boolean fileDeleted=false;
		try {
		Files.delete(Paths.get(path)); 
		fileDeleted=true;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return fileDeleted;
	}
}

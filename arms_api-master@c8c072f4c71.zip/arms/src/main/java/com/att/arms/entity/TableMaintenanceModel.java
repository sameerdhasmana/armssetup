package com.att.arms.entity;

import lombok.Data;

@Data
public class TableMaintenanceModel {

	private String strFilter;
	private String strSort;
	private String customerGrpCD;
	private String menuMsg;
	private String userLoginCd;

	private String segment;
	private String description;
	private String segmentGroup;
	private String businessUnit;
	private String excludeWebTaxiFlag;
	private String function;

}

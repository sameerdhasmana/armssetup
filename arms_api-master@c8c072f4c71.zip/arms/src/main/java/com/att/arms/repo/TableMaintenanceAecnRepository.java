package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.TableMaintenanceAecn;

@Transactional
public interface TableMaintenanceAecnRepository extends JpaRepository<TableMaintenanceAecn, String> {

	@Query(value = "Exec arms_tblmaint_aecn_fetchAllDetails_ex :strFilter,:strSort", nativeQuery = true)
	public List<TableMaintenanceAecn> getAenaMaintRecords(@Param("strFilter") String strFilter,
			@Param("strSort") String strSort);

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.UserAdminRole;

@Transactional
public interface UserAdminRoleRepository extends JpaRepository<UserAdminRole, String> {

	@Query(value = "EXEC arms_user_admin_roles_list ", nativeQuery = true)
	public List<UserAdminRole> getAdminRoleList();

}
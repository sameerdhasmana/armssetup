package com.att.arms.service;

import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface TransferService {

	boolean validateTransferNotesQueryRequest(UserDetails userDetails);

	Map<Object, Object> transferNotes(String userLoginCdFrom,String userLoginCdTo, Map<Object, Object> responseMap);
	
	boolean validateTransferCustomerQueryRequest(UserDetails userDetails);

	Map<Object, Object> transferCustomer(String customerGrpCdFrom,String customerGrpCdTo, Map<Object, Object> responseMap);

	Map<Object, Object> getUsers(Map<Object, Object> responseMap);

}

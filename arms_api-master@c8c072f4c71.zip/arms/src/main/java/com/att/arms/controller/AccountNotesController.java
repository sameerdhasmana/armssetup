package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.AccountsNoteService;
import com.att.arms.service.CustomerNotesService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class AccountNotesController {

	@Autowired
	CustomerNotesService customerNotesService;
	@Autowired
	AccountsNoteService accountsNoteService;

	@PostMapping("accountNotes")
	public ResponseEntity<Object> accountNotes(@RequestBody UserDetails userDetails) {
		boolean response = this.accountsNoteService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.accountsNoteService.populateAccountNotes(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("acntNotesContactInfo")
	public ResponseEntity<Object> acntNotesContactInfo(@RequestBody UserDetails userDetails) {
		boolean response = this.accountsNoteService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.accountsNoteService.populateAccountNotesContactInfo(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("populateInTreatment")
	public ResponseEntity<Object> populateInTreatment(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validatePopulateQuery(userDetails);
		if (response) {
			responseMap = this.accountsNoteService.populateInTreatmentDetails(userDetails.getUserLoginCd(),
					userDetails.getSelectedAccountNumbers(), userDetails.getOriginatingSystem(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("resolveAccountNotes")
	public ResponseEntity<Object> resolveAccountNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.customerNotesService.validateNotesQuery(userDetails);
		if (response) {
			responseMap = this.accountsNoteService.resolveAccountNotes(userDetails.getUserLoginCd(),
					userDetails.getNotes(), userDetails.getNoteId(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("addAccountNotes")
	public ResponseEntity<Object> addAccountNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validateAddNotesQuery(userDetails);
		if (response) {
			responseMap = this.accountsNoteService.addAccountNote(userDetails.getUserLoginCd(),
					userDetails.getAccountNumber(),userDetails.getAcntNoteOrgSys(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("addAccountDetails")
	public ResponseEntity<Object> addAccountDetails(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validateAddDetailNotesQuery(userDetails);
		if (response) {
			responseMap = this.accountsNoteService.addAccountDetails(userDetails.getUserLoginCd(),
					userDetails.getSelectedAccountNumbers(), userDetails.getOriginatingSystem(),
					userDetails.getCustomerGrpCd(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("saveAccountNotes")
	public ResponseEntity<Object> saveAccountNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validateSaveNotesQuery(userDetails);
		if (response) {
			responseMap = this.accountsNoteService.saveAccountNotes(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("saveAccountDetails")
	public ResponseEntity<Object> saveAccountDetails(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validateSaveNotesDetailsQuery(userDetails);
		if (response) {
			responseMap = this.accountsNoteService.saveAccountDetails(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("deleteAccountNotes")
	public ResponseEntity<Object> deleteAccountNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& !CollectionUtils.isEmpty(userDetails.getNoteIdList())) {
			responseMap = this.accountsNoteService.deleteAccountNotes(userDetails.getNoteIdList(),
					userDetails.getUserLoginCd(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("accountNoteText")
	public ResponseEntity<Object> accountNoteText(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validateGetNotesTextQuery(userDetails);
		if (response) {
			responseMap = this.accountsNoteService.getAccountNoteText(userDetails.getUserLoginCd(),
					userDetails.getTemplateName(),userDetails.getTemplateType(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("massResolveAccountNotes")
	public ResponseEntity<Object> massResolveAccountNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validateMassNotesQuery(userDetails);
		if (response) {
			responseMap = this.accountsNoteService.massResolveAccountNotes(userDetails.getSelectedAccountNumbers(),
					userDetails.getOriginatingSystem(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("saveMassResolveAccountNotes")
	public ResponseEntity<Object> saveMassResolveAccountNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validateSaveMassNotesQuery(userDetails);
		if (response) {
			responseMap = this.accountsNoteService.saveMassResolveAccountNotes(userDetails.getUserLoginCd(),
					userDetails.getNotesList(), userDetails.getNoteIdList(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("permNotes")
	public ResponseEntity<Object> permNotes(@RequestBody UserDetails userDetails) {
		boolean response = this.accountsNoteService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.accountsNoteService.populatePermNotes(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("accountNoteHistory")
	public ResponseEntity<Object> accountNoteHistory(@RequestBody UserDetails userDetails) {
		boolean response = this.accountsNoteService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.accountsNoteService.populateAccountHistory(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("deleteAccountContacts")
	public ResponseEntity<Object> deleteAccountContacts(@RequestBody UserDetails userDetails) {
		boolean response = this.accountsNoteService.validateDeleteQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.accountsNoteService.deleteAccountContacts(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
}

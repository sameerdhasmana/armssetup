package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerNotes;

@Transactional
public interface CustomerNotesRepository extends JpaRepository<CustomerNotes, String> {

	@Query(value = "Exec ARMS_QRY_customer_tab_notes_v22 :customerGrpCd", nativeQuery = true)
	public List<CustomerNotes> getCustomerNotes(@Param("customerGrpCd") String customerGrpCd);

	@Query(value = "Exec arms_custqry_notes_getcontactinfo :customerGrpCd", nativeQuery = true)
	public List<Object[]> getCustomerNotesContactInfo(@Param("customerGrpCd") String customerGrpCd);

	@Query(value = "EXEC arms_business_group_all_list :userLoginCd , :blankFlag", nativeQuery = true)
	public List<String> getBusinessGroupList(@Param("userLoginCd") String userLoginCd,
			@Param("blankFlag") Integer blankFlag);

	@Modifying
	@Query(value = "Exec arms_custqry_notes_chkresolved :note_id, :resolved,:notes", nativeQuery = true)
	public void resolveCustomerNotes(@Param("note_id") Integer noteId, @Param("resolved") Integer resolved,
			@Param("notes") String notes);

	@Modifying
	@Query(value = "Exec arms_custqry_notes_delete_v22 :note_id", nativeQuery = true)
	public void deleteCustomerNotes(@Param("note_id") String noteId);

	@Modifying
	@Query(value = "Exec arms_custqry_notes_addmodify_v19 :modeType, :noteId,:billingPeriod,:region,:group,:customerGrpCd"
			+ ",:resolved,:activityCode,:commitmentAmt,:bringupDate,:subActivity,:talkedTo,:loggedByUserID,:notes,:contestedAmt,"
			+ ":rcCd,:nxtactCd,:commitmentDate", nativeQuery = true)
	public void saveCustomerNote(@Param("modeType") Integer modeType, @Param("noteId") Integer noteId,
			@Param("billingPeriod") String billingPeriod, @Param("region") String region, @Param("group") String group,
			@Param("customerGrpCd") String customerGrpCd, @Param("resolved") Integer resolved,
			@Param("activityCode") String activityCode, @Param("commitmentAmt") Double commitmentAmt,
			@Param("bringupDate") String bringupDate, @Param("subActivity") String subActivity,
			@Param("talkedTo") String talkedTo, @Param("loggedByUserID") String loggedByUserID,
			@Param("notes") String notes, @Param("contestedAmt") Double contestedAmt, @Param("rcCd") String rcCd,
			@Param("nxtactCd") String nxtactCd, @Param("commitmentDate") String commitmentDate);

}

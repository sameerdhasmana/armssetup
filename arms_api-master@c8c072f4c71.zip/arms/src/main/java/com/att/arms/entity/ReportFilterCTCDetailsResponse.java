package com.att.arms.entity;

import java.util.List;

public class ReportFilterCTCDetailsResponse {

	private GlobalLogonUsers globalLogonUsers;
	private List<ChildTieCodeDetails> childTieCodeDetails;
	
	private String errorMsg;

	public GlobalLogonUsers getGlobalLogonUsers() {
		return globalLogonUsers;
	}

	public void setGlobalLogonUsers(GlobalLogonUsers globalLogonUsers) {
		this.globalLogonUsers = globalLogonUsers;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<ChildTieCodeDetails> getChildTieCodeDetails() {
		return childTieCodeDetails;
	}

	public void setChildTieCodeDetails(List<ChildTieCodeDetails> childTieCodeDetails) {
		this.childTieCodeDetails = childTieCodeDetails;
	}


}

package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(CommitmentHistory.CommitmentHistoryId.class)
@Data
public class CommitmentHistory {

	@Id
	@JsonProperty("account_number")
	@Column(name="account_number")
	private String accountNumber;
	@Id
	@JsonProperty("originating_system")
	@Column(name="originating_system")
	private String originatingSystem;
	@JsonProperty("date_entered")
	@Column(name="date_entered")
	private String dateEntered;
	@Id
	private Double amount;
	@Id
	@JsonProperty("due_date")
	@Column(name="due_date")
	private String dueDate;
	private String status;
	
	@SuppressWarnings("serial")
	@Data
	public static class CommitmentHistoryId implements Serializable {

		private String accountNumber;
		private String originatingSystem;
		private Double amount;
		private String dueDate;
		
		
	}
}

package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.repo.SummaryReportByCustomerRepository;
import com.att.arms.reports.repo.SummaryReportByCustomerStatusRepository;
import com.att.arms.reports.entity.SummaryReportByCustomerResponseModel;
import com.att.arms.reports.entity.SummaryReportByCustomerStatusResponseModel;
import com.att.arms.reports.entity.SummaryReportBySegmentResponseModel;
import com.att.arms.reports.entity.SummaryReportByStateResponseModel;
import com.att.arms.reports.repo.SummaryReportBySegmentRepository;
import com.att.arms.reports.repo.SummaryReportByStateRepository;
import com.att.arms.utils.CommonReportsUtils;

@Service
public class SummaryExcelReportServiceImpl implements SummaryExcelReportService {

	@Autowired 
	SummaryReportByCustomerRepository summaryExcelReportByCustomerRepository;
	
	@Autowired 
	SummaryReportByCustomerStatusRepository summaryExcelReportByCustomerStatusRepository;
	
	@Autowired 
	SummaryReportBySegmentRepository summaryExcelReportBySegmentRepository;
	
	@Autowired 
	SummaryReportByStateRepository summaryExcelReportByStateRepository;
	
	//byCustomer
	@Override
	public ByteArrayInputStream searchByCustomer(UserDetails requestModel, Map<Object, Object> responseMap) {
		List<SummaryReportByCustomerResponseModel> response = summaryExcelReportByCustomerRepository.byCustomer(
				requestModel.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
				requestModel.getExclusions(), 
				"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
				requestModel.getCustomerChidFlag()
				);
		
		try (Workbook summaryReportByCustomerSheetWorkbook = new XSSFWorkbook()) {
			Sheet summaryReportByCustomerDetailsSheet = summaryReportByCustomerSheetWorkbook
					.createSheet("Segment Report By Segment Customer");

			if (response != null) {

				addHeaderContentForCustomer(summaryReportByCustomerDetailsSheet, summaryReportByCustomerSheetWorkbook);
				addActualContentForCustomer(response, summaryReportByCustomerDetailsSheet, summaryReportByCustomerSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			summaryReportByCustomerSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//byCustomer
		private void addHeaderContentForCustomer(Sheet summaryByCustomer, Workbook summaryByCustomerWorkBook) {
			Row row = summaryByCustomer.createRow(0);
			CellStyle headerCellStyle = summaryByCustomerWorkBook.createCellStyle();
			headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			Cell cell1 = row.createCell(0);
			cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
			cell1.setCellStyle(headerCellStyle);

			Cell cell2 = row.createCell(1);
			cell2.setCellValue(ReportsConstant.CUSTOMER);
			cell2.setCellStyle(headerCellStyle);

			Cell cell4 = row.createCell(2);
			cell4.setCellValue(ReportsConstant.CURRENT_BILLING);
			cell4.setCellStyle(headerCellStyle);

			Cell cell5 = row.createCell(3);
			cell5.setCellValue(ReportsConstant.CURRENT_BALANCE);
			cell5.setCellStyle(headerCellStyle);

			Cell cell6 = row.createCell(4);
			cell6.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
			cell6.setCellStyle(headerCellStyle);

			Cell cell7 = row.createCell(5);
			cell7.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
			cell7.setCellStyle(headerCellStyle);

			Cell cell8 = row.createCell(6);
			cell8.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
			cell8.setCellStyle(headerCellStyle);

			Cell cell9 = row.createCell(7);
			cell9.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
			cell9.setCellStyle(headerCellStyle);

			Cell cell10 = row.createCell(8);
			cell10.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
			cell10.setCellStyle(headerCellStyle);

			Cell cell11 = row.createCell(9);
			cell11.setCellValue(ReportsConstant.TOTAL_DUE);
			cell11.setCellStyle(headerCellStyle);

			Cell cell12 = row.createCell(10);
			cell12.setCellValue(ReportsConstant.DISPUTE);
			cell12.setCellStyle(headerCellStyle);

			Cell cell13 = row.createCell(11);
			cell13.setCellValue(ReportsConstant.DSO);
			cell13.setCellStyle(headerCellStyle);
			
			//Setting Auto Column Width
			summaryByCustomer.createFreezePane(1, 1);
		}

	
	//byCustomer
	private void addActualContentForCustomer(List<SummaryReportByCustomerResponseModel> responseList,
			Sheet summaryByCustomerSheet, Workbook summaryByCustomerWorkBook) {

		CellStyle dataCellStyleBlack = summaryByCustomerWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = summaryByCustomerWorkBook.createCellStyle();
		Font BlackColorFont = summaryByCustomerWorkBook.createFont();
		BlackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        dataCellStyleBlack.setFont(BlackColorFont);
        
        Font REDColorFont = summaryByCustomerWorkBook.createFont();
        REDColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(REDColorFont);
        
		Row dataRow ;

		BigDecimal currentBilling = BigDecimal.ZERO;
		BigDecimal pastDue0Amt = BigDecimal.ZERO;
		BigDecimal pastDue30Amt = BigDecimal.ZERO;
		BigDecimal pastDue60Amt = BigDecimal.ZERO;
		BigDecimal pastDue90Amt = BigDecimal.ZERO;
		BigDecimal pastDue120Amt = BigDecimal.ZERO;
		BigDecimal PastDueAmt = BigDecimal.ZERO;
		BigDecimal totalDueAmt = BigDecimal.ZERO;
		BigDecimal dispute = BigDecimal.ZERO;
		BigDecimal qdso = BigDecimal.ZERO;

		for (int i = 0; i < responseList.size(); i++) {
			dataRow = summaryByCustomerSheet.createRow(i + 1);
		CellStyle styleCurrencyFormat = summaryByCustomerWorkBook.createCellStyle();
		styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(responseList.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(responseList.get(i).getCustomer());
			cell2.setCellStyle(dataCellStyleBlack);

			currentBilling=responseList.get(i).getCurrentBillingAmount();
			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell3.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell3.setCellStyle(styleCurrencyFormat);


			pastDue0Amt=responseList.get(i).getPastDue0Amount();
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell4.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO) > 0?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);


			pastDue30Amt=responseList.get(i).getPastDue30Amount();
			Cell cell5= dataRow.createCell(4);
			cell5.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);


			pastDue60Amt=responseList.get(i).getPastDue60Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);


			pastDue90Amt=responseList.get(i).getPastDue90Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);


			pastDue120Amt=responseList.get(i).getPastDue120Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);


			PastDueAmt=responseList.get(i).getTotalPastDueAmount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(PastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(PastDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);


			totalDueAmt=responseList.get(i).getTotalAmount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);


			dispute=responseList.get(i).getDispute();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(dispute.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);


			qdso=responseList.get(i).getDso();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(qdso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(qdso.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);
			summaryByCustomerSheet.setColumnWidth(i,summaryByCustomerSheet.getColumnWidth(i)*23/10);	
		}
	}


	//bySegment
	@Override
	public ByteArrayInputStream searchBySegment(UserDetails requestModel, Map<Object, Object> responseMap) {
		List<SummaryReportBySegmentResponseModel> response =  summaryExcelReportBySegmentRepository.bySegment(
				requestModel.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
				requestModel.getExclusions(), 
				"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
				requestModel.getCustomerChidFlag()
				);
		
		try (Workbook summaryReportForSegmentSheetWorkbook = new XSSFWorkbook()) {
			Sheet summaryReportForSegmentDetailsSheet = summaryReportForSegmentSheetWorkbook
					.createSheet("Summary Report By Segment");

			if (response != null) {

				addHeaderContentPerSegment(summaryReportForSegmentDetailsSheet, summaryReportForSegmentSheetWorkbook);
				addActualContentForSegment(response, summaryReportForSegmentDetailsSheet,summaryReportForSegmentSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			summaryReportForSegmentSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//bySegment
			private void addHeaderContentPerSegment(Sheet summaryBySegment, Workbook summaryBySegmentWorkBook) {
				Row row = summaryBySegment.createRow(0);
				CellStyle headerCellStyle = summaryBySegmentWorkBook.createCellStyle();
				headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
				headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

				Cell cell1 = row.createCell(0);
				cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
				cell1.setCellStyle(headerCellStyle);

				Cell cell2 = row.createCell(1);
				cell2.setCellValue(ReportsConstant.SEGMENT);
				cell2.setCellStyle(headerCellStyle);

				Cell cell3 = row.createCell(2);
				cell3.setCellValue(ReportsConstant.CURRENT_BILLING);
				cell3.setCellStyle(headerCellStyle);

				Cell cell4 = row.createCell(3);
				cell4.setCellValue(ReportsConstant.CURRENT_BALANCE);
				cell4.setCellStyle(headerCellStyle);

				Cell cell5 = row.createCell(4);
				cell5.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
				cell5.setCellStyle(headerCellStyle);

				Cell cell6 = row.createCell(5);
				cell6.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
				cell6.setCellStyle(headerCellStyle);

				Cell cell7 = row.createCell(6);
			    cell7.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
				cell7.setCellStyle(headerCellStyle);

				Cell cell8 = row.createCell(7);
				cell8.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
				cell8.setCellStyle(headerCellStyle);

				Cell cell9 = row.createCell(8);
				cell9.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
				cell9.setCellStyle(headerCellStyle);

				Cell cell10 = row.createCell(9);
				cell10.setCellValue(ReportsConstant.TOTAL_DUE);
				cell10.setCellStyle(headerCellStyle);

				Cell cell11 = row.createCell(10);
				cell11.setCellValue(ReportsConstant.DISPUTE);
				cell11.setCellStyle(headerCellStyle);

				Cell cell12 = row.createCell(11);
				cell12.setCellValue(ReportsConstant.DSO);
				cell12.setCellStyle(headerCellStyle);
				
				//Setting Auto Column Width
				summaryBySegment.createFreezePane(1, 1);
			}
	
	//bySegment
	private void addActualContentForSegment(List<SummaryReportBySegmentResponseModel> response,
			Sheet summaryBySegmentSheet, Workbook summaryBySegmentWorkBook) {

		CellStyle dataCellStyleBlack = summaryBySegmentWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = summaryBySegmentWorkBook.createCellStyle();
		Font BlackColorFont = summaryBySegmentWorkBook.createFont();
		BlackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        dataCellStyleBlack.setFont(BlackColorFont);
        
        Font REDColorFont = summaryBySegmentWorkBook.createFont();
        REDColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(REDColorFont);
        
		Row dataRow ;

		BigDecimal currentBilling = BigDecimal.ZERO;
		BigDecimal pastDue0Amt = BigDecimal.ZERO;
		BigDecimal pastDue30Amt = BigDecimal.ZERO;
		BigDecimal pastDue60Amt = BigDecimal.ZERO;
		BigDecimal pastDue90Amt = BigDecimal.ZERO;
		BigDecimal pastDue120Amt = BigDecimal.ZERO;
		BigDecimal PastDueAmt = BigDecimal.ZERO;
		BigDecimal totalDueAmt = BigDecimal.ZERO;
		BigDecimal dispute = BigDecimal.ZERO;
		BigDecimal qdso = BigDecimal.ZERO;

		for (int i = 0; i < response.size(); i++) {
			dataRow = summaryBySegmentSheet.createRow(i + 1);
		CellStyle styleCurrencyFormat = summaryBySegmentWorkBook.createCellStyle();
		styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(response.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(response.get(i).getSegment());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell3.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell3.setCellStyle(styleCurrencyFormat);

			pastDue0Amt=response.get(i).getPastDue0Amount();
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell4.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);

			pastDue30Amt=response.get(i).getPastDue30Amount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);

			pastDue60Amt=response.get(i).getPastDue60Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);

			pastDue90Amt=response.get(i).getPastDue90Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);

			pastDue120Amt=response.get(i).getPastDue120Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);

			PastDueAmt=response.get(i).getTotalPastDueAmount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(PastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(PastDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);

			totalDueAmt=response.get(i).getTotalAmount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);

			dispute=response.get(i).getDispute();
			Cell cell11= dataRow.createCell(10);
			cell11.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(dispute.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);

			qdso=response.get(i).getDso();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(qdso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(qdso.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);
		  
			summaryBySegmentSheet.setColumnWidth(i,summaryBySegmentSheet.getColumnWidth(i)*23/10);
		}}


	//byCustomerByStatus
	@Override
	public ByteArrayInputStream searchByCustomerStatus(UserDetails requestModel, Map<Object, Object> responseMap) {
		List<SummaryReportByCustomerStatusResponseModel> response = summaryExcelReportByCustomerStatusRepository.byCustomerStatus(
				requestModel.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
				requestModel.getExclusions(), 
				"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
				requestModel.getCustomerChidFlag()
				);
		
		try (Workbook summaryReportByCustomerStatusSheetWorkbook = new XSSFWorkbook()) {
			Sheet summaryReportByCustomerStatusDetailsSheet = summaryReportByCustomerStatusSheetWorkbook
					.createSheet("Summary Report By Customer Status");

			if (response != null) {
			    addHeaderContentForCustomerStatus(summaryReportByCustomerStatusDetailsSheet, summaryReportByCustomerStatusSheetWorkbook);
				addActualContentForCustomerStatus(response, summaryReportByCustomerStatusDetailsSheet, summaryReportByCustomerStatusSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			summaryReportByCustomerStatusSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
		//byCustomerStatus
		private void addActualContentForCustomerStatus(List<SummaryReportByCustomerStatusResponseModel> response,
				Sheet summaryByCustomerStatus, Workbook summaryByCustomerStatusWorkBook) {

			CellStyle dataCellStyleBlack = summaryByCustomerStatusWorkBook.createCellStyle();
			CellStyle dataCellStyleRed = summaryByCustomerStatusWorkBook.createCellStyle();
			Font BlackColorFont = summaryByCustomerStatusWorkBook.createFont();
			BlackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
	        dataCellStyleBlack.setFont(BlackColorFont);
	        
	        Font REDColorFont = summaryByCustomerStatusWorkBook.createFont();
	        REDColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
			dataCellStyleRed.setFont(REDColorFont);
	        

		BigDecimal currentBilling = BigDecimal.ZERO;
		BigDecimal pastDue0Amt = BigDecimal.ZERO;
		BigDecimal pastDue30Amt = BigDecimal.ZERO;
		BigDecimal pastDue60Amt = BigDecimal.ZERO;
		BigDecimal pastDue90Amt = BigDecimal.ZERO;
		BigDecimal pastDue120Amt = BigDecimal.ZERO;
		BigDecimal PastDueAmt = BigDecimal.ZERO;
		BigDecimal totalDueAmt = BigDecimal.ZERO;
		BigDecimal dispute = BigDecimal.ZERO;
		BigDecimal qdso = BigDecimal.ZERO;

		for (int i = 0; i < response.size(); i++) {
			Row dataRow = summaryByCustomerStatus.createRow(i + 1);
		CellStyle styleCurrencyFormat = summaryByCustomerStatusWorkBook.createCellStyle();
		styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(response.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(response.get(i).getCustomer());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(response.get(i).getStatus());
			cell3.setCellStyle(dataCellStyleBlack);
			
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell4.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);


			pastDue0Amt=response.get(i).getPastDue0Amount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);


			pastDue30Amt=response.get(i).getPastDue30Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);


			pastDue60Amt=response.get(i).getPastDue60Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);


			pastDue90Amt=response.get(i).getPastDue90Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);


			pastDue120Amt=response.get(i).getPastDue120Amount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);


			PastDueAmt=response.get(i).getTotalPastDueAmount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(PastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(PastDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);


			totalDueAmt=response.get(i).getTotalAmount();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);


			dispute=response.get(i).getDispute();
			Cell cell12= dataRow.createCell(11);
			cell12.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(dispute.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);


			qdso=response.get(i).getDso();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(qdso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell13.setCellStyle(qdso.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);
		  
			

			 summaryByCustomerStatus.setColumnWidth(i,summaryByCustomerStatus.getColumnWidth(i)*23/10);
		}}
		
	//byCustomerStatus
	private void addHeaderContentForCustomerStatus(Sheet summaryByCustomerStatus, Workbook summaryByCustomerStatusWorkBook) {
		Row row = summaryByCustomerStatus.createRow(0);
		CellStyle headerCellStyle = summaryByCustomerStatusWorkBook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.CUSTOMER);
		cell2.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(2);
		cell4.setCellValue(ReportsConstant.STATUS);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(3);
		cell5.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(4);
		cell6.setCellValue(ReportsConstant.CURRENT_BALANCE);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(5);
		cell7.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(6);
		cell8.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(7);
		cell9.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(8);
		cell10.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(9);
		cell11.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(10);
		cell12.setCellValue(ReportsConstant.TOTAL_DUE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(11);
		cell13.setCellValue(ReportsConstant.DISPUTE);
		cell13.setCellStyle(headerCellStyle);

		Cell cell14 = row.createCell(12);
		cell14.setCellValue(ReportsConstant.DSO);
		cell14.setCellStyle(headerCellStyle);
		
		//Setting Auto Column Width
		summaryByCustomerStatus.createFreezePane(1, 1);
	}

	//By State
	@Override
	public ByteArrayInputStream searchByState(UserDetails requestModel, Map<Object, Object> responseMap) {
		List<SummaryReportByStateResponseModel> response = summaryExcelReportByStateRepository.byState(
				requestModel.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
				requestModel.getExclusions(), 
				"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
				requestModel.getCustomerChidFlag()
				);
		
		try (Workbook summaryReportByStateSheetWorkbook = new XSSFWorkbook()) {
			Sheet summaryReportByStateDetailsSheet = summaryReportByStateSheetWorkbook
					.createSheet("Summary Report By State");

			if (response != null) {

				addHeaderContent(summaryReportByStateDetailsSheet , summaryReportByStateSheetWorkbook);
				addActualContentForState(response,summaryReportByStateDetailsSheet , summaryReportByStateSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			summaryReportByStateSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
		}
			
			private void addHeaderContent(Sheet summaryReportByStateDetailsSheet, Workbook summaryReportByStateSheetWorkbook) {
				Row row = summaryReportByStateDetailsSheet.createRow(0);
				CellStyle headerCellStyle = summaryReportByStateSheetWorkbook.createCellStyle();
				headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
				headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

				Cell cell1 = row.createCell(0);
				cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
				cell1.setCellStyle(headerCellStyle);

				Cell cell2 = row.createCell(1);
				cell2.setCellValue(ReportsConstant.STATE);
				cell2.setCellStyle(headerCellStyle);
			

				Cell cell3 = row.createCell(2);
				cell3.setCellValue(ReportsConstant.CURRENT_BILLING);
				cell3.setCellStyle(headerCellStyle);

				Cell cell4 = row.createCell(3);
				cell4.setCellValue(ReportsConstant.CURRENT_BALANCE);
				cell4.setCellStyle(headerCellStyle);

				Cell cell5 = row.createCell(4);
				cell5.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
				cell5.setCellStyle(headerCellStyle);

				Cell cell6 = row.createCell(5);
				cell6.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
				cell6.setCellStyle(headerCellStyle);

				Cell cell7 = row.createCell(6);
				cell7.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
				cell7.setCellStyle(headerCellStyle);

				Cell cell8 = row.createCell(7);
				cell8.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
				cell8.setCellStyle(headerCellStyle);

				Cell cell9 = row.createCell(8);
				cell9.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
				cell9.setCellStyle(headerCellStyle);

				Cell cell10 = row.createCell(9);
				cell10.setCellValue(ReportsConstant.TOTAL_DUE);
				cell10.setCellStyle(headerCellStyle);

				Cell cell11 = row.createCell(10);
				cell11.setCellValue(ReportsConstant.DISPUTE);
				cell11.setCellStyle(headerCellStyle);

				Cell cell12 = row.createCell(11);
				cell12.setCellValue(ReportsConstant.DSO);
				cell12.setCellStyle(headerCellStyle);
				
				//Setting Auto Column Width
				summaryReportByStateDetailsSheet.createFreezePane(1, 1);
	}

			//ByState
			private void addActualContentForState(List<SummaryReportByStateResponseModel> responseList,
					Sheet summaryReportByStateWorkSheet, Workbook summaryReportBystateWorkBook) {

				CellStyle dataCellStyleBlack = summaryReportBystateWorkBook.createCellStyle();
				CellStyle dataCellStyleRed = summaryReportBystateWorkBook.createCellStyle();
				Font BlackColorFont = summaryReportBystateWorkBook.createFont();
				BlackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		      dataCellStyleBlack.setFont(BlackColorFont);
		      
		      Font REDColorFont = summaryReportBystateWorkBook.createFont();
		      REDColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
				dataCellStyleRed.setFont(REDColorFont);
		      
				Row dataRow ;

				BigDecimal currentBilling = BigDecimal.ZERO;
				BigDecimal pastDue0Amt = BigDecimal.ZERO;
				BigDecimal pastDue30Amt = BigDecimal.ZERO;
				BigDecimal pastDue60Amt = BigDecimal.ZERO;
				BigDecimal pastDue90Amt = BigDecimal.ZERO;
				BigDecimal pastDue120Amt = BigDecimal.ZERO;
				BigDecimal PastDueAmt = BigDecimal.ZERO;
				BigDecimal totalDueAmt = BigDecimal.ZERO;
				BigDecimal dispute = BigDecimal.ZERO;
				BigDecimal qdso = BigDecimal.ZERO;

				for (int i = 0; i < responseList.size(); i++) {
					dataRow =summaryReportByStateWorkSheet .createRow(i + 1);
				CellStyle styleCurrencyFormat = summaryReportBystateWorkBook.createCellStyle();
				styleCurrencyFormat.setDataFormat((short)8);

					Cell cell1 = dataRow.createCell(0);
					cell1.setCellValue(responseList.get(i).getBillingPeriod());
					cell1.setCellStyle(dataCellStyleBlack);

					Cell cell2 = dataRow.createCell(1);
					cell2.setCellValue(responseList.get(i).getState());
					cell2.setCellStyle(dataCellStyleBlack);

					currentBilling=responseList.get(i).getCurrentBillingAmount();
					Cell cell3 = dataRow.createCell(2);
					cell3.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell3.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell3.setCellStyle(styleCurrencyFormat);

					pastDue0Amt=responseList.get(i).getPastDue0Amount();
					Cell cell4 = dataRow.createCell(3);
					cell4.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell4.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell4.setCellStyle(styleCurrencyFormat);


					pastDue30Amt=responseList.get(i).getPastDue30Amount();
					Cell cell5 = dataRow.createCell(4);
					cell5.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell5.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell5.setCellStyle(styleCurrencyFormat);


					pastDue60Amt=responseList.get(i).getPastDue60Amount();
					Cell cell6 = dataRow.createCell(5);
					cell6.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell6.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell6.setCellStyle(styleCurrencyFormat);


					pastDue90Amt=responseList.get(i).getPastDue90Amount();
					Cell cell7 = dataRow.createCell(6);
					cell7.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell7.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell7.setCellStyle(styleCurrencyFormat);


					pastDue120Amt=responseList.get(i).getPastDue120Amount();
					Cell cell8 = dataRow.createCell(7);
					cell8.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell8.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell8.setCellStyle(styleCurrencyFormat);


					PastDueAmt=responseList.get(i).getTotalPastDueAmount();
					Cell cell9 = dataRow.createCell(8);
					cell9.setCellValue(PastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell9.setCellStyle(PastDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell9.setCellStyle(styleCurrencyFormat);


					totalDueAmt=responseList.get(i).getTotalAmount();
					Cell cell10 = dataRow.createCell(9);
					cell10.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell10.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell10.setCellStyle(styleCurrencyFormat);


					dispute=responseList.get(i).getDispute();
					Cell cell11 = dataRow.createCell(10);
					cell11.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell11.setCellStyle(dispute.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell11.setCellStyle(styleCurrencyFormat);


					qdso=responseList.get(i).getDso();
					Cell cell12 = dataRow.createCell(11);
					cell12.setCellValue(qdso.setScale(2, RoundingMode.HALF_UP).doubleValue());
					cell12.setCellStyle(qdso.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
					cell12.setCellStyle(styleCurrencyFormat);
					summaryReportByStateWorkSheet.setColumnWidth(i,summaryReportByStateWorkSheet.getColumnWidth(i)*23/10);
		}
	}	
}



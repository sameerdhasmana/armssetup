package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class SegmentMaintenanceGroup {
	@Id
	@JsonProperty("segmentGroupCode")
	@Column(name = "segment_grp_cd")
	private String segmentGrpCd;
	@JsonProperty("segmentGroupDesc")
	@Column(name = "segment_grp_desc")
	private String segmentGrpDesc;
	@JsonProperty("insertDate")
	@Column(name = "insert_dt")
	private String insertDt;
	@JsonProperty("updateDate")
	@Column(name = "update_dt")
	private String updateDt;

}

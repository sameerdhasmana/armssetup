package com.att.arms.service;

import java.util.List;
import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface AccountsNoteService {

	boolean validateQueryRequest(UserDetails userDetails);

	Map<Object, Object> populateAccountNotes(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> populateAccountNotesContactInfo(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> resolveAccountNotes(String userLoginCd, String notes, Integer noteId,
			Map<Object, Object> responseMap);

	boolean validatePopulateQuery(UserDetails userDetails);

	Map<Object, Object> populateInTreatmentDetails(String userLoginCd, List<String> accountNumberList,
			List<String> originatingSystemList, Map<Object, Object> responseMap);

	Map<Object, Object> addAccountNote(String userLoginCd, String accountNumber, String originatingSystem,
			Map<Object, Object> responseMap);

	Map<Object, Object> addAccountDetails(String userLoginCd, List<String> accountNumberList,
			List<String> originatingSystemList, String customerGrpCd, Map<Object, Object> responseMap);

	boolean validateAddNotesQuery(UserDetails userDetails);

	Map<Object, Object> deleteAccountNotes(List<String> noteIdList, String userLoginCd,
			Map<Object, Object> responseMap);

	Map<Object, Object> saveAccountNotes(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateSaveNotesQuery(UserDetails userDetails);

	boolean validateSaveNotesDetailsQuery(UserDetails userDetails);

	Map<Object, Object> saveAccountDetails(UserDetails userDetails, Map<Object, Object> responseMap);
	
	Map<Object, Object> getAccountNoteText(String userLoginCd,String templateName,String templateType,Map<Object, Object> responseMap);

	boolean validateGetNotesTextQuery(UserDetails userDetails);

	boolean validateAddDetailNotesQuery(UserDetails userDetails);
	
	boolean validateMassNotesQuery(UserDetails userDetails);

	Map<Object, Object> saveMassResolveAccountNotes(String userLoginCd, List<String> notesList, List<String> noteIdList,
			Map<Object, Object> responseMap);

	boolean validateSaveMassNotesQuery(UserDetails userDetails);

	Map<Object, Object> massResolveAccountNotes(List<String> accountNumberList, List<String> originatingSystemList,
			Map<Object, Object> responseMap);

	Map<Object, Object> populatePermNotes(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> populateAccountHistory(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateDeleteQueryRequest(UserDetails userDetails);

	Map<Object, Object> deleteAccountContacts(UserDetails userDetails, Map<Object, Object> responseMap);

}

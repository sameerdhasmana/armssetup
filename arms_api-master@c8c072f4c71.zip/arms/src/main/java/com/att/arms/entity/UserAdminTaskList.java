package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class UserAdminTaskList {

	@Id
	@Column(name = "taskId")
	private Integer taskId;
	@Column(name = "description")
	private String description;
	@Column(name = "allowedRoles")
	private Integer allowedRoles;
}

package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.SegmentReportByCustomerResponseModel;
import com.att.arms.reports.entity.SegmentReportByRegionResponseModel;
import com.att.arms.reports.repo.SegmentReportByCustomerRepository;
import com.att.arms.reports.repo.SegmentReportByRegionRepository;
import com.att.arms.utils.CommonReportsUtils;

@Service
public class SegmentExcelReportServiceImpl implements SegmentExcelReportService {

	@Autowired 
	SegmentReportByCustomerRepository SegmentReportByCustomerRepository;
	
	@Autowired 
	SegmentReportByRegionRepository SegmentReportByRegionRepository;
	
	//byCustomer
	@Override
	public ByteArrayInputStream searchByCustomer(UserDetails requestModel, Map<Object, Object> responseMap) {
		// hardcoding customerChidFlag = 0, since I didnot get any responses for other values customerChidFlag
		List<SegmentReportByCustomerResponseModel> response = SegmentReportByCustomerRepository.byCustomer(
				requestModel.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
				requestModel.getExclusions(), 
				"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
				requestModel.getCustomerChidFlag()
				);
		
		try (Workbook segmentReportByCustomerSheetWorkbook = new XSSFWorkbook()) {
			Sheet segmentReportByCustomerDetailsSheet = segmentReportByCustomerSheetWorkbook
					.createSheet("Segment Report By Segment Customer");

			if (response != null) {

				addHeaderContent(segmentReportByCustomerDetailsSheet, segmentReportByCustomerSheetWorkbook);
				addActualContent(response, segmentReportByCustomerDetailsSheet, segmentReportByCustomerSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			segmentReportByCustomerSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//byCustomer
	private void addActualContent(List<SegmentReportByCustomerResponseModel> responseList,
			Sheet segmentByCustomerSheet, Workbook segmentByCustomerWorkBook) {

		CellStyle dataCellStyleBlack = segmentByCustomerWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = segmentByCustomerWorkBook.createCellStyle();
		Font BlackColorFont = segmentByCustomerWorkBook.createFont();
		BlackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        dataCellStyleBlack.setFont(BlackColorFont);
        
        Font REDColorFont = segmentByCustomerWorkBook.createFont();
        REDColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(REDColorFont);
        
		Row dataRow ;

		BigDecimal currentBilling = BigDecimal.ZERO;
		BigDecimal pastDue0Amt = BigDecimal.ZERO;
		BigDecimal pastDue30Amt = BigDecimal.ZERO;
		BigDecimal pastDue60Amt = BigDecimal.ZERO;
		BigDecimal pastDue90Amt = BigDecimal.ZERO;
		BigDecimal pastDue120Amt = BigDecimal.ZERO;
		BigDecimal PastDueAmt = BigDecimal.ZERO;
		BigDecimal totalDueAmt = BigDecimal.ZERO;
		BigDecimal dispute = BigDecimal.ZERO;
		BigDecimal qdso = BigDecimal.ZERO;

		for (int i = 0; i < responseList.size(); i++) {
			dataRow = segmentByCustomerSheet.createRow(i + 1);
		CellStyle styleCurrencyFormat = segmentByCustomerWorkBook.createCellStyle();
		styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(responseList.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(responseList.get(i).getSegment());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(responseList.get(i).getCustomer());
			cell3.setCellStyle(dataCellStyleBlack);

			currentBilling=responseList.get(i).getCurrentBillingAmount();
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell4.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);


			pastDue0Amt=responseList.get(i).getPastDue0Amount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO) > 0?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);


			pastDue30Amt=responseList.get(i).getPastDue30Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);


			pastDue60Amt=responseList.get(i).getPastDue60Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);


			pastDue90Amt=responseList.get(i).getPastDue90Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);


			pastDue120Amt=responseList.get(i).getPastDue120Amount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);


			PastDueAmt=responseList.get(i).getTotalPastDueAmount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(PastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(PastDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);


			totalDueAmt=responseList.get(i).getTotalAmount();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);


			dispute=responseList.get(i).getDispute();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(dispute.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);


			qdso=responseList.get(i).getDso();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(qdso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell13.setCellStyle(qdso.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);
			segmentByCustomerSheet.setColumnWidth(i,segmentByCustomerSheet.getColumnWidth(i)*23/10);
	        
			
		}
	}

	private void addHeaderContent(Sheet segmentByCustomerSheet, Workbook segmentByCustomerWorkBook) {
		Row row = segmentByCustomerSheet.createRow(0);
		CellStyle headerCellStyle = segmentByCustomerWorkBook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.SEGMENT);
		cell2.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.CUSTOMER);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.CURRENT_BALANCE);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.TOTAL_DUE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.DISPUTE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.DSO);
		cell13.setCellStyle(headerCellStyle);
		
		//Setting Auto Column Width
		segmentByCustomerSheet.autoSizeColumn(1);
		segmentByCustomerSheet.createFreezePane(1, 1);
	}

	//byRegion
	@Override
	public ByteArrayInputStream searchByRegion(UserDetails requestModel, Map<Object, Object> responseMap) {
		List<SegmentReportByRegionResponseModel> response = SegmentReportByRegionRepository.byRegion(
				requestModel.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
				requestModel.getExclusions(), 
				"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
				requestModel.getCustomerChidFlag()
				);
		try (Workbook segmentReportByCustomerSheetWorkbook = new XSSFWorkbook()) {
			Sheet segmentReportByCustomerDetailsSheet = segmentReportByCustomerSheetWorkbook
					.createSheet("segment Report By Segment Region");

			if (response != null) {

				addHeaderContentForPerRegion(segmentReportByCustomerDetailsSheet, segmentReportByCustomerSheetWorkbook);
				addActualContentForPerRegion(response, segmentReportByCustomerDetailsSheet, segmentReportByCustomerSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			segmentReportByCustomerSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void addHeaderContentForPerRegion(Sheet segmentByCustomerSheet, Workbook segmentByCustomerWorkBook) {
		Row row = segmentByCustomerSheet.createRow(0);
		CellStyle headerCellStyle = segmentByCustomerWorkBook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.SEGMENT);
		cell2.setCellStyle(headerCellStyle);
		
		Cell cell14 = row.createCell(1);
		cell14.setCellValue(ReportsConstant.REGION);
		cell14.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.CUSTOMER);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.CURRENT_BALANCE);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.TOTAL_DUE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.DISPUTE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.DSO);
		cell13.setCellStyle(headerCellStyle);
		
		//Setting Auto Column Width
		segmentByCustomerSheet.autoSizeColumn(1);
		segmentByCustomerSheet.createFreezePane(1, 1);
	}

	//byRegion
	private void addActualContentForPerRegion(List<SegmentReportByRegionResponseModel> responseList,
			Sheet segmentByCustomerSheet, Workbook segmentByCustomerWorkBook) {

		CellStyle dataCellStyleBlack = segmentByCustomerWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = segmentByCustomerWorkBook.createCellStyle();
		Font BlackColorFont = segmentByCustomerWorkBook.createFont();
		BlackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        dataCellStyleBlack.setFont(BlackColorFont);
        
        Font REDColorFont = segmentByCustomerWorkBook.createFont();
        REDColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(REDColorFont);
        
		Row dataRow ;

		BigDecimal currentBilling = BigDecimal.ZERO;
		BigDecimal pastDue0Amt = BigDecimal.ZERO;
		BigDecimal pastDue30Amt = BigDecimal.ZERO;
		BigDecimal pastDue60Amt = BigDecimal.ZERO;
		BigDecimal pastDue90Amt = BigDecimal.ZERO;
		BigDecimal pastDue120Amt = BigDecimal.ZERO;
		BigDecimal PastDueAmt = BigDecimal.ZERO;
		BigDecimal totalDueAmt = BigDecimal.ZERO;
		BigDecimal dispute = BigDecimal.ZERO;
		BigDecimal qdso = BigDecimal.ZERO;

		for (int i = 0; i < responseList.size(); i++) {
			dataRow = segmentByCustomerSheet.createRow(i + 1);
		CellStyle styleCurrencyFormat = segmentByCustomerWorkBook.createCellStyle();
		styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(responseList.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(responseList.get(i).getSegment());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell14 = dataRow.createCell(1);
			cell14.setCellValue(responseList.get(i).getRegion());
			cell14.setCellStyle(dataCellStyleBlack);
			
			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(responseList.get(i).getCustomer());
			cell3.setCellStyle(dataCellStyleBlack);

			currentBilling=responseList.get(i).getCurrentBillingAmount();
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell4.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);


			pastDue0Amt=responseList.get(i).getPastDue0Amount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);


			pastDue30Amt=responseList.get(i).getPastDue30Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);


			pastDue60Amt=responseList.get(i).getPastDue60Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);


			pastDue90Amt=responseList.get(i).getPastDue90Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);


			pastDue120Amt=responseList.get(i).getPastDue120Amount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);


			PastDueAmt=responseList.get(i).getTotalPastDueAmount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(PastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(PastDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);


			totalDueAmt=responseList.get(i).getTotalAmount();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);


			dispute=responseList.get(i).getDispute();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(dispute.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);


			qdso=responseList.get(i).getDso();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(qdso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell13.setCellStyle(qdso.compareTo(BigDecimal.ZERO)>0?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);
		
			segmentByCustomerSheet.setColumnWidth(i,segmentByCustomerSheet.getColumnWidth(i)*23/10);
		}
	}	
}
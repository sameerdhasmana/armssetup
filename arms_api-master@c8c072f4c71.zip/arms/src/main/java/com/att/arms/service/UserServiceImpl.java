package com.att.arms.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.GlobalLogonUsers;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	@Override
	public boolean validateUser(UserDetails userDetails) {
		boolean response=false;
		if (StringUtils.isNotEmpty(userDetails.getUserLoginCd()) && StringUtils.isNotEmpty(userDetails.getAppName())
				&& StringUtils.isNotEmpty(userDetails.getEnvironment())
				&& StringUtils.isNotEmpty(userDetails.getUserPcName())
				&& StringUtils.isNotEmpty(userDetails.getUserPcLoginId())
				&& StringUtils.isNotEmpty(userDetails.getUserPcIp())) {
			response=true;
		}
		return response;
	}

	@Override
	public GlobalLogonUsers findUserDetails(String userLoginCd, String appname, String environment, String userPcName,
			String userPcLoginId, String userPcIP, Integer globalLogonResponseCd) {
		return this.userRepository.findUserDetails(userLoginCd, appname, environment, userPcName, userPcLoginId,
				userPcIP, globalLogonResponseCd);
	}
	
	@Override
	public boolean checkSessionTiming(String userLoginCd) {
		boolean sessionValid=true;
		String response=userRepository.checkSessionTiming(ApplicationConstant.ARMS_APP_NAME,userLoginCd);
		if(StringUtils.isNotEmpty(response) && response.equals("0")) {
			sessionValid=false;
		}
		return sessionValid;
	}

}

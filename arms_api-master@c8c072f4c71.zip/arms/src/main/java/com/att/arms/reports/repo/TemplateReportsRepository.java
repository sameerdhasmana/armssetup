package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.reports.entity.MaintainanceReportAllCustomerQDSODetails;
import com.att.arms.reports.entity.TemplateReportsEntity;


@Transactional
public interface TemplateReportsRepository extends JpaRepository<TemplateReportsEntity, String>{
	
	@Query(value = "exec arms_template_reports_v20 '202201','',1,0,"
			+ "'v_bias_cabs_combo_v20.acct_nbr AS ''v_bias_cabs_combo_v20.acct_nbr'',"
			+ "v_bias_cabs_combo_v20.originating_system AS ''v_bias_cabs_combo_v20.originating_system'',"
			+ "v_bias_cabs_combo_v20.past_due_pmt_trm AS ''v_bias_cabs_combo_v20.past_due_pmt_trm'',"
			+ "SUM(ISNULL(v_bias_cabs_combo_v20.total_amt, 0)) AS ''v_bias_cabs_combo_v20.total_amt'',"
			+ "SUM(ISNULL(v_bias_cabs_combo_v20.past_due_amt, 0)) AS ''v_bias_cabs_combo_v20.past_due_amt'',"
			+ "SUM(ISNULL(v_bias_cabs_combo_v20.plus_60_amt, 0)) AS ''v_bias_cabs_combo_v20.plus_60_amt'',"
			+ "v_bias_cabs_combo_v20.collectable_pd AS ''v_bias_cabs_combo_v20.collectable_pd'',"
			+ "v_bias_cabs_combo_v20.collectable AS ''v_bias_cabs_combo_v20.collectable'',"
			+ "SUM(ISNULL(TXT131_CLAIM_ACCT_SUM.CLAIMED_AMT, 0)) AS ''TXT131_CLAIM_ACCT_SUM.CLAIMED_AMT''',"
			+ "'v_bias_cabs_combo_v20 INNER JOIN customer_xref3 (nolock) ON v_bias_cabs_combo_v20.acct_nbr = customer_xref3.acct_nbr "
			+ "AND v_bias_cabs_combo_v20.originating_system = customer_xref3.originating_system  LEFT OUTER JOIN txt131_claim_acct_sum (nolock) "
			+ "ON v_bias_cabs_combo_v20.acct_nbr = txt131_claim_acct_sum.account_id "
			+ "AND v_bias_cabs_combo_v20.originating_system  = txt131_claim_acct_sum.originating_system ',"
			+ "'v_bias_cabs_combo_v20.past_due_pmt_trm > ''500''  AND v_bias_cabs_combo_v20.total_amt > 1200  "
			+ "AND  v_bias_cabs_combo_v20.billing_period = ''202201'' "
			+ "AND v_bias_cabs_combo_v20.originating_system IN  (''CABS'',''CRIS'' ) "
			+ "AND (customer_xref3.exclude_flg = 0 OR (customer_xref3.exclude_flg <> 0 "
			+ "AND CAST(customer_xref3.billing_period_exclude_start AS INT) > 202201)) "
			+ "AND  v_bias_cabs_combo_v20.bus_unit_cd  = ''LSC''   "
			+ "AND  v_bias_cabs_combo_v20.originating_company_cd  = ''BLS''   "
			+ "AND  v_bias_cabs_combo_v20.status_cd  IN(''LIVE'', ''FINAL'')   "
			+ "AND  customer_xref3.customer_grp_cd IN(''A000415'')  "
			+ "AND customer_xref3.customer_grp_cd IS NOT NULL ',"
			+ "'v_bias_cabs_combo_v20.acct_nbr,v_bias_cabs_combo_v20.originating_system,"
			+ "v_bias_cabs_combo_v20.past_due_pmt_trm,v_bias_cabs_combo_v20.collectable_pd,"
			+ "v_bias_cabs_combo_v20.collectable','v_bias_cabs_combo_v20.collectable_pd','0'", nativeQuery = true)
	public List<TemplateReportsEntity> findTemplateReportsList(@Param("billingPeriod") String billingPeriod);
	
	/*@Query(value = "exec arms_template_reports_v20 :billingPeriod,'',1,0,"
			+ "'v_bias_cabs_combo_v20.acct_nbr AS ''v_bias_cabs_combo_v20.acct_nbr'',"
			+ "v_bias_cabs_combo_v20.originating_system AS ''v_bias_cabs_combo_v20.originating_system'',"
			+ "v_bias_cabs_combo_v20.past_due_pmt_trm AS ''v_bias_cabs_combo_v20.past_due_pmt_trm'',"
			+ "SUM(ISNULL(v_bias_cabs_combo_v20.total_amt, 0)) AS ''v_bias_cabs_combo_v20.total_amt'',"
			+ "SUM(ISNULL(v_bias_cabs_combo_v20.past_due_amt, 0)) AS ''v_bias_cabs_combo_v20.past_due_amt'',"
			+ "SUM(ISNULL(v_bias_cabs_combo_v20.plus_60_amt, 0)) AS ''v_bias_cabs_combo_v20.plus_60_amt'',"
			+ "v_bias_cabs_combo_v20.collectable_pd AS ''v_bias_cabs_combo_v20.collectable_pd'',"
			+ "v_bias_cabs_combo_v20.collectable AS ''v_bias_cabs_combo_v20.collectable'',"
			+ "SUM(ISNULL(TXT131_CLAIM_ACCT_SUM.CLAIMED_AMT, 0)) AS ''TXT131_CLAIM_ACCT_SUM.CLAIMED_AMT''',"
			+ "'v_bias_cabs_combo_v20 INNER JOIN customer_xref3 (nolock) ON v_bias_cabs_combo_v20.acct_nbr = customer_xref3.acct_nbr "
			+ "AND v_bias_cabs_combo_v20.originating_system = customer_xref3.originating_system  LEFT OUTER JOIN txt131_claim_acct_sum (nolock) "
			+ "ON v_bias_cabs_combo_v20.acct_nbr = txt131_claim_acct_sum.account_id "
			+ "AND v_bias_cabs_combo_v20.originating_system  = txt131_claim_acct_sum.originating_system ',"
			+ "'v_bias_cabs_combo_v20.past_due_pmt_trm > ''500''  AND v_bias_cabs_combo_v20.total_amt > 1200  "
			+ "AND  v_bias_cabs_combo_v20.billing_period = ''202201'' "
			+ "AND v_bias_cabs_combo_v20.originating_system IN  (''CABS'',''CRIS'' ) "
			+ "AND (customer_xref3.exclude_flg = 0 OR (customer_xref3.exclude_flg <> 0 "
			+ "AND CAST(customer_xref3.billing_period_exclude_start AS INT) > 202201)) "
			+ "AND  v_bias_cabs_combo_v20.bus_unit_cd  = ''LSC''   "
			+ "AND  v_bias_cabs_combo_v20.originating_company_cd  = ''BLS''   "
			+ "AND  v_bias_cabs_combo_v20.status_cd  IN(''LIVE'', ''FINAL'')   "
			+ "AND  customer_xref3.customer_grp_cd IN(''A000415'')  "
			+ "AND customer_xref3.customer_grp_cd IS NOT NULL ',"
			+ "'v_bias_cabs_combo_v20.acct_nbr,v_bias_cabs_combo_v20.originating_system,"
			+ "v_bias_cabs_combo_v20.past_due_pmt_trm,v_bias_cabs_combo_v20.collectable_pd,"
			+ "v_bias_cabs_combo_v20.collectable','v_bias_cabs_combo_v20.collectable_pd','0'", nativeQuery = true)
	public List<Object[]> findTemplateReportsList(@Param("billingPeriod") String billingPeriod);*/
	
}
	
	
	
	


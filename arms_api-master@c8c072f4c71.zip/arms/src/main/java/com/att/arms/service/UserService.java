package com.att.arms.service;

import com.att.arms.entity.GlobalLogonUsers;
import com.att.arms.entity.UserDetails;

public interface UserService {

	boolean validateUser(UserDetails userDetails);

	public GlobalLogonUsers findUserDetails(String userLoginCd, String appname, String environment, String userPcName,
			String userPcLoginId, String userPcIP, Integer globalLogonResponseCd);

	boolean checkSessionTiming(String userLoginCd);

}

package com.att.arms.reports.service;

import com.att.arms.entity.UserDetails;

import java.io.ByteArrayInputStream;
import java.util.Map;

public interface SegmentExcelReportService {

	ByteArrayInputStream searchByCustomer(UserDetails requestModel,  Map<Object, Object> responseMap);
	
	ByteArrayInputStream searchByRegion(UserDetails requestModel,  Map<Object, Object> responseMap);
	
}

package com.att.arms.entity;

import lombok.Data;
@Data
public class GridHeaders {

	private Boolean pinned;
	private String headerName;
	private Integer sortIndex;
	private String aggFunc;
	private Boolean sortable;
	private String sort;
	private Integer pivotIndex;
	private Boolean rowGroup;
	private Boolean filter;
	private Boolean hide;
	private String field;
	private Integer rowGroupIndex;
	private Integer flex;
	private Integer width;
	private Boolean pivot;
	private String colId;
	private Boolean resizable;
	private Boolean checkboxSelection;
	private String tooltipField;
	private String headerClass;
	private String cellClass;
	private String type;
	
}

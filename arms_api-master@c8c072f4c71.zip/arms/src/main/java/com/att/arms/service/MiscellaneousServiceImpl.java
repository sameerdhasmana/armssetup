package com.att.arms.service;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.AccountBringupHeaderFooterPageEvent;
import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.CPPOHeaderFooterPageEvent;
import com.att.arms.config.CustCopyHeaderFooterPageEvent;
import com.att.arms.config.CustomerBringupHeaderFooterPageEvent;
import com.att.arms.config.MyCustomerHeaderFooterPageEvent;
import com.att.arms.config.PermNotesHeaderFooterPageEvent;
import com.att.arms.config.RepCopyHeaderFooterPageEvent;
import com.att.arms.entity.AccountPermNotesReport;
import com.att.arms.entity.AccountsBringUpDetails;
import com.att.arms.entity.CPPODetails;
import com.att.arms.entity.CustomerBringUpDetails;
import com.att.arms.entity.CustomerCopy;
import com.att.arms.entity.CustomerPermNotesReport;
import com.att.arms.entity.MyCustomerDetails;
import com.att.arms.entity.RepCopy;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.AccountPermNotesReportRepository;
import com.att.arms.repo.AccountsBringUpDetailsRepository;
import com.att.arms.repo.CPPORepository;
import com.att.arms.repo.CustomerBringUpDetailsRepository;
import com.att.arms.repo.CustomerCopyRepository;
import com.att.arms.repo.CustomerPermNotesReportRepository;
import com.att.arms.repo.MyCustomerDetailsRepository;
import com.att.arms.repo.RepCopyRepository;
import com.att.arms.utils.CommonUtils;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class MiscellaneousServiceImpl implements MiscellaneousService {

	private static final Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.BOLD);
	private static final DecimalFormat df = new DecimalFormat("0.00");
	private static final String CURRENT_BILLING_TOTAL_BY_SYSTEM = "currentBillingTotalBySystem";
	private static final String PAST_DUE_TOTAL_BY_SYSTEM = "pastDueTotalBySystem";
	private static final String TOTAL_DUE_AMT_BY_SYSTEM = "totalDueAmtBySystem";
	private static final String DISPUTE_TOTAL_BY_SYSTEM = "disputeTotalBySystem";
	private static final String CURRENT_BALANCE_TOTAL_BY_SYSTEM = "currentBalanceTotalBySystem";
	private static final String PAST_DUE_30_TOTAL_BY_SYSTEM = "pastDue30TotalBySystem";
	private static final String PAST_DUE_60_TOTAL_BY_SYSTEM = "pastDue60TotalBySystem";
	private static final String PAST_DUE_90_TOTAL_BY_SYSTEM = "pastDue90TotalBySystem";
	private static final String PAST_DUE_120_TOTAL_BY_SYSTEM = "pastDue120TotalBySystem";
	private static final String PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM = "promotionalBalanceTotalBySystem";
	private static final String CURRENT_BILLING_TOTAL_BY_SUBGROUP = "currentBillingTotalBySubGroup";
	private static final String TOTAL_DUE_AMT_BY_SUBGROUP = "totalDueAmtBySubGroup";
	private static final String DISPUTE_TOTAL_BY_SUBGROUP = "disputeTotalBySubGroup";
	private static final String CURRENT_BALANCE_TOTAL_BY_SUBGROUP = "currentBalanceTotalBySubGroup";
	private static final String PAST_DUE_TOTAL_BY_SUBGROUP = "pastDueTotalBySubGroup";
	private static final String PAST_DUE_30_TOTAL_BY_SUBGROUP = "pastDue30TotalBySubGroup";
	private static final String PAST_DUE_60_TOTAL_BY_SUBGROUP = "pastDue60TotalBySubGroup";
	private static final String PAST_DUE_90_TOTAL_BY_SUBGROUP = "pastDue90TotalBySubGroup";
	private static final String PAST_DUE_120_TOTAL_BY_SUBGROUP = "pastDue120TotalBySubGroup";
	private static final String PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP = "promotionalBalanceTotalBySubGroup";
	private static final String ROLLING_TOTAL_BY_STATE = "rollingTotalByState";
	private static final String CURRENT_BILLING_TOTAL = "currentBillingTotal";
	private static final String CURRENT_BALANCE_TOTAL = "currentBalanceTotal";
	private static final String PAST_DUE_TOTAL = "pastDueTotal";
	private static final String PAST_DUE_30_TOTAL = "pastDue30Total";
	private static final String PAST_DUE_60_TOTAL = "pastDue60Total";
	private static final String PAST_DUE_90_TOTAL = "pastDue90Total";
	private static final String PAST_DUE_120_TOTAL = "pastDue120Total";
	private static final String PROMOTIONAL_BALANCE_TOTAL = "promotionalBalanceTotal";
	private static final String TOTAL_DUE_AMT = "totalDueAmt";
	private static final String DISPUTE_TOTAL = "disputeTotal";
	private static final String ACCOUNT_PERM_NOTE_REPORT = "AccountPermNoteReport_";
	private static final String CPPO_REPORT = "CPPOReports_";
	private static final String REP_COPY_REPORT = "RepCopyReports_";
	private static final String PERM_NOTE_REPORT = "PermNoteReport_";
	private static final String CUSTOMER_COPY_REPORT = "CustCopyReport_";
	private static final String MY_CUSTOMER_REPORT = "MyCustomerReport_";
	private static final String CUSTOMER_BRINGUP_REPORT = "CustomerBringupReport_";
	private static final String ACCOUNT_BRINGUP_REPORT = "AccountBringupReport_";
	private static final String TOTAL_FOR = "Total for ";
	private static final String STATE = "State:";
	@Autowired
	CPPORepository cPPORepository;
	@Autowired
	CustomerPermNotesReportRepository customerPermNotesReportRepository;
	@Autowired
	AccountPermNotesReportRepository accountPermNotesReportRepository;
	@Autowired
	private RepCopyRepository repCopyRepository;
	@Autowired
	private CustomerCopyRepository customerCopyRepository;
	@Autowired
	MyCustomerDetailsRepository myCustomerDetailsRepository;
	@Autowired
	CustomerBringUpDetailsRepository customerBringUpDetailsRepository;
	@Autowired
	AccountsBringUpDetailsRepository accountsBringUpDetailsRepository;

	@Override
	public List<CPPODetails> getCPPOReport(UserDetails userDetails, Map<Object, Object> responseMap) {

		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String acnaSubType = "";
		String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		String exclusionClass = "";
		String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		String acnaCriteriaType = "";
		String acnaValue = userDetails.getAcnaValue();
		String ctcValue = userDetails.getCtcValue();
		String billName = userDetails.getBillName();
		Integer rollUp = userDetails.getRollUp() != null ? userDetails.getRollUp() : 0;
		Integer exclusion = 0;

		switch (userDetails.getExclusions()) {
		case ApplicationConstant.INCLUDED_ACCOUNTS:
			exclusion = 1;
			break;

		case ApplicationConstant.EXCLUDED_ACCOUNTS:
			exclusion = 0;
			break;

		default:
			exclusion = 2;
			break;
		}
		if (!userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}
		if (userDetails.getTabType() != null) {
			switch (userDetails.getTabType()) {
			case 2:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.ACNA_SUB_TYPE;
				break;
			case 3:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.AECN_SUB_TYPE;
				break;
			case 4:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.OCN_SUB_TYPE;
				break;
			case 5:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_CTC;
				acnaSubType = ApplicationConstant.CTC_SUB_TYPE;
				break;
			default:
				break;

			}
		}

		return cPPORepository.getCPPODetails(userDetails.getCustomerGrpCd(), selectedGroups,
				userDetails.getBillingPeriod(), statusClause, userDetails.getExclusiveAccess(), exclusion,
				exclusionClass, billName, userDetails.getStateFilter(), segment, acnaCriteriaType, acnaSubType,
				acnaValue, ctcValue, rollUp);
	}

	@Override
	public boolean validateCPPOReportQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getExclusions())
				&& StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public ByteArrayInputStream generateCPPOReport(UserDetails userDetails, Map<Object, Object> responseMap) {
		List<CPPODetails> cppoDetails = null;
		Document document = new Document(PageSize.A4, 36, 36, 200, 100);
		Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
		try (FileOutputStream out = new FileOutputStream(CPPO_REPORT + userDetails.getUserLoginCd() + ".pdf")) {

			PdfWriter writer = PdfWriter.getInstance(document, out);
			document.setPageSize(rectangle);
			CPPOHeaderFooterPageEvent event = new CPPOHeaderFooterPageEvent();
			String grpSelected = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
			event.setHeader(userDetails.getBillingPeriod(), "('" + grpSelected + "')", userDetails.getCustomerName());

			writer.setPageEvent(event);
			document.open();

			cppoDetails = getCPPOReport(userDetails, responseMap);
			if (!CollectionUtils.isEmpty(cppoDetails)) {

				addActualContent(cppoDetails, document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				document.add(Chunk.NEWLINE);
				responseMap.remove("msg");
			}

			document.close();
			writer.close();

			Path path = Paths.get(CPPO_REPORT + userDetails.getUserLoginCd() + ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(CPPO_REPORT + userDetails.getUserLoginCd() + ".pdf");
		}
		return null;
	}

	private void addActualContent(List<CPPODetails> cppoDetailsList, Document document) throws DocumentException {

		Map<String, Map<String, List<CPPODetails>>> cppoDetailsBySystemAndStateMap = cppoDetailsList.stream()
				.sorted((c1, c2) -> c1.getOriginatingSystem().compareTo(c2.getOriginatingSystem())).collect(Collectors
						.groupingBy(CPPODetails::getOriginatingSystem, Collectors.groupingBy(CPPODetails::getStateCd)));
		HashMap<String, Double> summationMap = new HashMap<>();
		double currentBillingTotal = 0;
		double pastDueTotal = 0;
		double totalDueAmt = 0;
		double disputeTotal = 0;

		cppoDetailsBySystemAndStateMap.forEach((system, cppoDetailsBySystemMap) -> {
			TreeMap<String, List<CPPODetails>> sorted = new TreeMap<>();
			sorted.putAll(cppoDetailsBySystemMap);
			Paragraph sys = new Paragraph(system, boldFont);
			sys.setAlignment(Element.ALIGN_JUSTIFIED);

			try {
				document.add(sys);

				double currentBillingTotalBySystem = 0;
				if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SYSTEM)
						&& summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM) != null) {
					currentBillingTotalBySystem = currentBillingTotalBySystem
							+ summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM);
				}
				double pastDueTotalBySystem = 0;
				if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SYSTEM)
						&& summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM) != null) {
					pastDueTotalBySystem = pastDueTotalBySystem + summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM);
				}
				double totalDueAmtBySystem = 0;
				if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SYSTEM)
						&& summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM) != null) {
					totalDueAmtBySystem = totalDueAmtBySystem + summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM);
				}
				double disputeTotalBySystem = 0;
				if (summationMap.containsKey(DISPUTE_TOTAL_BY_SYSTEM)
						&& summationMap.get(DISPUTE_TOTAL_BY_SYSTEM) != null) {
					disputeTotalBySystem = disputeTotalBySystem + summationMap.get(DISPUTE_TOTAL_BY_SYSTEM);
				}

				sorted.forEach((stateCd, cppoDetailsByStateCdList) -> {
					Paragraph state = new Paragraph(stateCd, boldFont);
					state.setAlignment(Element.ALIGN_JUSTIFIED);

					try {
						document.add(state);

						double currentBillingTotalByState = 0;
						double pastDueTotalByState = 0;
						double totalDueAmtByState = 0;
						double disputeTotalByState = 0;
						double rollingTotalByState = 0;
						if (summationMap.containsKey(ROLLING_TOTAL_BY_STATE)
								&& summationMap.get(ROLLING_TOTAL_BY_STATE) != null) {
							rollingTotalByState = rollingTotalByState + summationMap.get(ROLLING_TOTAL_BY_STATE);
						}

						for (CPPODetails cppoDetail : cppoDetailsByStateCdList) {
							PdfPTable table = new PdfPTable(8);

							float[] columnWidths = { 5f, 5f, 5f, 5f, 5f, 5f, 5f, 5f };

							table.setWidths(columnWidths);
							table.setWidthPercentage(96);

							PdfPCell cell3 = new PdfPCell(new Paragraph(cppoDetail.getSegmentCd()));
							cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell3.setBorder(Rectangle.NO_BORDER);

							PdfPCell cell4 = new PdfPCell(new Paragraph(cppoDetail.getAccountNumber()));
							cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell4.setBorder(Rectangle.NO_BORDER);

							PdfPCell cell5 = new PdfPCell(new Paragraph(cppoDetail.getStatusCd()));
							cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell5.setBorder(Rectangle.NO_BORDER);

							PdfPCell cell6 = new PdfPCell(new Paragraph("" + cppoDetail.getCurrentBillingAmt()));
							cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell6.setBorder(Rectangle.NO_BORDER);

							PdfPCell cell7 = new PdfPCell(new Paragraph("" + cppoDetail.getPastDueAmt()));
							cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell7.setBorder(Rectangle.NO_BORDER);

							PdfPCell cell8 = new PdfPCell(new Paragraph("" + cppoDetail.getDisputeAmt()));
							cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell8.setBorder(Rectangle.NO_BORDER);

							PdfPCell cell9 = new PdfPCell(new Paragraph("" + cppoDetail.getTotalAmt()));
							cell9.disableBorderSide(0);
							cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell9.setBorder(Rectangle.NO_BORDER);

							rollingTotalByState = rollingTotalByState + cppoDetail.getTotalAmt();

							PdfPCell cell10 = new PdfPCell(new Paragraph("" + df.format(rollingTotalByState)));
							cell10.disableBorderSide(0);
							cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell10.setBorder(Rectangle.NO_BORDER);

							table.addCell(cell3);
							table.addCell(cell4);
							table.addCell(cell5);
							table.addCell(cell6);
							table.addCell(cell7);
							table.addCell(cell8);
							table.addCell(cell9);
							table.addCell(cell10);

							document.add(table);

							currentBillingTotalByState = currentBillingTotalByState + cppoDetail.getCurrentBillingAmt();
							pastDueTotalByState = pastDueTotalByState + cppoDetail.getPastDueAmt();
							totalDueAmtByState = totalDueAmtByState + cppoDetail.getTotalAmt();
							disputeTotalByState = disputeTotalByState + cppoDetail.getDisputeAmt();

						}
						summationMap.put(ROLLING_TOTAL_BY_STATE, rollingTotalByState);

						PdfPTable totalTable = new PdfPTable(6);

						float[] columnWidths2 = { 15f, 5f, 5f, 5f, 5f, 5f };

						totalTable.setWidths(columnWidths2);
						totalTable.setWidthPercentage(96);

						PdfPCell totalStateCell3 = new PdfPCell(new Paragraph(stateCd, boldFont));
						totalStateCell3.setBorderColor(BaseColor.DARK_GRAY);
						totalStateCell3.setBorder(Rectangle.TOP);
						totalStateCell3.setHorizontalAlignment(Element.ALIGN_CENTER);
						totalStateCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

						PdfPCell totalStateCell4 = new PdfPCell(
								new Paragraph("" + df.format(currentBillingTotalByState)));
						totalStateCell4.setBorderColor(BaseColor.DARK_GRAY);
						totalStateCell4.setBorder(Rectangle.TOP);
						totalStateCell4.setHorizontalAlignment(Element.ALIGN_CENTER);
						totalStateCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

						PdfPCell totalStateCell5 = new PdfPCell(new Paragraph("" + df.format(pastDueTotalByState)));
						totalStateCell5.setBorderColor(BaseColor.DARK_GRAY);
						totalStateCell5.setBorder(Rectangle.TOP);
						totalStateCell5.setHorizontalAlignment(Element.ALIGN_CENTER);
						totalStateCell5.setVerticalAlignment(Element.ALIGN_MIDDLE);

						PdfPCell totalStateCell6 = new PdfPCell(new Paragraph("" + df.format(disputeTotalByState)));
						totalStateCell6.setBorder(Rectangle.TOP);
						totalStateCell6.setBorderColor(BaseColor.DARK_GRAY);
						totalStateCell6.setHorizontalAlignment(Element.ALIGN_CENTER);
						totalStateCell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

						PdfPCell totalStateCell7 = new PdfPCell(new Paragraph("" + df.format(totalDueAmtByState)));
						totalStateCell7.setBorder(Rectangle.TOP);
						totalStateCell7.setBorderColor(BaseColor.DARK_GRAY);
						totalStateCell7.setHorizontalAlignment(Element.ALIGN_CENTER);
						totalStateCell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

						PdfPCell totalStateCell8 = new PdfPCell(new Paragraph(""));
						totalStateCell8.setBorderColor(BaseColor.DARK_GRAY);
						totalStateCell8.setBorder(Rectangle.TOP);
						totalStateCell8.disableBorderSide(Rectangle.RIGHT);
						totalStateCell8.disableBorderSide(Rectangle.BOTTOM);

						totalTable.addCell(totalStateCell3);
						totalTable.addCell(totalStateCell4);
						totalTable.addCell(totalStateCell5);
						totalTable.addCell(totalStateCell6);
						totalTable.addCell(totalStateCell7);
						totalTable.addCell(totalStateCell8);
						if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SYSTEM)) {
							summationMap.put(CURRENT_BILLING_TOTAL_BY_SYSTEM,
									summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM) + currentBillingTotalByState);
						} else {
							summationMap.put(CURRENT_BILLING_TOTAL_BY_SYSTEM, currentBillingTotalByState);
						}

						if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SYSTEM)) {
							summationMap.put(PAST_DUE_TOTAL_BY_SYSTEM,
									summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM) + pastDueTotalByState);
						} else {
							summationMap.put(PAST_DUE_TOTAL_BY_SYSTEM, pastDueTotalByState);
						}

						if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SYSTEM)) {
							summationMap.put(TOTAL_DUE_AMT_BY_SYSTEM,
									summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM) + totalDueAmtByState);
						} else {
							summationMap.put(TOTAL_DUE_AMT_BY_SYSTEM, totalDueAmtByState);
						}

						if (summationMap.containsKey(DISPUTE_TOTAL_BY_SYSTEM)) {
							summationMap.put(DISPUTE_TOTAL_BY_SYSTEM,
									summationMap.get(DISPUTE_TOTAL_BY_SYSTEM) + disputeTotalByState);
						} else {
							summationMap.put(DISPUTE_TOTAL_BY_SYSTEM, disputeTotalByState);
						}

						document.add(totalTable);
						document.add(Chunk.NEWLINE);
					} catch (DocumentException e) {
						e.printStackTrace();
					}

				});

				PdfPTable totalTable = new PdfPTable(6);

				float[] columnWidths2 = { 15f, 5f, 5f, 5f, 5f, 5f };

				totalTable.setWidths(columnWidths2);
				totalTable.setWidthPercentage(96);

				if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SYSTEM)) {
					currentBillingTotalBySystem = summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM);
					summationMap.remove(CURRENT_BILLING_TOTAL_BY_SYSTEM);
				}

				if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SYSTEM)) {
					pastDueTotalBySystem = summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM);
					summationMap.remove(PAST_DUE_TOTAL_BY_SYSTEM);
				}

				if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SYSTEM)) {
					totalDueAmtBySystem = summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM);
					summationMap.remove(TOTAL_DUE_AMT_BY_SYSTEM);
				}

				if (summationMap.containsKey(DISPUTE_TOTAL_BY_SYSTEM)) {
					disputeTotalBySystem = summationMap.get(DISPUTE_TOTAL_BY_SYSTEM);
					summationMap.remove(DISPUTE_TOTAL_BY_SYSTEM);
				}

				PdfPCell totalSystemCell3 = new PdfPCell(new Paragraph(system, boldFont));
				totalSystemCell3.setBorderColor(BaseColor.DARK_GRAY);
				totalSystemCell3.setBorder(Rectangle.TOP);
				totalSystemCell3.setHorizontalAlignment(Element.ALIGN_CENTER);
				totalSystemCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalSystemCell4 = new PdfPCell(new Paragraph("" + df.format(currentBillingTotalBySystem)));
				totalSystemCell4.setBorderColor(BaseColor.DARK_GRAY);
				totalSystemCell4.setBorder(Rectangle.TOP);
				totalSystemCell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				totalSystemCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalSystemCell5 = new PdfPCell(new Paragraph("" + df.format(pastDueTotalBySystem)));
				totalSystemCell5.setBorderColor(BaseColor.DARK_GRAY);
				totalSystemCell5.setBorder(Rectangle.TOP);
				totalSystemCell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				totalSystemCell5.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalSystemCell6 = new PdfPCell(new Paragraph("" + df.format(disputeTotalBySystem)));
				totalSystemCell6.setBorderColor(BaseColor.DARK_GRAY);
				totalSystemCell6.setBorder(Rectangle.TOP);
				totalSystemCell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				totalSystemCell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalSystemCell7 = new PdfPCell(new Paragraph("" + df.format(totalDueAmtBySystem)));
				totalSystemCell7.setBorderColor(BaseColor.DARK_GRAY);
				totalSystemCell7.setBorder(Rectangle.TOP);
				totalSystemCell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				totalSystemCell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalSystemCell8 = new PdfPCell(new Paragraph(""));
				totalSystemCell8.setBorderColor(BaseColor.DARK_GRAY);
				totalSystemCell8.setBorder(Rectangle.TOP);
				totalSystemCell8.disableBorderSide(Rectangle.RIGHT);
				totalSystemCell8.disableBorderSide(Rectangle.BOTTOM);

				totalTable.addCell(totalSystemCell3);
				totalTable.addCell(totalSystemCell4);
				totalTable.addCell(totalSystemCell5);
				totalTable.addCell(totalSystemCell6);
				totalTable.addCell(totalSystemCell7);
				totalTable.addCell(totalSystemCell8);

				if (summationMap.containsKey(CURRENT_BILLING_TOTAL)) {
					summationMap.put(CURRENT_BILLING_TOTAL,
							summationMap.get(CURRENT_BILLING_TOTAL) + currentBillingTotalBySystem);
				} else {
					summationMap.put(CURRENT_BILLING_TOTAL, currentBillingTotalBySystem);
				}

				if (summationMap.containsKey(PAST_DUE_TOTAL)) {
					summationMap.put(PAST_DUE_TOTAL, summationMap.get(PAST_DUE_TOTAL) + pastDueTotalBySystem);
				} else {
					summationMap.put(PAST_DUE_TOTAL, pastDueTotalBySystem);
				}

				if (summationMap.containsKey(TOTAL_DUE_AMT)) {
					summationMap.put(TOTAL_DUE_AMT, summationMap.get(TOTAL_DUE_AMT) + totalDueAmtBySystem);
				} else {
					summationMap.put(TOTAL_DUE_AMT, totalDueAmtBySystem);
				}

				if (summationMap.containsKey(DISPUTE_TOTAL)) {
					summationMap.put(DISPUTE_TOTAL, summationMap.get(DISPUTE_TOTAL) + disputeTotalBySystem);
				} else {
					summationMap.put(DISPUTE_TOTAL, disputeTotalBySystem);
				}

				document.add(totalTable);
				document.add(Chunk.NEWLINE);
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
		});
		PdfPTable totalTable = new PdfPTable(6);

		float[] columnWidths2 = { 15f, 5f, 5f, 5f, 5f, 5f };

		totalTable.setWidths(columnWidths2);
		totalTable.setWidthPercentage(96);

		if (summationMap.containsKey(CURRENT_BILLING_TOTAL)) {
			currentBillingTotal = summationMap.get(CURRENT_BILLING_TOTAL);
			summationMap.remove(CURRENT_BILLING_TOTAL);
		}

		if (summationMap.containsKey(PAST_DUE_TOTAL)) {
			pastDueTotal = summationMap.get(PAST_DUE_TOTAL);
			summationMap.remove(PAST_DUE_TOTAL);
		}

		if (summationMap.containsKey(TOTAL_DUE_AMT)) {
			totalDueAmt = summationMap.get(TOTAL_DUE_AMT);
			summationMap.remove(TOTAL_DUE_AMT);
		}

		if (summationMap.containsKey(DISPUTE_TOTAL)) {
			disputeTotal = summationMap.get(DISPUTE_TOTAL);
			summationMap.remove(DISPUTE_TOTAL);
		}

		PdfPCell totalSystemCell3 = new PdfPCell(new Paragraph("Report Total", boldFont));
		totalSystemCell3.setBorderColor(BaseColor.DARK_GRAY);
		totalSystemCell3.setBorder(Rectangle.NO_BORDER);
		totalSystemCell3.enableBorderSide(Rectangle.TOP);
		totalSystemCell3.enableBorderSide(Rectangle.BOTTOM);
		totalSystemCell3.setHorizontalAlignment(Element.ALIGN_CENTER);
		totalSystemCell3.setPadding(10f);
		totalSystemCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalSystemCell4 = new PdfPCell(new Paragraph("" + df.format(currentBillingTotal)));
		totalSystemCell4.setBorderColor(BaseColor.DARK_GRAY);
		totalSystemCell4.setBorder(Rectangle.NO_BORDER);
		totalSystemCell4.enableBorderSide(Rectangle.TOP);
		totalSystemCell4.enableBorderSide(Rectangle.BOTTOM);
		totalSystemCell4.setHorizontalAlignment(Element.ALIGN_CENTER);
		totalSystemCell4.setPadding(10f);
		totalSystemCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalSystemCell5 = new PdfPCell(new Paragraph("" + df.format(pastDueTotal)));
		totalSystemCell5.setBorderColor(BaseColor.DARK_GRAY);
		totalSystemCell5.setBorder(Rectangle.NO_BORDER);
		totalSystemCell5.enableBorderSide(Rectangle.TOP);
		totalSystemCell5.enableBorderSide(Rectangle.BOTTOM);
		totalSystemCell5.setHorizontalAlignment(Element.ALIGN_CENTER);
		totalSystemCell5.setPadding(10f);
		totalSystemCell5.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalSystemCell6 = new PdfPCell(new Paragraph("" + df.format(disputeTotal)));
		totalSystemCell6.setBorderColor(BaseColor.DARK_GRAY);
		totalSystemCell6.setBorder(Rectangle.NO_BORDER);
		totalSystemCell6.enableBorderSide(Rectangle.TOP);
		totalSystemCell6.enableBorderSide(Rectangle.BOTTOM);
		totalSystemCell6.setHorizontalAlignment(Element.ALIGN_CENTER);
		totalSystemCell6.setPadding(10f);
		totalSystemCell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalSystemCell7 = new PdfPCell(new Paragraph("" + df.format(totalDueAmt)));
		totalSystemCell7.setBorderColor(BaseColor.DARK_GRAY);
		totalSystemCell7.setBorder(Rectangle.NO_BORDER);
		totalSystemCell7.enableBorderSide(Rectangle.TOP);
		totalSystemCell7.enableBorderSide(Rectangle.BOTTOM);
		totalSystemCell7.setHorizontalAlignment(Element.ALIGN_CENTER);
		totalSystemCell7.setPadding(10f);
		totalSystemCell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalSystemCell8 = new PdfPCell(new Paragraph(""));
		totalSystemCell8.setBorderColor(BaseColor.DARK_GRAY);
		totalSystemCell8.setBorder(Rectangle.NO_BORDER);
		totalSystemCell8.enableBorderSide(Rectangle.TOP);
		totalSystemCell8.enableBorderSide(Rectangle.BOTTOM);

		totalTable.addCell(totalSystemCell3);
		totalTable.addCell(totalSystemCell4);
		totalTable.addCell(totalSystemCell5);
		totalTable.addCell(totalSystemCell6);
		totalTable.addCell(totalSystemCell7);
		totalTable.addCell(totalSystemCell8);
		document.add(totalTable);
	}

	@Override
	public boolean validateAccountPermNoteRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getAccountNumber())
				&& StringUtils.isNotEmpty(userDetails.getAcntNoteOrgSys())) {
			response = true;
		}
		return response;
	}

	@Override
	public ByteArrayInputStream generatePermNoteReport(String customerGrpCd, String userLoginCd,
			Map<Object, Object> responseMap) {

		Document document = new Document(PageSize.A4, 36, 36, 150, 100);
		Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
		try (FileOutputStream out = new FileOutputStream(
				PERM_NOTE_REPORT + (StringUtils.isNotEmpty(userLoginCd) ? userLoginCd : customerGrpCd) + ".pdf")) {
			PdfWriter writer = PdfWriter.getInstance(document, out);
			document.setPageSize(rectangle);
			PermNotesHeaderFooterPageEvent event = new PermNotesHeaderFooterPageEvent();

			writer.setPageEvent(event);
			document.open();

			List<CustomerPermNotesReport> permNoteList = customerPermNotesReportRepository
					.getCustomerPermNotesReport(customerGrpCd);
			if (!CollectionUtils.isEmpty(permNoteList)) {

				addContent(permNoteList, document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				document.add(Chunk.NEWLINE);
				responseMap.remove("msg");
			}

			document.close();
			writer.close();
			Path path = Paths.get(
					PERM_NOTE_REPORT + (StringUtils.isNotEmpty(userLoginCd) ? userLoginCd : customerGrpCd) + ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);

		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(
					PERM_NOTE_REPORT + (StringUtils.isNotEmpty(userLoginCd) ? userLoginCd : customerGrpCd) + ".pdf");
		}
		return null;

	}

	private void addContent(List<CustomerPermNotesReport> permNoteList, Document document) throws DocumentException {
		try {
			Paragraph sys = new Paragraph(permNoteList.get(0).getCustomerLegalNm().toUpperCase(), boldFont);
			sys.setAlignment(Element.ALIGN_JUSTIFIED);
			document.add(sys);
			document.add(Chunk.NEWLINE);
			for (CustomerPermNotesReport permNote : permNoteList) {
				PdfPTable table = new PdfPTable(5);

				float[] columnWidths = { 1f, 1f, 2f, 1f, 1f };

				table.setWidths(columnWidths);
				table.setWidthPercentage(96);

				PdfPCell cell3 = new PdfPCell(new Paragraph(permNote.getBillingPeriod()));
				cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.enableBorderSide(Rectangle.BOTTOM);
				cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell4 = new PdfPCell(new Paragraph(permNote.getResolved() == 1 ? "Yes" : "No"));
				cell4.setBorder(Rectangle.NO_BORDER);
				cell4.enableBorderSide(Rectangle.BOTTOM);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell5 = new PdfPCell(new Paragraph(permNote.getNotes()));
				cell5.setBorder(Rectangle.NO_BORDER);
				cell5.enableBorderSide(Rectangle.BOTTOM);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell5.setPadding(5f);
				PdfPCell cell6 = new PdfPCell(new Paragraph("" + permNote.getInsertDate()));
				cell6.setBorder(Rectangle.NO_BORDER);
				cell6.enableBorderSide(Rectangle.BOTTOM);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell7 = new PdfPCell(new Paragraph("" + permNote.getRep()));
				cell7.setBorder(Rectangle.NO_BORDER);
				cell7.enableBorderSide(Rectangle.BOTTOM);
				cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);

				document.add(table);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public ByteArrayInputStream generateAccountPermNoteReport(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		Document document = new Document(PageSize.A4, 36, 36, 150, 100);
		Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
		try (FileOutputStream out = new FileOutputStream(
				ACCOUNT_PERM_NOTE_REPORT + userDetails.getAccountNumber() + ".pdf")) {
			PdfWriter writer = PdfWriter.getInstance(document, out);
			document.setPageSize(rectangle);
			PermNotesHeaderFooterPageEvent event = new PermNotesHeaderFooterPageEvent();

			writer.setPageEvent(event);
			document.open();

			List<AccountPermNotesReport> permNoteList = accountPermNotesReportRepository
					.getAccountPermNotesReport(userDetails.getAccountNumber(), userDetails.getAcntNoteOrgSys());
			if (!CollectionUtils.isEmpty(permNoteList)) {

				addAccountContent(permNoteList, userDetails.getAccountNumber(), document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				document.add(Chunk.NEWLINE);
				responseMap.remove("msg");
			}

			document.close();
			writer.close();
			Path path = Paths.get(ACCOUNT_PERM_NOTE_REPORT + userDetails.getAccountNumber() + ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);

		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {

			CommonUtils.deleteFile(ACCOUNT_PERM_NOTE_REPORT + userDetails.getAccountNumber() + ".pdf");

		}
		return null;
	}

	private void addAccountContent(List<AccountPermNotesReport> permNoteList, String accountNumber, Document document)
			throws DocumentException {
		try {
			Paragraph acc = new Paragraph(accountNumber, boldFont);
			Paragraph sys = new Paragraph(permNoteList.get(0).getSystem(), boldFont);
			acc.setAlignment(Element.ALIGN_JUSTIFIED);
			document.add(acc);
			document.add(sys);
			document.add(Chunk.NEWLINE);
			for (AccountPermNotesReport permNote : permNoteList) {
				PdfPTable table = new PdfPTable(5);

				float[] columnWidths = { 1f, 1f, 2f, 1f, 1f };

				table.setWidths(columnWidths);
				table.setWidthPercentage(96);

				PdfPCell cell3 = new PdfPCell(new Paragraph(permNote.getBillingPeriod()));
				cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.enableBorderSide(Rectangle.BOTTOM);
				cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell4 = new PdfPCell(new Paragraph(permNote.getResolved() == 1 ? "Yes" : "No"));
				cell4.setBorder(Rectangle.NO_BORDER);
				cell4.enableBorderSide(Rectangle.BOTTOM);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell5 = new PdfPCell(new Paragraph(permNote.getNotes()));
				cell5.setBorder(Rectangle.NO_BORDER);
				cell5.enableBorderSide(Rectangle.BOTTOM);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell5.setPadding(5f);
				PdfPCell cell6 = new PdfPCell(new Paragraph("" + permNote.getInsertDate()));
				cell6.setBorder(Rectangle.NO_BORDER);
				cell6.enableBorderSide(Rectangle.BOTTOM);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell7 = new PdfPCell(new Paragraph("" + permNote.getRep()));
				cell7.setBorder(Rectangle.NO_BORDER);
				cell7.enableBorderSide(Rectangle.BOTTOM);
				cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);

				document.add(table);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<RepCopy> getRepCopyReport(UserDetails userDetails, Map<Object, Object> responseMap) {

		String busUnitCd = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String acnaSubType = "";
		String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		String acnaCriteriaType = "";
		String billName = userDetails.getBillName();
		Integer rollUp = userDetails.getRollUp() != null ? userDetails.getRollUp() : 0;
		String classClause = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		Integer exclusion = 0;

		switch (userDetails.getExclusions()) {
		case ApplicationConstant.INCLUDED_ACCOUNTS:
			exclusion = 1;
			break;

		case ApplicationConstant.EXCLUDED_ACCOUNTS:
			exclusion = 0;
			break;

		default:
			exclusion = 2;
			break;
		}

		if (userDetails.getTabType() != null) {
			switch (userDetails.getTabType()) {
			case 2:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.ACNA_SUB_TYPE;
				break;
			case 3:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.AECN_SUB_TYPE;
				break;
			case 4:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.OCN_SUB_TYPE;
				break;
			case 5:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_CTC;
				acnaSubType = ApplicationConstant.CTC_SUB_TYPE;
				break;
			default:
				break;

			}
		}
		return repCopyRepository.getRepCopyReport(userDetails.getCustomerGrpCd(), busUnitCd,
				userDetails.getBillingPeriod(), statusClause, userDetails.getExclusiveAccess(), exclusion, classClause,
				billName, userDetails.getStateFilter(), segment, acnaCriteriaType, acnaSubType,
				userDetails.getAcnaValue(), userDetails.getCtcValue(), rollUp);
	}

	@Override
	public ByteArrayInputStream generateRepCopyReport(UserDetails userDetails, Map<Object, Object> responseMap) {
		List<RepCopy> cppoDetails = null;
		Document document = new Document(PageSize.A4, 36, 36, 200, 100);
		Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
		try (FileOutputStream out = new FileOutputStream(REP_COPY_REPORT + userDetails.getUserLoginCd() + ".pdf")) {

			PdfWriter writer = PdfWriter.getInstance(document, out);
			document.setPageSize(rectangle);
			RepCopyHeaderFooterPageEvent event = new RepCopyHeaderFooterPageEvent();
			String grpSelected = CommonUtils.getListToCommaSeparatedString(userDetails.getBusUnitCdList());
			String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());

			event.setHeader(userDetails.getBillingPeriod(), "('" + grpSelected + "')", userDetails.getCustomerName(),
					statusClause);
			writer.setPageEvent(event);
			document.open();

			cppoDetails = getRepCopyReport(userDetails, responseMap);
			if (!CollectionUtils.isEmpty(cppoDetails)) {

				addRepCopyContent(cppoDetails, document); 
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				document.add(Chunk.NEWLINE);
				responseMap.remove("msg");
			}

			document.close();
			writer.close();

			Path path = Paths.get(REP_COPY_REPORT + userDetails.getUserLoginCd() + ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(REP_COPY_REPORT + userDetails.getUserLoginCd() + ".pdf");
		}
		return null;
	}

	private void addRepCopyContent(List<RepCopy> repCopyDetailsList, Document document) throws DocumentException {
		Map<String, Map<String, Map<String, List<RepCopy>>>> custCopyDetailsByApSubGrpSystemAndStateMap = repCopyDetailsList
				.stream().collect(Collectors.groupingBy(RepCopy::getApSubGrpNm, Collectors
						.groupingBy(RepCopy::getOriginatingSystem, Collectors.groupingBy(RepCopy::getStateCd))));
		HashMap<String, Double> summationMap = new HashMap<>();
		double currentBillingTotal = 0;
		double currentBalanceTotal = 0;
		double pastDue30Total = 0;
		double pastDue60Total = 0;
		double pastDue90Total = 0;
		double pastDue120Total = 0;
		double pastDueTotal = 0;
		double totalDueAmt = 0;
		double disputeTotal = 0;
		double promotionalBalanceTotal = 0;
		Map<String, Map<String, Map<String, List<RepCopy>>>> repCopyDetailsByApSubGrpSystemAndStateMapSorted = new TreeMap<>();
		repCopyDetailsByApSubGrpSystemAndStateMapSorted.putAll(custCopyDetailsByApSubGrpSystemAndStateMap);
		repCopyDetailsByApSubGrpSystemAndStateMapSorted.forEach((apSubGroup, repCopyDetailsByApSubGroupMap) -> {
			TreeMap<String, Map<String, List<RepCopy>>> sorted = new TreeMap<>();
			sorted.putAll(repCopyDetailsByApSubGroupMap);
			Paragraph apSubGrp = new Paragraph("AP Sub Group: " + apSubGroup, boldFont);
			apSubGrp.setAlignment(Element.ALIGN_JUSTIFIED);

			try {
				document.add(apSubGrp);

				double currentBillingTotalBySubGroup = 0;
				if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SUBGROUP)
						&& summationMap.get(CURRENT_BILLING_TOTAL_BY_SUBGROUP) != null) {
					currentBillingTotalBySubGroup = currentBillingTotalBySubGroup
							+ summationMap.get(CURRENT_BILLING_TOTAL_BY_SUBGROUP);
				}
				double currentBalanceTotalBySubGroup = 0;
				if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SUBGROUP)
						&& summationMap.get(CURRENT_BALANCE_TOTAL_BY_SUBGROUP) != null) {
					currentBalanceTotalBySubGroup = currentBalanceTotalBySubGroup
							+ summationMap.get(CURRENT_BALANCE_TOTAL_BY_SUBGROUP);
				}
				double pastDue30TotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_30_TOTAL_BY_SUBGROUP) != null) {
					pastDue30TotalBySubGroup = pastDue30TotalBySubGroup
							+ summationMap.get(PAST_DUE_30_TOTAL_BY_SUBGROUP);
				}

				double pastDue60TotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_60_TOTAL_BY_SUBGROUP) != null) {
					pastDue60TotalBySubGroup = pastDue60TotalBySubGroup
							+ summationMap.get(PAST_DUE_60_TOTAL_BY_SUBGROUP);
				}

				double pastDue90TotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_90_TOTAL_BY_SUBGROUP) != null) {
					pastDue90TotalBySubGroup = pastDue90TotalBySubGroup
							+ summationMap.get(PAST_DUE_90_TOTAL_BY_SUBGROUP);
				}

				double pastDue120TotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_120_TOTAL_BY_SUBGROUP) != null) {
					pastDue120TotalBySubGroup = pastDue120TotalBySubGroup
							+ summationMap.get(PAST_DUE_120_TOTAL_BY_SUBGROUP);
				}

				double pastDueTotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_TOTAL_BY_SUBGROUP) != null) {
					pastDueTotalBySubGroup = pastDueTotalBySubGroup + summationMap.get(PAST_DUE_TOTAL_BY_SUBGROUP);
				}
				double totalDueAmtBySubGroup = 0;
				if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SUBGROUP)
						&& summationMap.get(TOTAL_DUE_AMT_BY_SUBGROUP) != null) {
					totalDueAmtBySubGroup = totalDueAmtBySubGroup + summationMap.get(TOTAL_DUE_AMT_BY_SUBGROUP);
				}
				double disputeTotalBySubGroup = 0;
				if (summationMap.containsKey(DISPUTE_TOTAL_BY_SUBGROUP)
						&& summationMap.get(DISPUTE_TOTAL_BY_SUBGROUP) != null) {
					disputeTotalBySubGroup = disputeTotalBySubGroup + summationMap.get(DISPUTE_TOTAL_BY_SUBGROUP);
				}
				double promotionalBalanceTotalBySubGroup = 0;
				if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP) != null) {
					promotionalBalanceTotalBySubGroup = promotionalBalanceTotalBySubGroup
							+ summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP);
				}

				sorted.forEach((system, repCopyDetailsBySystemList) -> {
					TreeMap<String, List<RepCopy>> systemSorted = new TreeMap<>();
					systemSorted.putAll(repCopyDetailsBySystemList);
					Paragraph sys = new Paragraph("System: " + system, boldFont);
					sys.setAlignment(Element.ALIGN_JUSTIFIED);

					try {
						document.add(sys);

						double currentBillingTotalBySystem = 0;
						if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SYSTEM)
								&& summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM) != null) {
							currentBillingTotalBySystem = currentBillingTotalBySystem
									+ summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM);
						}
						double currentBalanceTotalBySystem = 0;
						if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SYSTEM)
								&& summationMap.get(CURRENT_BALANCE_TOTAL_BY_SYSTEM) != null) {
							currentBalanceTotalBySystem = currentBalanceTotalBySystem
									+ summationMap.get(CURRENT_BALANCE_TOTAL_BY_SYSTEM);
						}
						double pastDue30TotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_30_TOTAL_BY_SYSTEM) != null) {
							pastDue30TotalBySystem = pastDue30TotalBySystem
									+ summationMap.get(PAST_DUE_30_TOTAL_BY_SYSTEM);
						}

						double pastDue60TotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_60_TOTAL_BY_SYSTEM) != null) {
							pastDue60TotalBySystem = pastDue60TotalBySystem
									+ summationMap.get(PAST_DUE_60_TOTAL_BY_SYSTEM);
						}

						double pastDue90TotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_90_TOTAL_BY_SYSTEM) != null) {
							pastDue90TotalBySystem = pastDue90TotalBySystem
									+ summationMap.get(PAST_DUE_90_TOTAL_BY_SYSTEM);
						}

						double pastDue120TotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_120_TOTAL_BY_SYSTEM) != null) {
							pastDue120TotalBySystem = pastDue120TotalBySystem
									+ summationMap.get(PAST_DUE_120_TOTAL_BY_SYSTEM);
						}

						double pastDueTotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM) != null) {
							pastDueTotalBySystem = pastDueTotalBySystem + summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM);
						}
						double totalDueAmtBySystem = 0;
						if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SYSTEM)
								&& summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM) != null) {
							totalDueAmtBySystem = totalDueAmtBySystem + summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM);
						}
						double disputeTotalBySystem = 0;
						if (summationMap.containsKey(DISPUTE_TOTAL_BY_SYSTEM)
								&& summationMap.get(DISPUTE_TOTAL_BY_SYSTEM) != null) {
							disputeTotalBySystem = disputeTotalBySystem + summationMap.get(DISPUTE_TOTAL_BY_SYSTEM);
						}
						double promotionalBalanceTotalBySystem = 0;
						if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM)
								&& summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM) != null) {
							promotionalBalanceTotalBySystem = promotionalBalanceTotalBySystem
									+ summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM);
						}
						systemSorted.forEach((stateCd, repCopyDetailsByStateCdList) -> {
							double currentBillingTotalByState = 0;
							double currentBalanceTotalByState = 0;
							double pastDue30TotalByState = 0;
							double pastDue60TotalByState = 0;
							double pastDue90TotalByState = 0;
							double pastDue120TotalByState = 0;
							double pastDueTotalByState = 0;
							double totalDueAmtByState = 0;
							double disputeTotalByState = 0;
							double promotionalBalanceTotalByState = 0;
							Paragraph state = new Paragraph(STATE + stateCd, boldFont);
							state.setAlignment(Element.ALIGN_JUSTIFIED);

							try {
								document.add(new Paragraph(STATE + stateCd, boldFont));

								for (RepCopy repCopy : repCopyDetailsByStateCdList) {

									PdfPTable table = new PdfPTable(16);

									float[] columnWidths = { 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f,
											1f };

									table.setWidths(columnWidths);
									table.setWidthPercentage(96);

									PdfPCell cell3 = new PdfPCell(new Paragraph(repCopy.getSegmentCd()));
									cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
									cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell3.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell4 = new PdfPCell(new Paragraph(repCopy.getAccountNbr()));
									cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
									cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell4.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell5 = new PdfPCell(new Paragraph("" + repCopy.getLastBillingDate()));
									cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
									cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell5.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell6 = new PdfPCell(new Paragraph(repCopy.getAcnaCd()));
									cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
									cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell6.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell7 = new PdfPCell(new Paragraph(""));
									cell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell7.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell8 = new PdfPCell(new Paragraph(""));
									cell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell8.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell9 = new PdfPCell(new Paragraph("$" + repCopy.getCurrentBillingAmt()));
									cell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell9.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell10 = new PdfPCell(new Paragraph("$" + repCopy.getPastDue0Amt()));
									cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell10.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell11 = new PdfPCell(new Paragraph("$" + repCopy.getPastDue30Amt()));
									cell11.disableBorderSide(0);
									cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell11.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell12 = new PdfPCell(new Paragraph("$" + repCopy.getPastDue60Amt()));
									cell12.disableBorderSide(0);
									cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell12.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell13 = new PdfPCell(new Paragraph("$" + repCopy.getPastDue90Amt()));
									cell13.disableBorderSide(0);
									cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell13.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell14 = new PdfPCell(new Paragraph("$" + repCopy.getPastDue120Amt()));
									cell14.disableBorderSide(0);
									cell14.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell14.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell14.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell15 = new PdfPCell(new Paragraph("$" + repCopy.getPastDueAmt()));
									cell15.disableBorderSide(0);
									cell15.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell15.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell15.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell16 = new PdfPCell(new Paragraph("$" + repCopy.getTotalAmt()));
									cell16.disableBorderSide(0);
									cell16.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell16.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell16.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell17 = new PdfPCell(new Paragraph("$" + repCopy.getDisputeAmt()));
									cell17.disableBorderSide(0);
									cell17.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell17.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell17.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell18 = new PdfPCell(new Paragraph("$" + repCopy.getPromoCr()));
									cell18.disableBorderSide(0);
									cell18.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell18.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell18.setBorder(Rectangle.NO_BORDER);

									table.addCell(cell3);
									table.addCell(cell4);
									table.addCell(cell5);
									table.addCell(cell6);
									table.addCell(cell7);
									table.addCell(cell8);
									table.addCell(cell9);
									table.addCell(cell10);
									table.addCell(cell11);
									table.addCell(cell12);
									table.addCell(cell13);
									table.addCell(cell14);
									table.addCell(cell15);
									table.addCell(cell16);
									table.addCell(cell17);
									table.addCell(cell18);

									document.add(table);

									currentBillingTotalByState = currentBillingTotalByState
											+ repCopy.getCurrentBillingAmt();
									currentBalanceTotalByState = currentBalanceTotalByState + repCopy.getPastDue0Amt();
									pastDue30TotalByState = pastDue30TotalByState + repCopy.getPastDue30Amt();
									pastDue60TotalByState = pastDue60TotalByState + repCopy.getPastDue60Amt();
									pastDue90TotalByState = pastDue90TotalByState + repCopy.getPastDue90Amt();
									pastDue120TotalByState = pastDue120TotalByState + repCopy.getPastDue120Amt();
									pastDueTotalByState = pastDueTotalByState + repCopy.getPastDueAmt();
									totalDueAmtByState = totalDueAmtByState + repCopy.getTotalAmt();
									disputeTotalByState = disputeTotalByState + repCopy.getDisputeAmt();
									promotionalBalanceTotalByState = promotionalBalanceTotalByState
											+ repCopy.getPromoCr();

								}

								PdfPTable totalTable = new PdfPTable(15);

								float[] columnWidths2 = { 1f, 1f, 1f, 1f, 2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

								totalTable.setWidths(columnWidths2);
								totalTable.setWidthPercentage(96);

								totalTable = addTotalRowNoBorder("", totalTable);
								totalTable = addTotalRowNoBorder("", totalTable);
								totalTable = addTotalRowNoBorder("", totalTable);
								totalTable = addTotalRowNoBorder("", totalTable);
								totalTable = addTotalRow(TOTAL_FOR + stateCd, totalTable);
								totalTable = addTotalRow("$" + df.format(currentBillingTotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(currentBalanceTotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDue30TotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDue60TotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDue90TotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDue120TotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDueTotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(totalDueAmtByState), totalTable);
								totalTable = addTotalRow("$" + df.format(disputeTotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(promotionalBalanceTotalByState), totalTable);

								if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SYSTEM)) {
									summationMap.put(CURRENT_BILLING_TOTAL_BY_SYSTEM,
											summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM)
													+ currentBillingTotalByState);
								} else {
									summationMap.put(CURRENT_BILLING_TOTAL_BY_SYSTEM, currentBillingTotalByState);
								}

								if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SYSTEM)) {
									summationMap.put(CURRENT_BALANCE_TOTAL_BY_SYSTEM,
											summationMap.get(CURRENT_BALANCE_TOTAL_BY_SYSTEM)
													+ currentBalanceTotalByState);
								} else {
									summationMap.put(CURRENT_BALANCE_TOTAL_BY_SYSTEM, currentBalanceTotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_30_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_30_TOTAL_BY_SYSTEM) + pastDue30TotalByState);
								} else {
									summationMap.put(PAST_DUE_30_TOTAL_BY_SYSTEM, pastDue30TotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_60_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_60_TOTAL_BY_SYSTEM) + pastDue60TotalByState);
								} else {
									summationMap.put(PAST_DUE_60_TOTAL_BY_SYSTEM, pastDue60TotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_90_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_90_TOTAL_BY_SYSTEM) + pastDue90TotalByState);
								} else {
									summationMap.put(PAST_DUE_90_TOTAL_BY_SYSTEM, pastDue90TotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_120_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_120_TOTAL_BY_SYSTEM) + pastDue120TotalByState);
								} else {
									summationMap.put(PAST_DUE_120_TOTAL_BY_SYSTEM, pastDue120TotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM) + pastDueTotalByState);
								} else {
									summationMap.put(PAST_DUE_TOTAL_BY_SYSTEM, pastDueTotalByState);
								}

								if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SYSTEM)) {
									summationMap.put(TOTAL_DUE_AMT_BY_SYSTEM,
											summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM) + totalDueAmtByState);
								} else {
									summationMap.put(TOTAL_DUE_AMT_BY_SYSTEM, totalDueAmtByState);
								}

								if (summationMap.containsKey(DISPUTE_TOTAL_BY_SYSTEM)) {
									summationMap.put(DISPUTE_TOTAL_BY_SYSTEM,
											summationMap.get(DISPUTE_TOTAL_BY_SYSTEM) + disputeTotalByState);
								} else {
									summationMap.put(DISPUTE_TOTAL_BY_SYSTEM, disputeTotalByState);
								}

								if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM)) {
									summationMap.put(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM,
											summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM)
													+ promotionalBalanceTotalByState);
								} else {
									summationMap.put(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM,
											promotionalBalanceTotalByState);
								}
								document.add(totalTable);
								document.add(Chunk.NEWLINE);
							} catch (DocumentException e) {
								e.printStackTrace();
							}

						});

						PdfPTable totalTable = new PdfPTable(15);

						float[] columnWidths2 = { 1f, 1f, 1f, 1f, 2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

						totalTable.setWidths(columnWidths2);
						totalTable.setWidthPercentage(96);

						if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SYSTEM)) {
							currentBillingTotalBySystem = summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM);
							summationMap.remove(CURRENT_BILLING_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SYSTEM)) {
							currentBalanceTotalBySystem = summationMap.get(CURRENT_BALANCE_TOTAL_BY_SYSTEM);
							summationMap.remove(CURRENT_BALANCE_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SYSTEM)) {
							pastDue30TotalBySystem = summationMap.get(PAST_DUE_30_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_30_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SYSTEM)) {
							pastDue60TotalBySystem = summationMap.get(PAST_DUE_60_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_60_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SYSTEM)) {
							pastDue90TotalBySystem = summationMap.get(PAST_DUE_90_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_90_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SYSTEM)) {
							pastDue120TotalBySystem = summationMap.get(PAST_DUE_120_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_120_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SYSTEM)) {
							pastDueTotalBySystem = summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SYSTEM)) {
							totalDueAmtBySystem = summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM);
							summationMap.remove(TOTAL_DUE_AMT_BY_SYSTEM);
						}

						if (summationMap.containsKey(DISPUTE_TOTAL_BY_SYSTEM)) {
							disputeTotalBySystem = summationMap.get(DISPUTE_TOTAL_BY_SYSTEM);
							summationMap.remove(DISPUTE_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM)) {
							promotionalBalanceTotalBySystem = summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM);
							summationMap.remove(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM);
						}
						totalTable = addTotalRowNoBorder("", totalTable);
						totalTable = addTotalRowNoBorder("", totalTable);
						totalTable = addTotalRowNoBorder("", totalTable);
						totalTable = addTotalRowNoBorder("", totalTable);
						totalTable = addTotalRow(TOTAL_FOR + system, totalTable);
						totalTable = addTotalRow("$" + df.format(currentBillingTotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(currentBalanceTotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDue30TotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDue60TotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDue90TotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDue120TotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDueTotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(totalDueAmtBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(disputeTotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(promotionalBalanceTotalBySystem), totalTable);

						if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SUBGROUP)) {
							summationMap.put(CURRENT_BILLING_TOTAL_BY_SUBGROUP,
									summationMap.get(CURRENT_BILLING_TOTAL_BY_SUBGROUP) + currentBillingTotalBySystem);
						} else {
							summationMap.put(CURRENT_BILLING_TOTAL_BY_SUBGROUP, currentBillingTotalBySystem);
						}

						if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SUBGROUP)) {
							summationMap.put(CURRENT_BALANCE_TOTAL_BY_SUBGROUP,
									summationMap.get(CURRENT_BALANCE_TOTAL_BY_SUBGROUP) + currentBalanceTotalBySystem);
						} else {
							summationMap.put(CURRENT_BALANCE_TOTAL_BY_SUBGROUP, currentBalanceTotalBySystem);
						}

						if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_30_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_30_TOTAL_BY_SUBGROUP) + pastDue30TotalBySystem);
						} else {
							summationMap.put(PAST_DUE_30_TOTAL_BY_SUBGROUP, pastDue30TotalBySystem);
						}
						if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_60_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_60_TOTAL_BY_SUBGROUP) + pastDue60TotalBySystem);
						} else {
							summationMap.put(PAST_DUE_60_TOTAL_BY_SUBGROUP, pastDue60TotalBySystem);
						}
						if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_90_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_90_TOTAL_BY_SUBGROUP) + pastDue90TotalBySystem);
						} else {
							summationMap.put(PAST_DUE_90_TOTAL_BY_SUBGROUP, pastDue90TotalBySystem);
						}
						if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_120_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_120_TOTAL_BY_SUBGROUP) + pastDue120TotalBySystem);
						} else {
							summationMap.put(PAST_DUE_120_TOTAL_BY_SUBGROUP, pastDue120TotalBySystem);
						}
						if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_TOTAL_BY_SUBGROUP) + pastDueTotalBySystem);
						} else {
							summationMap.put(PAST_DUE_TOTAL_BY_SUBGROUP, pastDueTotalBySystem);
						}

						if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SUBGROUP)) {
							summationMap.put(TOTAL_DUE_AMT_BY_SUBGROUP,
									summationMap.get(TOTAL_DUE_AMT_BY_SUBGROUP) + totalDueAmtBySystem);
						} else {
							summationMap.put(TOTAL_DUE_AMT_BY_SUBGROUP, totalDueAmtBySystem);
						}

						if (summationMap.containsKey(DISPUTE_TOTAL_BY_SUBGROUP)) {
							summationMap.put(DISPUTE_TOTAL_BY_SUBGROUP,
									summationMap.get(DISPUTE_TOTAL_BY_SUBGROUP) + disputeTotalBySystem);
						} else {
							summationMap.put(DISPUTE_TOTAL_BY_SUBGROUP, disputeTotalBySystem);
						}
						if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP,
									summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP)
											+ promotionalBalanceTotalBySystem);
						} else {
							summationMap.put(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP, promotionalBalanceTotalBySystem);
						}

						document.add(totalTable);
					} catch (DocumentException e2) {
						e2.printStackTrace();
					}
				});
				PdfPTable totalTable = new PdfPTable(15);

				float[] columnWidths2 = { 1f, 1f, 1f, 1f, 2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

				totalTable.setWidths(columnWidths2);
				totalTable.setWidthPercentage(96);

				if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SUBGROUP)) {
					currentBillingTotalBySubGroup = summationMap.get(CURRENT_BILLING_TOTAL_BY_SUBGROUP);
					summationMap.remove(CURRENT_BILLING_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SUBGROUP)) {
					currentBalanceTotalBySubGroup = summationMap.get(CURRENT_BALANCE_TOTAL_BY_SUBGROUP);
					summationMap.remove(CURRENT_BALANCE_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SUBGROUP)) {
					pastDue30TotalBySubGroup = summationMap.get(PAST_DUE_30_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_30_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SUBGROUP)) {
					pastDue60TotalBySubGroup = summationMap.get(PAST_DUE_60_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_60_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SUBGROUP)) {
					pastDue90TotalBySubGroup = summationMap.get(PAST_DUE_90_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_90_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SUBGROUP)) {
					pastDue120TotalBySubGroup = summationMap.get(PAST_DUE_120_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_120_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SUBGROUP)) {
					pastDueTotalBySubGroup = summationMap.get(PAST_DUE_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SUBGROUP)) {
					totalDueAmtBySubGroup = summationMap.get(TOTAL_DUE_AMT_BY_SUBGROUP);
					summationMap.remove(TOTAL_DUE_AMT_BY_SUBGROUP);
				}

				if (summationMap.containsKey(DISPUTE_TOTAL_BY_SUBGROUP)) {
					disputeTotalBySubGroup = summationMap.get(DISPUTE_TOTAL_BY_SUBGROUP);
					summationMap.remove(DISPUTE_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP)) {
					promotionalBalanceTotalBySubGroup = summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP);
					summationMap.remove(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP);
				}
				totalTable = addTotalRowNoBorder("", totalTable);
				totalTable = addTotalRowNoBorder("", totalTable);
				totalTable = addTotalRowNoBorder("", totalTable);
				totalTable = addTotalRowNoBorder("", totalTable);
				totalTable = addTotalRow(TOTAL_FOR + apSubGroup, totalTable);
				totalTable = addTotalRow("$" + df.format(currentBillingTotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(currentBalanceTotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDue30TotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDue60TotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDue90TotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDue120TotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDueTotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(totalDueAmtBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(disputeTotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(promotionalBalanceTotalBySubGroup), totalTable);

				if (summationMap.containsKey(CURRENT_BILLING_TOTAL)) {
					summationMap.put(CURRENT_BILLING_TOTAL,
							summationMap.get(CURRENT_BILLING_TOTAL) + currentBillingTotalBySubGroup);
				} else {
					summationMap.put(CURRENT_BILLING_TOTAL, currentBillingTotalBySubGroup);
				}

				if (summationMap.containsKey(CURRENT_BALANCE_TOTAL)) {
					summationMap.put(CURRENT_BALANCE_TOTAL,
							summationMap.get(CURRENT_BALANCE_TOTAL) + currentBalanceTotalBySubGroup);
				} else {
					summationMap.put(CURRENT_BALANCE_TOTAL, currentBalanceTotalBySubGroup);
				}

				if (summationMap.containsKey(PAST_DUE_30_TOTAL)) {
					summationMap.put(PAST_DUE_30_TOTAL, summationMap.get(PAST_DUE_30_TOTAL) + pastDue30TotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_30_TOTAL, pastDue30TotalBySubGroup);
				}
				if (summationMap.containsKey(PAST_DUE_60_TOTAL)) {
					summationMap.put(PAST_DUE_60_TOTAL, summationMap.get(PAST_DUE_60_TOTAL) + pastDue60TotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_60_TOTAL, pastDue60TotalBySubGroup);
				}
				if (summationMap.containsKey(PAST_DUE_90_TOTAL)) {
					summationMap.put(PAST_DUE_90_TOTAL, summationMap.get(PAST_DUE_90_TOTAL) + pastDue90TotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_90_TOTAL, pastDue90TotalBySubGroup);
				}
				if (summationMap.containsKey(PAST_DUE_120_TOTAL)) {
					summationMap.put(PAST_DUE_120_TOTAL,
							summationMap.get(PAST_DUE_120_TOTAL) + pastDue120TotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_120_TOTAL, pastDue120TotalBySubGroup);
				}
				if (summationMap.containsKey(PAST_DUE_TOTAL)) {
					summationMap.put(PAST_DUE_TOTAL, summationMap.get(PAST_DUE_TOTAL) + pastDueTotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_TOTAL, pastDueTotalBySubGroup);
				}

				if (summationMap.containsKey(TOTAL_DUE_AMT)) {
					summationMap.put(TOTAL_DUE_AMT, summationMap.get(TOTAL_DUE_AMT) + totalDueAmtBySubGroup);
				} else {
					summationMap.put(TOTAL_DUE_AMT, totalDueAmtBySubGroup);
				}

				if (summationMap.containsKey(DISPUTE_TOTAL)) {
					summationMap.put(DISPUTE_TOTAL, summationMap.get(DISPUTE_TOTAL) + disputeTotalBySubGroup);
				} else {
					summationMap.put(DISPUTE_TOTAL, disputeTotalBySubGroup);
				}
				if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL)) {
					summationMap.put(PROMOTIONAL_BALANCE_TOTAL,
							summationMap.get(PROMOTIONAL_BALANCE_TOTAL) + promotionalBalanceTotalBySubGroup);
				} else {
					summationMap.put(PROMOTIONAL_BALANCE_TOTAL, promotionalBalanceTotalBySubGroup);
				}

			} catch (DocumentException e) {
				e.printStackTrace();
			}
		});
		PdfPTable totalTable = new PdfPTable(15);

		float[] columnWidths2 = { 1f, 1f, 1f, 1f, 2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

		totalTable.setWidths(columnWidths2);
		totalTable.setWidthPercentage(96);

		if (summationMap.containsKey(CURRENT_BILLING_TOTAL)) {
			currentBillingTotal = summationMap.get(CURRENT_BILLING_TOTAL);
			summationMap.remove(CURRENT_BILLING_TOTAL);
		}

		if (summationMap.containsKey(CURRENT_BALANCE_TOTAL)) {
			currentBalanceTotal = summationMap.get(CURRENT_BALANCE_TOTAL);
			summationMap.remove(CURRENT_BALANCE_TOTAL);
		}

		if (summationMap.containsKey(PAST_DUE_30_TOTAL)) {
			pastDue30Total = summationMap.get(PAST_DUE_30_TOTAL);
			summationMap.remove(PAST_DUE_30_TOTAL);
		}
		if (summationMap.containsKey(PAST_DUE_60_TOTAL)) {
			pastDue60Total = summationMap.get(PAST_DUE_60_TOTAL);
			summationMap.remove(PAST_DUE_60_TOTAL);
		}

		if (summationMap.containsKey(PAST_DUE_90_TOTAL)) {
			pastDue90Total = summationMap.get(PAST_DUE_90_TOTAL);
			summationMap.remove(PAST_DUE_90_TOTAL);
		}

		if (summationMap.containsKey(PAST_DUE_120_TOTAL)) {
			pastDue120Total = summationMap.get(PAST_DUE_120_TOTAL);
			summationMap.remove(PAST_DUE_120_TOTAL);
		}

		if (summationMap.containsKey(PAST_DUE_TOTAL)) {
			pastDueTotal = summationMap.get(PAST_DUE_TOTAL);
			summationMap.remove(PAST_DUE_TOTAL);
		}

		if (summationMap.containsKey(TOTAL_DUE_AMT)) {
			totalDueAmt = summationMap.get(TOTAL_DUE_AMT);
			summationMap.remove(TOTAL_DUE_AMT);
		}

		if (summationMap.containsKey(DISPUTE_TOTAL)) {
			disputeTotal = summationMap.get(DISPUTE_TOTAL);
			summationMap.remove(DISPUTE_TOTAL);
		}
		if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL)) {
			promotionalBalanceTotal = summationMap.get(PROMOTIONAL_BALANCE_TOTAL);
			summationMap.remove(PROMOTIONAL_BALANCE_TOTAL);
		}
		totalTable = addTotalRowNoBorder("", totalTable);
		totalTable = addTotalRowNoBorder("", totalTable);
		totalTable = addTotalRowNoBorder("", totalTable);
		totalTable = addTotalRowNoBorder("", totalTable);
		totalTable = addGrandTotalRow("Grand Total", totalTable);
		totalTable = addGrandTotalRow("$" + df.format(currentBillingTotal), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(currentBalanceTotal), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDue30Total), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDue60Total), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDue90Total), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDue120Total), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDueTotal), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(totalDueAmt), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(disputeTotal), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(promotionalBalanceTotal), totalTable);
		document.add(totalTable);
	}

	@Override
	public ByteArrayInputStream generateCustCopyReport(UserDetails userDetails, Map<Object, Object> responseMap) {
		Document document = new Document(PageSize.A4, 36, 36, 150, 50);
		Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
		try (FileOutputStream out = new FileOutputStream(
				CUSTOMER_COPY_REPORT + userDetails.getUserLoginCd() + ".pdf")) {

			PdfWriter writer = PdfWriter.getInstance(document, out);
			document.setPageSize(rectangle);

			CustCopyHeaderFooterPageEvent event = new CustCopyHeaderFooterPageEvent();
			String grpSelected = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
			String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
			event.setHeader(userDetails.getBillingPeriod(), "('" + grpSelected + "')", userDetails.getCustomerName(),
					statusClause);

			writer.setPageEvent(event);
			document.open();
			document.setMargins(36, 36, 100, 50);
			List<CustomerCopy> customerCopyDetails = getCustomerCopyReport(userDetails);
			if (!CollectionUtils.isEmpty(customerCopyDetails)) {

				addCustomerCopyContent(customerCopyDetails, document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				document.add(Chunk.NEWLINE);
				responseMap.remove("msg");
			}

			document.close();
			writer.close();

			Path path = Paths.get(CUSTOMER_COPY_REPORT + userDetails.getUserLoginCd() + ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(CUSTOMER_COPY_REPORT + userDetails.getUserLoginCd() + ".pdf");
		}
		return null;
	}

	private List<CustomerCopy> getCustomerCopyReport(UserDetails userDetails) {

		String busUnitCd = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String acnaSubType = "";
		String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		String acnaCriteriaType = "";
		String billName = userDetails.getBillName();
		Integer rollUp = userDetails.getRollUp() != null ? userDetails.getRollUp() : 0;
		String classClause = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		Integer exclusion = 0;

		switch (userDetails.getExclusions()) {
		case ApplicationConstant.INCLUDED_ACCOUNTS:
			exclusion = 1;
			break;

		case ApplicationConstant.EXCLUDED_ACCOUNTS:
			exclusion = 0;
			break;

		default:
			exclusion = 2;
			break;
		}

		if (userDetails.getTabType() != null) {
			switch (userDetails.getTabType()) {
			case 2:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.ACNA_SUB_TYPE;
				break;
			case 3:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.AECN_SUB_TYPE;
				break;
			case 4:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.OCN_SUB_TYPE;
				break;
			case 5:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_CTC;
				acnaSubType = ApplicationConstant.CTC_SUB_TYPE;
				break;
			default:
				break;

			}
		}

		return customerCopyRepository.getCustCopyReport(userDetails.getCustomerGrpCd(), busUnitCd,
				userDetails.getBillingPeriod(), statusClause, userDetails.getExclusiveAccess(), exclusion, classClause,
				billName, userDetails.getStateFilter(), segment, acnaCriteriaType, acnaSubType,
				userDetails.getAcnaValue(), userDetails.getCtcValue(), rollUp);
	}

	private void addCustomerCopyContent(List<CustomerCopy> customerCopyDetailsList, Document document)
			throws DocumentException {

		Map<String, Map<String, Map<String, List<CustomerCopy>>>> custCopyDetailsByApSubGrpSystemAndStateMap = customerCopyDetailsList
				.stream().collect(Collectors.groupingBy(CustomerCopy::getApSubGrpNm, Collectors.groupingBy(
						CustomerCopy::getOriginatingSystem, Collectors.groupingBy(CustomerCopy::getStateCd))));
		HashMap<String, Double> summationMap = new HashMap<>();
		double currentBillingTotal = 0;
		double currentBalanceTotal = 0;
		double pastDue30Total = 0;
		double pastDue60Total = 0;
		double pastDue90Total = 0;
		double pastDue120Total = 0;
		double pastDueTotal = 0;
		double totalDueAmt = 0;
		double disputeTotal = 0;
		double promotionalBalanceTotal = 0;
		Map<String, Map<String, Map<String, List<CustomerCopy>>>> custCopyDetailsByApSubGrpSystemAndStateMapSorted = new TreeMap<>();
		custCopyDetailsByApSubGrpSystemAndStateMapSorted.putAll(custCopyDetailsByApSubGrpSystemAndStateMap);
		custCopyDetailsByApSubGrpSystemAndStateMapSorted.forEach((apSubGroup, custCopyDetailsByApSubGroupMap) -> {
			TreeMap<String, Map<String, List<CustomerCopy>>> sorted = new TreeMap<>();
			sorted.putAll(custCopyDetailsByApSubGroupMap);
			Paragraph apSubGrp = new Paragraph("AP Sub Group: " + apSubGroup, boldFont);
			apSubGrp.setAlignment(Element.ALIGN_JUSTIFIED);

			try {
				document.add(apSubGrp);

				double currentBillingTotalBySubGroup = 0;
				if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SUBGROUP)
						&& summationMap.get(CURRENT_BILLING_TOTAL_BY_SUBGROUP) != null) {
					currentBillingTotalBySubGroup = currentBillingTotalBySubGroup
							+ summationMap.get(CURRENT_BILLING_TOTAL_BY_SUBGROUP);
				}
				double currentBalanceTotalBySubGroup = 0;
				if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SUBGROUP)
						&& summationMap.get(CURRENT_BALANCE_TOTAL_BY_SUBGROUP) != null) {
					currentBalanceTotalBySubGroup = currentBalanceTotalBySubGroup
							+ summationMap.get(CURRENT_BALANCE_TOTAL_BY_SUBGROUP);
				}
				double pastDue30TotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_30_TOTAL_BY_SUBGROUP) != null) {
					pastDue30TotalBySubGroup = pastDue30TotalBySubGroup
							+ summationMap.get(PAST_DUE_30_TOTAL_BY_SUBGROUP);
				}

				double pastDue60TotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_60_TOTAL_BY_SUBGROUP) != null) {
					pastDue60TotalBySubGroup = pastDue60TotalBySubGroup
							+ summationMap.get(PAST_DUE_60_TOTAL_BY_SUBGROUP);
				}

				double pastDue90TotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_90_TOTAL_BY_SUBGROUP) != null) {
					pastDue90TotalBySubGroup = pastDue90TotalBySubGroup
							+ summationMap.get(PAST_DUE_90_TOTAL_BY_SUBGROUP);
				}

				double pastDue120TotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_120_TOTAL_BY_SUBGROUP) != null) {
					pastDue120TotalBySubGroup = pastDue120TotalBySubGroup
							+ summationMap.get(PAST_DUE_120_TOTAL_BY_SUBGROUP);
				}

				double pastDueTotalBySubGroup = 0;
				if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PAST_DUE_TOTAL_BY_SUBGROUP) != null) {
					pastDueTotalBySubGroup = pastDueTotalBySubGroup + summationMap.get(PAST_DUE_TOTAL_BY_SUBGROUP);
				}
				double totalDueAmtBySubGroup = 0;
				if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SUBGROUP)
						&& summationMap.get(TOTAL_DUE_AMT_BY_SUBGROUP) != null) {
					totalDueAmtBySubGroup = totalDueAmtBySubGroup + summationMap.get(TOTAL_DUE_AMT_BY_SUBGROUP);
				}
				double disputeTotalBySubGroup = 0;
				if (summationMap.containsKey(DISPUTE_TOTAL_BY_SUBGROUP)
						&& summationMap.get(DISPUTE_TOTAL_BY_SUBGROUP) != null) {
					disputeTotalBySubGroup = disputeTotalBySubGroup + summationMap.get(DISPUTE_TOTAL_BY_SUBGROUP);
				}
				double promotionalBalanceTotalBySubGroup = 0;
				if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP)
						&& summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP) != null) {
					promotionalBalanceTotalBySubGroup = promotionalBalanceTotalBySubGroup
							+ summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP);
				}

				sorted.forEach((system, custCopyDetailsBySystemList) -> {
					TreeMap<String, List<CustomerCopy>> systemSorted = new TreeMap<>();
					systemSorted.putAll(custCopyDetailsBySystemList);
					Paragraph sys = new Paragraph("System: " + system, boldFont);
					sys.setAlignment(Element.ALIGN_JUSTIFIED);

					try {
						document.add(sys);

						double currentBillingTotalBySystem = 0;
						if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SYSTEM)
								&& summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM) != null) {
							currentBillingTotalBySystem = currentBillingTotalBySystem
									+ summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM);
						}
						double currentBalanceTotalBySystem = 0;
						if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SYSTEM)
								&& summationMap.get(CURRENT_BALANCE_TOTAL_BY_SYSTEM) != null) {
							currentBalanceTotalBySystem = currentBalanceTotalBySystem
									+ summationMap.get(CURRENT_BALANCE_TOTAL_BY_SYSTEM);
						}
						double pastDue30TotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_30_TOTAL_BY_SYSTEM) != null) {
							pastDue30TotalBySystem = pastDue30TotalBySystem
									+ summationMap.get(PAST_DUE_30_TOTAL_BY_SYSTEM);
						}

						double pastDue60TotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_60_TOTAL_BY_SYSTEM) != null) {
							pastDue60TotalBySystem = pastDue60TotalBySystem
									+ summationMap.get(PAST_DUE_60_TOTAL_BY_SYSTEM);
						}

						double pastDue90TotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_90_TOTAL_BY_SYSTEM) != null) {
							pastDue90TotalBySystem = pastDue90TotalBySystem
									+ summationMap.get(PAST_DUE_90_TOTAL_BY_SYSTEM);
						}

						double pastDue120TotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_120_TOTAL_BY_SYSTEM) != null) {
							pastDue120TotalBySystem = pastDue120TotalBySystem
									+ summationMap.get(PAST_DUE_120_TOTAL_BY_SYSTEM);
						}

						double pastDueTotalBySystem = 0;
						if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SYSTEM)
								&& summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM) != null) {
							pastDueTotalBySystem = pastDueTotalBySystem + summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM);
						}
						double totalDueAmtBySystem = 0;
						if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SYSTEM)
								&& summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM) != null) {
							totalDueAmtBySystem = totalDueAmtBySystem + summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM);
						}
						double disputeTotalBySystem = 0;
						if (summationMap.containsKey(DISPUTE_TOTAL_BY_SYSTEM)
								&& summationMap.get(DISPUTE_TOTAL_BY_SYSTEM) != null) {
							disputeTotalBySystem = disputeTotalBySystem + summationMap.get(DISPUTE_TOTAL_BY_SYSTEM);
						}
						double promotionalBalanceTotalBySystem = 0;
						if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM)
								&& summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM) != null) {
							promotionalBalanceTotalBySystem = promotionalBalanceTotalBySystem
									+ summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM);
						}
						systemSorted.forEach((stateCd, custCopyDetailsByStateCdList) -> {
							double currentBillingTotalByState = 0;
							double currentBalanceTotalByState = 0;
							double pastDue30TotalByState = 0;
							double pastDue60TotalByState = 0;
							double pastDue90TotalByState = 0;
							double pastDue120TotalByState = 0;
							double pastDueTotalByState = 0;
							double totalDueAmtByState = 0;
							double disputeTotalByState = 0;
							double promotionalBalanceTotalByState = 0;
							Paragraph state = new Paragraph(STATE + stateCd, boldFont);
							state.setAlignment(Element.ALIGN_JUSTIFIED);

							try {
								document.add(new Paragraph(STATE + stateCd, boldFont));

								for (CustomerCopy customerCopy : custCopyDetailsByStateCdList) {

									PdfPTable table = new PdfPTable(16);

									float[] columnWidths = { 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f,
											1f };

									table.setWidths(columnWidths);
									table.setWidthPercentage(96);

									PdfPCell cell3 = new PdfPCell(new Paragraph(customerCopy.getSegmentCd()));
									cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
									cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell3.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell4 = new PdfPCell(new Paragraph(customerCopy.getAccountNbr()));
									cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
									cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell4.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell5 = new PdfPCell(
											new Paragraph("" + customerCopy.getLastBillingDate()));
									cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
									cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell5.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell6 = new PdfPCell(new Paragraph(customerCopy.getAcnaCd()));
									cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
									cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell6.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell7 = new PdfPCell(new Paragraph(""));
									cell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell7.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell8 = new PdfPCell(new Paragraph(""));
									cell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell8.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell9 = new PdfPCell(
											new Paragraph("$" + customerCopy.getCurrentBillingAmt()));
									cell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell9.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell10 = new PdfPCell(new Paragraph("$" + customerCopy.getPastDue0Amt()));
									cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell10.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell11 = new PdfPCell(new Paragraph("$" + customerCopy.getPastDue30Amt()));
									cell11.disableBorderSide(0);
									cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell11.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell12 = new PdfPCell(new Paragraph("$" + customerCopy.getPastDue60Amt()));
									cell12.disableBorderSide(0);
									cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell12.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell13 = new PdfPCell(new Paragraph("$" + customerCopy.getPastDue90Amt()));
									cell13.disableBorderSide(0);
									cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell13.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell14 = new PdfPCell(
											new Paragraph("$" + customerCopy.getPastDue120Amt()));
									cell14.disableBorderSide(0);
									cell14.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell14.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell14.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell15 = new PdfPCell(new Paragraph("$" + customerCopy.getPastDueAmt()));
									cell15.disableBorderSide(0);
									cell15.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell15.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell15.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell16 = new PdfPCell(new Paragraph("$" + customerCopy.getTotalAmt()));
									cell16.disableBorderSide(0);
									cell16.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell16.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell16.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell17 = new PdfPCell(new Paragraph("$" + customerCopy.getDisputeAmt()));
									cell17.disableBorderSide(0);
									cell17.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell17.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell17.setBorder(Rectangle.NO_BORDER);

									PdfPCell cell18 = new PdfPCell(new Paragraph("$" + customerCopy.getPromoCr()));
									cell18.disableBorderSide(0);
									cell18.setHorizontalAlignment(Element.ALIGN_RIGHT);
									cell18.setVerticalAlignment(Element.ALIGN_MIDDLE);
									cell18.setBorder(Rectangle.NO_BORDER);

									table.addCell(cell3);
									table.addCell(cell4);
									table.addCell(cell5);
									table.addCell(cell6);
									table.addCell(cell7);
									table.addCell(cell8);
									table.addCell(cell9);
									table.addCell(cell10);
									table.addCell(cell11);
									table.addCell(cell12);
									table.addCell(cell13);
									table.addCell(cell14);
									table.addCell(cell15);
									table.addCell(cell16);
									table.addCell(cell17);
									table.addCell(cell18);

									document.add(table);

									currentBillingTotalByState = currentBillingTotalByState
											+ customerCopy.getCurrentBillingAmt();
									currentBalanceTotalByState = currentBalanceTotalByState
											+ customerCopy.getPastDue0Amt();
									pastDue30TotalByState = pastDue30TotalByState + customerCopy.getPastDue30Amt();
									pastDue60TotalByState = pastDue60TotalByState + customerCopy.getPastDue60Amt();
									pastDue90TotalByState = pastDue90TotalByState + customerCopy.getPastDue90Amt();
									pastDue120TotalByState = pastDue120TotalByState + customerCopy.getPastDue120Amt();
									pastDueTotalByState = pastDueTotalByState + customerCopy.getPastDueAmt();
									totalDueAmtByState = totalDueAmtByState + customerCopy.getTotalAmt();
									disputeTotalByState = disputeTotalByState + customerCopy.getDisputeAmt();
									promotionalBalanceTotalByState = promotionalBalanceTotalByState
											+ customerCopy.getPromoCr();

								}

								PdfPTable totalTable = new PdfPTable(15);

								float[] columnWidths2 = { 1f, 1f, 1f, 1f, 2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

								totalTable.setWidths(columnWidths2);
								totalTable.setWidthPercentage(96);

								totalTable = addTotalRowNoBorder("", totalTable);
								totalTable = addTotalRowNoBorder("", totalTable);
								totalTable = addTotalRowNoBorder("", totalTable);
								totalTable = addTotalRowNoBorder("", totalTable);
								totalTable = addTotalRow(TOTAL_FOR + stateCd, totalTable);
								totalTable = addTotalRow("$" + df.format(currentBillingTotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(currentBalanceTotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDue30TotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDue60TotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDue90TotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDue120TotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(pastDueTotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(totalDueAmtByState), totalTable);
								totalTable = addTotalRow("$" + df.format(disputeTotalByState), totalTable);
								totalTable = addTotalRow("$" + df.format(promotionalBalanceTotalByState), totalTable);

								if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SYSTEM)) {
									summationMap.put(CURRENT_BILLING_TOTAL_BY_SYSTEM,
											summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM)
													+ currentBillingTotalByState);
								} else {
									summationMap.put(CURRENT_BILLING_TOTAL_BY_SYSTEM, currentBillingTotalByState);
								}

								if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SYSTEM)) {
									summationMap.put(CURRENT_BALANCE_TOTAL_BY_SYSTEM,
											summationMap.get(CURRENT_BALANCE_TOTAL_BY_SYSTEM)
													+ currentBalanceTotalByState);
								} else {
									summationMap.put(CURRENT_BALANCE_TOTAL_BY_SYSTEM, currentBalanceTotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_30_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_30_TOTAL_BY_SYSTEM) + pastDue30TotalByState);
								} else {
									summationMap.put(PAST_DUE_30_TOTAL_BY_SYSTEM, pastDue30TotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_60_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_60_TOTAL_BY_SYSTEM) + pastDue60TotalByState);
								} else {
									summationMap.put(PAST_DUE_60_TOTAL_BY_SYSTEM, pastDue60TotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_90_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_90_TOTAL_BY_SYSTEM) + pastDue90TotalByState);
								} else {
									summationMap.put(PAST_DUE_90_TOTAL_BY_SYSTEM, pastDue90TotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_120_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_120_TOTAL_BY_SYSTEM) + pastDue120TotalByState);
								} else {
									summationMap.put(PAST_DUE_120_TOTAL_BY_SYSTEM, pastDue120TotalByState);
								}

								if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SYSTEM)) {
									summationMap.put(PAST_DUE_TOTAL_BY_SYSTEM,
											summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM) + pastDueTotalByState);
								} else {
									summationMap.put(PAST_DUE_TOTAL_BY_SYSTEM, pastDueTotalByState);
								}

								if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SYSTEM)) {
									summationMap.put(TOTAL_DUE_AMT_BY_SYSTEM,
											summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM) + totalDueAmtByState);
								} else {
									summationMap.put(TOTAL_DUE_AMT_BY_SYSTEM, totalDueAmtByState);
								}

								if (summationMap.containsKey(DISPUTE_TOTAL_BY_SYSTEM)) {
									summationMap.put(DISPUTE_TOTAL_BY_SYSTEM,
											summationMap.get(DISPUTE_TOTAL_BY_SYSTEM) + disputeTotalByState);
								} else {
									summationMap.put(DISPUTE_TOTAL_BY_SYSTEM, disputeTotalByState);
								}

								if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM)) {
									summationMap.put(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM,
											summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM)
													+ promotionalBalanceTotalByState);
								} else {
									summationMap.put(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM,
											promotionalBalanceTotalByState);
								}
								document.add(totalTable);
								document.add(Chunk.NEWLINE);
							} catch (DocumentException e) {
								e.printStackTrace();
							}

						});

						PdfPTable totalTable = new PdfPTable(15);

						float[] columnWidths2 = { 1f, 1f, 1f, 1f, 2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

						totalTable.setWidths(columnWidths2);
						totalTable.setWidthPercentage(96);

						if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SYSTEM)) {
							currentBillingTotalBySystem = summationMap.get(CURRENT_BILLING_TOTAL_BY_SYSTEM);
							summationMap.remove(CURRENT_BILLING_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SYSTEM)) {
							currentBalanceTotalBySystem = summationMap.get(CURRENT_BALANCE_TOTAL_BY_SYSTEM);
							summationMap.remove(CURRENT_BALANCE_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SYSTEM)) {
							pastDue30TotalBySystem = summationMap.get(PAST_DUE_30_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_30_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SYSTEM)) {
							pastDue60TotalBySystem = summationMap.get(PAST_DUE_60_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_60_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SYSTEM)) {
							pastDue90TotalBySystem = summationMap.get(PAST_DUE_90_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_90_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SYSTEM)) {
							pastDue120TotalBySystem = summationMap.get(PAST_DUE_120_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_120_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SYSTEM)) {
							pastDueTotalBySystem = summationMap.get(PAST_DUE_TOTAL_BY_SYSTEM);
							summationMap.remove(PAST_DUE_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SYSTEM)) {
							totalDueAmtBySystem = summationMap.get(TOTAL_DUE_AMT_BY_SYSTEM);
							summationMap.remove(TOTAL_DUE_AMT_BY_SYSTEM);
						}

						if (summationMap.containsKey(DISPUTE_TOTAL_BY_SYSTEM)) {
							disputeTotalBySystem = summationMap.get(DISPUTE_TOTAL_BY_SYSTEM);
							summationMap.remove(DISPUTE_TOTAL_BY_SYSTEM);
						}

						if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM)) {
							promotionalBalanceTotalBySystem = summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM);
							summationMap.remove(PROMOTIONAL_BALANCE_TOTAL_BY_SYSTEM);
						}
						totalTable = addTotalRowNoBorder("", totalTable);
						totalTable = addTotalRowNoBorder("", totalTable);
						totalTable = addTotalRowNoBorder("", totalTable);
						totalTable = addTotalRowNoBorder("", totalTable);
						totalTable = addTotalRow(TOTAL_FOR + system, totalTable);
						totalTable = addTotalRow("$" + df.format(currentBillingTotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(currentBalanceTotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDue30TotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDue60TotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDue90TotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDue120TotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(pastDueTotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(totalDueAmtBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(disputeTotalBySystem), totalTable);
						totalTable = addTotalRow("$" + df.format(promotionalBalanceTotalBySystem), totalTable);

						if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SUBGROUP)) {
							summationMap.put(CURRENT_BILLING_TOTAL_BY_SUBGROUP,
									summationMap.get(CURRENT_BILLING_TOTAL_BY_SUBGROUP) + currentBillingTotalBySystem);
						} else {
							summationMap.put(CURRENT_BILLING_TOTAL_BY_SUBGROUP, currentBillingTotalBySystem);
						}

						if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SUBGROUP)) {
							summationMap.put(CURRENT_BALANCE_TOTAL_BY_SUBGROUP,
									summationMap.get(CURRENT_BALANCE_TOTAL_BY_SUBGROUP) + currentBalanceTotalBySystem);
						} else {
							summationMap.put(CURRENT_BALANCE_TOTAL_BY_SUBGROUP, currentBalanceTotalBySystem);
						}

						if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_30_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_30_TOTAL_BY_SUBGROUP) + pastDue30TotalBySystem);
						} else {
							summationMap.put(PAST_DUE_30_TOTAL_BY_SUBGROUP, pastDue30TotalBySystem);
						}
						if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_60_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_60_TOTAL_BY_SUBGROUP) + pastDue60TotalBySystem);
						} else {
							summationMap.put(PAST_DUE_60_TOTAL_BY_SUBGROUP, pastDue60TotalBySystem);
						}
						if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_90_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_90_TOTAL_BY_SUBGROUP) + pastDue90TotalBySystem);
						} else {
							summationMap.put(PAST_DUE_90_TOTAL_BY_SUBGROUP, pastDue90TotalBySystem);
						}
						if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_120_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_120_TOTAL_BY_SUBGROUP) + pastDue120TotalBySystem);
						} else {
							summationMap.put(PAST_DUE_120_TOTAL_BY_SUBGROUP, pastDue120TotalBySystem);
						}
						if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PAST_DUE_TOTAL_BY_SUBGROUP,
									summationMap.get(PAST_DUE_TOTAL_BY_SUBGROUP) + pastDueTotalBySystem);
						} else {
							summationMap.put(PAST_DUE_TOTAL_BY_SUBGROUP, pastDueTotalBySystem);
						}

						if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SUBGROUP)) {
							summationMap.put(TOTAL_DUE_AMT_BY_SUBGROUP,
									summationMap.get(TOTAL_DUE_AMT_BY_SUBGROUP) + totalDueAmtBySystem);
						} else {
							summationMap.put(TOTAL_DUE_AMT_BY_SUBGROUP, totalDueAmtBySystem);
						}

						if (summationMap.containsKey(DISPUTE_TOTAL_BY_SUBGROUP)) {
							summationMap.put(DISPUTE_TOTAL_BY_SUBGROUP,
									summationMap.get(DISPUTE_TOTAL_BY_SUBGROUP) + disputeTotalBySystem);
						} else {
							summationMap.put(DISPUTE_TOTAL_BY_SUBGROUP, disputeTotalBySystem);
						}
						if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP)) {
							summationMap.put(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP,
									summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP)
											+ promotionalBalanceTotalBySystem);
						} else {
							summationMap.put(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP, promotionalBalanceTotalBySystem);
						}

						document.add(totalTable);
					} catch (DocumentException e2) {
						e2.printStackTrace();
					}
				});
				PdfPTable totalTable = new PdfPTable(15);

				float[] columnWidths2 = { 1f, 1f, 1f, 1f, 2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

				totalTable.setWidths(columnWidths2);
				totalTable.setWidthPercentage(96);

				if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_SUBGROUP)) {
					currentBillingTotalBySubGroup = summationMap.get(CURRENT_BILLING_TOTAL_BY_SUBGROUP);
					summationMap.remove(CURRENT_BILLING_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(CURRENT_BALANCE_TOTAL_BY_SUBGROUP)) {
					currentBalanceTotalBySubGroup = summationMap.get(CURRENT_BALANCE_TOTAL_BY_SUBGROUP);
					summationMap.remove(CURRENT_BALANCE_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_30_TOTAL_BY_SUBGROUP)) {
					pastDue30TotalBySubGroup = summationMap.get(PAST_DUE_30_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_30_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_60_TOTAL_BY_SUBGROUP)) {
					pastDue60TotalBySubGroup = summationMap.get(PAST_DUE_60_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_60_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_90_TOTAL_BY_SUBGROUP)) {
					pastDue90TotalBySubGroup = summationMap.get(PAST_DUE_90_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_90_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_120_TOTAL_BY_SUBGROUP)) {
					pastDue120TotalBySubGroup = summationMap.get(PAST_DUE_120_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_120_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PAST_DUE_TOTAL_BY_SUBGROUP)) {
					pastDueTotalBySubGroup = summationMap.get(PAST_DUE_TOTAL_BY_SUBGROUP);
					summationMap.remove(PAST_DUE_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(TOTAL_DUE_AMT_BY_SUBGROUP)) {
					totalDueAmtBySubGroup = summationMap.get(TOTAL_DUE_AMT_BY_SUBGROUP);
					summationMap.remove(TOTAL_DUE_AMT_BY_SUBGROUP);
				}

				if (summationMap.containsKey(DISPUTE_TOTAL_BY_SUBGROUP)) {
					disputeTotalBySubGroup = summationMap.get(DISPUTE_TOTAL_BY_SUBGROUP);
					summationMap.remove(DISPUTE_TOTAL_BY_SUBGROUP);
				}

				if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP)) {
					promotionalBalanceTotalBySubGroup = summationMap.get(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP);
					summationMap.remove(PROMOTIONAL_BALANCE_TOTAL_BY_SUBGROUP);
				}
				totalTable = addTotalRowNoBorder("", totalTable);
				totalTable = addTotalRowNoBorder("", totalTable);
				totalTable = addTotalRowNoBorder("", totalTable);
				totalTable = addTotalRowNoBorder("", totalTable);
				totalTable = addTotalRow(TOTAL_FOR + apSubGroup, totalTable);
				totalTable = addTotalRow("$" + df.format(currentBillingTotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(currentBalanceTotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDue30TotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDue60TotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDue90TotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDue120TotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(pastDueTotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(totalDueAmtBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(disputeTotalBySubGroup), totalTable);
				totalTable = addTotalRow("$" + df.format(promotionalBalanceTotalBySubGroup), totalTable);

				if (summationMap.containsKey(CURRENT_BILLING_TOTAL)) {
					summationMap.put(CURRENT_BILLING_TOTAL,
							summationMap.get(CURRENT_BILLING_TOTAL) + currentBillingTotalBySubGroup);
				} else {
					summationMap.put(CURRENT_BILLING_TOTAL, currentBillingTotalBySubGroup);
				}

				if (summationMap.containsKey(CURRENT_BALANCE_TOTAL)) {
					summationMap.put(CURRENT_BALANCE_TOTAL,
							summationMap.get(CURRENT_BALANCE_TOTAL) + currentBalanceTotalBySubGroup);
				} else {
					summationMap.put(CURRENT_BALANCE_TOTAL, currentBalanceTotalBySubGroup);
				}

				if (summationMap.containsKey(PAST_DUE_30_TOTAL)) {
					summationMap.put(PAST_DUE_30_TOTAL, summationMap.get(PAST_DUE_30_TOTAL) + pastDue30TotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_30_TOTAL, pastDue30TotalBySubGroup);
				}
				if (summationMap.containsKey(PAST_DUE_60_TOTAL)) {
					summationMap.put(PAST_DUE_60_TOTAL, summationMap.get(PAST_DUE_60_TOTAL) + pastDue60TotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_60_TOTAL, pastDue60TotalBySubGroup);
				}
				if (summationMap.containsKey(PAST_DUE_90_TOTAL)) {
					summationMap.put(PAST_DUE_90_TOTAL, summationMap.get(PAST_DUE_90_TOTAL) + pastDue90TotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_90_TOTAL, pastDue90TotalBySubGroup);
				}
				if (summationMap.containsKey(PAST_DUE_120_TOTAL)) {
					summationMap.put(PAST_DUE_120_TOTAL,
							summationMap.get(PAST_DUE_120_TOTAL) + pastDue120TotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_120_TOTAL, pastDue120TotalBySubGroup);
				}
				if (summationMap.containsKey(PAST_DUE_TOTAL)) {
					summationMap.put(PAST_DUE_TOTAL, summationMap.get(PAST_DUE_TOTAL) + pastDueTotalBySubGroup);
				} else {
					summationMap.put(PAST_DUE_TOTAL, pastDueTotalBySubGroup);
				}

				if (summationMap.containsKey(TOTAL_DUE_AMT)) {
					summationMap.put(TOTAL_DUE_AMT, summationMap.get(TOTAL_DUE_AMT) + totalDueAmtBySubGroup);
				} else {
					summationMap.put(TOTAL_DUE_AMT, totalDueAmtBySubGroup);
				}

				if (summationMap.containsKey(DISPUTE_TOTAL)) {
					summationMap.put(DISPUTE_TOTAL, summationMap.get(DISPUTE_TOTAL) + disputeTotalBySubGroup);
				} else {
					summationMap.put(DISPUTE_TOTAL, disputeTotalBySubGroup);
				}
				if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL)) {
					summationMap.put(PROMOTIONAL_BALANCE_TOTAL,
							summationMap.get(PROMOTIONAL_BALANCE_TOTAL) + promotionalBalanceTotalBySubGroup);
				} else {
					summationMap.put(PROMOTIONAL_BALANCE_TOTAL, promotionalBalanceTotalBySubGroup);
				}

			} catch (DocumentException e) {
				e.printStackTrace();
			}
		});
		PdfPTable totalTable = new PdfPTable(15);

		float[] columnWidths2 = { 1f, 1f, 1f, 1f, 2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

		totalTable.setWidths(columnWidths2);
		totalTable.setWidthPercentage(96);

		if (summationMap.containsKey(CURRENT_BILLING_TOTAL)) {
			currentBillingTotal = summationMap.get(CURRENT_BILLING_TOTAL);
			summationMap.remove(CURRENT_BILLING_TOTAL);
		}

		if (summationMap.containsKey(CURRENT_BALANCE_TOTAL)) {
			currentBalanceTotal = summationMap.get(CURRENT_BALANCE_TOTAL);
			summationMap.remove(CURRENT_BALANCE_TOTAL);
		}

		if (summationMap.containsKey(PAST_DUE_30_TOTAL)) {
			pastDue30Total = summationMap.get(PAST_DUE_30_TOTAL);
			summationMap.remove(PAST_DUE_30_TOTAL);
		}
		if (summationMap.containsKey(PAST_DUE_60_TOTAL)) {
			pastDue60Total = summationMap.get(PAST_DUE_60_TOTAL);
			summationMap.remove(PAST_DUE_60_TOTAL);
		}

		if (summationMap.containsKey(PAST_DUE_90_TOTAL)) {
			pastDue90Total = summationMap.get(PAST_DUE_90_TOTAL);
			summationMap.remove(PAST_DUE_90_TOTAL);
		}

		if (summationMap.containsKey(PAST_DUE_120_TOTAL)) {
			pastDue120Total = summationMap.get(PAST_DUE_120_TOTAL);
			summationMap.remove(PAST_DUE_120_TOTAL);
		}

		if (summationMap.containsKey(PAST_DUE_TOTAL)) {
			pastDueTotal = summationMap.get(PAST_DUE_TOTAL);
			summationMap.remove(PAST_DUE_TOTAL);
		}

		if (summationMap.containsKey(TOTAL_DUE_AMT)) {
			totalDueAmt = summationMap.get(TOTAL_DUE_AMT);
			summationMap.remove(TOTAL_DUE_AMT);
		}

		if (summationMap.containsKey(DISPUTE_TOTAL)) {
			disputeTotal = summationMap.get(DISPUTE_TOTAL);
			summationMap.remove(DISPUTE_TOTAL);
		}
		if (summationMap.containsKey(PROMOTIONAL_BALANCE_TOTAL)) {
			promotionalBalanceTotal = summationMap.get(PROMOTIONAL_BALANCE_TOTAL);
			summationMap.remove(PROMOTIONAL_BALANCE_TOTAL);
		}
		totalTable = addTotalRowNoBorder("", totalTable);
		totalTable = addTotalRowNoBorder("", totalTable);
		totalTable = addTotalRowNoBorder("", totalTable);
		totalTable = addTotalRowNoBorder("", totalTable);
		totalTable = addGrandTotalRow("Grand Total", totalTable);
		totalTable = addGrandTotalRow("$" + df.format(currentBillingTotal), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(currentBalanceTotal), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDue30Total), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDue60Total), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDue90Total), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDue120Total), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(pastDueTotal), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(totalDueAmt), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(disputeTotal), totalTable);
		totalTable = addGrandTotalRow("$" + df.format(promotionalBalanceTotal), totalTable);
		document.add(totalTable);
	}

	private PdfPTable addGrandTotalRow(String label, PdfPTable totalTable) {
		PdfPCell totalSystemCell = new PdfPCell(new Paragraph(label, boldFont));
		totalSystemCell.setBorderColor(BaseColor.DARK_GRAY);
		totalSystemCell.setBorder(Rectangle.NO_BORDER);
		totalSystemCell.enableBorderSide(Rectangle.TOP);
		totalSystemCell.enableBorderSide(Rectangle.BOTTOM);
		totalSystemCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalSystemCell.setPadding(10f);
		totalSystemCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		totalTable.addCell(totalSystemCell);
		return totalTable;
	}

	private PdfPTable addTotalRow(String label, PdfPTable totalTable) {
		PdfPCell totalSystemCell = new PdfPCell(new Paragraph(label, boldFont));
		totalSystemCell.setBorderColor(BaseColor.DARK_GRAY);
		totalSystemCell.setBorder(Rectangle.TOP);
		totalSystemCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalSystemCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		totalTable.addCell(totalSystemCell);
		return totalTable;
	}

	private PdfPTable addTotalRowNoBorder(String label, PdfPTable totalTable) {
		PdfPCell totalSystemCell = new PdfPCell(new Paragraph(label, boldFont));
		totalSystemCell.setBorder(Rectangle.NO_BORDER);
		totalTable.addCell(totalSystemCell);
		return totalTable;
	}

	@Override
	public boolean validateCustCopyReportRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getCustomerName())
				&& StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateMyCustomerReportRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& StringUtils.isNotEmpty(userDetails.getFirstName())
				&& userDetails.getCustomerType()!=null
				&& StringUtils.isNotEmpty(userDetails.getRegion())) {
			response = true;
		}
		return response;
	}

	@Override
	public ByteArrayInputStream generateMyCustomerReport(UserDetails userDetails, Map<Object, Object> responseMap) {
		Document document = new Document(PageSize.A4, 36, 36, 100, 50);
		Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
		try (FileOutputStream out = new FileOutputStream(MY_CUSTOMER_REPORT + userDetails.getUserLoginCd() + ".pdf")) {

			PdfWriter writer = PdfWriter.getInstance(document, out);
			document.setPageSize(rectangle);

			MyCustomerHeaderFooterPageEvent event = new MyCustomerHeaderFooterPageEvent();
			String grpSelected = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
			String userName = userDetails.getLastName() + (StringUtils.isNotEmpty(userDetails.getLastName()) ? "," : "")
					+ userDetails.getFirstName();
			event.setHeader(userDetails.getBillingPeriod(), "('" + grpSelected + "')", userName,
					userDetails.getRegion());

			writer.setPageEvent(event);
			document.open();
			document.setMargins(36, 36, 100, 50);
			List<MyCustomerDetails> myCustomerDetails = myCustomerDetailsRepository.getCustomerDetailsPersonal(
					grpSelected, userDetails.getRegion(), userDetails.getBillingPeriod(), userDetails.getUserLoginCd(),
					userDetails.getEnteredValue());
			if (!CollectionUtils.isEmpty(myCustomerDetails)) {

				addMyCustomerContent(myCustomerDetails, document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				document.add(Chunk.NEWLINE);
				responseMap.remove("msg");
			}

			document.close();
			writer.close();

			Path path = Paths.get(MY_CUSTOMER_REPORT + userDetails.getUserLoginCd() + ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(MY_CUSTOMER_REPORT + userDetails.getUserLoginCd() + ".pdf");
		}
		return null;
	}

	private void addMyCustomerContent(List<MyCustomerDetails> myCustomerDetailsList, Document document)
			throws DocumentException {
		for (MyCustomerDetails myCustomer : myCustomerDetailsList) {

			PdfPTable table = new PdfPTable(6);

			float[] columnWidths = { 2f, 1f, 1f, 1f, 1f, 1f };

			table.setWidths(columnWidths);
			table.setWidthPercentage(96);

			PdfPCell cell3 = new PdfPCell(new Paragraph(myCustomer.getCustomerLegalNm()));
			cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell3.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell4 = new PdfPCell(new Paragraph("" + myCustomer.getCurrentBillingAmt()));
			cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell4.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell5 = new PdfPCell(new Paragraph("" + myCustomer.getTotalAmt()));
			cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell5.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell6 = new PdfPCell(new Paragraph("" + myCustomer.getDisputedAmt()));
			cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell6.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell7 = new PdfPCell(new Paragraph("" + myCustomer.getCollectable()));
			cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell7.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell8 = new PdfPCell(new Paragraph("" + myCustomer.getPriority()));
			cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell8.setBorder(Rectangle.NO_BORDER);

			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);
			table.addCell(cell8);

			document.add(table);
		}
	}

	@Override
	public ByteArrayInputStream generateCustomerBringupReport(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		Document document = new Document(PageSize.A4, 36, 36, 100, 50);
		Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
		try (FileOutputStream out = new FileOutputStream(
				CUSTOMER_BRINGUP_REPORT + userDetails.getUserLoginCd() + ".pdf")) {

			PdfWriter writer = PdfWriter.getInstance(document, out);
			document.setPageSize(rectangle);

			CustomerBringupHeaderFooterPageEvent event = new CustomerBringupHeaderFooterPageEvent();
			String grpSelected = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
			String userName = userDetails.getLastName() + (StringUtils.isNotEmpty(userDetails.getLastName()) ? "," : "")
					+ userDetails.getFirstName();
			event.setHeader(userDetails.getBillingPeriod(), "('" + grpSelected + "')", userName,
					userDetails.getRegion());

			writer.setPageEvent(event);
			document.open();
			document.setMargins(36, 36, 100, 50);
			List<CustomerBringUpDetails> customerBringupDetails = customerBringUpDetailsRepository
					.getCustomerDetailsBringUp(grpSelected, userDetails.getRegion(), userDetails.getBillingPeriod(),
							userDetails.getUserLoginCd(), userDetails.getEnteredValue(), "C");
			if (!CollectionUtils.isEmpty(customerBringupDetails)) {

				addCustomerBringupContent(customerBringupDetails, document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				document.add(Chunk.NEWLINE);
				responseMap.remove("msg");
			}

			document.close();
			writer.close();

			Path path = Paths.get(CUSTOMER_BRINGUP_REPORT + userDetails.getUserLoginCd() + ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(CUSTOMER_BRINGUP_REPORT + userDetails.getUserLoginCd() + ".pdf");
		}
		return null;
	}

	private void addCustomerBringupContent(List<CustomerBringUpDetails> customerBringupDetailsList, Document document)
			throws DocumentException {
		for (CustomerBringUpDetails customerBringup : customerBringupDetailsList) {

			PdfPTable table = new PdfPTable(5);

			float[] columnWidths = { 2f, 1f, 1f, 1f, 1f };

			table.setWidths(columnWidths);
			table.setWidthPercentage(96);

			PdfPCell cell3 = new PdfPCell(new Paragraph(customerBringup.getCustomerLegalNm()));
			cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell3.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell4 = new PdfPCell(new Paragraph("" + customerBringup.getCommitAmt()));
			cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell4.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell5 = new PdfPCell(new Paragraph("" + customerBringup.getPastDueAmt()));
			cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell5.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell6 = new PdfPCell(new Paragraph("" + customerBringup.getCallbackDate()));
			cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell6.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell7 = new PdfPCell(new Paragraph("" + customerBringup.getPriority()));
			cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell7.setBorder(Rectangle.NO_BORDER);

			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);

			document.add(table);
		}
	}

	@Override
	public ByteArrayInputStream generateAccountBringupReport(UserDetails userDetails, Map<Object, Object> responseMap) {
		Document document = new Document(PageSize.A4, 36, 36, 100, 50);
		Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
		try (FileOutputStream out = new FileOutputStream(
				ACCOUNT_BRINGUP_REPORT + userDetails.getUserLoginCd() + ".pdf")) {

			PdfWriter writer = PdfWriter.getInstance(document, out);
			document.setPageSize(rectangle);

			AccountBringupHeaderFooterPageEvent event = new AccountBringupHeaderFooterPageEvent();
			String grpSelected = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
			String userName = userDetails.getLastName() + (StringUtils.isNotEmpty(userDetails.getLastName()) ? "," : "")
					+ userDetails.getFirstName();
			event.setHeader(userDetails.getBillingPeriod(), "('" + grpSelected + "')", userName,
					userDetails.getRegion());

			writer.setPageEvent(event);
			document.open();
			document.setMargins(36, 36, 100, 50);
			List<AccountsBringUpDetails> accountBringupDetails = accountsBringUpDetailsRepository
					.getAccountDetailsBringUp(grpSelected, userDetails.getRegion(), userDetails.getBillingPeriod(),
							userDetails.getUserLoginCd(), userDetails.getEnteredValue(), "A");
			if (!CollectionUtils.isEmpty(accountBringupDetails)) {

				addAccountBringupContent(accountBringupDetails, document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				document.add(Chunk.NEWLINE);
				responseMap.remove("msg");
			}

			document.close();
			writer.close();

			Path path = Paths.get(ACCOUNT_BRINGUP_REPORT + userDetails.getUserLoginCd() + ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(ACCOUNT_BRINGUP_REPORT + userDetails.getUserLoginCd() + ".pdf");
		}
		return null;
	}
	
	private void addAccountBringupContent(List<AccountsBringUpDetails> accountBringupDetailsList, Document document)
			throws DocumentException {
		for (AccountsBringUpDetails accountBringup : accountBringupDetailsList) {

			PdfPTable table = new PdfPTable(6);

			float[] columnWidths = { 2f, 1f, 1f, 1f, 1f ,1f};

			table.setWidths(columnWidths);
			table.setWidthPercentage(96);

			PdfPCell cell3 = new PdfPCell(new Paragraph(accountBringup.getCustomerLegalNm()));
			cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell3.setBorder(Rectangle.NO_BORDER);
			
			PdfPCell cell4 = new PdfPCell(new Paragraph("" + accountBringup.getAccountNumber()));
			cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell4.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell5 = new PdfPCell(new Paragraph("" + accountBringup.getCommitAmt()));
			cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell5.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell6 = new PdfPCell(new Paragraph("" + accountBringup.getPastDueAmt()));
			cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell6.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell7 = new PdfPCell(new Paragraph("" + accountBringup.getCallbackDate()));
			cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell7.setBorder(Rectangle.NO_BORDER);

			PdfPCell cell8 = new PdfPCell(new Paragraph("" + accountBringup.getPriority()));
			cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell8.setBorder(Rectangle.NO_BORDER);

			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);
			table.addCell(cell8);

			document.add(table);
		}
	}
}
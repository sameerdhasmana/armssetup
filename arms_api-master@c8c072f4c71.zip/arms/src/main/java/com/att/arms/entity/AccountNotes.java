package com.att.arms.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(AccountNotes.AccountNotesId.class)
@Data
public class AccountNotes {

	@Id
	@JsonProperty("notes_id")
	@Column(name="notes_id")
	private Integer notesId;
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@Id
	@JsonProperty("billing_period")
	@Column(name="billing_period")
	private String billingPeriod;
	private Integer resolved;
	@JsonProperty("next_call_back_date")
	@Column(name="next_call_back_date")
	private String nextCallBackDate;
	@JsonProperty("commitment_amt")
	@Column(name="commitment_amt")
	private Double commitmentAmt;
	@JsonProperty("talked_to")
	@Column(name="talked_to")
	private String talkedTo;
	private String notes;
	@JsonProperty("user_login_cd")
	@Column(name="user_login_cd")
	private String userLoginCd;
	@JsonProperty("call_type")
	@Column(name="call_type")
	private String callType;
	@JsonProperty("payment_method")
	@Column(name="payment_method")
	private String paymentMethod;
	@JsonProperty("customer_phone_number")
	@Column(name="customer_phone_number")
	private String customerPhoneNumber;
	@JsonProperty("customer_phone_number_extn")
	@Column(name="customer_phone_number_extn")
	private String customerPhoneNumberExtn;
	@JsonProperty("customer_email")
	@Column(name="customer_email")
	private String customerEmail;
	@JsonProperty("contact_attuid")
	@Column(name="contact_attuid")
	private String contactAttuid;
	@Id
	@JsonProperty("account_number")
	@Column(name="account_number")
	private String accountNumber;
	@JsonProperty("insert_date")
	@Column(name="insert_date")
	private Date insertDate;
	@JsonProperty("logged_by")
	@Column(name="logged_by")
	private String loggedBy;
	@JsonProperty("activity_cd")
	@Column(name="activity_cd")
	private String activityCd;
	@JsonProperty("copy_to_biller")
	@Column(name="copy_to_biller")
	private Integer copyToBiller;
	@JsonProperty("biller_note_perm")
	@Column(name="biller_note_perm")
	private Integer billerNotePerm;
	@JsonProperty("copy_biller_value")
	@Column(name="copy_biller_value")
	private String copyBillerValue;
	private String subdesc;
	@JsonProperty("bring_up_type")
	@Column(name="bring_up_type")
	private String bringUpType;
	@JsonProperty("send_to_adapt")
	@Column(name="send_to_adapt")
	private Integer sendToAdapt;
	@JsonProperty("my_bring_up")
	@Column(name="my_bring_up")
	private Integer myBringUp;
	@Id
	@JsonProperty("originating_system")
	@Column(name="originating_system")
	private String originatingSystem;
	@JsonProperty("contested_amt")
	@Column(name="contested_amt")
	private Double contestedAmt;
	@JsonProperty("root_cause")
	@Column(name="root_cause")
	private String rootCause;
	@JsonProperty("next_action")
	@Column(name="next_action")
	private String nextAction;
	@JsonProperty("commitment_date")
	@Column(name="commitment_date")
	private String commitmentDate;
	
	@SuppressWarnings("serial")
	@Data
	public static class AccountNotesId implements Serializable {

		private Integer notesId;
		private String billingPeriod;
		private String accountNumber;
		private String originatingSystem;

	}
}

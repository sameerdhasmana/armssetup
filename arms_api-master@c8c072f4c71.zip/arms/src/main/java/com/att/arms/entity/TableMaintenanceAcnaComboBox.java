package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class TableMaintenanceAcnaComboBox {

	@Id
	@JsonProperty("customerLegalNm")
	@Column(name = "customer_legal_nm")
	private String customerLegalNm;
	@JsonProperty("customerGrpCd")
	@Column(name = "customer_grp_cd")
	private String customerGrpCd;
}

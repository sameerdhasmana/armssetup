package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.SegmentMaintenanceBusGroup;

@Transactional
public interface SegmentMaintenanceBusUnitRepository extends JpaRepository<SegmentMaintenanceBusGroup, String> {

	@Query(value = "Exec arms_business_group_all_list_v22 :user_login_id", nativeQuery = true)
	public List<SegmentMaintenanceBusGroup> fetchSegmentMaintenanceBusUnitGrp(@Param("user_login_id") String userLoginId);
}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.ProfileDetails;

@Transactional
public interface ProfileDetailsRepository extends JpaRepository<ProfileDetails, String> {

	@Query(value = "EXEC arms_profmgt_sortord_list_v19 :userLoginCd,'','' ", nativeQuery = true)
	public List<ProfileDetails> getProfileDetails(@Param("userLoginCd") String userLoginCd);

	@Query(value = "EXEC arms_profmgt_isrt_updt_v22 :userLoginCd,:action,:prfl_type,:prfl_name,"
			+ ":prfl_owner,:prfl_qry_type,:prfl_qry_cust_grp_cd,:prfl_qry_acna,:prfl_qry_aecn,"
			+ ":prfl_qry_ocn,:prfl_qry_ctc,:prfl_qry_bill_nm,:prfl_excl_incl,:prfl_excl_stat,"
			+ ":prfl_orig_sys,:group,:prfl_acct_stat,:prfl_segment_cd,:prfl_rutp_ind,:prfl_brngup_dt_ref,"
			+ ":prfl_brngup_type,:prfl_flag_act_list,:prfl_flag_desc_list,:prfl_flag_dt_ref,:prfl_amt_type"
			+ ",:mprfl_amt_operator,:prfl_amt_value,:prfl_disp_amt_ref,:prfl_ctstd_amt_ref,:prfl_unapp_amt_operator,"
			+ ":prfl_unapp_amt_value,:prfl_usr_assgnmt_ind,:prfl_sort1_field,:prfl_sort1_order"
			+ ",:prfl_sort2_field,:prfl_sort2_order,:prfl_sort3_field,:prfl_sort3_order"
			+ ",:prfl_sort4_field,:prfl_sort4_order,:prfl_sort5_field,:prfl_sort5_order,:prfl_h1_logins ", nativeQuery = true)
	public String saveManageProfile(@Param("userLoginCd") String userLoginCd, @Param("action") String action,
			@Param("prfl_type") String prflType, @Param("prfl_name") String prflName,
			@Param("prfl_owner") String prflOwner, @Param("prfl_qry_type") String prflQryType,
			@Param("prfl_qry_cust_grp_cd") String prflQryCustGrpCd, @Param("prfl_qry_acna") String prflQryAcna,
			@Param("prfl_qry_aecn") String prflQryAecn, @Param("prfl_qry_ocn") String prflQryOcn,
			@Param("prfl_qry_ctc") String prflQryCtc, @Param("prfl_qry_bill_nm") String prflQryBillNm,
			@Param("prfl_excl_incl") String prflExclIncl, @Param("prfl_excl_stat") String prflExclStat,
			@Param("prfl_orig_sys") String prflOrigSys, @Param("group") String group,
			@Param("prfl_acct_stat") String prflAcctStat, @Param("prfl_segment_cd") String prflSegmentCd,
			@Param("prfl_rutp_ind") String prflRutpInd, @Param("prfl_brngup_dt_ref") String prflBrngupDtRef,
			@Param("prfl_brngup_type") String prflBrngupType, @Param("prfl_flag_act_list") String prflFlagActList,
			@Param("prfl_flag_desc_list") String prflFlagDescList, @Param("prfl_flag_dt_ref") String prflFlagDtRef,
			@Param("prfl_amt_type") String prflAmtType, @Param("mprfl_amt_operator") String mprflAmtOperator,
			@Param("prfl_amt_value") Double prflAmtValue, @Param("prfl_disp_amt_ref") String prflDispAmtRef,
			@Param("prfl_ctstd_amt_ref") String prflCtstdAmtRef,
			@Param("prfl_unapp_amt_operator") String prflUnappAmtOperator,
			@Param("prfl_unapp_amt_value") Double prflUnappAmtValue,
			@Param("prfl_usr_assgnmt_ind") String prflUsrAssgnmtInd, @Param("prfl_sort1_field") String prflSort1Field,
			@Param("prfl_sort1_order") String prflSort1Order, @Param("prfl_sort2_field") String prflSort2Field,
			@Param("prfl_sort2_order") String prflSort2Order, @Param("prfl_sort3_field") String prflSort3Field,
			@Param("prfl_sort3_order") String prflSort3Order, @Param("prfl_sort4_field") String prflSort4Field,
			@Param("prfl_sort4_order") String prflSort4Order, @Param("prfl_sort5_field") String prflSort5Field,
			@Param("prfl_sort5_order") String prflSort5Order, @Param("prfl_h1_logins") String prflH1Logins);

	@Modifying
	@Query(value = "EXEC arms_profmgt_set_default_v19 :userLoginCd,:profileName,:profileType", nativeQuery = true)
	public void setDefaultProfile(@Param("userLoginCd") String userLoginCd, @Param("profileName") String profileName,
			@Param("profileType") String profileType);

	@Modifying
	@Query(value = "EXEC arms_profmgt_delete_v19 :userLoginCd,:profileName,:profileType", nativeQuery = true)
	public void deleteProfile(@Param("userLoginCd") String userLoginCd, @Param("profileName") String profileName,
			@Param("profileType") String profileType);

}

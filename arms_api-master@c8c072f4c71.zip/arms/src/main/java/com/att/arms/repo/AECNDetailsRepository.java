package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.AECNDetails;
@Transactional
public interface AECNDetailsRepository extends JpaRepository<AECNDetails, String> {
	
	@Query(value = "EXEC arms_custqry_aecn_query_for_lb_v22 :group ,:strVal", nativeQuery = true)
	public List<AECNDetails> getAecnDetails(@Param("group") String group, @Param("strVal") String strVal);

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.ContestedAmtView;

@Transactional
public interface ContestedAmtViewRepository extends JpaRepository<ContestedAmtView, String> {

	@Query(value = "exec arms_contested_amt_view_v19 :accountNumber,:originatingSystem,:userLoginCd", nativeQuery = true)
	public List<ContestedAmtView> getContestedAmtViewList(@Param("accountNumber") String accountNumber,
			@Param("originatingSystem") String originatingSystem,@Param("userLoginCd") String userLoginCd);

}

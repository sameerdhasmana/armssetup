package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class Manager {

	@Id
	@JsonProperty("manager_uid")
	@Column(name="h2uid")
	private String managerUid;

}

package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.reports.entity.MaintainanceReportAllCustomerQDSODetails;
import com.att.arms.reports.repo.MaintenanceReportsAllCustomerQDSORepository;
import com.itextpdf.text.DocumentException;

@Service
public class MaintenanceExcelReportsServiceImpl implements MaintenanceExcelReportsService {
	
	@Autowired
	MaintenanceReportsAllCustomerQDSORepository maintenanceReportsAllCustomerQDSORepository;

	
	@SuppressWarnings("unused")
	@Override
	public ByteArrayInputStream createExcelWithDbData(String billingPeriod, String originatingSystem,
			String reportStatus, Map<Object, Object> responseMap) throws DocumentException, FileNotFoundException {

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		List<MaintainanceReportAllCustomerQDSODetails> allCustomerQdsoDetailsList = null;
			
		allCustomerQdsoDetailsList = maintenanceReportsAllCustomerQDSORepository
				.findMaintainanceReportAllCustomerQDSODetailsList(billingPeriod, originatingSystem, reportStatus);
 		try (Workbook allCustomerDetailsSheetWorkbook = new XSSFWorkbook()) {
			Sheet allCustomerDetailsSheet = allCustomerDetailsSheetWorkbook.createSheet("AllCustomerQ-DSODetails");

			if (allCustomerQdsoDetailsList != null) {

				addHeaderContent(allCustomerDetailsSheet, allCustomerDetailsSheetWorkbook);
				addActualContent(allCustomerQdsoDetailsList, allCustomerDetailsSheet, allCustomerDetailsSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			allCustomerDetailsSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void addActualContent(List<MaintainanceReportAllCustomerQDSODetails> allCustomerQDSODetailsList,
			Sheet allCustomerDetailsSheet, Workbook allCustomerDetailsSheetWorkbook) {

		CellStyle dataCellStyleBlack = allCustomerDetailsSheetWorkbook.createCellStyle();
		CellStyle dataCellStyleRed = allCustomerDetailsSheetWorkbook.createCellStyle();
		Font blackColorFont = allCustomerDetailsSheetWorkbook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        dataCellStyleBlack.setFont(blackColorFont);
        
        Font redColorFont = allCustomerDetailsSheetWorkbook.createFont();
        redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);
        
		Row dataRow ;

		double currentBilling = 0;
		double pastDue0Amt = 0;
		double pastDue30Amt = 0;
		double pastDue60Amt = 0;
		double pastDue90Amt = 0;
		double pastDue120Amt = 0;
		double pastDueAmt = 0;
		double totalDueAmt = 0;
		double dispute = 0;
		double qdso = 0;

		for (int i = 0; i < allCustomerQDSODetailsList.size(); i++) {
			dataRow = allCustomerDetailsSheet.createRow(i + 1);
		CellStyle styleCurrencyFormat = allCustomerDetailsSheetWorkbook.createCellStyle();
		styleCurrencyFormat.setDataFormat((short)8);
			
			

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(allCustomerQDSODetailsList.get(i).getBusUnitCd());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(allCustomerQDSODetailsList.get(i).getOriginatingCompanyCd());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(allCustomerQDSODetailsList.get(i).getSegmentCd());
			cell3.setCellStyle(dataCellStyleBlack);

			currentBilling=allCustomerQDSODetailsList.get(i).getCurrentBillingAmt();
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(currentBilling);
			cell4.setCellStyle(currentBilling>0?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);


			pastDue0Amt=allCustomerQDSODetailsList.get(i).getPastDue0Amt();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(pastDue0Amt);
			cell5.setCellStyle(pastDue0Amt>0?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);


			pastDue30Amt=allCustomerQDSODetailsList.get(i).getPastDue30Amt();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue30Amt);
			cell6.setCellStyle(pastDue30Amt>0?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);


			pastDue60Amt=allCustomerQDSODetailsList.get(i).getPastDue60Amt();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue60Amt);
			cell7.setCellStyle(pastDue60Amt>0?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);


			pastDue90Amt=allCustomerQDSODetailsList.get(i).getPastDue90Amt();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue90Amt);
			cell8.setCellStyle(pastDue90Amt>0?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);


			pastDue120Amt=allCustomerQDSODetailsList.get(i).getPastDue120Amt();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue120Amt);
			cell9.setCellStyle(pastDue120Amt>0?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);


			pastDueAmt=allCustomerQDSODetailsList.get(i).getPastDueAmt();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(pastDueAmt);
			cell10.setCellStyle(pastDueAmt>0?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);


			totalDueAmt=allCustomerQDSODetailsList.get(i).getTotalAmt();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(totalDueAmt);
			cell11.setCellStyle(totalDueAmt>0?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);


			dispute=allCustomerQDSODetailsList.get(i).getDispute();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(dispute);
			cell12.setCellStyle(dispute>0?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);


			qdso=allCustomerQDSODetailsList.get(i).getQdso();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(qdso);
			cell13.setCellStyle(qdso>0?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);

			allCustomerDetailsSheet.setColumnWidth(i,allCustomerDetailsSheet.getColumnWidth(i)*23/10);
	        
			
		}
	}

	private void addHeaderContent(Sheet allCustomerDetailsSheet, Workbook allCustomerDetailsSheetWorkbook) {
		Row row = allCustomerDetailsSheet.createRow(0);
		CellStyle headerCellStyle = allCustomerDetailsSheetWorkbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.GROUP);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.REGION);
		cell2.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.SEGMENT);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.PAST_DUE_0_DAYS);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.TOTAL_DUE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.DISPUTE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.QDSO);
		cell13.setCellStyle(headerCellStyle);
		
		 allCustomerDetailsSheet.createFreezePane(1, 1);
	}
}

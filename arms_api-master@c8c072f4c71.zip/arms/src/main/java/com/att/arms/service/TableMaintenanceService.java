package com.att.arms.service;

import java.util.Map;

import com.att.arms.entity.TableMaintenanceModel;

public interface TableMaintenanceService {

	boolean validateQueryRequest(TableMaintenanceModel tableMaintModel);

	boolean validateSegmentUpdateQueryRequest(TableMaintenanceModel segmentUpdateModel);

	public Map<Object, Object> fetchMessage(Map<Object, Object> responseMap);

	Map<Object, Object> getCustomerInfo(Map<Object, Object> responseMap);

	Map<Object, Object> getCustomerUsage(TableMaintenanceModel tableMaintModel, Map<Object, Object> responseMap);

	Map<Object, Object> modifyMenuMsg(TableMaintenanceModel tableMaintModel, Map<Object, Object> responseMap);

	Map<Object, Object> fetchCustMaintenance(TableMaintenanceModel tableMaintModel, Map<Object, Object> responseMap);

	Map<Object, Object> fetchSegmentMaintenance(TableMaintenanceModel tableMaintModel, Map<Object, Object> responseMap);

	Map<Object, Object> getAcnaMaintRecords(TableMaintenanceModel tableMaintModel, Map<Object, Object> responseMap);

	Map<Object, Object> getAecnMaintRecords(TableMaintenanceModel tableMaintModel, Map<Object, Object> responseMap);
	
	Map<Object, Object> segmentUpdate(TableMaintenanceModel segmentUpdateModel, Map<Object, Object> responseMap);

}

package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(CPPODetails.CPPODetailsId.class)
@Data
public class CPPODetails {

	@JsonProperty("billing_period")
	@Column(name="billing_period")
	private String billingPeriod;
	@Id
	@JsonProperty("originating_system")
	@Column(name="originating_system")
	private String originatingSystem;
	@JsonProperty("state_cd")
	@Column(name="state_cd")
	private String stateCd;
	@JsonProperty("segment_cd")
	@Column(name="segment_cd")
	private String segmentCd;
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("customer_legal_nm")
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	@JsonProperty("status_cd")
	@Column(name="status_cd")
	private String statusCd;
	@JsonProperty("acna_cd")
	@Column(name="acna_cd")
	private String acnaCd;
	@Id
	@JsonProperty("account_number")
	@Column(name="acct_nbr")
	private String accountNumber;
	private Double currentBillingAmt;
	private Double totalAmt;
	@JsonProperty("customer_nm")
	@Column(name="customer_nm")
	private String customerNm;
	private Double pastDueAmt;
	private Double disputeAmt;
	

	@SuppressWarnings("serial")
	@Data
	public static class CPPODetailsId implements Serializable {

		private String accountNumber;
		private String originatingSystem;
		
	}
}

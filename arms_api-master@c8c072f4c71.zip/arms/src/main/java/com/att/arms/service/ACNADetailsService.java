package com.att.arms.service;

import java.util.List;
import java.util.Map;

import com.att.arms.entity.ACNADetails;
import com.att.arms.entity.AECNDetails;
import com.att.arms.entity.CTCDetails;
import com.att.arms.entity.OCNDetails;
import com.att.arms.entity.UserDetails;

public interface ACNADetailsService {

	public List<ACNADetails> getACNADetails(String group, String strVal);

	public List<AECNDetails> getAECNDetails(String group, String strVal);

	public List<CTCDetails> getCTCDetails(String group, String strVal);

	public List<OCNDetails> getOCNDetails(String group, String strVal);

	boolean validateQueryRequest(UserDetails userDetails);

	Map<Object, Object> getQueryResponse(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> populateACNA(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateACNAInvoiceQueryRequest(UserDetails userDetails);

	Map<Object, Object> populateACNAInvoiceView(UserDetails userDetails, Map<Object, Object> responseMap);

	String getACNASubType(Integer tabCode);

	String getACNACriteriaType(Integer tabCode);

	Map<Object, Object> getSummaryResponse(UserDetails userDetails, Map<Object, Object> responseMap);
}

package com.att.arms.service;

import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface AccountsService {

	boolean validateQueryRequest(UserDetails userDetails);

	Map<Object, Object> getAIFCustomerInfo(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateAIFCustomerInfo(UserDetails userDetails);

	Map<Object, Object> getAIFAlternateBillperiodGroup(UserDetails userDetails, Map<Object, Object> responseMap);
	
	Map<Object, Object> getCommitmentHistory(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> closeCommitmentHistory(UserDetails userDetails, Map<Object, Object> responseMap);
	
	boolean validateCloseQueryRequest(UserDetails userDetails);

	Map<Object, Object> getAIFValidCheck(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getAIFCollectionUserId(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getAIFCustomerDetails(Map<Object, Object> responseMap, UserDetails userDetails);
}

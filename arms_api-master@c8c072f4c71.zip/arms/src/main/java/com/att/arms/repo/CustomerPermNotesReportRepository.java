package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerPermNotesReport;

@Transactional
public interface CustomerPermNotesReportRepository extends JpaRepository<CustomerPermNotesReport, String> {

	@Query(value = "exec arms_rpt_perm_notes :customerGrpCd", nativeQuery = true)
	public List<CustomerPermNotesReport> getCustomerPermNotesReport(@Param("customerGrpCd") String customerGrpCd);

}

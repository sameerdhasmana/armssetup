package com.att.arms.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.ManageProfileDetails;

@Transactional
public interface ManageProfileDetailsRepository extends JpaRepository<ManageProfileDetails, String> {

	@Query(value = "exec arms_profmgt_init_v22 :userLoginCd,:profileName,:profileType", nativeQuery = true)
	public ManageProfileDetails getManageProfileDetails(@Param("userLoginCd") String userLoginCd,
			@Param("profileName") String profileName, @Param("profileType") String profileType);
}

package com.att.arms.service;

import java.util.List;
import java.util.Map;

import com.att.arms.entity.AccountsBringUpDetails;
import com.att.arms.entity.CustomerAgedDetails;
import com.att.arms.entity.CustomerBringUpDetails;
import com.att.arms.entity.CustomerDetails;
import com.att.arms.entity.InvoiceViewDetails;
import com.att.arms.entity.MyCustomerDetails;
import com.att.arms.entity.UserDetails;

public interface CustomerDetailsService {

	public List<CustomerDetails> getCustomerDetails(String billingPeriod, String group, String strVal);

	public List<MyCustomerDetails> getCustomerDetailsPersonal(String group, String region, String billingPeriod,
			String userLoginCode, String strVal);

	public List<CustomerBringUpDetails> getCustomerDetailsBringUp(String group, String region, String billingPeriod,
			String userLoginCode, String strVal, String bringUpType);

	public List<AccountsBringUpDetails> getAccountDetailsBringUp(String group, String region, String billingPeriod,
			String userLoginCode, String strVal, String bringUpType);

	boolean validateQueryRequest(UserDetails userDetails);

	Map<Object, Object> getQueryResponse(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> populateCustomers(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateInvoiceQueryRequest(UserDetails userDetails);

	Map<Object, Object> populateInvoiceView(UserDetails userDetails, Map<Object, Object> responseMap);

	String getCustomerType(Integer customerCode);

	public Map<Object, Object> getsingleCustomerSummary(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> viewInternalContacts(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getEmaorView(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateViewQueryRequest(UserDetails userDetails);

	public List<CustomerAgedDetails> getCustomerAgedDetails(String profileName, String profileType,
			String strStateClause, String strOriginatingCompanyCD, String strQueryType, String strGroup,
			String strCustomerGrpCd, String strUserLoginCode, String strBillingPeriod, String strStatusClause,
			String strAccountStatusClause, String strClassClause, String strSegmentClause,
			String strOriginatingSystemClause, String myacctNbr, String rollupFlag, String acctInvFlag);
	
	public List<InvoiceViewDetails> getInvoiceViewDetails(String profileName, String profileType,
			String strStateClause, String strOriginatingCompanyCD, String strQueryType, String strGroup,
			String strCustomerGrpCd, String strUserLoginCode, String strBillingPeriod, String strStatusClause,
			String strAccountStatusClause, String strClassClause, String strSegmentClause,
			String strOriginatingSystemClause, String myacctNbr, String rollupFlag, String acctInvFlag);

	public Map<Object, Object> accountPastDue(String accountNumber, String acntNoteOrgSys,
			Map<Object, Object> responseMap);

	public Map<Object, Object> cashDataDetails(String accountNumber, Integer byPayment, Integer byAdjustment,
			String acntNoteOrgSys, Map<Object, Object> responseMap);

	public Map<Object, Object> breakdownDetails(String accountNumber, String acntNoteOrgSys,
			Map<Object, Object> responseMap);

	public Map<Object, Object> taxiClaimDetails(String accountNumber, String acntNoteOrgSys,
			Map<Object, Object> responseMap);

	public Map<Object, Object> getCustAPSubGrp(UserDetails userDetails, Map<Object, Object> responseMap);

	public boolean validatesubGrp(UserDetails userDetails);

	public Map<Object, Object> apSubGroupUpdate(UserDetails userDetails, Map<Object, Object> responseMap);
}

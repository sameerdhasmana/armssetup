package com.att.arms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.entity.GlobalLogonUsers;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.UserService;

@RestController
@CrossOrigin("*")
@RequestMapping(value="/api/")
public class UserController {

	@Autowired
	UserService userService;

	@PostMapping("/login/getUserDetails")
	public ResponseEntity<GlobalLogonUsers> getUserDetails(@RequestBody UserDetails userDetails) {
		boolean validUserDetails = this.userService.validateUser(userDetails);
		GlobalLogonUsers response = new GlobalLogonUsers();
		if (validUserDetails) {

			response = this.userService.findUserDetails(userDetails.getUserLoginCd(), userDetails.getAppName(),
					userDetails.getEnvironment(), userDetails.getUserPcName(), userDetails.getUserPcLoginId(),
					userDetails.getUserPcIp(), 0);
			if (response != null) {
				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		}
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("validateUser")
	public ResponseEntity<Boolean> validateUser(@RequestBody UserDetails userDetails) {
		boolean validUserDetails = this.userService.validateUser(userDetails);
		if (validUserDetails) {
			GlobalLogonUsers glUser = this.userService.findUserDetails(userDetails.getUserLoginCd(),
					userDetails.getAppName(), userDetails.getEnvironment(), userDetails.getUserPcName(),
					userDetails.getUserPcLoginId(), userDetails.getUserPcIp(), 0);

			if (glUser != null) {
				return new ResponseEntity<>(true, HttpStatus.OK);
			}

		}
		return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
	}

}

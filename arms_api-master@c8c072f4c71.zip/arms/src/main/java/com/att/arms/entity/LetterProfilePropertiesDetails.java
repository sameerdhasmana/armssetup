package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class LetterProfilePropertiesDetails {
	@Id
	@JsonProperty("letterProfileFieldId")
	@Column(name = "letter_profile_field_id")
	private Integer letterProfileFieldId;
	@JsonProperty("fieldEditable")
	@Column(name = "field_editable")
	private String fieldEditable;
	@JsonProperty("fieldRequired")
	@Column(name = "field_required")
	private String fieldRequired;
	@JsonProperty("fieldPrepopulated")
	@Column(name = "field_prepopulated")
	private String fieldPrepopulated;
}
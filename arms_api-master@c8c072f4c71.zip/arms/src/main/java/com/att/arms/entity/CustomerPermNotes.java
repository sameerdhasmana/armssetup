package com.att.arms.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Entity
@IdClass(CustomerPermNotes.CustomerPermNotesId.class)
@Data
public class CustomerPermNotes {

	@Id
	private Integer notesId;
	@Id
	private String billingPeriod;
	@JsonFormat(pattern = "MM/dd/yyyy hh:mm:ss aa")
	private Date insertDate;
	@Id
	private String customerGrpCd;
	private Integer resolved;
	private Double commitmentAmount;
	private String talkedTo;
	private String notes;
	private String bringUpDate;
	private String userLoginCd;
	private String loggedBy;
	
	
	@SuppressWarnings("serial")
	@Data
	public static class CustomerPermNotesId implements Serializable {

		private Integer notesId;
		private String billingPeriod;
		private String customerGrpCd;

	}
}

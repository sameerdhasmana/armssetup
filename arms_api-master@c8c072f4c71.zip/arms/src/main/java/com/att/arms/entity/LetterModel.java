package com.att.arms.entity;

import java.util.List;

import lombok.Data;

@Data
public class LetterModel {

	private String userLoginCd;
	private String letterProfileName;
	private String letterProfilesDesc;
	private String letterTypeId;
	private String acctApplicability;
	private String returnAddrId;
	private List<String> segment;
	private List<String> originatingSystem;
	private List<LetterProfileModel> letterProfileList;
	private Integer blank;
	private List<String> groupSelected;
	private List<String> busUnitCdList;
	private List<String> stateCdList;
	private Integer letterProfilesId;
	private List<String> letterProfilesIdList;


}

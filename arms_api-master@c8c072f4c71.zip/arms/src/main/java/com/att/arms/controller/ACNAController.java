package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.ACNADetailsService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class ACNAController {

	@Autowired
	ACNADetailsService acnaDetailsService;

	@PostMapping("submitACNAQuery")
	public ResponseEntity<Object> submitACNAQuery(@RequestBody UserDetails userDetails) {
		boolean response = this.acnaDetailsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.acnaDetailsService.getQueryResponse(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("populateACNA")
	public ResponseEntity<Object> populateACNA(@RequestBody UserDetails userDetails) {
		boolean response = this.acnaDetailsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.acnaDetailsService.populateACNA(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);

		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("acnaInvoiceView")
	public ResponseEntity<Object> invoiceView(@RequestBody UserDetails userDetails) {
		boolean response = this.acnaDetailsService.validateACNAInvoiceQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.acnaDetailsService.populateACNAInvoiceView(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	// ACNA FOR SUMMERY
	@PostMapping("summaryACNAQuery")
	public ResponseEntity<Object> summaryACNAQuery(@RequestBody UserDetails userDetails) {
		boolean response = this.acnaDetailsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.acnaDetailsService.getSummaryResponse(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
}

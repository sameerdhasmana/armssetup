package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.FilterResponse;
import com.att.arms.entity.HeaderDetails;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.FilterService;
import com.att.arms.service.UserService;
import com.att.arms.utils.CommonUtils;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class FilterController {

	@Autowired
	UserService userService;
	@Autowired
	FilterService filterService;
	

	@PostMapping("populateFilter")
	public ResponseEntity<FilterResponse> populateFilter(@RequestBody UserDetails userDetails) {
		userDetails = CommonUtils.getCurrentUserDetails(userDetails.getUserLoginCd(), userDetails.getEnvironment(),
				userDetails.getAppName(), userDetails);
		boolean validUserDetails = this.userService.validateUser(userDetails);
		FilterResponse filter = new FilterResponse();
		
		if (validUserDetails) {
			filter = this.filterService.populateFilter(filter, userDetails);
			if (StringUtils.isEmpty(filter.getErrorMsg())) {
				return new ResponseEntity<>(filter, HttpStatus.OK);
			}
		}
		filter.setErrorMsg("Invalid User");
		return new ResponseEntity<>(filter, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("repopulateFilter")
	public ResponseEntity<FilterResponse> rePopulateFilter(@RequestBody UserDetails userDetails) {
		FilterResponse filter = new FilterResponse();
		if (!CollectionUtils.isEmpty(userDetails.getGroupSelected())) {
			filter = this.filterService.rePopulateFilter(filter, userDetails);
			return new ResponseEntity<>(filter, HttpStatus.OK);
		} else {
			filter.setErrorMsg("No Group Selected");
			return new ResponseEntity<>(filter, HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("saveHeaderParameters")
	public ResponseEntity<Object> saveHeaderParameters(@RequestBody HeaderDetails headerDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.filterService.validateHeaderRequest(headerDetails);
		if (response) {
			responseMap = this.filterService.saveHeaderParameters(responseMap, headerDetails);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("resetColumnOrder")
	public ResponseEntity<Object> resetColumnOrder(@RequestBody HeaderDetails headerDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.filterService.validateResetColumnOrderRequest(headerDetails);
		if (response) {
			responseMap = this.filterService.resetColumnOrder(responseMap, headerDetails);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
}

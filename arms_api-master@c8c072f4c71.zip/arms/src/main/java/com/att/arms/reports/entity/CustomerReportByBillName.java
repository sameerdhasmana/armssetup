package com.att.arms.reports.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(CustomerReportByBillName.CustomerReportId.class)
@Data
public class CustomerReportByBillName {

	@JsonProperty("billingPeriod")
	@Column(name = "Billing Period")
	private String billingPeriod;
	
	@Id
	@JsonProperty("customer")
	@Column(name = "Customer")
	private String customer;
	
	@Id
	@JsonProperty("customer_grp_cd")
	@Column(name = "customer_grp_cd")
	private String customerGrpCd;
	
	@Id
	@JsonProperty("Account Number")
	@Column(name = "Account Number")
	private String accountNumber;
	
	@JsonProperty("billName")
	@Column(name = "Bill Name")
	private String billName;	
	@JsonProperty("billDate")
	@Column(name = "Bill Date")
	private Date billDate;

	@JsonProperty("segment")
	@Column(name = "Segment")
	private String segment;

	@JsonProperty("State")
	@Column(name = "state")
	private String state;

	@JsonProperty("acna")
	@Column(name = "ACNA")
	private String acna;

	@JsonProperty("aecn")
	@Column(name = "AECN")
	private String aecn;

	@JsonProperty("ocn")
	@Column(name = "OCN")
	private String ocn;

	@JsonProperty("status")
	@Column(name = "Status")
	private String status;

	@JsonProperty("currentBillingAmount")
	@Column(name = "Current Billing Amount")
	private Double currentBillingAmount;

	@JsonProperty("pastDue0Amount")
	@Column(name = "Past Due 0 Amount")
	private Double pastDue0Amount;

	@JsonProperty("totalPastDue")
	@Column(name = "Total Past Due")
	private Double totalPastDue;

	@JsonProperty("totalAmount")
	@Column(name = "Total Amount")
	private Double totalAmount;

	@JsonProperty("dispute")
	@Column(name = "Dispute")
	private Double dispute;
	

	@JsonProperty("dso")
	@Column(name = "DSO")
	private Integer dso;
	 
	
	@SuppressWarnings("serial")
	@Data
	public static class CustomerReportId implements Serializable {

		private String customerGrpCd;
		private String customer;  
		private String accountNumber;

			
	}

}

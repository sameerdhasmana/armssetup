package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class LetterTypes {
	@Id
	@JsonProperty("letter_type_id")
	@Column(name="letter_type_id")
	private Integer letterTypeId;
	@JsonProperty("letter_type_desc")
	@Column(name="letter_type_desc")
	private String letterTypeDesc;	
}

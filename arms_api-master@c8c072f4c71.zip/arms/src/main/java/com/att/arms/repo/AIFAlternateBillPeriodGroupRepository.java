package com.att.arms.repo;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.att.arms.entity.AIFBillPeriodGroup;

@Transactional
public interface AIFAlternateBillPeriodGroupRepository extends JpaRepository<AIFBillPeriodGroup, String> {

	@Query(value = "Exec arms_custqry_AIF_alternate_billperiod_group_v22 :AcctInvFAN,:indicator, :originating_system, :strLoginCd", nativeQuery = true)
	public List<AIFBillPeriodGroup> getAIFAlternateBillperiodGroup(@Param("AcctInvFAN") String acctInvFAN,
			@Param("indicator") String indicator, @Param("originating_system") String originatingSystem,
			@Param("strLoginCd") String strLoginCd);

	@Query(value = "Exec arms_custqry_AIF_valid_check :AcctInvFAN,:indicator,:originating_system", nativeQuery = true)
	public List<Object[]> getAIFValidCheck(@Param("AcctInvFAN") String acctInvFAN, @Param("indicator") String indicator,
			@Param("originating_system") String originatingSystem);

	@Query(value = "Exec arms_custqry_AIF_collection_userid :AcctInvFAN,:indicator,:originating_system", nativeQuery = true)
	public List<Object[]> getAIFCollectionUserId(@Param("AcctInvFAN") String acctInvFAN,
			@Param("indicator") String indicator, @Param("originating_system") String originatingSystem);
}

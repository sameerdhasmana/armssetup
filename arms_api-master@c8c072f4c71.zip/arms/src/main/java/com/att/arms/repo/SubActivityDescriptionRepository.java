package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.SubActivityDescription;

@Transactional
public interface SubActivityDescriptionRepository extends JpaRepository<SubActivityDescription, String> {

	@Query(value = "exec arms_sub_activity_short_description '1'", nativeQuery = true)
	public List<SubActivityDescription> getAllSubActivityDescription();

	
}

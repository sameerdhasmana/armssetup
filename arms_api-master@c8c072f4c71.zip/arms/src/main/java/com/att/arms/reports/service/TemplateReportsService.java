package com.att.arms.reports.service;

import java.util.Map;

import com.att.arms.reports.entity.TemplateDetailsModel;

public interface TemplateReportsService {

	Map<Object, Object> saveOrUpdateTemplateFile(TemplateDetailsModel templateDetailsModel, Map<Object, Object> responseMap);

	void deleteTemplateFile(String userLoginCd, String updatedType,String reportType, String reportName);

	Map<Object, Object> loadSelectedTemplateFile(String userLoginCd, String reportType, String reportName,
			Map<Object, Object> responseMap);

}

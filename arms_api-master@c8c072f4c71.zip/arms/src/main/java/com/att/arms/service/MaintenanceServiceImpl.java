package com.att.arms.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.APSubGroup;
import com.att.arms.entity.CustomerInfo;
import com.att.arms.entity.MaintenanceContactDetails;
import com.att.arms.entity.MaintenanceFetchAccountAPSubGroup;
import com.att.arms.entity.NotesDetails;
import com.att.arms.entity.NotesTemplate;
import com.att.arms.entity.ProfileManagementUsers;
import com.att.arms.entity.RequestModel;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.APSubGroupRepository;
import com.att.arms.repo.AccountNotesRepository;
import com.att.arms.repo.CustomerInfoRepository;
import com.att.arms.repo.MaintenanceContactDetailsRepository;
import com.att.arms.repo.MaintenanceFetchAccountAPSubGroupRepository;
import com.att.arms.repo.NotesDetailsRepository;
import com.att.arms.repo.NotesTemplateRepository;
import com.att.arms.repo.ProfileManagementUsersRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class MaintenanceServiceImpl implements MaintenanceService {

	@Autowired
	CustomerInfoRepository customerInfoRepository;
	@Autowired
	MaintenanceContactDetailsRepository maintenanceContactDetailsRepository;
	@Autowired
	MaintenanceFetchAccountAPSubGroupRepository maintenanceFetchAccountAPSubGroupRepository;
	@Autowired
	APSubGroupRepository aPSubGroupRepository;
	@Autowired
	AccountNotesRepository accountNotesRepository;
	@Autowired
	ProfileManagementUsersRepository profileManagementUsersRepository;
	@Autowired
	NotesTemplateRepository notesTemplateRepository;
	@Autowired
	NotesDetailsRepository notesDetailsRepository;

	@Override
	public boolean validateDeleteQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd()) && userDetails.getSequence() != null) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSaveQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSubGroupQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getGroup())
				&& StringUtils.isNotEmpty(userDetails.getRegion())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSubGroupGridQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getGroup())
				&& StringUtils.isNotEmpty(userDetails.getRegion())
				&& StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSaveSubGroupGridQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getAccountNumber())
				&& StringUtils.isNotEmpty(userDetails.getAcntNoteOrgSys())
				&& StringUtils.isNotEmpty(userDetails.getApSubGroupName())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> getAllContacts(Map<Object, Object> responseMap) {
		List<CustomerInfo> customerInfo = customerInfoRepository.getAllCustomerInfo();
		if (!CollectionUtils.isEmpty(customerInfo)) {
			responseMap.put(ApplicationConstant.CUSTOMER_INFO, customerInfo);
		}
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateContacts(String customerGrpCd, Map<Object, Object> responseMap) {
		List<MaintenanceContactDetails> contactDetails = maintenanceContactDetailsRepository
				.getMaintenanceContactDetailsList(customerGrpCd);
		if (!CollectionUtils.isEmpty(contactDetails)) {
			responseMap.put(ApplicationConstant.MAINTENANCE_CONTACT_DETAILS, contactDetails);
		}
		return responseMap;
	}

	@Override
	public Map<Object, Object> deleteContacts(String customerGrpCd, String userLoginCd, Integer sequence,
			Map<Object, Object> responseMap) {
		maintenanceContactDetailsRepository.deleteMaintenanceContactDetails(customerGrpCd, sequence, userLoginCd,
				ApplicationConstant.MAINTENANCE_CONTACT_DELETE_PROCESS);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> saveContacts(UserDetails userDetails, Map<Object, Object> responseMap) {
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		if (userDetails.getModeType() != null && userDetails.getModeType().equals(1)) {
			maintenanceContactDetailsRepository.saveContacts(userDetails.getCustomerGrpCd(), userDetails.getFirstName(),
					userDetails.getLastName(), userDetails.getAddress(), userDetails.getCity(), userDetails.getState(),
					userDetails.getZip(), userDetails.getTitle(), userDetails.getPhoneNumber(),
					userDetails.getPhoneNumberExtn(), userDetails.getFaxNumber(), userDetails.getEmail(),
					userDetails.getNotes(), userDetails.getPriority());
		} else if (userDetails.getModeType() != null && userDetails.getModeType().equals(2)) {
			maintenanceContactDetailsRepository.updateContacts(userDetails.getCustomerGrpCd(),
					userDetails.getSequence(), userDetails.getFirstName(), userDetails.getLastName(),
					userDetails.getAddress(), userDetails.getCity(), userDetails.getState(), userDetails.getZip(),
					userDetails.getTitle(), userDetails.getPhoneNumber(), userDetails.getPhoneNumberExtn(),
					userDetails.getFaxNumber(), userDetails.getEmail(), userDetails.getNotes(),
					userDetails.getPriority(), userDetails.getUserLoginCd(),
					ApplicationConstant.MAINTENANCE_CONTACT_MODIFY_PROCESS);
		} else {
			responseMap.remove("msg");
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "Unable to save the records");
		}
		return responseMap;
	}

	@Override
	public Map<Object, Object> renderApSubGroup(String group, String region, Map<Object, Object> responseMap) {
		List<CustomerInfo> customerInfo = customerInfoRepository.getMaintenanceCustList(group);
		List<Object[]> billingPeriodList = maintenanceContactDetailsRepository
				.getMaintenanceSubGroupBillingPeriod(group, region);
		responseMap.put(ApplicationConstant.CUSTOMER_INFO, customerInfo);
		responseMap.put(ApplicationConstant.BILLING_PERIOD, billingPeriodList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> renderApSubGroupGrid(String customerGrpCd, String billingPeriod, String userLoginCd,
			String group, String region, Map<Object, Object> responseMap) {
		List<MaintenanceFetchAccountAPSubGroup> accountDetails = maintenanceFetchAccountAPSubGroupRepository
				.getMaintenanceAccountApSubGroup(customerGrpCd, billingPeriod, userLoginCd, group, region, "", "");
		List<APSubGroup> apSubGroupList = aPSubGroupRepository.getAPSubGroupList(customerGrpCd);
		responseMap.put(ApplicationConstant.AP_SUB_GROUP_GRID, accountDetails);
		responseMap.put(ApplicationConstant.AP_SUB_GROUP, apSubGroupList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> saveApSubGroupGrid(String accountNumber, String apSubGrpName, String userLoginCd,
			String originatingSystem, Map<Object, Object> responseMap) {
		accountNotesRepository.saveAPSubGroup(accountNumber, apSubGrpName, userLoginCd,
				ApplicationConstant.ACCOUNT_AP_SUB_GROUP_MAINTENANCE, originatingSystem);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> manageTemplateNotes(String userLoginCd, Map<Object, Object> responseMap) {
		List<ProfileManagementUsers> userList = profileManagementUsersRepository
				.getProfileManagementUsersList(userLoginCd);
		responseMap.put(ApplicationConstant.ALL_USERS, userList);
		List<NotesTemplate> notesTemplateList = notesTemplateRepository.getNotesTemplateList(userLoginCd);
		responseMap.put(ApplicationConstant.NOTE_TEMPLATE, notesTemplateList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getTemplateDetails(String userLoginCd, String templateName, String templateType,
			Map<Object, Object> responseMap) {
		List<NotesDetails> noteDetails = notesDetailsRepository.getNotesDetails(userLoginCd, templateName,
				templateType);
		responseMap.put(ApplicationConstant.NOTES_DETAILS, noteDetails);
		List<ProfileManagementUsers> userList = profileManagementUsersRepository
				.getProfileManagementUsersList(userLoginCd);
		responseMap.put(ApplicationConstant.ALL_USERS, userList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> deleteTemplate(String userLoginCd, String templateName, String templateType,
			Map<Object, Object> responseMap) {
		String response = notesTemplateRepository.deleteNoteTemplate(userLoginCd, templateName, templateType);
		responseMap.put("msg", response);
		return responseMap;
	}

	@Override
	public boolean validateSaveTemplateQuery(RequestModel requestModel) {
		boolean response = false;
		if (StringUtils.isNotEmpty(requestModel.getUserLoginCd())
				&& StringUtils.isNotEmpty(requestModel.getTemplateName())
				&& StringUtils.isNotEmpty(requestModel.getTemplateType())
				&& StringUtils.isNotEmpty(requestModel.getTemplateNote())
				&& !CollectionUtils.isEmpty(requestModel.getTemplateH1Logins())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> saveTemplate(String userLoginCd, String templateName, String templateType,
			String templateOwner, String templateNote, List<String> templateH1Logins, Map<Object, Object> responseMap) {
		String templateLogins=CommonUtils.getListToCommaSeparatedString(templateH1Logins);
		String response = notesTemplateRepository.saveNoteTemplate(userLoginCd, templateName, templateType,
				templateOwner, templateNote, templateLogins);
		responseMap.put("msg", response);
		return responseMap;
	}

}

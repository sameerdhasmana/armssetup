package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.DispIntervalDetails;

@Transactional
public interface DispIntervalDetailsRepository extends JpaRepository<DispIntervalDetails, String>{
	@Query(value = "EXEC arms_rpt_disp_interval_for_lb_v20" , nativeQuery = true)
	public List<DispIntervalDetails> findDispIntervalList();

}

package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.att.arms.entity.UserDetails;
import com.itextpdf.text.DocumentException;

@Service
public class TemplateReportsPdfServiceImpl implements TemplateReportsPdfService{

	@Override
	public ByteArrayInputStream createPdfWithDbData(UserDetails userDetails, Map<Object, Object> responseMap)
			throws DocumentException, IOException {
		// TODO Auto-generated method stub
		return null;
	}

}

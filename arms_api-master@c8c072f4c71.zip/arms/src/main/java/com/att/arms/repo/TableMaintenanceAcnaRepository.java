package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.TableMaintenanceAcnaComboBox;

@Transactional
public interface TableMaintenanceAcnaRepository extends JpaRepository<TableMaintenanceAcnaComboBox, String> {

	@Query(value = "Exec arms_tblmaint_ACNA_customer_combo", nativeQuery = true)
	public List<TableMaintenanceAcnaComboBox> getMaintAcnaCustomer();

	@Query(value = "Exec arms_maintainance_fetch_customer_lb :user_bus_grp", nativeQuery = true)
	public List<TableMaintenanceAcnaComboBox> getCustomerLb(@Param("user_bus_grp") String userBusGrp);

}

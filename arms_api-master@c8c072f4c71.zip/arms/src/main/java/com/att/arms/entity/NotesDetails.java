package com.att.arms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Entity
public class NotesDetails {

	@Id
	@JsonProperty("nttmplt_id")
	@Column(name="nttmplt_id")
	private Integer nttmpltId;
	@JsonProperty("nttmplt_name")
	@Column(name="nttmplt_name")
	private String nttmpltName;
	@JsonProperty("nttmplt_type")
	@Column(name="nttmplt_type")
	private String nttmpltType;
	@JsonProperty("nttmplt_owner")
	@Column(name="nttmplt_owner")
	private String nttmpltOwner;
	@JsonProperty("nttmplt_tmplt")
	@Column(name="nttmplt_tmplt")
	private String nttmpltTmplt;
	@JsonProperty("nttmplt_h1_logins")
	@Column(name="nttmplt_h1_logins")
	private String nttmpltH1Logins;
	@JsonProperty("nttmplt_last_updt")
	@Column(name="nttmplt_last_updt")
	private Date nttmpltLastUpdt;
	@JsonProperty("nttmplt_last_updt_uid")
	@Column(name="nttmplt_last_updt_uid")
	private String nttmpltLastUpdtUid;

}

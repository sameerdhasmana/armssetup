package com.att.arms.reports.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(CustomerReportByRegionSegmentStatus.CustomerReportId.class)
@Data
public class CustomerReportByRegionSegmentStatus {

	@JsonProperty("billingPeriod")
	@Column(name = "Billing Period")
	private String billingPeriod;

	@Id
	@JsonProperty("customer")
	@Column(name = "Customer")
	private String customer;

	@Id
	@JsonProperty("customer_grp_cd")
	@Column(name = "customer_grp_cd")
	private String customerGrpCd;

	@JsonProperty("region")
	@Column(name = "Region")
	private String region;

	@JsonProperty("segment")
	@Column(name = "Segment")
	private String segment;

	@JsonProperty("status")
	@Column(name = "Status")
	private String status;

	@JsonProperty("currentBillingAmount")
	@Column(name = "Current Billing Amount")
	private Double currentBillingAmount;

	@JsonProperty("pastDue0Amount")
	@Column(name = "Past Due 0 Amount")
	private Double pastDue0Amount;

	@JsonProperty("pastDue30Amount")
	@Column(name = "Past Due 30 Amount")
	private Double pastDue30Amount;

	@JsonProperty("pastDue60Amount")
	@Column(name = "Past Due 60 Amount")
	private Double pastDue60Amount;

	@JsonProperty("pastDue90Amount")
	@Column(name = "Past Due 90 Amount")
	private Double pastDue90Amount;

	@JsonProperty("pastDue120Amount")
	@Column(name = "Past Due 120 Amount")
	private Double pastDue120Amount;

	@JsonProperty("totalPastDue")
	@Column(name = "Total Past Due")
	private Double totalPastDue;

	@JsonProperty("totalAmount")
	@Column(name = "Total Amount")
	private Double totalAmount;

	@JsonProperty("dispute")
	@Column(name = "Dispute")
	private Double dispute;

	@JsonProperty("dso")
	@Column(name = "DSO")
	private Integer dso;

	@SuppressWarnings("serial")
	@Data
	public static class CustomerReportId implements Serializable {

		private String customerGrpCd;
		private String customer;
		private String region;
		private String segment;
		private String status;

	}

}

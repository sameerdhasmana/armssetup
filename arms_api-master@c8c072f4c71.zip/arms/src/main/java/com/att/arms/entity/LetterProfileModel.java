package com.att.arms.entity;

import lombok.Data;

@Data
public class LetterProfileModel {

	private Integer letterProfileFieldId;
	private Integer fieldEditable;
	private Integer fieldRequired;
	private Integer fieldPrepopulated;

}

package com.att.arms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class TaxiClaimDetails {

	@Id
	private String attClaim;
	private String workedBy;
	private String billDate;
	private String custClaimNo;
	private String input;
	private String received;
	private String acknowledge;
	private String followUp;
	private String referred;
	private String referredTo;
	private Double claimed;
	private Double adjNonSO;
	private Double adjSO;
	private Double paidBack;
	private Double denied;
	private Double shortPaid;
	private Double balance;
	private String rejectInd;
	private String jeopardyInd;
	private String pmProjectInd;
	private String audit;
	private String ticket;

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.APSubGroup;

@Transactional
public interface APSubGroupRepository extends JpaRepository<APSubGroup, String> {

	@Query(value = "exec arms_maintenance_fetch_account_ap_sub_group_combo :customerGrpCd", nativeQuery = true)
	public List<APSubGroup> getAPSubGroupList(@Param("customerGrpCd") String customerGrpCd);

}

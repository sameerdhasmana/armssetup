package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class Message {

	@Id
	@JsonProperty("the_msg_id")
	@Column(name="the_msg_id")
	private String theMsgId;
	@JsonProperty("the_msg")
	@Column(name="the_msg")
	private String theMsg;
}

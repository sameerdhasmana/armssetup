package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
@IdClass(NotesTemplate.NotesTemplateId.class)

public class NotesTemplate {

	@Id
	@JsonProperty("template_type")
	@Column(name = "template_type")
	private String templateType;
	@Id
	@JsonProperty("template_name")
	@Column(name = "template_name")
	private String templateName;

	@Data
	public static class NotesTemplateId implements Serializable {

		private static final long serialVersionUID = 1L;
		private String templateName;
		private String templateType;

	}
}

package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class TemplateFieldsDetails {

	@JsonProperty("system")
	@Column(name="system")
	private String system;
	@JsonProperty("parent_table")
	@Column(name="parent_table")
	private String parentTable;
	@JsonProperty("database_name")
	@Column(name="database_name")
	private String databaseName;
	@Id
	@JsonProperty("english_name")
	@Column(name="english_name")
	private String englishName;
	@JsonProperty("report_name1")
	@Column(name="report_name1")
	private String reportName1;
	@JsonProperty("report_name2")
	@Column(name="report_name2")
	private String reportName2;
	@JsonProperty("width")
	@Column(name="width")
	private Double width;
	@JsonProperty("is_section")
	@Column(name="is_section")
	private Double isSection;
	@JsonProperty("is_sum")
	@Column(name="is_sum")
	private Double isSum;
	@JsonProperty("column_type")
	@Column(name="column_type")
	private Double columnType;
	@JsonProperty("alignment_header")
	@Column(name="alignment_header")
	private Double alignmentHeader;
	@JsonProperty("alignment_body")
	@Column(name="alignment_body")
	private Double alignmentBody;
		
}

package com.att.arms.reports.entity;

import java.util.List;

import lombok.Data;
@Data
public class TemplateDetailsModel {
	private String userLoginCd;
	private String reportType;
	private String reportName;
	private String updatedType;
	private String exclusions;
	private String billingPeriod;
	private String customerChildFlag;
	private List<String> exclusionClass;
	private List<String> originatingSystem;
	private List<String> groupSelected;
	private List<String> statusClause;
	private List<String> segment;
	private List<String> templateSelectedFields;
	private List<String> groupByFields;
	private List<String> sortByFields;
	private String sortOrder;
	private List<String> criteriaClause;
	private List<String> originatingCompanyCdClause;
	private List<String> customerGrpCd;
	

}

package com.att.arms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class RepCopy {

	@Id
	@JsonProperty("account_number")
	@Column(name = "acct_nbr")
	private String accountNbr;
	@JsonProperty("originating_system")
	@Column(name = "originating_system")
	private String originatingSystem;
	@JsonProperty("segment_cd")
	@Column(name = "segment_cd")
	private String segmentCd;
	@JsonProperty("state_cd")
	@Column(name = "state_cd")
	private String stateCd;
	@JsonProperty("customer_grp_cd")
	@Column(name = "customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("customer_legal_nm")
	@Column(name = "customer_legal_nm")
	private String customerLegalNm;
	@JsonProperty("billing_period")
	@Column(name = "billing_period")
	private String billingPeriod;
	@JsonProperty("accountNumberCode")
	@Column(name = "acct_nbr_cd")
	private String accountNumberCode;
	@JsonProperty("status_cd")
	@Column(name = "status_cd")
	private String statusCd;
	@JsonProperty("lastBillingDate")
	@Column(name = "last_Billing_dt")
	private Date lastBillingDate;
	@JsonProperty("acna_cd")
	@Column(name = "acna_cd")
	private String acnaCd;
	private Double currentBillingAmt;
	@JsonProperty("pastDue0Amt")
	@Column(name = "Past_Due_0_Amt")
	private Double pastDue0Amt;
	@JsonProperty("pastDue30Amt")
	@Column(name = "Past_Due_30_Amt")
	private Double pastDue30Amt;
	@JsonProperty("pastDue60Amt")
	@Column(name = "Past_Due_60_Amt")
	private Double pastDue60Amt;
	@JsonProperty("pastDue90Amt")
	@Column(name = "Past_Due_90_Amt")
	private Double pastDue90Amt;
	@JsonProperty("pastDue120Amt")
	@Column(name = "Past_Due_120_Amt")
	private Double pastDue120Amt;
	private Double totalAmt;
	private Double pastDueAmt;
	private Double disputeAmt;
	@JsonProperty("customer_nm")
	@Column(name = "customer_nm")
	private String customerNm;
	@JsonProperty("accountNumber")
	@Column(name = "account_Number")
	private String accountNumber;
	@JsonProperty("apSubGrpNm")
	@Column(name = "ap_sub_grp_nm")
	private String apSubGrpNm;
	@JsonProperty("promo_cr")
	@Column(name = "PROMO_CR")
	private Double promoCr;

}

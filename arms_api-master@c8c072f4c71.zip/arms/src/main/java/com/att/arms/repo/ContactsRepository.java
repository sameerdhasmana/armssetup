package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.Contacts;

@Transactional
public interface ContactsRepository extends JpaRepository<Contacts, String> {

	@Query(value = "Exec arms_vc_contacts_search_v19 :fname, :lname, :phone, :email, :hdqtr, :strlogincd", nativeQuery = true)
	public List<Contacts> getSearchContacts(@Param("fname") String fname, @Param("lname") String lname,
			@Param("phone") String phone, @Param("email") String email, @Param("hdqtr") String hdqtr,
			@Param("strlogincd") String strlogincd);

	
}

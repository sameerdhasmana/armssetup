package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class CustomerBillingPeriod {

	@Id
	@JsonProperty("billing_period")
	@Column(name="billing_period")
	private String billingPeriod;

	
}

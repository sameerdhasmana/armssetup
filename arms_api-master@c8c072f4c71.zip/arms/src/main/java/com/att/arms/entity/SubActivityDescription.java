package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class SubActivityDescription {

	@Id
	@JsonProperty("sub_activity_short_description")
	@Column(name = "sub_activity_short_description")
	private String subActivityShortDescription;

}

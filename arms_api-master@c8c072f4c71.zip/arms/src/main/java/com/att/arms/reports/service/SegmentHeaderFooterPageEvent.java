package com.att.arms.reports.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.utils.CommonReportsUtils;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class SegmentHeaderFooterPageEvent extends PdfPageEventHelper {

	private PdfTemplate t;
	private Image total;
	private static final Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 15, Font.BOLD);
	private static final Font boldFont1 = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);
	private static final Font boldFont2 = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);

	UserDetails userDetails;
	String groupByType;
    String billingPeriodHeader;
    String reportType;
    String groupsHeader;
    String regionHeader;
    String statusHeader;
    String segmentHeader;
    String classesHeader;

	public void onOpenDocument(PdfWriter writer, Document document) {
		t = writer.getDirectContent().createTemplate(30, 16);
		try {
			total = Image.getInstance(t);
		} catch (BadElementException e) {
			e.printStackTrace();
		}
		total.setRole(PdfName.ARTIFACT);
	}

	@Override
	public void onEndPage(PdfWriter writer, Document document) {
		addHeader(writer);
		addFooter(writer);
	}

	private void addHeader(PdfWriter writer) {
		try {
			Paragraph billingPeriodAmt = new Paragraph("Billing Period: " + userDetails.getBillingPeriod(), boldFont1);
			Paragraph groups = new Paragraph("Group(s): " + CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), boldFont1);
			Paragraph region = new Paragraph("Region(s): " + CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), boldFont1);
			Paragraph status = new Paragraph("Status: " + CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()), boldFont1);
			Paragraph segment = new Paragraph("Segment(s): " + CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()), boldFont1);
			Paragraph classes = new Paragraph("Class(es): " + userDetails.getExclusions(), boldFont1);
			PdfPTable titleMain = new PdfPTable(3);
			titleMain.setTotalWidth(1150f);
			
			String title = getTitle(reportType, groupByType);
			PdfPCell cell1 = new PdfPCell(
					new Paragraph(title, new Font(Font.FontFamily.TIMES_ROMAN, 30, Font.BOLD)));
		
			PdfPCell cell2 = new PdfPCell(new Paragraph(billingPeriodAmt));
			PdfPCell cell3 = new PdfPCell(new Paragraph(groups));
			PdfPCell cell4 = new PdfPCell(new Paragraph(region));
			PdfPCell cell5 = new PdfPCell(new Paragraph(status));
			PdfPCell cell6 = new PdfPCell(new Paragraph(segment));
			PdfPCell cell7 = new PdfPCell(new Paragraph(classes));
			PdfPCell emptyCell = new PdfPCell(new Paragraph(""));
			
			cell1.setBorder(Rectangle.NO_BORDER);
			cell2.setBorder(Rectangle.NO_BORDER);
			cell3.setBorder(Rectangle.NO_BORDER);
			cell4.setBorder(Rectangle.NO_BORDER);
			cell5.setBorder(Rectangle.NO_BORDER);
			cell6.setBorder(Rectangle.NO_BORDER);
			cell7.setBorder(Rectangle.NO_BORDER);
			emptyCell.setBorder(Rectangle.NO_BORDER);
			
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell1.setRowspan(2);
			cell1.setColspan(2);
			
			cell2.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell2.setRowspan(2);
			cell2.setColspan(1);
			
			emptyCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			emptyCell.setRowspan(1);
			emptyCell.setColspan(3);
			
			cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell3.setRowspan(1);
			cell3.setColspan(1);
			
			cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell4.setRowspan(1);
			cell4.setColspan(1);
			
			cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell5.setRowspan(1);
			cell5.setColspan(1);
			
			cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell6.setRowspan(1);
			cell6.setColspan(3);
			
			emptyCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			emptyCell.setRowspan(1);
			emptyCell.setColspan(3);
			
			cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell7.setRowspan(1);
			cell7.setColspan(3);
			
			titleMain.addCell(cell1);
			titleMain.addCell(cell2);
			titleMain.addCell(cell3);
			titleMain.addCell(cell4);
			titleMain.addCell(cell5);
			titleMain.addCell(cell6);
			titleMain.addCell(cell7);
			
			PdfContentByte canvas = writer.getDirectContent();
			canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
			titleMain.writeSelectedRows(0, -1, 80, 1770, canvas);
			canvas.endMarkedContentSequence();
				
		PdfPTable table = new PdfPTable(11);

		float[] columnWidth2 = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

		table.setWidths(columnWidth2);
		table.setTotalWidth(1150);
		table.setLockedWidth(true);
		table.getDefaultCell().setFixedHeight(100);
		table.getDefaultCell().setBorder(Rectangle.TOP);
		table.getDefaultCell().setBorderColor(BaseColor.BLACK);
	
		PdfPCell cell8 = new PdfPCell(new Paragraph(ReportsConstant.CUSTOMER,boldFont2));
		cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.enableBorderSide(Rectangle.TOP);
		cell8.setPaddingBottom(2f);
		cell8.enableBorderSide(Rectangle.BOTTOM);

		PdfPCell cell9 = new PdfPCell(new Paragraph(ReportsConstant.CURRENT_BILLING,boldFont2));
		cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.enableBorderSide(Rectangle.TOP);
		cell9.setPaddingBottom(2f);
		cell9.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell10 = new PdfPCell(new Paragraph(ReportsConstant.CURRENT_BALANCE,boldFont2));
		cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.enableBorderSide(Rectangle.TOP);
		cell10.setPaddingBottom(2f);
		cell10.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell11 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_30_DAYS,boldFont2));
		cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.enableBorderSide(Rectangle.TOP);
		cell11.setPaddingBottom(2f);
		cell11.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell12 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_60_DAYS,boldFont2));
		cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.enableBorderSide(Rectangle.TOP);
		cell12.setPaddingBottom(2f);
		cell12.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell13 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_90_DAYS,boldFont2));
		cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.enableBorderSide(Rectangle.TOP);
		cell13.setPaddingBottom(2f);
		cell13.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell14 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_120_DAYS,boldFont2));
		cell14.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell14.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell14.setBorder(Rectangle.NO_BORDER);
		cell14.enableBorderSide(Rectangle.TOP);
		cell14.setPaddingBottom(2f);
		cell14.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell15 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_PAST_DUE,boldFont2));
		cell15.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell15.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell15.setBorder(Rectangle.NO_BORDER);
		cell15.enableBorderSide(Rectangle.TOP);
		cell15.setPaddingBottom(2f);
		cell15.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell16 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_DUE,boldFont2));
		cell16.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell16.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell16.setBorder(Rectangle.NO_BORDER);
		cell16.enableBorderSide(Rectangle.TOP);
		cell16.setPaddingBottom(2f);
		cell16.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell17 = new PdfPCell(new Paragraph(ReportsConstant.DISPUTE,boldFont2));
		cell17.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell17.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell17.setBorder(Rectangle.NO_BORDER);
		cell17.enableBorderSide(Rectangle.TOP);
		cell17.setPaddingBottom(2f);
		cell17.enableBorderSide(Rectangle.BOTTOM);

		PdfPCell cell18 = new PdfPCell(new Paragraph(ReportsConstant.DSO,boldFont2));
		cell18.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell18.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell18.setBorder(Rectangle.NO_BORDER);
		cell18.enableBorderSide(Rectangle.TOP);
		cell18.setPaddingBottom(2f);
		cell18.enableBorderSide(Rectangle.BOTTOM);
		
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);
		table.addCell(cell14);
		table.addCell(cell15);
		table.addCell(cell16);
		table.addCell(cell17);
		table.addCell(cell18);

		canvas = writer.getDirectContent();
		canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
		table.writeSelectedRows(0, -1, 80, 1665, canvas);
		canvas.endMarkedContentSequence();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	private String getTitle(String reportType, String groupType) {
		switch(reportType) {
			case "segment":
				return getSegmentBasedReport(groupType);
			case "summary":
				return getSummaryBasedReport(groupType);
		}
		return "";
	}
	
	private String getSegmentBasedReport(String groupBy) {
		switch(groupBy) {
			case "byCustomer":
				return "Segment Report (by Customer)";
			case "byRegion":
				return "Segment Report (by Customer, Region)";
		}
		return "";
	}
	
	private String getSummaryBasedReport(String groupBy) {
		switch(groupBy) {
			case "byCustomer":
				return "Summary Report (by Customer)";
			case "byCustomerStatus":
				return "Summary Report (by Customer, Status)";
			case "bySegment":
				return "Summary Report by Segment";
			case "byState":
				return "Summary Report by State";
		}
		return "";
	}
	
	private void addFooter(PdfWriter writer) {
		PdfPTable footer = new PdfPTable(4);
		try {
			footer.setWidths(new int[] { 10, 80, 5, 2 });
			footer.setTotalWidth(1150);
			footer.setLockedWidth(true);
			footer.getDefaultCell().setFixedHeight(200);
			footer.getDefaultCell().setBorder(Rectangle.TOP);
			footer.getDefaultCell().setBorderColor(BaseColor.BLACK);

			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");
			String date = formatter.format(new Date());

			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			footer.addCell(new Phrase(date, new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD)));
			
			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			footer.addCell(new Phrase("SOLELY FOR USE BY EMPLOYEES OF AT&T COMPANIES WHO HAVE A NEED TO KNOW.NOT TO BE DISCLOSED TO OR USED BY ANY OTHER PERSON"
					+"WITHOUT PRIOR AUTHORIZATION CONFIDENTIAL\r\n",new Font(Font.FontFamily.HELVETICA, 10)));
			
					
			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			footer.addCell(new Phrase(String.format("Page %d of", writer.getPageNumber()),
					new Font(Font.FontFamily.HELVETICA, 8)));

			PdfPCell totalPageCount = new PdfPCell(total);
			totalPageCount.setBorder(Rectangle.TOP);
			totalPageCount.setBorderColor(BaseColor.BLACK);
			footer.addCell(totalPageCount);

			PdfContentByte canvas = writer.getDirectContent();
			canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
			footer.writeSelectedRows(0, -1, 74, 50, canvas);
			canvas.endMarkedContentSequence();

		} catch (DocumentException de) {
			throw new ExceptionConverter(de);
		}
	}

	public void onCloseDocument(PdfWriter writer, Document document) {

		int totalLength = String.valueOf(writer.getPageNumber()).length();
		int totalWidth = totalLength * 5;
		ColumnText.showTextAligned(t, Element.ALIGN_RIGHT,
				new Phrase(String.valueOf(writer.getPageNumber()), new Font(Font.FontFamily.HELVETICA, 8)), totalWidth,
				6, 0);

	}

	public void setHeader(UserDetails userDetails, String reportType, String groupByType 
	) {
        this.userDetails = userDetails;
        this.reportType = reportType;
        this.groupByType = groupByType;
	}
}
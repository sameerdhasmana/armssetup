package com.att.arms.service;

import java.util.List;
import java.util.Map;

import com.att.arms.entity.AccountClassification;
import com.att.arms.entity.CustomerBillingPeriod;
import com.att.arms.entity.CustomerGroupList;
import com.att.arms.entity.CustomerSegment;
import com.att.arms.entity.FilterResponse;
import com.att.arms.entity.HeaderDetails;
import com.att.arms.entity.OriginatingSystem;
import com.att.arms.entity.UserDetails;

public interface FilterService {

	public List<CustomerGroupList> findcustomerGroupList(String group);

	public List<CustomerBillingPeriod> findCustomerBillingPeriod(List<String> group);

	public List<CustomerSegment> findCustomerSegmentList(List<String> group);

	public List<AccountClassification> findAccountsClassificationList();

	public List<OriginatingSystem> findOriginatingSystemList();

	FilterResponse populateFilter(FilterResponse filter, UserDetails userDetails);

	FilterResponse rePopulateFilter(FilterResponse filter, UserDetails userDetails);

	public boolean validateHeaderRequest(HeaderDetails headerDetails);

	public Map<Object, Object> saveHeaderParameters(Map<Object, Object> responseMap, HeaderDetails headerDetails);

	public boolean validateResetColumnOrderRequest(HeaderDetails headerDetails);

	public Map<Object, Object> resetColumnOrder(Map<Object, Object> responseMap, HeaderDetails headerDetails);

}

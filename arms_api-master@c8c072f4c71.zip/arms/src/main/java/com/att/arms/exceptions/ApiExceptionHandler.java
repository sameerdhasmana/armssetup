package com.att.arms.exceptions;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.att.arms.config.ApplicationConstant;

@RestControllerAdvice(basePackages = "com.att.arms")
public class ApiExceptionHandler extends ResponseEntityExceptionHandler{

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		List<String> errors = ex.getBindingResult().getAllErrors().stream().map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.toList());
		
		HttpServletRequest req = ((ServletWebRequest)request).getRequest();
		
		ApiErrorResponse  apiError = ApiErrorResponseBuilder.getInstance()
				.withErrorId(ApplicationConstant.ARMS+LocalDateTime.now(ZoneOffset.UTC))
				.forPath(req.getRequestURI())
				.withErrors(errors)
				.withMessage(ex.getMessage())
				.withStatus(status.value())
				.build();
				
		
		return new ResponseEntity<>(apiError,headers,status);
	}
	
	@ExceptionHandler(ResponseStatusException.class)
	public ResponseEntity<ApiErrorResponse> handleResponseStatusException(ResponseStatusException ex, HttpServletRequest request){
		
		List<String> errors = Arrays.asList(ex.getReason());
		
		ApiErrorResponse  apiError = ApiErrorResponseBuilder.getInstance()
				.withErrorId(ApplicationConstant.ARMS+LocalDateTime.now(ZoneOffset.UTC))
				.forPath(request.getRequestURI())
				.withErrors(errors)
				.withMessage(ex.getMessage())
				.withStatus(ex.getStatus().value())
				.build();
		
		return new ResponseEntity<>(apiError,ex.getStatus());
	}
	
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiErrorResponse> handleException(Exception ex , HttpServletRequest request){
		List<String> errors = Arrays.asList(ex.getMessage());
		
		
		ApiErrorResponse  apiError = ApiErrorResponseBuilder.getInstance()
				.withErrorId(ApplicationConstant.ARMS+LocalDateTime.now(ZoneOffset.UTC))
				.forPath(request.getRequestURI())
				.withErrors(errors)
				.withMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase())
				.withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
				.build();
		
		return new ResponseEntity<>(apiError,HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	
}
package com.att.arms.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.service.CustomerRepDetailsByAccNumPdfService;
import com.att.arms.reports.service.CustomerRepDetailsByBillNamePdfService;
import com.att.arms.reports.service.CustomerReportByRegionSegmentService;
import com.att.arms.reports.service.CustomerReportByRegionSegmentStatusService;
import com.att.arms.reports.service.CustomerReportExcelService;
import com.itextpdf.text.DocumentException;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class CustomerReportController {

	@Autowired
	private CustomerRepDetailsByAccNumPdfService customerReportPdfService;

	@Autowired
	private CustomerRepDetailsByBillNamePdfService customerReportBillNamePdfService;

	@Autowired
	private CustomerReportByRegionSegmentService customerReportByRegionSegmentService;

	@Autowired
	private CustomerReportByRegionSegmentStatusService customerReportByRegionSegmentStatusService;

	@Autowired
	private CustomerReportExcelService customerReportExcelService;

	@PostMapping("downloadCustomerReportByAccountNumberPDF")
	public ResponseEntity<Map<Object, Object>> getCustomerReportDetailsByAccountNumberPDF(
			@RequestBody UserDetails userDetails, HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByAccountNumber.pdf");

		ByteArrayInputStream stream = customerReportPdfService.getCustRepDetailsByAccNumPdf(userDetails, responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("downloadCustomerReportByBillNamePDF")
	public ResponseEntity<Map<Object, Object>> getCustomerReportDetailsByBillNamePDF(
			@RequestBody UserDetails userDetails, HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByBillName.pdf");

		ByteArrayInputStream stream = customerReportBillNamePdfService.getCustRepDetailsByBillNamePdf(userDetails,
				responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("downloadCustomerReportByRegionStateExcel")
	public ResponseEntity<Object> getCustomerReportDetailsByRegionStateExcel(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByRegionState.xlsx");

		ByteArrayInputStream stream = customerReportExcelService.getCustRepDetailsByRegStateExcel(userDetails,
				responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("downloadCustomerReportByRegionStateSegmentExcel")
	public ResponseEntity<Object> getCustomerReportDetailsByRegionStateSegmentExcel(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByRegionStateSegment.xlsx");

		ByteArrayInputStream stream = customerReportExcelService.getCustRepDetailsByRegStateSegExcel(userDetails,
				responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("downloadCustomerReportByRegionSegmentExcel")
	public ResponseEntity<Object> getCustomerReportDetailsByRegionSegmentExcel(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByRegionSegment.xlsx");

		ByteArrayInputStream stream = customerReportExcelService.getCustRepDetailsByRegSegExcel(userDetails,
				responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("downloadCustomerReportByRegionSegmentStatusExcel")
	public ResponseEntity<Object> getCustomerReportDetailsByRegionSegmentStatusExcel(
			@RequestBody UserDetails userDetails, HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByRegionSegmentStatus.xlsx");

		ByteArrayInputStream stream = customerReportExcelService.getCustRepDetailsByRegSegStatusExcel(userDetails,
				responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("downloadCustomerReportByRegionSegmentPDF")
	public ResponseEntity<Map<Object, Object>> getCustomerReportDetailsByRegionSegmentPDF(
			@RequestBody UserDetails userDetails, HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByRegionSegment.pdf");

		ByteArrayInputStream stream = customerReportByRegionSegmentService.getCustRepDetailsByRegSegPdf(userDetails,
				responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("downloadCustomerReportByRegionSegmentStatusPDF")
	public ResponseEntity<Map<Object, Object>> getCustomerReportDetailsByRegionSegmentStatusPDF(
			@RequestBody UserDetails userDetails, HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByRegionSegmentStatus.pdf");

		ByteArrayInputStream stream = customerReportByRegionSegmentStatusService
				.getCustRepDetailsByRegSegStatusPdf(userDetails, responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("downloadCustomerReportByAccountNumberExcel")
	public ResponseEntity<Object> getCustomerReportDetailsByAccountNumberExcel(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByAccountNumber.xlsx");

		ByteArrayInputStream stream = customerReportExcelService.getCustRepDetailsByAccNumExcel(userDetails,
				responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("downloadCustomerReportByBillNameExcel")
	public ResponseEntity<Object> getCustomerReportDetailsByBillNameExcel(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws DocumentException, IOException {

		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=CustomerReportByBillName.xlsx");

		ByteArrayInputStream stream = customerReportExcelService.getCustRepDetailsByBillNameExcel(userDetails,
				responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
}

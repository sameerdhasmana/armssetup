package com.att.arms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class AccountNoteTalkedTo {

	@Id
	private String contact;
	private String email;
	private String tn;
	private String ext;
	private Integer sortkey;
	

}

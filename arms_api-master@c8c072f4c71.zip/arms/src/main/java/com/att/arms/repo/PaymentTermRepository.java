package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.PaymentTerm;

@Transactional
public interface PaymentTermRepository extends JpaRepository<PaymentTerm, String> {

	@Query(value = "exec arms_payment_terms_acct_get :userLoginCd ,:accountNumber", nativeQuery = true)
	public List<PaymentTerm> paymentTermsByAccount(@Param("userLoginCd") String userLoginCd,
			@Param("accountNumber") String accountNumber);

	@Query(value = "exec arms_payment_terms_customer_get_v22 :userLoginCd ,:group,:originatingSystem,:segment,:customerGrpCd", nativeQuery = true)
	public List<PaymentTerm> paymentTermsByContact(@Param("userLoginCd") String userLoginCd,
			@Param("group") String group, @Param("originatingSystem") String originatingSystem,
			@Param("segment") String segment, @Param("customerGrpCd") String customerGrpCd);

	@Modifying
	@Query(value = "exec arms_payment_terms_acct_update_v22 :userLoginCd ,:accountNumber,:paymentTerm,:originatingSystem", nativeQuery = true)
	public void updatePaymentTerms(@Param("userLoginCd") String userLoginCd,
			@Param("accountNumber") String accountNumber, @Param("paymentTerm") Integer paymentTerm,
			@Param("originatingSystem") String originatingSystem);
}

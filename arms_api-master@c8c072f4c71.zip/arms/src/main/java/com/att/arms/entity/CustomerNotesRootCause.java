package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class CustomerNotesRootCause {

	@Id
	@JsonProperty("rc_cd")
	@Column(name="rc_cd")
	private String rcCd;
	@JsonProperty("rc_desc")
	@Column(name="rc_desc")
	private String rcDesc;
	
}

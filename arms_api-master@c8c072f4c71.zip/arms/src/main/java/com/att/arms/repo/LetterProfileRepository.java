package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.LetterProfile;

@Transactional
public interface LetterProfileRepository extends JpaRepository<LetterProfile, Integer> {

	@Query(value = "Exec arms_letter_profile_field_list_v22 :user_login_id,:blank", nativeQuery = true)
	public List<LetterProfile> getLetterProfileField(@Param("user_login_id") String userLoginId,
			@Param("blank") Integer blank);

	@Query(value = "Exec arms_state_xref3_list :user_login_id,:blank", nativeQuery = true)
	public List<String> getStateCode(@Param("user_login_id") String userLoginId, @Param("blank") Integer blank);

	@Modifying
	@Query(value = "Exec arms_letter_profile_create :letter_profiles_name,:letter_profiles_desc,:user_login_cd,:letter_type_id,:acct_applicability,:return_addr_id,:bus_unit_cd_list,"
			+ ":segment_cd_list,:originating_system_list,:state_cd_list", nativeQuery = true)
	public void saveLetterProfile(@Param("letter_profiles_name") String letterProfilesName,
			@Param("letter_profiles_desc") String letterProfilesDesc, @Param("user_login_cd") String userLoginCd,
			@Param("letter_type_id") String letterTypeId, @Param("acct_applicability") String acctApplicability,
			@Param("return_addr_id") String returnAddrId, @Param("bus_unit_cd_list") String busUnitCdList,
			@Param("segment_cd_list") String segmentCdList,
			@Param("originating_system_list") String originatingSystemList, @Param("state_cd_list") String stateCdList);

	@Query(value = "Exec arms_originating_system_all_list :user_login_id,:blank", nativeQuery = true)
	public List<String> getOriginatingSystemList(@Param("user_login_id") String userLoginId,
			@Param("blank") Integer blank);

	@Modifying
	@Query(value = "Exec arms_letter_profile_modify :letter_profiles_id,:letter_profiles_name,:letter_profiles_desc,:user_login_cd,:letter_type_id,:acct_applicability,:return_addr_id,:bus_unit_cd_list,"
			+ ":segment_cd_list,:originating_system_list,:state_cd_list", nativeQuery = true)
	public void saveModifyLetter(@Param("letter_profiles_id") Integer letterProfilesId,
			@Param("letter_profiles_name") String letterProfilesName,
			@Param("letter_profiles_desc") String letterProfilesDesc, @Param("user_login_cd") String userLoginCd,
			@Param("letter_type_id") String letterTypeId, @Param("acct_applicability") String acctApplicability,
			@Param("return_addr_id") String returnAddrId, @Param("bus_unit_cd_list") String busUnitCdList,
			@Param("segment_cd_list") String segmentCdList,
			@Param("originating_system_list") String originatingSystemList, @Param("state_cd_list") String stateCdList);

	@Modifying
	@Query(value = "Exec arms_letter_profile_modify_field_properties :letter_profiles_id,"
			+ ":letter_profile_field_id,:field_editable,:field_required,:field_prepopulated", nativeQuery = true)
	public void saveModifyProfileField(@Param("letter_profiles_id") Integer letterProfilesId,
			@Param("letter_profile_field_id") Integer letterProfileFieldId,
			@Param("field_editable") Integer letterProfilesDesc, @Param("field_required") Integer fieldRequired,
			@Param("field_prepopulated") Integer fieldPrepopulated);
	@Modifying
	@Query(value = "Exec arms_letter_profile_delete :user_login_id,:letter_profiles_id", nativeQuery = true)
	public void deleteLetterProfile(@Param("user_login_id") String userLoginCd,
			@Param("letter_profiles_id") Integer letterProfilesId);

	@Modifying
	@Query(value = "Exec arms_letter_profile_create_field_properties :letter_profiles_name,:letter_profile_field_id,:field_editable,:field_required,:field_prepopulated", nativeQuery = true)
	public void saveFieldProperties(@Param("letter_profiles_name") String letterProfilesName,
			@Param("letter_profile_field_id") Integer letterProfileFieldId,
			@Param("field_editable") Integer fieldEditable, @Param("field_required") Integer fieldRequired,
			@Param("field_prepopulated") Integer fieldPrepopulated);
}

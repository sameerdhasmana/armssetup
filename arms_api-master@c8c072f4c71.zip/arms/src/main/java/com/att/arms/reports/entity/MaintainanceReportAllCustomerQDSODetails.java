package com.att.arms.reports.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(MaintainanceReportAllCustomerQDSODetails.MaintainanceReportAllCustomerQDSODetailsId.class)
@Data
public class MaintainanceReportAllCustomerQDSODetails {
	
	
	@Id
	@JsonProperty("bus_unit_cd")
	@Column(name="bus_unit_cd")
	private String busUnitCd;
	@Id
	@JsonProperty("originating_company_cd")
	@Column(name="originating_company_cd")
	private String originatingCompanyCd;
	@Id
	@JsonProperty("segment_cd")
	@Column(name="segment_cd")
	private String segmentCd;
	@JsonProperty("current_billing_amt")
	@Column(name="current_billing_amt")
	private Double currentBillingAmt;
	@JsonProperty("past_due_0_amt")
	@Column(name="past_due_0_amt")
	private Double pastDue0Amt;
	@JsonProperty("past_due_30_amt")
	@Column(name="past_due_30_amt")
	private Double pastDue30Amt;
	@JsonProperty("past_due_60_amt")
	@Column(name="past_due_60_amt")
	private Double pastDue60Amt;
	@JsonProperty("past_due_90_amt")
	@Column(name="past_due_90_amt")
	private Double pastDue90Amt;
	@JsonProperty("past_due_120_amt")
	@Column(name="past_due_120_amt")
	private Double pastDue120Amt;
	@JsonProperty("total_amt")
	@Column(name="total_amt")
	private Double totalAmt;	
	@JsonProperty("past_due_amt")
	@Column(name="past_due_amt")
	private Double pastDueAmt;
	@JsonProperty("dispute")
	@Column(name="dispute")
	private Double dispute;
	@JsonProperty("Qdso")
	@Column(name="QDSO")
	private Double qdso;
	
	@SuppressWarnings("serial")
	@Data
	public static class MaintainanceReportAllCustomerQDSODetailsId implements Serializable {

		private String busUnitCd;
		private String originatingCompanyCd;
		private String segmentCd;
		

			
	}

}

package com.att.arms.reports.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(SummaryReportByStateResponseModel.SummaryReportId.class)
@Data
public class SummaryReportByStateResponseModel {
	@Id 
	@JsonProperty("Billing Period")
	@Column(name="Billing Period")
	private String billingPeriod;

	@Id
	@JsonProperty("State")
	@Column(name="State")
	private String state;
	
	@Id
	@JsonProperty("Current Billing Amount")
	@Column(name="Current Billing Amount")
	private BigDecimal currentBillingAmount;
	
	@Id
	@JsonProperty("Past Due 0 Amount")
	@Column(name="Past Due 0 Amount")
	private BigDecimal pastDue0Amount;
	
    @Id
	@JsonProperty("Past Due 30 Amount")
	@Column(name="Past Due 30 Amount")
	private BigDecimal pastDue30Amount;
	
    @Id
	@JsonProperty("Past Due 60 Amount")
	@Column(name="Past Due 60 Amount")
	private BigDecimal pastDue60Amount;
	
     @Id
	@JsonProperty("Past Due 90 Amount")
	@Column(name="Past Due 90 Amount")
	private BigDecimal pastDue90Amount;
	
     @Id
	@JsonProperty("Past Due 120 Amount")
	@Column(name="Past Due 120 Amount")
	private BigDecimal pastDue120Amount;
	 
     @Id
	@JsonProperty("Total Past Due")
	@Column(name="Total Past Due")
	private BigDecimal totalPastDueAmount;
	 
     @Id
	@JsonProperty("Total Amount")
	@Column(name="Total Amount")
	private BigDecimal totalAmount;
    
 	
     @Id
	@JsonProperty("Dispute")
	@Column(name="Dispute")
	private BigDecimal dispute;
     
     @Id
	@JsonProperty("DSO")
	@Column(name="DSO")
	private BigDecimal dso;	
	

	@SuppressWarnings("serial")
	@Data
	public static class SummaryReportId implements Serializable {
		
		private String billingPeriod;
		private String state;
		private BigDecimal currentBillingAmount;
		private BigDecimal pastDue0Amount;
		private BigDecimal pastDue30Amount;
		private BigDecimal pastDue60Amount;
		private BigDecimal pastDue90Amount;
		private BigDecimal pastDue120Amount;
		private BigDecimal totalAmount;
		private BigDecimal totalPastDueAmount;
		private BigDecimal dispute;
		private BigDecimal dso;
	}}
		
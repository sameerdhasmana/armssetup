package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
@IdClass(OCNDetails.OCNDetailsId.class)

public class OCNDetails {

	@JsonProperty("customer_grp_cd")
	@Column(name = "customer_grp_cd")
	@Id
	private String customerGrpCd;
	@JsonProperty("customer_legal_nm")
	@Column(name = "customer_legal_nm")
	private String customerLegalNm;
	@Id
	@JsonProperty("ocn_cd")
	@Column(name = "ocn_cd")
	private String ocnCd;

	@Data
	public static class OCNDetailsId implements Serializable {

		private static final long serialVersionUID = 1L;
		private String ocnCd;
		private String customerGrpCd;

	}

}

package com.att.arms.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.service.SummaryExcelReportService;
import com.att.arms.reports.service.SummaryPdfReportService;
import com.itextpdf.text.DocumentException;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class SummaryReportController {
	
	@Autowired
	SummaryPdfReportService summaryPdfReportService;
	
	@Autowired
	SummaryExcelReportService summaryExcelReportService;
	
	@PostMapping("summaryExcelReportByCustomer")
	public ResponseEntity<Object> summaryExcelReportByCustomer(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.summaryExcelReportService.searchByCustomer(requestModel, responseMap);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=summaryExcelReportByCustomer.xlsx");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("summaryExcelReportByCustomerStatus")
	public ResponseEntity<Object> summaryExcelReportByCustomerStatus(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.summaryExcelReportService.searchByCustomerStatus(requestModel, responseMap);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=summaryExcelReportByCustomerStatus.xlsx");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("summaryExcelReportBySegment")
	public ResponseEntity<Object> summaryExcelReportBySegment(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.summaryExcelReportService.searchBySegment(requestModel, responseMap);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=summaryExcelReportBySegment.xlsx");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("summaryExcelReportByState")
	public ResponseEntity<Object> summaryExcelReportByState(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.summaryExcelReportService.searchByState(requestModel, responseMap);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=SummaryExcelReportByState.xlsx");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	private boolean isValidUserData(UserDetails requestModel) {
		return requestModel.getBillingPeriod() != null && !requestModel.getBillingPeriod().isEmpty();
	}

	@PostMapping("summaryPdfReportByCustomer")
	public ResponseEntity<Object> summaryPdfReportByCustomer(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.summaryPdfReportService.searchByCustomer(requestModel, responseMap);
			response.setContentType("application/octet-stream");
	    	response.setHeader("Content-Disposition", "attachment; filename=summaryPdfReportByCustomer.pdf");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("summaryPdfReportByCustomerStatus")
	public ResponseEntity<Object> summaryPdfReportByCustomerStatus(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.summaryPdfReportService.searchByCustomerStatus(requestModel, responseMap);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=summaryPdfReportByCustomerStatus.pdf");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("summaryPdfReportBySegment")
	public ResponseEntity<Object> summaryPdfReportBySegment(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.summaryPdfReportService.searchBySegment(requestModel, responseMap);
			response.setContentType("application/octet-stream");
	    	response.setHeader("Content-Disposition", "attachment; filename=summaryPdfReportBySegment.pdf");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("summaryPdfReportByState")
	public ResponseEntity<Object> summaryPdfReportByState(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.summaryPdfReportService.searchByState(requestModel, responseMap);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=summaryPdfReportByState.pdf");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
}


package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.RequestModel;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.CustomerDetailsService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class CustomerController {

	@Autowired
	CustomerDetailsService customerDetailsService;

	@PostMapping("submitCustomerQuery")
	public ResponseEntity<Object> submitCustomerQuery(@RequestBody UserDetails userDetails) {
		boolean response = this.customerDetailsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.customerDetailsService.getQueryResponse(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("populateCustomers")
	public ResponseEntity<Object> populateCustomers(@RequestBody UserDetails userDetails) {
		boolean response = this.customerDetailsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.customerDetailsService.populateCustomers(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);

		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("invoiceView")
	public ResponseEntity<Object> invoiceView(@RequestBody UserDetails userDetails) {
		boolean response = this.customerDetailsService.validateInvoiceQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.customerDetailsService.populateInvoiceView(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("singleCustomerSummary")
	public ResponseEntity<Object> singleCustomerSummary(@RequestBody UserDetails userDetails) {
		boolean response = this.customerDetailsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.customerDetailsService.getsingleCustomerSummary(userDetails, responseMap);

			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("viewInternalContacts")
	public ResponseEntity<Object> viewInternalContacts(@RequestBody UserDetails userDetails) {
		boolean response = this.customerDetailsService.validateViewQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.customerDetailsService.viewInternalContacts(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("emaorView")
	public ResponseEntity<Object> emaorView(@RequestBody UserDetails userDetails) {
		boolean response = this.customerDetailsService.validateViewQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.customerDetailsService.getEmaorView(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("accountPastDue")
	public ResponseEntity<Object> accountPastDue(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(userDetails.getAccountNumber())
				&& StringUtils.isNotEmpty(userDetails.getAcntNoteOrgSys())) {
			responseMap = this.customerDetailsService.accountPastDue(userDetails.getAccountNumber(),
					userDetails.getAcntNoteOrgSys(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("cashDataDetails")
	public ResponseEntity<Object> cashDataDetails(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(requestModel.getAccountNumber())
				&& StringUtils.isNotEmpty(requestModel.getAcntNoteOrgSys())) {
			responseMap = this.customerDetailsService.cashDataDetails(requestModel.getAccountNumber(),
					requestModel.getByPayment(), requestModel.getByAdjustment(),
					requestModel.getAcntNoteOrgSys(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("breakdownDetails")
	public ResponseEntity<Object> breakdownDetails(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(requestModel.getAccountNumber())
				&& StringUtils.isNotEmpty(requestModel.getAcntNoteOrgSys())) {
			responseMap = this.customerDetailsService.breakdownDetails(requestModel.getAccountNumber(),
					requestModel.getAcntNoteOrgSys(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("taxiClaimDetails")
	public ResponseEntity<Object> taxiClaimDetails(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(requestModel.getAccountNumber())
				&& StringUtils.isNotEmpty(requestModel.getAcntNoteOrgSys())) {
			responseMap = this.customerDetailsService.taxiClaimDetails(requestModel.getAccountNumber(),
					requestModel.getAcntNoteOrgSys(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	@PostMapping("custAPSubGrpDetails")
	public ResponseEntity<Object> custAPSubGrp(@RequestBody UserDetails userDetails) {
		boolean response = this.customerDetailsService.validatesubGrp(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.customerDetailsService.getCustAPSubGrp(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	@PostMapping("apSubGroupUpdate")
	public ResponseEntity<Object> apSubGroupupdate(@RequestBody UserDetails userDetails) {
		boolean response = this.customerDetailsService.validatesubGrp(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.customerDetailsService.apSubGroupUpdate(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
}

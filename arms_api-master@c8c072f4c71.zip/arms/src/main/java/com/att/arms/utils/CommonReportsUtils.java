package com.att.arms.utils;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

public class CommonReportsUtils {

	public static String getListToCommaQuotesSeparatedAddBracketsString(List<String> groupList) {
		String grp = null;
		if (!CollectionUtils.isEmpty(groupList)) {
			grp = "('" + groupList.stream().collect(Collectors.joining("','"));
			return grp + "')";
		} else {
			return "";
		}
	}

	public static String getListToCommaQuotesSeparatedString(List<String> groupList) {
		String grp = null;
		if (!CollectionUtils.isEmpty(groupList)) {
			grp = "'" + groupList.stream().collect(Collectors.joining("','"));
			return grp + "'";
		} else {
			return "";
		}
	}

}

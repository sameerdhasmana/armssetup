package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.reports.entity.UserTemplateDetails;

@Transactional
public interface TemplateFilesDetailsRepository extends JpaRepository<UserTemplateDetails, String> {

	@Query(value = "exec arms_rpt_user_rpt_list_v22 :userLoginCd,:reportType", nativeQuery = true)
	public List<UserTemplateDetails> getTemplateFilesDetails(@Param("userLoginCd") String userLoginCd, @Param("reportType") String reportType);
}

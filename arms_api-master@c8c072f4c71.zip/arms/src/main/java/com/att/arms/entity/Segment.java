package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class Segment {

	@Id
	@JsonProperty("segment_cd")
	@Column(name = "segment_cd")
	private String segmentCd;
	@JsonProperty("segment_desc")
	@Column(name = "segment_desc")
	private String segmentDesc;

}

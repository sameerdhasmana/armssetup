package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerDetails;

@Transactional
public interface CustomerDetailsRepository extends JpaRepository<CustomerDetails, String> {

	@Query(value = "Exec arms_custqry_customer_query_for_lb_excl_period_v22 :billingPeriod , :group , :strVal", nativeQuery = true)
	public List<CustomerDetails> getCustomerDetails(@Param("billingPeriod") String billingPeriod,
			@Param("group") String group, @Param("strVal") String strVal);

}

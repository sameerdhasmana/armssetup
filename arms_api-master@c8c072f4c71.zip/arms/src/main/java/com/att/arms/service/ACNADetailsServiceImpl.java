package com.att.arms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.ACNADetails;
import com.att.arms.entity.AECNDetails;
import com.att.arms.entity.CTCDetails;
import com.att.arms.entity.CustomerAgedDetails;
import com.att.arms.entity.InvoiceViewDetails;
import com.att.arms.entity.OCNDetails;
import com.att.arms.entity.SummaryDetails;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.ACNADetailsRepository;
import com.att.arms.repo.AECNDetailsRepository;
import com.att.arms.repo.CTCDetailsRepository;
import com.att.arms.repo.CustomerAgedDetailsRepository;
import com.att.arms.repo.InvoiceViewRepository;
import com.att.arms.repo.OCNDetailsRepository;
import com.att.arms.repo.SummaryDetailsRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class ACNADetailsServiceImpl implements ACNADetailsService {

	@Autowired
	CustomerAgedDetailsRepository customerAgedDetailsRepository;
	@Autowired
	ACNADetailsRepository acnaDetailsRepository;
	@Autowired
	AECNDetailsRepository aecnDetailsRepository;
	@Autowired
	CTCDetailsRepository ctcDetailsRepository;
	@Autowired
	OCNDetailsRepository ocnDetailsRepository;
	@Autowired
	InvoiceViewRepository invoiceViewRepository;
	@Autowired
	SummaryDetailsRepository summaryDetailsRepository;
	@Autowired
	CommonService commonService;

	@Override
	public List<ACNADetails> getACNADetails(String group, String strVal) {
		return acnaDetailsRepository.getAcnaDetails(group, strVal);
	}

	@Override
	public List<AECNDetails> getAECNDetails(String group, String strVal) {
		return aecnDetailsRepository.getAecnDetails(group, strVal);
	}

	@Override
	public List<CTCDetails> getCTCDetails(String group, String strVal) {
		return ctcDetailsRepository.getCtcDetails(group, strVal);
	}

	@Override
	public List<OCNDetails> getOCNDetails(String group, String strVal) {
		return ocnDetailsRepository.getOcnDetails(group, strVal);
	}

	@Override
	public boolean validateQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& StringUtils.isNotEmpty(userDetails.getBillingPeriod()) && userDetails.getEnteredValue() != null) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateACNAInvoiceQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getCustomerGrpCd()) && userDetails.getTabType() != null) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> getQueryResponse(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<ACNADetails> acnaDetailsList = new ArrayList<>();
		List<AECNDetails> aecnDetailsList = new ArrayList<>();
		List<OCNDetails> ocnDetailsList = new ArrayList<>();
		List<CTCDetails> ctcDetailsList = new ArrayList<>();
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String acnaSubType = "";
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		String exclusionClass = "";
		String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		String acnaCriteriaType = "";
		String acnaValue = StringUtils.isNotEmpty(userDetails.getAcnaValue())?userDetails.getAcnaValue().trim():"";
		String ctcValue = StringUtils.isNotEmpty(userDetails.getCtcValue())?userDetails.getCtcValue().trim():"";
		Integer rollUp=userDetails.getRollUp()!=null?userDetails.getRollUp():0;
		if (!userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}

		if (StringUtils.isNotEmpty(selectedGroups)
				|| !(StringUtils.isNotEmpty(userDetails.getAcnaValue())
						|| (StringUtils.isNotEmpty(userDetails.getCtcValue())))) {

			switch (userDetails.getTabType()) {
			case 2:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.ACNA_SUB_TYPE;
				if(StringUtils.isEmpty(userDetails.getCustomerGrpCd())){
				acnaDetailsList = getACNADetails(selectedGroups, userDetails.getEnteredValue());
				}
				break;
			case 3:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.AECN_SUB_TYPE;
				if(StringUtils.isEmpty(userDetails.getCustomerGrpCd())){
				aecnDetailsList = getAECNDetails(selectedGroups, userDetails.getEnteredValue());
				}
				break;
			case 4:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.OCN_SUB_TYPE;
				if(StringUtils.isEmpty(userDetails.getCustomerGrpCd())){
				ocnDetailsList = getOCNDetails(selectedGroups, userDetails.getEnteredValue());
				}
				break;
			case 5:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_CTC;
				acnaSubType = ApplicationConstant.CTC_SUB_TYPE;
				if(StringUtils.isEmpty(userDetails.getCustomerGrpCd())){
				ctcDetailsList = getCTCDetails(selectedGroups, userDetails.getEnteredValue());
				}
				break;
			default:
				break;

			}

		}

		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd()) || (!CollectionUtils.isEmpty(acnaDetailsList))
				|| (!CollectionUtils.isEmpty(aecnDetailsList)) || (!CollectionUtils.isEmpty(ocnDetailsList))
				|| (!CollectionUtils.isEmpty(ctcDetailsList))) {
			String customerGrpCd = "";
			if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
				customerGrpCd = userDetails.getCustomerGrpCd().trim();
			} else if (acnaDetailsList != null && acnaDetailsList.size() == 1) {
				customerGrpCd = acnaDetailsList.get(0).getCustomerGrpCd();
				if (StringUtils.isEmpty(acnaValue)) {
					acnaValue = acnaDetailsList.get(0).getAcnaCd().trim();
					ctcValue = "";
				}
			} else if (aecnDetailsList != null && aecnDetailsList.size() == 1) {
				customerGrpCd = aecnDetailsList.get(0).getCustomerGrpCd();
				if (StringUtils.isEmpty(acnaValue)) {
					acnaValue = aecnDetailsList.get(0).getAecnCd().trim();
					ctcValue = "";
				}
			} else if (ocnDetailsList != null && ocnDetailsList.size() == 1) {
				customerGrpCd = ocnDetailsList.get(0).getCustomerGrpCd();
				if (StringUtils.isEmpty(acnaValue)) {
					acnaValue = ocnDetailsList.get(0).getOcnCd().trim();
					ctcValue = "";
				}
			} else if (ctcDetailsList != null && ctcDetailsList.size() == 1) {
				customerGrpCd = ctcDetailsList.get(0).getCustomerGrpCd();
				acnaValue = "";
				ctcValue = ctcDetailsList.get(0).getCustomerGrpChildCd().trim();
			}
			if (StringUtils.isNotEmpty(customerGrpCd)) {
				List<CustomerAgedDetails> agedDetail = customerAgedDetailsRepository.getACNAAgedDetails(userDetails.getProfileName(), userDetails.getProfileType(), "", "",
						selectedGroups, customerGrpCd.trim(), userDetails.getUserLoginCd().trim(),
						userDetails.getBillingPeriod().trim(), statusClause, userDetails.getExclusions().trim(),
						exclusionClass, segment, originatingSystem, acnaCriteriaType, acnaSubType, acnaValue, ctcValue,
						rollUp);
				responseMap.put(ApplicationConstant.AGED_DETAIL, agedDetail);
				commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(), ApplicationConstant.AGED_DETAIL, responseMap);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.NO_DATA_FOUND_MSG);
		}
		responseMap.put(ApplicationConstant.ACNA, acnaDetailsList);
		responseMap.put(ApplicationConstant.AECN, aecnDetailsList);
		responseMap.put(ApplicationConstant.OCN, ocnDetailsList);
		responseMap.put(ApplicationConstant.CTC, ctcDetailsList);

		return responseMap;
	}

	@Override
	public Map<Object, Object> populateACNA(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<ACNADetails> acnaDetailsList = null;
		List<AECNDetails> aecnDetailsList = null;
		List<OCNDetails> ocnDetailsList = null;
		List<CTCDetails> ctcDetailsList = null;
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());

		if (StringUtils.isNotEmpty(selectedGroups) && StringUtils.isEmpty(userDetails.getCustomerGrpCd())) {

			if (userDetails.getTabType().equals(ApplicationConstant.TAB_TYPE_ACNA)) {
				acnaDetailsList = getACNADetails(selectedGroups, userDetails.getEnteredValue());
				responseMap.put(ApplicationConstant.ACNA, acnaDetailsList);
			} else if (userDetails.getTabType().equals(ApplicationConstant.TAB_TYPE_AECN)) {
				aecnDetailsList = getAECNDetails(selectedGroups, userDetails.getEnteredValue());
				responseMap.put(ApplicationConstant.AECN, aecnDetailsList);
			} else if (userDetails.getTabType().equals(ApplicationConstant.TAB_TYPE_OCN)) {
				ocnDetailsList = getOCNDetails(selectedGroups, userDetails.getEnteredValue());
				responseMap.put(ApplicationConstant.OCN, ocnDetailsList);
			} else if (userDetails.getTabType().equals(ApplicationConstant.TAB_TYPE_CTC)) {
				ctcDetailsList = getCTCDetails(selectedGroups, userDetails.getEnteredValue());
				responseMap.put(ApplicationConstant.CTC, ctcDetailsList);
			}

		}

		return responseMap;
	}

	@Override
	public Map<Object, Object> populateACNAInvoiceView(UserDetails userDetails, Map<Object, Object> responseMap) {

		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String acnaSubType = getACNASubType(userDetails.getTabType());
		String acnaCriteriaType = getACNACriteriaType(userDetails.getTabType());
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		String exclusionClass = "";
		String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		Integer rollUp=userDetails.getRollUp()!=null?userDetails.getRollUp():0;
		if (!userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}
		if (StringUtils.isNotEmpty(selectedGroups) || StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			List<InvoiceViewDetails> agedDetail = invoiceViewRepository.getACNAInvoiceViewDetails(userDetails.getProfileName(), userDetails.getProfileType(), "", "",
					selectedGroups, userDetails.getCustomerGrpCd().trim(), userDetails.getUserLoginCd().trim(),
					userDetails.getBillingPeriod().trim(), statusClause, userDetails.getExclusions().trim(),
					exclusionClass, segment, originatingSystem, acnaCriteriaType, acnaSubType,
					userDetails.getAcnaValue(), userDetails.getCtcValue(), rollUp);

			responseMap.put(ApplicationConstant.INVOICE_VIEW, agedDetail);
			commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(), ApplicationConstant.INVOICE_VIEW, responseMap);

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return responseMap;
	}

	@Override
	public String getACNASubType(Integer tabCode) {
		String acnaSubType = "";
		switch (tabCode) {
		case 2:
			acnaSubType = ApplicationConstant.ACNA_SUB_TYPE;
			break;
		case 3:
			acnaSubType = ApplicationConstant.AECN_SUB_TYPE;
			break;
		case 4:
			acnaSubType = ApplicationConstant.OCN_SUB_TYPE;
			break;
		case 5:
			acnaSubType = ApplicationConstant.CTC_SUB_TYPE;
			break;
		default:
			acnaSubType = ApplicationConstant.ACNA_SUB_TYPE;
			break;

		}

		return acnaSubType;
	}

	@Override
	public String getACNACriteriaType(Integer tabCode) {
		String acnaCriteriaType = "";
		switch (tabCode) {
		case 2:
		case 3:
		case 4:
			acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
			break;
		case 5:
			acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_CTC;
			break;
		default:
			acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
			break;

		}

		return acnaCriteriaType;
	}

	// summery
	@Override
	public Map<Object, Object> getSummaryResponse(UserDetails userDetails, Map<Object, Object> responseMap) {

		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String acnaSubType = "";
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		String exclusionClass = "";
		String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		String acnaCriteriaType = "";
		String acnaValue = userDetails.getAcnaValue();
		String ctcValue = userDetails.getCtcValue();
		Integer rollUp=userDetails.getRollUp()!=null?userDetails.getRollUp():0;
		if (!userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}
		if (StringUtils.isNotEmpty(selectedGroups) && StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())
				&& (StringUtils.isNotEmpty(userDetails.getAcnaValue())
						|| (StringUtils.isNotEmpty(userDetails.getCtcValue())))) {

			switch (userDetails.getTabType()) {
			case 2:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.ACNA_SUB_TYPE;
				break;
			case 3:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.AECN_SUB_TYPE;
				break;
			case 4:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_ACNA;
				acnaSubType = ApplicationConstant.OCN_SUB_TYPE;
				break;
			case 5:
				acnaCriteriaType = ApplicationConstant.CRITERIA_TYPE_CTC;
				acnaSubType = ApplicationConstant.CTC_SUB_TYPE;
				break;
			default:
				break;

			}
		}

		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			String customerGrpCd = "";
			if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
				customerGrpCd = userDetails.getCustomerGrpCd().trim();
			}
			if (StringUtils.isNotEmpty(customerGrpCd)) {
				List<SummaryDetails> summaryDetail = summaryDetailsRepository.getSummaryDetails(userDetails.getProfileName(), userDetails.getProfileType(), "",
						selectedGroups, customerGrpCd, userDetails.getUserLoginCd(), userDetails.getBillingPeriod(),
						statusClause, userDetails.getExclusions(), exclusionClass, segment, originatingSystem,
						acnaCriteriaType, acnaSubType, acnaValue, ctcValue, rollUp);
				responseMap.put(ApplicationConstant.SUMMARY_DETAIL, summaryDetail);
				commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(), ApplicationConstant.SUMMARY_DETAIL, responseMap);
			} else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.NO_DATA_FOUND_MSG);

			}

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.NO_DATA_FOUND_MSG);

		}
		return responseMap;
	}
}
package com.att.arms.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JwtRequestInterceptor {

	@Autowired

	private JwtTokenAuthorizationOncePerRequestFilter jwtTokenAuthorizationOncePerRequestFilter;

	@Bean
	public FilterRegistrationBean<JwtTokenAuthorizationOncePerRequestFilter> logFilter() {
		FilterRegistrationBean<JwtTokenAuthorizationOncePerRequestFilter> registrationBean = new FilterRegistrationBean<>();
		registrationBean.setFilter(jwtTokenAuthorizationOncePerRequestFilter);
		registrationBean.addUrlPatterns("/api/*");
		return registrationBean;
	}

}

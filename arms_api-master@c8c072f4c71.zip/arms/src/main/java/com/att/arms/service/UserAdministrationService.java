package com.att.arms.service;

import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface UserAdministrationService {

	boolean validateQueryRequest(UserDetails userDetails);

	Map<Object, Object> getMaintenanceUsers(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getUserAdminReports(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getAdminRoleList(Map<Object, Object> responseMap);
	
}

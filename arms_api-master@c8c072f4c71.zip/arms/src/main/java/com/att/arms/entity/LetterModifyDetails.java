package com.att.arms.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Entity
public class LetterModifyDetails {
	@Id
	@JsonProperty("letterProfilesName")
	@Column(name = "letter_profiles_name")
	private String letterProfilesName;
	@JsonProperty("letterTypeId")
	@Column(name = "letter_type_id")
	private Integer letterTypeId;
	@JsonProperty("letterProfilesDesc")
	@Column(name = "letter_profiles_desc")
	private String letterProfileDesc;
	@JsonProperty("acctApplicability")
	@Column(name = "acct_applicability")
	private String acctApplicability;
	@JsonProperty("returnAddrId")
	@Column(name = "return_addr_id")
	private Integer returnAddrId;

	@JsonIgnore
	@Column(name = "originating_system_list")
	private String originatingSystemList;

	@Transient
	@JsonProperty("originatingSystemList")
	private List<String> originatingSystem;
	@JsonIgnore
	@Column(name = "bus_unit_cd_list")
	private String busUnitCdList;
	@Transient
	@JsonProperty("busUnitCdList")
	private List<String> busUnitCd;
	@JsonIgnore
	@Column(name = "segment_cd_list")
	private String segmentCdList;
	@Transient
	@JsonProperty("segmentCdList")
	private List<String> segmentCd;
	@JsonIgnore
	@Column(name = "state_cd_list")
	private String stateCdList;
	@JsonProperty("stateCdList")
	@Transient
	private List<String> stateCd;

}

package com.att.arms.config;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class RepCopyHeaderFooterPageEvent extends PdfPageEventHelper {

	private PdfTemplate t;
	private Image total;
    String billingPeriodHeader;
    String businessUnitHeader;
    String customerLegalName;
    String statusClause;



	@Override
	public void onOpenDocument(PdfWriter writer, Document document) {
		t = writer.getDirectContent().createTemplate(30, 16);
		try {
			total = Image.getInstance(t);
		} catch (BadElementException e) {
			e.printStackTrace();
		}
		total.setRole(PdfName.ARTIFACT);
	}
	
	 public void setHeader(String billingPeriodHeader,String businessUnitHeader,String customerLegalName,String statusClause) {
		 
         this.billingPeriodHeader = billingPeriodHeader;
         this.businessUnitHeader=businessUnitHeader;
         this.customerLegalName=customerLegalName;
         this.statusClause=statusClause;
     }

	@Override
	public void onEndPage(PdfWriter writer, Document document) {
		addHeader(writer);
		addFooter(writer);
	}

	private void addHeader(PdfWriter writer) {
		try {
			if(writer.getPageNumber() ==1) {
			PdfPTable heading = new PdfPTable(2);
			heading.setWidths(new int[] { 3, 1 });
			heading.setTotalWidth(1150);
			heading.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
			heading.setLockedWidth(true);
			PdfPCell cell = new PdfPCell(
					new Phrase(customerLegalName.toUpperCase(), new Font(Font.FontFamily.HELVETICA, 26, Font.BOLD)));
			cell.setRowspan(2);
			cell.getEffectivePaddingLeft();

			cell.setBorder(Rectangle.TOP);
			cell.getPaddingLeft();

			heading.addCell(cell);
			PdfPCell cell2 = new PdfPCell(
					new Phrase("Billing Period: "+billingPeriodHeader, new Font(Font.FontFamily.HELVETICA, 12)));
			cell2.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell2.setBorder(Rectangle.NO_BORDER);
			cell2.enableBorderSide(Rectangle.TOP);
			cell2.setPaddingBottom(5f);
			heading.addCell(cell2);
			PdfPCell cell3 = new PdfPCell(new Phrase("Group(s): "+businessUnitHeader, new Font(Font.FontFamily.HELVETICA, 12)));
			cell3.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell3.setBorder(Rectangle.NO_BORDER);
			heading.addCell(cell3);

			PdfContentByte canvas = writer.getDirectContent();
			canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
			heading.writeSelectedRows(0, -1, 80, 1762, canvas);
			canvas.endMarkedContentSequence();

			PdfPTable table = new PdfPTable(1);
			table.setWidths(new int[] { 1 });
			table.setTotalWidth(1150);
			PdfPCell cell4 = new PdfPCell(
					new Phrase("Status: "+statusClause.toUpperCase(), new Font(Font.FontFamily.HELVETICA, 14)));
			cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell4.setBorder(Rectangle.NO_BORDER);
			cell4.enableBorderSide(Rectangle.TOP);
			cell4.enableBorderSide(Rectangle.BOTTOM);
			cell4.setPaddingTop(5f);
			cell4.setPaddingBottom(2f);
			table.addCell(cell4);
			PdfContentByte canvas2 = writer.getDirectContent();
			canvas2.beginMarkedContentSequence(PdfName.ARTIFACT);
			table.writeSelectedRows(0, -1, 80, 1720, canvas2);
			canvas2.endMarkedContentSequence();
			}
			List<String> headersList=ApplicationConstant.REP_HEADERS;
			PdfPTable table2 = new PdfPTable(headersList.size());
			table2.setTotalWidth(1150);
			table2.setLockedWidth(true); //
			table2.setHorizontalAlignment(Element.ALIGN_MIDDLE);

			headersList.stream().forEach(ele ->{
				PdfPCell header = new PdfPCell(new Paragraph(ele));
				header.setBorder(Rectangle.NO_BORDER);
				header.enableBorderSide(Rectangle.BOTTOM);
				header.setHorizontalAlignment(Element.ALIGN_CENTER);
				header.setVerticalAlignment(Element.ALIGN_MIDDLE);
				table2.addCell(header);
			});

			
			PdfContentByte canvas3 = writer.getDirectContent();
			canvas3.beginMarkedContentSequence(PdfName.ARTIFACT);
			if(writer.getPageNumber() ==1) {
			table2.writeSelectedRows(0, -1, 80, 1682, canvas3);
			}else {
				table2.writeSelectedRows(0, -1, 80, 1760, canvas3);
			}
			
			canvas3.endMarkedContentSequence();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private void addFooter(PdfWriter writer) {
		PdfPTable footer = new PdfPTable(4);
		try {
			footer.setWidths(new int[] { 10, 80, 5, 2 });
			footer.setTotalWidth(1150);
			footer.setLockedWidth(true);
			footer.getDefaultCell().setFixedHeight(200);
			footer.getDefaultCell().setBorder(Rectangle.TOP);
			footer.getDefaultCell().setBorderColor(BaseColor.BLACK);

			SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy hh:mm:ss aa");
			String date = formatter.format(new Date());

			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			footer.addCell(new Phrase(date, new Font(Font.FontFamily.HELVETICA, 8)));

			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			footer.addCell(new Phrase(
					"SOLELY FOR USE BY EMPLOYEES OF AT&T COMPANIES WHO HAVE A NEED TO KNOW. NOT TO BE DISCLOSED TO OR USED BY ANY OTHER PERSON WITHOUT PRIOR AUTHORIZATION. CONFIDENTIAL",
					new Font(Font.FontFamily.HELVETICA, 10)));

			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			footer.addCell(new Phrase(String.format("Page %d of", writer.getPageNumber()),
					new Font(Font.FontFamily.HELVETICA, 8)));

			PdfPCell totalPageCount = new PdfPCell(total);
			totalPageCount.setBorder(Rectangle.TOP);
			totalPageCount.setBorderColor(BaseColor.BLACK);
			footer.addCell(totalPageCount);

			PdfContentByte canvas = writer.getDirectContent();
			canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
			footer.writeSelectedRows(0, -1, 74, 50, canvas);
			canvas.endMarkedContentSequence();

		} catch (DocumentException de) {
			throw new ExceptionConverter(de);
		}
	}

	@Override
	public void onCloseDocument(PdfWriter writer, Document document) {

		int totalLength = String.valueOf(writer.getPageNumber()).length();
		int totalWidth = totalLength * 5;
		ColumnText.showTextAligned(t, Element.ALIGN_RIGHT,
				new Phrase(String.valueOf(writer.getPageNumber()), new Font(Font.FontFamily.HELVETICA, 8)), totalWidth,
				6, 0);

	}
}
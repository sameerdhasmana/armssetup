package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.LetterProfileList;

@Transactional
public interface LetterProfileListRepository extends JpaRepository<LetterProfileList, Integer> {
	
	
	@Query(value = "Exec arms_letter_profile_list_v22 :user_login_id,:blank", nativeQuery = true)
	public List<LetterProfileList> getLetterProfileList(@Param("user_login_id") String userLoginId,
			@Param("blank") Integer blank);

	
}

package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.Data;

@Entity
@IdClass(CashDataDetails.CashDataDetailsId.class)
@Data
public class CashDataDetails {

	@Id
	@Column(name="billing_period")
	private String billingPeriod;
	@Column(name="last_billing_dt")
	private String lastBillingDate;
	@Id
	@Column(name="transaction_dt")
	private String transactionDate;
	@Id
	@Column(name="transaction_amt")
	private Double transactionAmount;
	@Id
	@Column(name="transaction_type")
	private String transactionType;
	@Id
	@Column(name="insert_dt")
	private String insertDate;
	private Integer payment;
	private Integer adjustment;
	@Id
	@Column(name="acct_nbr")
	private String accountNumber;
	@Id
	@Column(name="originating_System")
	private String originatingSystem;

	@SuppressWarnings("serial")
	@Data
	public static class CashDataDetailsId implements Serializable {

		private String billingPeriod;
		private String transactionDate;
		private Double transactionAmount;
		private String transactionType;
		private String insertDate;
		private String accountNumber;
		private String originatingSystem;
	}
}

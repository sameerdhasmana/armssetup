package com.att.arms.service;

import java.util.List;
import java.util.Map;

import com.att.arms.entity.RequestModel;
import com.att.arms.entity.UserDetails;

public interface MaintenanceService {

	Map<Object, Object> getAllContacts(Map<Object, Object> responseMap);

	Map<Object, Object> populateContacts(String customerGrpCd, Map<Object, Object> responseMap);

	boolean validateDeleteQueryRequest(UserDetails userDetails);
	
	boolean validateSaveQueryRequest(UserDetails userDetails);

	Map<Object, Object> deleteContacts(String customerGrpCd, String userLoginCd, Integer sequence,
			Map<Object, Object> responseMap);

	Map<Object, Object> saveContacts(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateSubGroupQueryRequest(UserDetails userDetails);

	Map<Object, Object> renderApSubGroup(String group, String region, Map<Object, Object> responseMap);

	boolean validateSubGroupGridQueryRequest(UserDetails userDetails);

	Map<Object, Object> renderApSubGroupGrid(String customerGrpCd, String billingPeriod, String userLoginCd,
			String group, String region, Map<Object, Object> responseMap);

	Map<Object, Object> saveApSubGroupGrid(String accountNumber, String apSubGrpName, String userLoginCd,
			String originatingSystem, Map<Object, Object> responseMap);

	boolean validateSaveSubGroupGridQueryRequest(UserDetails userDetails);

	Map<Object, Object> manageTemplateNotes(String userLoginCd, Map<Object, Object> responseMap);

	Map<Object, Object> getTemplateDetails(String userLoginCd, String templateName, String templateType,
			Map<Object, Object> responseMap);

	Map<Object, Object> deleteTemplate(String userLoginCd, String templateName, String templateType,
			Map<Object, Object> responseMap);

	boolean validateSaveTemplateQuery(RequestModel requestModel);

	Map<Object, Object> saveTemplate(String userLoginCd, String templateName, String templateType, String templateOwner,
			String templateNote, List<String> templateH1Logins, Map<Object, Object> responseMap);

}

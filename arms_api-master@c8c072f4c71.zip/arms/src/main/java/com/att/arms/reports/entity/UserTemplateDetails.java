package com.att.arms.reports.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class UserTemplateDetails {

	@Id
	@Column(name = "rpt_name")
	private String reportDisplayName;
	@Column(name = "rpt_type")
	private String reportType;
}

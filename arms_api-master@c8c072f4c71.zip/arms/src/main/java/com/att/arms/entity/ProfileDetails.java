package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class ProfileDetails {

	@Id
	@Column(name = "prfl_disp_nm")
	private String profileDisplayName;
	@Column(name = "prfl_col_nm")
	private String profileColName;
	@Column(name = "prfl_srt_id")
	private Integer profileSortId;

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.AccountNoteTalkedTo;

@Transactional
public interface AccountNoteTalkedToRepository extends JpaRepository<AccountNoteTalkedTo, String> {

	@Query(value = "exec arms_account_notes_talkedto_cb_v22 :accountNumber,:originatingSystem", nativeQuery = true)
	public List<AccountNoteTalkedTo> getAccountNoteTalkedToList(@Param("accountNumber") String accountNumber,
			@Param("originatingSystem") String originatingSystem);

}

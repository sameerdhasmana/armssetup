package com.att.arms.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.Data;

@Entity
@IdClass(AccountPermNotesReport.AccountPermNotesReportId.class)
@Data
public class AccountPermNotesReport {

	@Id
	@Column(name="billing_period")
	private String billingPeriod;
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	@Column(name="insert_dt")
	private Date insertDate;
	@Id
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	private Integer resolved;
	@Id
	private String notes;
	@Column(name="sub_activity_cd")
	private String subActivityCode;
	@Column(name="activity_cd")
	private String activityCode;
	@Id
	private String rep;
	@Id
	@Column(name="System")
	private String system;
	
	
	@SuppressWarnings("serial")
	@Data
	public static class AccountPermNotesReportId implements Serializable {

		private String billingPeriod;
		private String customerGrpCd;
		private String rep;
		private String notes;
		private String system;

	}
}

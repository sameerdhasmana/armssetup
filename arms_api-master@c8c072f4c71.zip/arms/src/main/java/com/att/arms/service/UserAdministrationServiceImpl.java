package com.att.arms.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.AuditAlertGui;
import com.att.arms.entity.AuditLogDailyGui;
import com.att.arms.entity.UserAdminReports;
import com.att.arms.entity.UserAdminRole;
import com.att.arms.entity.UserAdminTaskList;
import com.att.arms.entity.UserAdministrationMaintenance;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.UserAdminAuditAlertRepository;
import com.att.arms.repo.UserAdminAuditLogsRepository;
import com.att.arms.repo.UserAdminReportsRepository;
import com.att.arms.repo.UserAdminRoleRepository;
import com.att.arms.repo.UserAdminTaskListRepository;
import com.att.arms.repo.UserAdministrationRepository;

@Service
public class UserAdministrationServiceImpl implements UserAdministrationService {

	@Autowired
	UserAdministrationRepository userAdministrationRepository;

	@Autowired
	UserAdminReportsRepository userAdminReportsRepository;

	@Autowired
	UserAdminAuditLogsRepository userAdminAuditLogsRepository;
	@Autowired
	UserAdminAuditAlertRepository userAdminAuditAlertRepository;
	@Autowired
	UserAdminRoleRepository userAdminRoleRepository;
	@Autowired
	UserAdminTaskListRepository userAdminTaskListRepository;

	@Override
	public boolean validateQueryRequest(UserDetails userDetails) {
		return false;
	}

	@Override
	public Map<Object, Object> getMaintenanceUsers(UserDetails userDetails, Map<Object, Object> responseMap) {

		String strSort = "";
		String strFilter = "";
		List<UserAdministrationMaintenance> userMaintenance = userAdministrationRepository.getMaintenanceUsers(strSort,
				strFilter);
		responseMap.put(ApplicationConstant.CUSTOMER_NOTES, userMaintenance);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getUserAdminReports(UserDetails userDetails, Map<Object, Object> responseMap) {
		if (userDetails.getReportTabs() == null || userDetails.getReportTabs().isEmpty()) {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "Please provide report tab details!");

		} else {
			List<UserAdminReports> userAdminReports = null;
			List<AuditLogDailyGui> auditLogDailyGui = null;
			List<AuditAlertGui> auditAlertGui = null;
			if (userDetails.getReportTabs().equals("1")) {
				userAdminReports = userAdminReportsRepository.getUserExpiredReports();
				responseMap.put(ApplicationConstant.EXPIRED_USER_REPORT, userAdminReports);
			} else if (userDetails.getReportTabs().equals("2")) {
				userAdminReports = userAdminReportsRepository.getExpiredUsersToDisable();
				responseMap.put(ApplicationConstant.EXPIRED_USER_TO_DISABLED, userAdminReports);
			} else if (userDetails.getReportTabs().equals("3")) {
				userAdminReports = userAdminReportsRepository.getUserToDeleteStatus();
				responseMap.put(ApplicationConstant.USER_TO_BE_DELETED_REPORT, userAdminReports);
			} else if (userDetails.getReportTabs().equals("4")) {
				userAdminReports = userAdminReportsRepository.getUsersDeletedStatusRemove();
				responseMap.put(ApplicationConstant.USER_TO_BE_REMOVE_REPORT, userAdminReports);
			} else if (userDetails.getReportTabs().equals("5")) {
				userAdminReports = userAdminReportsRepository.getAlldeletedReports();
				responseMap.put(ApplicationConstant.ALL_DELETED_REPORT, userAdminReports);
			} else if (userDetails.getReportTabs().equals("6")) {
				userAdminReports = userAdminReportsRepository.getActiveInNinty();
				responseMap.put(ApplicationConstant.ALL_ACTIVE_IN_90_DAYS_REPORT, userAdminReports);
			} else if (userDetails.getReportTabs().equals("7")) {
				userAdminReports = userAdminReportsRepository.getActiveInOneTwenty();
				responseMap.put(ApplicationConstant.ALL_ACTIVE_IN_120_DAYS_REPORT, userAdminReports);
			} else if (userDetails.getReportTabs().equals("8")) {
				userAdminReports = userAdminReportsRepository.getNonActiverStatusAll();
				responseMap.put(ApplicationConstant.ALL_NON_ACTIVE_STATUS_ALL, userAdminReports);
			} else if (userDetails.getReportTabs().equals("9")) {
				auditLogDailyGui = userAdminAuditLogsRepository.getSecurityAuditLogdaily();
				responseMap.put(ApplicationConstant.SECURITY_AUDIT_LOG_DAILY_GUI, auditLogDailyGui);
			} else if (userDetails.getReportTabs().equals("10")) {
				auditAlertGui = userAdminAuditAlertRepository.getSecurityAuditAlertGui();
				responseMap.put(ApplicationConstant.SECURITY_AUDIT_ALERT_GUI, auditAlertGui);
			} else if (userDetails.getReportTabs().equals("11")) {
				userAdminReports = userAdminReportsRepository.getUserSuits();
				responseMap.put(ApplicationConstant.USER_SUITS_REPORT, userAdminReports);
			}

		}
		return responseMap;

	}

	@Override
	public Map<Object, Object> getAdminRoleList(Map<Object, Object> responseMap) {
		List<UserAdminRole> userAdminRole = userAdminRoleRepository.getAdminRoleList();
		responseMap.put(ApplicationConstant.USER_ADMIN_ROLE, userAdminRole);
		List<UserAdminTaskList> userAdmintask = userAdminTaskListRepository.getAdminTaskList();
		responseMap.put(ApplicationConstant.USER_ADMIN_TASK_LIST, userAdmintask);
		return responseMap;
	}
}

package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class CustomerMaintenance {

	@Column(name = "tieCode")
	private String tieCode;
	@Id
	@Column(name = "parentName")
	private String parentName;
	@Column(name = "priority")
	private String priority;
	@Column(name = "note")
	private String note;
	@JsonProperty("updateDate")
	@Column(name = "update_dt")
	private String updateDate;
}

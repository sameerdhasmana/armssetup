package com.att.arms.reports.service;

import static com.itextpdf.text.Element.ALIGN_LEFT;
import static com.itextpdf.text.Element.ALIGN_MIDDLE;
import static com.itextpdf.text.Element.ALIGN_RIGHT;
import static java.math.RoundingMode.HALF_UP;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.RegionReportByCustomerDetails;
import com.att.arms.reports.entity.RegionReportBySegmentCustomerDetails;
import com.att.arms.reports.entity.RegionReportBySegmentDetails;
import com.att.arms.reports.entity.RegionReportByStateCustomerDetails;
import com.att.arms.reports.entity.RegionReportByStateDetails;
import com.att.arms.reports.entity.RegionReportByStateSegmentDetails;
import com.att.arms.reports.repo.RegionReportsCustomerRepository;
import com.att.arms.reports.repo.RegionReportsRepository;
import com.att.arms.reports.repo.RegionReportsSegmentCustomerRepository;
import com.att.arms.reports.repo.RegionReportsStateCustomerRepository;
import com.att.arms.reports.repo.RegionReportsStateRepository;
import com.att.arms.reports.repo.RegionReportsStateSegmentRepository;
import com.att.arms.utils.CommonReportsUtils;
import com.att.arms.utils.CommonUtils;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;

@Service
public class RegionPdfReportsServiceImpl implements RegionPdfReportsService {

	private static final String AND_CX_CLASS_CD_IN = "AND (cx.class_cd IN (";
	private static final String REGION_REPORT_BY_STATE_SEGMENT_PDF = "RegionReportByStateSegment.pdf";
	private static final String REGION_REPORT_BY_STATE_CUSTOMER_PDF = "RegionReportByStateCustomer.pdf";
	private static final String REGION_REPORT_BY_SEGMENT_CUSTOMER_PDF = "RegionReportBySegmentCustomer.pdf";
	private static final String REGION_REPORT_BY_STATE_PDF = "RegionReportByState.pdf";
	private static final String REGION_REPORT_BY_CUSTOMER_PDF = "RegionReportByCustomer.pdf";
	private static final String NO_RECORDS_FOUND = "No Records Found";
	private static final String REGION_REPORT_BY_SEGMENT_PDF = "RegionReportBySegment.pdf";
	private static final Font boldFont_14 = new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.BOLD);
	private static final Font boldFont_13 = new Font(Font.FontFamily.TIMES_ROMAN, 13, Font.BOLD);
	private static final Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
	private static final Font textFontBold = new Font(Font.FontFamily.TIMES_ROMAN, 12f, Font.BOLD, BaseColor.BLACK);

	private static final String CURRENT_BILLING_TOTAL = "currentBillingTotal";
	private static final String PAST_DUE_0_AMT_TOTAL = "pastDue0AmtTotal";
	private static final String PAST_DUE_30_AMT_TOTAL = "pastDue30AmtTotal";
	private static final String PAST_DUE_60_AMT_TOTAL = "pastDue60AmtTotal";
	private static final String PAST_DUE_90_AMT_TOTAL = "pastDue90AmtTotal";
	private static final String PAST_DUE_120_AMT_TOTAL = "pastDue120AmtTotal";
	private static final String PAST_DUE_TOTAL = "PastDueAmtTotal";
	private static final String DUE_AMT_TOTAL = "totalDueAmt";
	private static final String DISPUTE_TOTAL = "disputeTotal";
	private static final String DSO_TOTAL = "dsoTotal";

	private static final String CURRENT_BILLING_SUB_TOTAL = "currentBillingSubTotal";
	private static final String PAST_DUE_0_AMT_SUB_TOTAL = "pastDue0AmtSubTotal";
	private static final String PAST_DUE_30_AMT_SUB_TOTAL = "pastDue30AmtSubTotal";
	private static final String PAST_DUE_60_AMT_SUB_TOTAL = "pastDue60AmtSubTotal";
	private static final String PAST_DUE_90_AMT_SUB_TOTAL = "pastDue90AmtSubTotal";
	private static final String PAST_DUE_120_AMT_SUB_TOTAL = "pastDue120AmtSubTotal";
	private static final String PAST_DUE_SUB_TOTAL = "pastDueAmtSubTotal";
	private static final String DUE_AMT_SUB_TOTAL = "dueAmtSubTotal";
	private static final String DISPUTE_SUB_TOTAL = "disputeSubTotal";
	private static final String DSO_SUB_TOTAL = "dsoSubTotal";

	private static final String CURRENT_BILLING_GRAND_TOTAL = "currentBillingGrandTotal";
	private static final String PAST_DUE_0_AMT_GRAND_TOTAL = "pastDue0AmtGrandTotal";
	private static final String PAST_DUE_30_AMT_GRAND_TOTAL = "pastDue30AmtGrandTotal";
	private static final String PAST_DUE_60_AMT_GRAND_TOTAL = "pastDue60AmtGrandTotal";
	private static final String PAST_DUE_90_AMT_GRAND_TOTAL = "pastDue90AmtGrandTotal";
	private static final String PAST_DUE_120_AMT_GRAND_TOTAL = "pastDue120AmtGrandTotal";
	private static final String PAST_DUE_GRAND_TOTAL = "pastDueAmtGrandTotal";
	private static final String DUE_AMT_GRAND_TOTAL = "dueAmtGrandTotal";
	private static final String DISPUTE_GRAND_TOTAL = "disputeGrandTotal";
	private static final String DSO_GRAND_TOTAL = "dsoGrandTotal";

	@Autowired
	RegionReportsRepository regionReportsBySegmentsRepository;

	@Autowired
	RegionReportsCustomerRepository regionReportsByCustomerRepository;

	@Autowired
	RegionReportsSegmentCustomerRepository regionReportsSegmentCustomerRepository;

	@Autowired
	RegionReportsStateRepository regionReportsStateRepository;

	@Autowired
	RegionReportsStateCustomerRepository regionReportsStateCustomerRepository;

	@Autowired
	RegionReportsStateSegmentRepository regionReportsStateSegmentRepository;

	@Override
	public ByteArrayInputStream createPdfForRegionSegment(UserDetails userDetails, Map<Object, Object> responseMap) {
		try {			
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);

			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream(REGION_REPORT_BY_SEGMENT_PDF));
			document.setPageSize(rectangle);
			RegionReportsHeaderFooterEvent event = new RegionReportsHeaderFooterEvent();
			event.setHeader(userDetails,ReportsConstant.SEGMENT, ReportsConstant.SEGMENT);
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);

			List<RegionReportBySegmentDetails> response = regionReportsBySegmentsRepository.bySegment(
					userDetails.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
					userDetails.getExclusions(), 
					AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
					userDetails.getCustomerChidFlag());

			if(response != null) {
				populateRegionBySegmentPdfWithActualValues(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, NO_RECORDS_FOUND);
			}

			document.close();
			writer.close();

			Path path = Paths.get(REGION_REPORT_BY_SEGMENT_PDF);
			byte[] bytea = Files.readAllBytes(path);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytea);
			return byteArrayInputStream;

		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(REGION_REPORT_BY_SEGMENT_PDF);
		}
		return null;
	}

	private void populateRegionBySegmentPdfWithActualValues(Document document, List<RegionReportBySegmentDetails> response) {
		Map<String, List<RegionReportBySegmentDetails>> regionBySegmentbyGroupMap = 
				response.stream()
				.collect(Collectors.groupingBy(RegionReportBySegmentDetails::getRegion));
		HashMap<String,BigDecimal> aitTotalsMap= new HashMap<>();
		HashMap<String,BigDecimal> grandTotalsMap= new HashMap<>();

		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		try {
			document.add(empty);
		} catch (DocumentException e2) {
			e2.printStackTrace();
		}

		regionBySegmentbyGroupMap.forEach((region, regionsBySegmentbyGroupList) -> {

			try {
				PdfPTable table1 = new PdfPTable(1);

				float[] columnWidths = { 5f };
				table1.setWidths(columnWidths);
				table1.setTotalWidth(1145);
				table1.setLockedWidth(true);
				table1.getDefaultCell().setFixedHeight(100);
				table1.getDefaultCell().setBorder(Rectangle.TOP);
				table1.getDefaultCell().setBorderColor(BaseColor.BLACK);

				PdfPCell cell3 = new PdfPCell(new Paragraph(region, boldFont));
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.disableBorderSide(0);
				cell3.setHorizontalAlignment(ALIGN_LEFT);
				cell3.setVerticalAlignment(ALIGN_MIDDLE);

				table1.addCell(cell3);
				document.add(table1);
			} catch (DocumentException e1) {
				e1.printStackTrace();
			}

			regionsBySegmentbyGroupList.forEach(segmentRow -> {

				PdfPTable table = new PdfPTable(11);
				try {
					populateRegionData(document, aitTotalsMap, segmentRow, table);			
				}catch (DocumentException e) {
					e.printStackTrace();
				}
			});
			try {
				calculateTotals(document, aitTotalsMap, grandTotalsMap, region);
			} catch (DocumentException e) {
				e.printStackTrace();
			}
		});	

		try {

			calculateGrandTotals(document, grandTotalsMap);
		}catch(DocumentException de) {
			de.printStackTrace();
		}
	}

	private void populateRegionData(Document document, HashMap<String, BigDecimal> aitTotalsMap,
			RegionReportBySegmentDetails segmentRow, PdfPTable table) throws DocumentException {
		float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };		
		table.setWidths(columnWidths);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);

		PdfPCell cell3 = new PdfPCell(new Paragraph(segmentRow.getSegment()));
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.disableBorderSide(0);
		cell3.setHorizontalAlignment(ALIGN_LEFT);

		PdfPCell cell4 = new PdfPCell(
				new Paragraph("$" +segmentRow.getCurrentBillingAmount().setScale(2, HALF_UP)));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.disableBorderSide(0);
		cell4.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell5 = new PdfPCell(				
				new Paragraph("$" +segmentRow.getPastDue0Amount().setScale(2, HALF_UP)));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.disableBorderSide(0);
		cell5.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell6 = new PdfPCell(
				new Paragraph("$" +segmentRow.getPastDue30Amount().setScale(2, HALF_UP)));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.disableBorderSide(0);
		cell6.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell7 = new PdfPCell(
				new Paragraph("$" +segmentRow.getPastDue60Amount().setScale(2, HALF_UP)));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.disableBorderSide(0);
		cell7.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell8 = new PdfPCell(
				new Paragraph("$" +segmentRow.getPastDue90Amount().setScale(2, HALF_UP)));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.disableBorderSide(0);
		cell8.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell9 = new PdfPCell(
				new Paragraph("$" +segmentRow.getPastDue120Amount().setScale(2, HALF_UP)));
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.disableBorderSide(0);
		cell9.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell10 = new PdfPCell(
				new Paragraph("$" +segmentRow.getTotalPastDueAmount().setScale(2, HALF_UP)));
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.disableBorderSide(0);
		cell10.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell11 = new PdfPCell(
				new Paragraph("$" +segmentRow.getTotalAmount().setScale(2, HALF_UP)));
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.disableBorderSide(0);
		cell11.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell12 = new PdfPCell(
				new Paragraph("$" +segmentRow.getDispute().setScale(2, HALF_UP)));
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.disableBorderSide(0);
		cell12.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell13 = new PdfPCell(
				new Paragraph("" +segmentRow.getDso().setScale(2, HALF_UP)));
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.disableBorderSide(0);
		cell13.setHorizontalAlignment(ALIGN_RIGHT);

		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);

		document.add(table);

		if(aitTotalsMap.containsKey(CURRENT_BILLING_TOTAL)) {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL, aitTotalsMap.get(CURRENT_BILLING_TOTAL).add(segmentRow.getCurrentBillingAmount()));
		}else {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL,segmentRow.getCurrentBillingAmount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_0_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL).add(segmentRow.getPastDue0Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL,segmentRow.getPastDue0Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_30_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL).add(segmentRow.getPastDue30Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL,segmentRow.getPastDue30Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_60_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL).add(segmentRow.getPastDue60Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL,segmentRow.getPastDue60Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_90_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL).add(segmentRow.getPastDue90Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL,segmentRow.getPastDue90Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_120_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL).add(segmentRow.getPastDue120Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL,segmentRow.getPastDue120Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_TOTAL, aitTotalsMap.get(PAST_DUE_TOTAL).add(segmentRow.getTotalPastDueAmount()));
		}else {
			aitTotalsMap.put(PAST_DUE_TOTAL,segmentRow.getTotalPastDueAmount());
		}

		if(aitTotalsMap.containsKey(DUE_AMT_TOTAL)) {
			aitTotalsMap.put(DUE_AMT_TOTAL, aitTotalsMap.get(DUE_AMT_TOTAL).add(segmentRow.getTotalAmount()));
		}else {
			aitTotalsMap.put(DUE_AMT_TOTAL,segmentRow.getTotalAmount());
		}

		if(aitTotalsMap.containsKey(DISPUTE_TOTAL)) {
			aitTotalsMap.put(DISPUTE_TOTAL, aitTotalsMap.get(DISPUTE_TOTAL).add(segmentRow.getDispute()));
		}else {
			aitTotalsMap.put(DISPUTE_TOTAL,segmentRow.getDispute());
		}

		if(aitTotalsMap.containsKey(DSO_TOTAL)) {
			aitTotalsMap.put(DSO_TOTAL, aitTotalsMap.get(DSO_TOTAL).add(segmentRow.getDso()));
		}else {
			aitTotalsMap.put(DSO_TOTAL,segmentRow.getDso());
		}
	}

	private void calculateGrandTotals(Document document, HashMap<String, BigDecimal> grandTotalsMap)
			throws DocumentException {
		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setColspan(1);
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells); 
		LineSeparator thickLine = new LineSeparator();
		thickLine.setLineWidth(2); 
		thickLine.setOffset(-4);

		PdfPCell  lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(10); 
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells); 
		LineSeparator thickLine2 = new LineSeparator();
		thickLine2.setLineWidth(2); 
		thickLine2.setOffset(8);

		PdfPCell  lineCells2 = new PdfPCell(new Paragraph(new Chunk(thickLine2)));
		lineCells2.setColspan(10); 
		lineCells2.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells2);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Grand Total ", textFontBold));
		totalCustCell.setColspan(10);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);

		PdfPTable grandTotalTable = new PdfPTable(11);
		float[] columnWidths2 = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		grandTotalTable.setWidths(columnWidths2);
		grandTotalTable.setTotalWidth(1145);
		grandTotalTable.setLockedWidth(true);
		grandTotalTable.getDefaultCell().setFixedHeight(100);
		grandTotalTable.getDefaultCell().setBorder(Rectangle.TOP);
		grandTotalTable.getDefaultCell().setBorderColor(BaseColor.BLACK);

		PdfPCell totalRegionCell3 = new PdfPCell(
				new Paragraph(""));
		totalRegionCell3.setBorder(Rectangle.NO_BORDER);
		totalRegionCell3.setHorizontalAlignment(ALIGN_RIGHT);		
		totalRegionCell3.setVerticalAlignment(ALIGN_RIGHT);
		totalRegionCell3.setPaddingBottom(5f);

		PdfPCell totalRegionCell4 = new PdfPCell(
				new Paragraph("$" +grandTotalsMap.get(CURRENT_BILLING_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell4.setBorder(Rectangle.NO_BORDER);
		totalRegionCell4.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell5 = new PdfPCell(
				new Paragraph("$" +grandTotalsMap.get(PAST_DUE_0_AMT_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell5.setBorder(Rectangle.NO_BORDER);
		totalRegionCell5.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell6 = new PdfPCell(
				new Paragraph("$" +grandTotalsMap.get(PAST_DUE_30_AMT_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell6.setBorder(Rectangle.NO_BORDER);
		totalRegionCell6.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell7 = new PdfPCell(
				new Paragraph("$" +grandTotalsMap.get(PAST_DUE_60_AMT_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell7.setBorder(Rectangle.NO_BORDER);
		totalRegionCell7.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell8 = new PdfPCell(
				new Paragraph("$" +grandTotalsMap.get(PAST_DUE_90_AMT_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell8.setBorder(Rectangle.NO_BORDER);
		totalRegionCell8.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell9 = new PdfPCell(
				new Paragraph("$" +grandTotalsMap.get(PAST_DUE_120_AMT_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell9.setBorder(Rectangle.NO_BORDER);
		totalRegionCell9.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell10 = new PdfPCell(
				new Paragraph("$" +grandTotalsMap.get(PAST_DUE_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell10.setBorder(Rectangle.NO_BORDER);
		totalRegionCell10.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell11 = new PdfPCell(
				new Paragraph("$" +grandTotalsMap.get(DUE_AMT_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell11.setBorder(Rectangle.NO_BORDER);
		totalRegionCell11.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell12 = new PdfPCell(
				new Paragraph("$" +grandTotalsMap.get(DISPUTE_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell12.setBorder(Rectangle.NO_BORDER);
		totalRegionCell12.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell13 = new PdfPCell(
				new Paragraph("" +grandTotalsMap.get(DSO_GRAND_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell13.setBorder(Rectangle.NO_BORDER);
		totalRegionCell13.setHorizontalAlignment(ALIGN_RIGHT);

		grandTotalTable.addCell(totalRegionCell3);
		grandTotalTable.addCell(totalRegionCell4);
		grandTotalTable.addCell(totalRegionCell5);
		grandTotalTable.addCell(totalRegionCell6);
		grandTotalTable.addCell(totalRegionCell7);
		grandTotalTable.addCell(totalRegionCell8);
		grandTotalTable.addCell(totalRegionCell9);
		grandTotalTable.addCell(totalRegionCell10);
		grandTotalTable.addCell(totalRegionCell11);
		grandTotalTable.addCell(totalRegionCell12);
		grandTotalTable.addCell(totalRegionCell13);


		document.add(grandTotalTable);
	}

	private void calculateTotals(Document document, HashMap<String, BigDecimal> aitTotalsMap,
			HashMap<String, BigDecimal> grandTotalsMap, String region) throws DocumentException {
		
		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setColspan(1);
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		LineSeparator  thickLine = new LineSeparator();
		thickLine.setLineWidth(2); 
		thickLine.setOffset(2);
		PdfPCell lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(10); 
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Total for " + region, textFontBold));
		totalCustCell.setColspan(10);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);
		PdfPTable totalTable = new PdfPTable(11);

		float[] columnWidths2 = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		totalTable.setWidths(columnWidths2);
		totalTable.setTotalWidth(1145);
		totalTable.setLockedWidth(true);
		totalTable.getDefaultCell().setFixedHeight(100);
		totalTable.getDefaultCell().setBorder(Rectangle.TOP);
		totalTable.getDefaultCell().setBorderColor(BaseColor.BLACK);

		PdfPCell totalRegionCell3 = new PdfPCell(
				new Paragraph(""));
		totalRegionCell3.setBorder(Rectangle.NO_BORDER);
		totalRegionCell3.disableBorderSide(0);
		totalRegionCell3.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell4 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(CURRENT_BILLING_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell4.setBorder(Rectangle.NO_BORDER);
		totalRegionCell4.disableBorderSide(0);
		totalRegionCell4.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell5 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(CURRENT_BILLING_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell5.setBorder(Rectangle.NO_BORDER);
		totalRegionCell5.disableBorderSide(0);
		totalRegionCell5.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell6 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell6.setBorder(Rectangle.NO_BORDER);
		totalRegionCell6.disableBorderSide(0);
		totalRegionCell6.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell7 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell7.setBorder(Rectangle.NO_BORDER);
		totalRegionCell7.disableBorderSide(0);
		totalRegionCell7.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell8 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell8.setBorder(Rectangle.NO_BORDER);
		totalRegionCell8.disableBorderSide(0);
		totalRegionCell8.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell9 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell9.setBorder(Rectangle.NO_BORDER);
		totalRegionCell9.disableBorderSide(0);
		totalRegionCell9.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell10 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell10.setBorder(Rectangle.NO_BORDER);
		totalRegionCell10.disableBorderSide(0);
		totalRegionCell10.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell11 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(DUE_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell11.setBorder(Rectangle.NO_BORDER);
		totalRegionCell11.disableBorderSide(0);
		totalRegionCell11.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell12 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(DISPUTE_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell12.setBorder(Rectangle.NO_BORDER);
		totalRegionCell12.disableBorderSide(0);
		totalRegionCell12.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell13 = new PdfPCell(
				new Paragraph("" +aitTotalsMap.get(DSO_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell13.setBorder(Rectangle.NO_BORDER);
		totalRegionCell13.disableBorderSide(0);
		totalRegionCell13.setHorizontalAlignment(ALIGN_RIGHT);

		totalTable.addCell(totalRegionCell3);
		totalTable.addCell(totalRegionCell4);
		totalTable.addCell(totalRegionCell5);
		totalTable.addCell(totalRegionCell6);
		totalTable.addCell(totalRegionCell7);
		totalTable.addCell(totalRegionCell8);
		totalTable.addCell(totalRegionCell9);
		totalTable.addCell(totalRegionCell10);
		totalTable.addCell(totalRegionCell11);
		totalTable.addCell(totalRegionCell12);
		totalTable.addCell(totalRegionCell13);
		document.add(totalTable);

		populateGrandTotals(aitTotalsMap, grandTotalsMap);
	}

	private void populateGrandTotals(HashMap<String, BigDecimal> aitTotalsMap,
			HashMap<String, BigDecimal> grandTotalsMap) {
		if(grandTotalsMap.containsKey(CURRENT_BILLING_GRAND_TOTAL)) {
			grandTotalsMap.put(CURRENT_BILLING_GRAND_TOTAL, grandTotalsMap.get(CURRENT_BILLING_GRAND_TOTAL).add(aitTotalsMap.get(CURRENT_BILLING_TOTAL)));
		}else {
			grandTotalsMap.put(CURRENT_BILLING_GRAND_TOTAL,aitTotalsMap.get(CURRENT_BILLING_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_0_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_0_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_0_AMT_GRAND_TOTAL).add(aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_0_AMT_GRAND_TOTAL,aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_30_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_30_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_30_AMT_GRAND_TOTAL).add(aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_30_AMT_GRAND_TOTAL,aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_60_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_60_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_60_AMT_GRAND_TOTAL).add(aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_60_AMT_GRAND_TOTAL,aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_90_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_90_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_90_AMT_GRAND_TOTAL).add(aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_90_AMT_GRAND_TOTAL,aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_120_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_120_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_120_AMT_GRAND_TOTAL).add(aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_120_AMT_GRAND_TOTAL,aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_GRAND_TOTAL).add(aitTotalsMap.get(PAST_DUE_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_GRAND_TOTAL,aitTotalsMap.get(PAST_DUE_TOTAL));
		}

		if(grandTotalsMap.containsKey(DUE_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(DUE_AMT_GRAND_TOTAL, grandTotalsMap.get(DUE_AMT_GRAND_TOTAL).add(aitTotalsMap.get(DUE_AMT_TOTAL)));
		}else {
			grandTotalsMap.put(DUE_AMT_GRAND_TOTAL,aitTotalsMap.get(DUE_AMT_TOTAL));
		}

		if(grandTotalsMap.containsKey(DISPUTE_GRAND_TOTAL)) {
			grandTotalsMap.put(DISPUTE_GRAND_TOTAL, grandTotalsMap.get(DISPUTE_GRAND_TOTAL).add(aitTotalsMap.get(DISPUTE_TOTAL)));
		}else {
			grandTotalsMap.put(DISPUTE_GRAND_TOTAL,aitTotalsMap.get(DISPUTE_TOTAL));
		}

		if(grandTotalsMap.containsKey(DSO_GRAND_TOTAL)) {
			grandTotalsMap.put(DSO_GRAND_TOTAL, grandTotalsMap.get(DSO_GRAND_TOTAL).add(aitTotalsMap.get(DSO_TOTAL)));
		}else {
			grandTotalsMap.put(DSO_GRAND_TOTAL,aitTotalsMap.get(DSO_TOTAL));
		}
	}

	@Override
	public ByteArrayInputStream createPdfForRegionCustomer(UserDetails userDetails, Map<Object, Object> responseMap) {
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);

			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream(REGION_REPORT_BY_CUSTOMER_PDF));
			document.setPageSize(rectangle);
			RegionReportsHeaderFooterEvent event = new RegionReportsHeaderFooterEvent();
			event.setHeader(userDetails,ReportsConstant.CUSTOMER, ReportsConstant.CUSTOMER);
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);

			List<RegionReportByCustomerDetails> response = regionReportsByCustomerRepository.byCustomer(
					userDetails.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
					userDetails.getExclusions(), 
					AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
					userDetails.getCustomerChidFlag());

			if(response != null) {
				populatePdfWithActualValues(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, NO_RECORDS_FOUND);
			}

			document.close();
			writer.close();

			Path path = Paths.get(REGION_REPORT_BY_CUSTOMER_PDF);
			byte[] bytea = Files.readAllBytes(path);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytea);
			return byteArrayInputStream;
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(REGION_REPORT_BY_CUSTOMER_PDF);
		}
		return null;
	}

	private void populatePdfWithActualValues(Document document, List<RegionReportByCustomerDetails> response) {
		Map<String, List<RegionReportByCustomerDetails>> regionByCustomerbyGroupMap = 
				response.stream()
				.collect(Collectors.groupingBy(RegionReportByCustomerDetails::getCustomer));

		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		try {
			document.add(empty);
		} catch (DocumentException e2) {
			e2.printStackTrace();
		}

		regionByCustomerbyGroupMap.forEach((region, regionsByCustomerbyGroupList) -> {

			regionsByCustomerbyGroupList.forEach(customerRow -> {
				PdfPTable table = new PdfPTable(11);
				try {
					float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
					table.setWidths(columnWidths);
					table.setTotalWidth(1145);
					table.setLockedWidth(true);
					table.getDefaultCell().setFixedHeight(100);
					table.getDefaultCell().setBorder(Rectangle.TOP);
					table.getDefaultCell().setBorderColor(BaseColor.BLACK);

					PdfPCell cell3 = new PdfPCell(new Paragraph(customerRow.getCustomer()));
					cell3.setBorder(Rectangle.NO_BORDER);
					cell3.setHorizontalAlignment(ALIGN_LEFT);

					PdfPCell cell4 = new PdfPCell(
							new Paragraph("$" +customerRow.getCurrentBillingAmount().setScale(2, HALF_UP)));
					cell4.setBorder(Rectangle.NO_BORDER);
					cell4.setHorizontalAlignment(ALIGN_RIGHT);

					PdfPCell cell5 = new PdfPCell(
							new Paragraph("$" +customerRow.getPastDue0Amount().setScale(2, HALF_UP)));
					cell5.setBorder(Rectangle.NO_BORDER);
					cell5.setHorizontalAlignment(ALIGN_RIGHT);

					PdfPCell cell6 = new PdfPCell(				
							new Paragraph("$" +customerRow.getPastDue60Amount().setScale(2, HALF_UP)));
					cell6.setBorder(Rectangle.NO_BORDER);
					cell6.setHorizontalAlignment(ALIGN_RIGHT);

					PdfPCell cell7 = new PdfPCell(
							new Paragraph("$" +customerRow.getPastDue60Amount().setScale(2, HALF_UP)));
					cell7.setBorder(Rectangle.NO_BORDER);
					cell7.setHorizontalAlignment(ALIGN_RIGHT);

					PdfPCell cell8 = new PdfPCell(
							new Paragraph("$" +customerRow.getPastDue90Amount().setScale(2, HALF_UP)));
					cell8.setBorder(Rectangle.NO_BORDER);
					cell8.setHorizontalAlignment(ALIGN_RIGHT);

					PdfPCell cell9 = new PdfPCell(
							new Paragraph("$" +customerRow.getPastDue120Amount().setScale(2, HALF_UP)));
					cell9.setBorder(Rectangle.NO_BORDER);
					cell9.setHorizontalAlignment(ALIGN_RIGHT);

					PdfPCell cell10 = new PdfPCell(
							new Paragraph("$" +customerRow.getTotalPastDueAmount().setScale(2, HALF_UP)));
					cell10.setBorder(Rectangle.NO_BORDER);
					cell10.setHorizontalAlignment(ALIGN_RIGHT);

					PdfPCell cell11 = new PdfPCell(
							new Paragraph("$" +customerRow.getTotalAmount().setScale(2, HALF_UP)));
					cell11.setBorder(Rectangle.NO_BORDER);
					cell11.setHorizontalAlignment(ALIGN_RIGHT);

					PdfPCell cell12 = new PdfPCell(
							new Paragraph("$" +customerRow.getDispute().setScale(2, HALF_UP)));
					cell12.setBorder(Rectangle.NO_BORDER);
					cell12.setHorizontalAlignment(ALIGN_RIGHT);

					PdfPCell cell13 = new PdfPCell(
							new Paragraph("" +customerRow.getDso().setScale(2, HALF_UP)));
					cell13.setBorder(Rectangle.NO_BORDER);
					cell13.setHorizontalAlignment(ALIGN_RIGHT);

					table.addCell(cell3);
					table.addCell(cell4);
					table.addCell(cell5);
					table.addCell(cell6);
					table.addCell(cell7);
					table.addCell(cell8);
					table.addCell(cell9);
					table.addCell(cell10);
					table.addCell(cell11);
					table.addCell(cell12);
					table.addCell(cell13);

					document.add(table);
				}catch (DocumentException e) {
					e.printStackTrace();
				}});});			
	}

	@Override
	public ByteArrayInputStream createPdfForRegionState(UserDetails userDetails, Map<Object, Object> responseMap) {
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);

			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream(REGION_REPORT_BY_STATE_PDF));
			document.setPageSize(rectangle);
			RegionReportsHeaderFooterEvent event = new RegionReportsHeaderFooterEvent();
			event.setHeader(userDetails,ReportsConstant.STATE, ReportsConstant.STATE);
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);

			List<RegionReportByStateDetails> response = regionReportsStateRepository.byState(
					userDetails.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
					userDetails.getExclusions(), 
					AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
					userDetails.getCustomerChidFlag());

			if(response != null) {
				populateRegionByStatePdfWithActualValues(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, NO_RECORDS_FOUND);
			}

			document.close();
			writer.close();

			Path path = Paths.get(REGION_REPORT_BY_STATE_PDF);
			byte[] bytea = Files.readAllBytes(path);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytea);
			return byteArrayInputStream;
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(REGION_REPORT_BY_STATE_PDF);
		}
		return null;
	}

	private void populateRegionByStatePdfWithActualValues(Document document, List<RegionReportByStateDetails> response) {
		Map<String, List<RegionReportByStateDetails>> regionByStatebyGroupMap = 
				response.stream()
				.collect(Collectors.groupingBy(RegionReportByStateDetails::getRegion));
		HashMap<String,BigDecimal> aitTotalsMap= new HashMap<>();
		HashMap<String,BigDecimal> grandTotalsMap= new HashMap<>();

		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		try {
			document.add(empty);
		} catch (DocumentException e2) {
			e2.printStackTrace();
		}

		regionByStatebyGroupMap.forEach((region, regionsByStatebyGroupList) -> {

			try {
				PdfPTable table1 = new PdfPTable(1);

				float[] columnWidths = { 5f };
				table1.setWidths(columnWidths);
				table1.setTotalWidth(1145);
				table1.setLockedWidth(true);
				table1.getDefaultCell().setFixedHeight(100);
				table1.getDefaultCell().setBorder(Rectangle.TOP);
				table1.getDefaultCell().setBorderColor(BaseColor.BLACK);

				PdfPCell cell3 = new PdfPCell(new Paragraph(region, boldFont));
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.disableBorderSide(0);
				cell3.setHorizontalAlignment(ALIGN_LEFT);
				cell3.setVerticalAlignment(ALIGN_MIDDLE);

				table1.addCell(cell3);
				document.add(table1);
			} catch (DocumentException e1) {
				e1.printStackTrace();
			}

			regionsByStatebyGroupList.forEach(segmentRow -> {

				PdfPTable table = new PdfPTable(11);
				try {
					populateRegionStateData(document, aitTotalsMap, segmentRow, table);			
				}catch (DocumentException e) {
					e.printStackTrace();
				}
			});
			try {
				calculateTotals(document, aitTotalsMap, grandTotalsMap, region);
			} catch (DocumentException e) {
				e.printStackTrace();
			}
		});	

		try {
			calculateGrandTotals(document, grandTotalsMap);
		}catch(DocumentException de) {
			de.printStackTrace();
		}
	}

	private void populateRegionStateData(Document document, HashMap<String, BigDecimal> aitTotalsMap,
			RegionReportByStateDetails stateRow, PdfPTable table) throws DocumentException {
		float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		table.setWidths(columnWidths);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);
		table.getDefaultCell().setFixedHeight(100);
		table.getDefaultCell().setBorder(Rectangle.TOP);
		table.getDefaultCell().setBorderColor(BaseColor.BLACK);

		PdfPCell cell3 = new PdfPCell(new Paragraph(stateRow.getState()));
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.setHorizontalAlignment(ALIGN_LEFT);

		PdfPCell cell4 = new PdfPCell(
				new Paragraph("$" +stateRow.getCurrentBillingAmount().setScale(2, HALF_UP)));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell5 = new PdfPCell(				
				new Paragraph("$" +stateRow.getPastDue0Amount().setScale(2, HALF_UP)));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell6 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue30Amount().setScale(2, HALF_UP)));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell7 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue60Amount().setScale(2, HALF_UP)));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell8 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue90Amount().setScale(2, HALF_UP)));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell9 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue120Amount().setScale(2, HALF_UP)));
		cell9.disableBorderSide(0);
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell10 = new PdfPCell(
				new Paragraph("$" +stateRow.getTotalPastDueAmount().setScale(2, HALF_UP)));
		cell10.disableBorderSide(0);
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell11 = new PdfPCell(
				new Paragraph("$" +stateRow.getTotalAmount().setScale(2, HALF_UP)));
		cell11.disableBorderSide(0);
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell12 = new PdfPCell(
				new Paragraph("$" +stateRow.getDispute().setScale(2, HALF_UP)));
		cell12.disableBorderSide(0);
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell13 = new PdfPCell(
				new Paragraph("" +stateRow.getDso().setScale(2, HALF_UP)));
		cell13.disableBorderSide(0);
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.setHorizontalAlignment(ALIGN_RIGHT);

		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);

		document.add(table);

		if(aitTotalsMap.containsKey(CURRENT_BILLING_TOTAL)) {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL, aitTotalsMap.get(CURRENT_BILLING_TOTAL).add(stateRow.getCurrentBillingAmount()));
		}else {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL,stateRow.getCurrentBillingAmount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_0_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL).add(stateRow.getPastDue0Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL,stateRow.getPastDue0Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_30_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL).add(stateRow.getPastDue30Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL,stateRow.getPastDue30Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_60_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL).add(stateRow.getPastDue60Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL,stateRow.getPastDue60Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_90_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL).add(stateRow.getPastDue90Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL,stateRow.getPastDue90Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_120_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL).add(stateRow.getPastDue120Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL,stateRow.getPastDue120Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_TOTAL, aitTotalsMap.get(PAST_DUE_TOTAL).add(stateRow.getTotalPastDueAmount()));
		}else {
			aitTotalsMap.put(PAST_DUE_TOTAL,stateRow.getTotalPastDueAmount());
		}

		if(aitTotalsMap.containsKey(DUE_AMT_TOTAL)) {
			aitTotalsMap.put(DUE_AMT_TOTAL, aitTotalsMap.get(DUE_AMT_TOTAL).add(stateRow.getTotalAmount()));
		}else {
			aitTotalsMap.put(DUE_AMT_TOTAL,stateRow.getTotalAmount());
		}

		if(aitTotalsMap.containsKey(DISPUTE_TOTAL)) {
			aitTotalsMap.put(DISPUTE_TOTAL, aitTotalsMap.get(DISPUTE_TOTAL).add(stateRow.getDispute()));
		}else {
			aitTotalsMap.put(DISPUTE_TOTAL,stateRow.getDispute());
		}

		if(aitTotalsMap.containsKey(DSO_TOTAL)) {
			aitTotalsMap.put(DSO_TOTAL, aitTotalsMap.get(DSO_TOTAL).add(stateRow.getDso()));
		}else {
			aitTotalsMap.put(DSO_TOTAL,stateRow.getDso());
		}
	}

	@Override
	public ByteArrayInputStream createPdfForRegionSegmentCustomer(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);

			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream(REGION_REPORT_BY_SEGMENT_CUSTOMER_PDF));
			document.setPageSize(rectangle);
			RegionReportsHeaderFooterEvent event = new RegionReportsHeaderFooterEvent();
			event.setHeader(userDetails, ReportsConstant.SEGMENT + " " + ReportsConstant.CUSTOMER, ReportsConstant.CUSTOMER);
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);

			List<RegionReportBySegmentCustomerDetails> response = regionReportsSegmentCustomerRepository.bySegmentCustomer(
					userDetails.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
					userDetails.getExclusions(), 
					AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
					userDetails.getCustomerChidFlag());

			if(response != null) {
				populateRegionBySegmentCustomerPdfWithActualValues(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, NO_RECORDS_FOUND);
			}

			document.close();
			writer.close();

			Path path = Paths.get(REGION_REPORT_BY_SEGMENT_CUSTOMER_PDF);
			byte[] bytea = Files.readAllBytes(path);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytea);
			return byteArrayInputStream;

		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(REGION_REPORT_BY_SEGMENT_CUSTOMER_PDF);
		}
		return null;
	}

	private void populateRegionBySegmentCustomerPdfWithActualValues(Document document, List<RegionReportBySegmentCustomerDetails> response) {
		Map<String, List<RegionReportBySegmentCustomerDetails>> regionBySegmentCustomerbyGroupMap = 
				response.stream()
				.collect(Collectors.groupingBy(RegionReportBySegmentCustomerDetails::getRegion));		
		HashMap<String,BigDecimal> grandTotalsMap= new HashMap<>();

		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		try {
			document.add(empty);
		} catch (DocumentException e2) {
			e2.printStackTrace();
		}

		regionBySegmentCustomerbyGroupMap.forEach((region, regionsBySegmentCustomerbyGroupList) -> {
			HashMap<String,BigDecimal> regionGrandTotalsMap= new HashMap<>();

			try {
				PdfPTable table1 = new PdfPTable(1);

				float[] columnWidths = { 5f };
				table1.setWidths(columnWidths);
				table1.setTotalWidth(1145);
				table1.setLockedWidth(true);
				table1.getDefaultCell().setFixedHeight(100);
				table1.getDefaultCell().setBorder(Rectangle.TOP);
				table1.getDefaultCell().setBorderColor(BaseColor.BLACK);

				PdfPCell cell3 = new PdfPCell(new Paragraph(region, boldFont_14));
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.disableBorderSide(0);
				cell3.setHorizontalAlignment(ALIGN_LEFT);
				cell3.setVerticalAlignment(ALIGN_MIDDLE);

				table1.addCell(cell3);
				document.add(table1);
			} catch (DocumentException e1) {
				e1.printStackTrace();
			}

			Map<String, List<RegionReportBySegmentCustomerDetails>> regionByRegionSegmentbyGroupMap = 
					regionsBySegmentCustomerbyGroupList.stream()
					.collect(Collectors.groupingBy(RegionReportBySegmentCustomerDetails::getSegment));

			regionByRegionSegmentbyGroupMap.forEach((segment, segmentRows) -> {

				HashMap<String,BigDecimal> aitTotalsMap= new HashMap<>();
				try {
					PdfPTable table1 = new PdfPTable(1);

					float[] columnWidths = { 5f };
					table1.setWidths(columnWidths);
					table1.setTotalWidth(1145);
					table1.setLockedWidth(true);
					table1.getDefaultCell().setFixedHeight(100);
					table1.getDefaultCell().setBorder(Rectangle.TOP);
					table1.getDefaultCell().setBorderColor(BaseColor.BLACK);

					PdfPCell cell3 = new PdfPCell(new Paragraph(segment, boldFont_13));
					cell3.setBorder(Rectangle.NO_BORDER);
					cell3.disableBorderSide(0);
					cell3.setHorizontalAlignment(ALIGN_LEFT);
					cell3.setVerticalAlignment(ALIGN_MIDDLE);

					table1.addCell(cell3);
					document.add(table1);
				} catch (DocumentException e1) {
					e1.printStackTrace();
				}

				segmentRows.forEach(customerRow -> {

					PdfPTable table = new PdfPTable(11);
					try {
						populateRegionSegmentCustomerData(document, aitTotalsMap, customerRow, table);			
					}catch (DocumentException e) {
						e.printStackTrace();
					}
				});
				try {
					calculateSegCustTotals(document, aitTotalsMap, regionGrandTotalsMap, segment);
				} catch (DocumentException e) {
					e.printStackTrace();
				}
			});	

			try {
				calculateRegionGrandTotals(document, regionGrandTotalsMap, grandTotalsMap, region);
			}catch(DocumentException de) {
				de.printStackTrace();
			}
		});
		try {
			calculateGrandTotals(document, grandTotalsMap);
		}catch(DocumentException de) {
			de.printStackTrace();
		}	
	}

	private void populateRegionSegmentCustomerData(Document document, HashMap<String, BigDecimal> aitTotalsMap,
			RegionReportBySegmentCustomerDetails stateRow, PdfPTable table) throws DocumentException {
		float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		table.setWidths(columnWidths);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);
		table.getDefaultCell().setFixedHeight(100);
		table.getDefaultCell().setBorder(Rectangle.TOP);
		table.getDefaultCell().setBorderColor(BaseColor.BLACK);

		PdfPCell cell3 = new PdfPCell(new Paragraph(stateRow.getCustomer()));
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.setHorizontalAlignment(ALIGN_LEFT);

		PdfPCell cell4 = new PdfPCell(
				new Paragraph("$" +stateRow.getCurrentBillingAmount().setScale(2, HALF_UP)));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell5 = new PdfPCell(				
				new Paragraph("$" +stateRow.getPastDue0Amount().setScale(2, HALF_UP)));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell6 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue30Amount().setScale(2, HALF_UP)));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell7 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue60Amount().setScale(2, HALF_UP)));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell8 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue90Amount().setScale(2, HALF_UP)));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell9 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue120Amount().setScale(2, HALF_UP)));
		cell9.disableBorderSide(0);
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell10 = new PdfPCell(
				new Paragraph("$" +stateRow.getTotalPastDueAmount().setScale(2, HALF_UP)));
		cell10.disableBorderSide(0);
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell11 = new PdfPCell(
				new Paragraph("$" +stateRow.getTotalAmount().setScale(2, HALF_UP)));
		cell11.disableBorderSide(0);
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell12 = new PdfPCell(
				new Paragraph("$" +stateRow.getDispute().setScale(2, HALF_UP)));
		cell12.disableBorderSide(0);
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell13 = new PdfPCell(
				new Paragraph("" +stateRow.getDso().setScale(2, HALF_UP)));
		cell13.disableBorderSide(0);
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.setHorizontalAlignment(ALIGN_RIGHT);

		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);

		document.add(table);

		if(aitTotalsMap.containsKey(CURRENT_BILLING_TOTAL)) {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL, aitTotalsMap.get(CURRENT_BILLING_TOTAL).add(stateRow.getCurrentBillingAmount()));
		}else {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL,stateRow.getCurrentBillingAmount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_0_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL).add(stateRow.getPastDue0Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL,stateRow.getPastDue0Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_30_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL).add(stateRow.getPastDue30Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL,stateRow.getPastDue30Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_60_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL).add(stateRow.getPastDue60Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL,stateRow.getPastDue60Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_90_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL).add(stateRow.getPastDue90Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL,stateRow.getPastDue90Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_120_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL).add(stateRow.getPastDue120Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL,stateRow.getPastDue120Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_TOTAL, aitTotalsMap.get(PAST_DUE_TOTAL).add(stateRow.getTotalPastDueAmount()));
		}else {
			aitTotalsMap.put(PAST_DUE_TOTAL,stateRow.getTotalPastDueAmount());
		}

		if(aitTotalsMap.containsKey(DUE_AMT_TOTAL)) {
			aitTotalsMap.put(DUE_AMT_TOTAL, aitTotalsMap.get(DUE_AMT_TOTAL).add(stateRow.getTotalAmount()));
		}else {
			aitTotalsMap.put(DUE_AMT_TOTAL,stateRow.getTotalAmount());
		}

		if(aitTotalsMap.containsKey(DISPUTE_TOTAL)) {
			aitTotalsMap.put(DISPUTE_TOTAL, aitTotalsMap.get(DISPUTE_TOTAL).add(stateRow.getDispute()));
		}else {
			aitTotalsMap.put(DISPUTE_TOTAL,stateRow.getDispute());
		}

		if(aitTotalsMap.containsKey(DSO_TOTAL)) {
			aitTotalsMap.put(DSO_TOTAL, aitTotalsMap.get(DSO_TOTAL).add(stateRow.getDso()));
		}else {
			aitTotalsMap.put(DSO_TOTAL,stateRow.getDso());
		}
	}

	private void calculateRegionGrandTotals(Document document, HashMap<String, BigDecimal> regionGrandTotalMap,
			HashMap<String, BigDecimal> grandTotalsMap, String segment) throws DocumentException {
		
		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setColspan(1);
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		LineSeparator  thickLine = new LineSeparator();
		thickLine.setLineWidth(2); 
		thickLine.setOffset(2);
		PdfPCell lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(10); 
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Total for " + segment, textFontBold));
		totalCustCell.setColspan(10);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);

		PdfPTable totalTable = new PdfPTable(11);

		float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		totalTable.setWidths(columnWidthsForOverallTotal);
		totalTable.setTotalWidth(1145);
		totalTable.setLockedWidth(true);

		PdfPCell totalRegionCell3 = new PdfPCell(
				new Paragraph(""));
		totalRegionCell3.setBorder(Rectangle.NO_BORDER);
		totalRegionCell3.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell4 = new PdfPCell(
				new Paragraph("$" +regionGrandTotalMap.get(CURRENT_BILLING_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell4.setBorder(Rectangle.NO_BORDER);
		totalRegionCell4.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell5 = new PdfPCell(
				new Paragraph("$" +regionGrandTotalMap.get(PAST_DUE_0_AMT_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell5.setBorder(Rectangle.NO_BORDER);
		totalRegionCell5.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell6 = new PdfPCell(
				new Paragraph("$" +regionGrandTotalMap.get(PAST_DUE_30_AMT_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell6.setBorder(Rectangle.NO_BORDER);
		totalRegionCell6.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell7 = new PdfPCell(
				new Paragraph("$" +regionGrandTotalMap.get(PAST_DUE_60_AMT_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell7.setBorder(Rectangle.NO_BORDER);
		totalRegionCell7.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell8 = new PdfPCell(
				new Paragraph("$" +regionGrandTotalMap.get(PAST_DUE_90_AMT_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell8.setBorder(Rectangle.NO_BORDER);
		totalRegionCell8.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell9 = new PdfPCell(
				new Paragraph("$" +regionGrandTotalMap.get(PAST_DUE_120_AMT_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell9.setBorder(Rectangle.NO_BORDER);
		totalRegionCell9.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell10 = new PdfPCell(
				new Paragraph("$" +regionGrandTotalMap.get(PAST_DUE_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell10.setBorder(Rectangle.NO_BORDER);
		totalRegionCell10.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell11 = new PdfPCell(
				new Paragraph("$" +regionGrandTotalMap.get(DUE_AMT_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell11.setBorder(Rectangle.NO_BORDER);
		totalRegionCell11.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell12 = new PdfPCell(
				new Paragraph("$" +regionGrandTotalMap.get(DISPUTE_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell12.setBorder(Rectangle.NO_BORDER);
		totalRegionCell12.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell13 = new PdfPCell(
				new Paragraph("" +regionGrandTotalMap.get(DSO_SUB_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell13.setBorder(Rectangle.NO_BORDER);
		totalRegionCell13.setHorizontalAlignment(ALIGN_RIGHT);

		totalTable.addCell(totalRegionCell3);
		totalTable.addCell(totalRegionCell4);
		totalTable.addCell(totalRegionCell5);
		totalTable.addCell(totalRegionCell6);
		totalTable.addCell(totalRegionCell7);
		totalTable.addCell(totalRegionCell8);
		totalTable.addCell(totalRegionCell9);
		totalTable.addCell(totalRegionCell10);
		totalTable.addCell(totalRegionCell11);
		totalTable.addCell(totalRegionCell12);
		totalTable.addCell(totalRegionCell13);


		document.add(totalTable);

		populateSegmentCustGrandTotals(regionGrandTotalMap, grandTotalsMap);
	}

	private void calculateSegCustTotals(Document document, HashMap<String, BigDecimal> aitTotalsMap,
			HashMap<String, BigDecimal> regionGrandTotalsMap, String region) throws DocumentException {

		PdfPTable table = new PdfPTable(11);

		float[] columnWidths1 = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

		table.setWidths(columnWidths1);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setColspan(1);
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		LineSeparator  thickLine = new LineSeparator();
		thickLine.setLineWidth(2); 
		thickLine.setOffset(-4);

		PdfPCell lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(10); 
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Total for " + region, textFontBold));
		totalCustCell.setColspan(10);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);

		PdfPTable totalTable = new PdfPTable(11);

		float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		totalTable.setWidths(columnWidths);
		totalTable.setTotalWidth(1145);
		totalTable.setLockedWidth(true);
		totalTable.getDefaultCell().setFixedHeight(100);

		PdfPCell totalRegionCell3 = new PdfPCell(
				new Paragraph(""));
		totalRegionCell3.setBorder(Rectangle.NO_BORDER);
		totalRegionCell3.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell4 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(CURRENT_BILLING_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell4.setBorder(Rectangle.NO_BORDER);
		totalRegionCell4.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell5 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell5.setBorder(Rectangle.NO_BORDER);
		totalRegionCell5.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell6 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell6.setBorder(Rectangle.NO_BORDER);
		totalRegionCell6.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell7 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell7.setBorder(Rectangle.NO_BORDER);
		totalRegionCell7.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell8 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell8.setBorder(Rectangle.NO_BORDER);
		totalRegionCell8.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell9 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell9.setBorder(Rectangle.NO_BORDER);
		totalRegionCell9.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell10 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(PAST_DUE_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell10.setBorder(Rectangle.NO_BORDER);
		totalRegionCell10.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell11 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(DUE_AMT_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell11.setBorder(Rectangle.NO_BORDER);
		totalRegionCell11.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell12 = new PdfPCell(
				new Paragraph("$" +aitTotalsMap.get(DISPUTE_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell12.setBorder(Rectangle.NO_BORDER);
		totalRegionCell12.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell totalRegionCell13 = new PdfPCell(
				new Paragraph("" +aitTotalsMap.get(DSO_TOTAL).setScale(2, HALF_UP)));
		totalRegionCell13.setBorder(Rectangle.NO_BORDER);
		totalRegionCell13.setHorizontalAlignment(ALIGN_RIGHT);

		totalTable.addCell(totalRegionCell3);
		totalTable.addCell(totalRegionCell4);
		totalTable.addCell(totalRegionCell5);
		totalTable.addCell(totalRegionCell6);
		totalTable.addCell(totalRegionCell7);
		totalTable.addCell(totalRegionCell8);
		totalTable.addCell(totalRegionCell9);
		totalTable.addCell(totalRegionCell10);
		totalTable.addCell(totalRegionCell11);
		totalTable.addCell(totalRegionCell12);
		totalTable.addCell(totalRegionCell13);


		document.add(totalTable);

		populateRegionGrandTotals(aitTotalsMap, regionGrandTotalsMap);
	}

	private void populateRegionGrandTotals(HashMap<String, BigDecimal> aitTotalsMap,
			HashMap<String, BigDecimal> regionGrandTotalsMap) {
		if(regionGrandTotalsMap.containsKey(CURRENT_BILLING_SUB_TOTAL)) {
			regionGrandTotalsMap.put(CURRENT_BILLING_SUB_TOTAL, regionGrandTotalsMap.get(CURRENT_BILLING_SUB_TOTAL).add(aitTotalsMap.get(CURRENT_BILLING_TOTAL)));
		}else {
			regionGrandTotalsMap.put(CURRENT_BILLING_SUB_TOTAL,aitTotalsMap.get(CURRENT_BILLING_TOTAL));
		}

		if(regionGrandTotalsMap.containsKey(PAST_DUE_0_AMT_SUB_TOTAL)) {
			regionGrandTotalsMap.put(PAST_DUE_0_AMT_SUB_TOTAL, regionGrandTotalsMap.get(PAST_DUE_0_AMT_SUB_TOTAL).add(aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL)));
		}else {
			regionGrandTotalsMap.put(PAST_DUE_0_AMT_SUB_TOTAL,aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL));
		}

		if(regionGrandTotalsMap.containsKey(PAST_DUE_30_AMT_SUB_TOTAL)) {
			regionGrandTotalsMap.put(PAST_DUE_30_AMT_SUB_TOTAL, regionGrandTotalsMap.get(PAST_DUE_30_AMT_SUB_TOTAL).add(aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL)));
		}else {
			regionGrandTotalsMap.put(PAST_DUE_30_AMT_SUB_TOTAL,aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL));
		}

		if(regionGrandTotalsMap.containsKey(PAST_DUE_60_AMT_SUB_TOTAL)) {
			regionGrandTotalsMap.put(PAST_DUE_60_AMT_SUB_TOTAL, regionGrandTotalsMap.get(PAST_DUE_60_AMT_SUB_TOTAL).add(aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL)));
		}else {
			regionGrandTotalsMap.put(PAST_DUE_60_AMT_SUB_TOTAL,aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL));
		}

		if(regionGrandTotalsMap.containsKey(PAST_DUE_90_AMT_SUB_TOTAL)) {
			regionGrandTotalsMap.put(PAST_DUE_90_AMT_SUB_TOTAL, regionGrandTotalsMap.get(PAST_DUE_90_AMT_SUB_TOTAL).add(aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL)));
		}else {
			regionGrandTotalsMap.put(PAST_DUE_90_AMT_SUB_TOTAL,aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL));
		}

		if(regionGrandTotalsMap.containsKey(PAST_DUE_120_AMT_SUB_TOTAL)) {
			regionGrandTotalsMap.put(PAST_DUE_120_AMT_SUB_TOTAL, regionGrandTotalsMap.get(PAST_DUE_120_AMT_SUB_TOTAL).add(aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL)));
		}else {
			regionGrandTotalsMap.put(PAST_DUE_120_AMT_SUB_TOTAL,aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL));
		}

		if(regionGrandTotalsMap.containsKey(PAST_DUE_SUB_TOTAL)) {
			regionGrandTotalsMap.put(PAST_DUE_SUB_TOTAL, regionGrandTotalsMap.get(PAST_DUE_SUB_TOTAL).add(aitTotalsMap.get(PAST_DUE_TOTAL)));
		}else {
			regionGrandTotalsMap.put(PAST_DUE_SUB_TOTAL,aitTotalsMap.get(PAST_DUE_TOTAL));
		}

		if(regionGrandTotalsMap.containsKey(DUE_AMT_SUB_TOTAL)) {
			regionGrandTotalsMap.put(DUE_AMT_SUB_TOTAL, regionGrandTotalsMap.get(DUE_AMT_SUB_TOTAL).add(aitTotalsMap.get(DUE_AMT_TOTAL)));
		}else {
			regionGrandTotalsMap.put(DUE_AMT_SUB_TOTAL,aitTotalsMap.get(DUE_AMT_TOTAL));
		}

		if(regionGrandTotalsMap.containsKey(DISPUTE_SUB_TOTAL)) {
			regionGrandTotalsMap.put(DISPUTE_SUB_TOTAL, regionGrandTotalsMap.get(DISPUTE_SUB_TOTAL).add(aitTotalsMap.get(DISPUTE_TOTAL)));
		}else {
			regionGrandTotalsMap.put(DISPUTE_SUB_TOTAL,aitTotalsMap.get(DISPUTE_TOTAL));
		}

		if(regionGrandTotalsMap.containsKey(DSO_SUB_TOTAL)) {
			regionGrandTotalsMap.put(DSO_SUB_TOTAL, regionGrandTotalsMap.get(DSO_SUB_TOTAL).add(aitTotalsMap.get(DSO_TOTAL)));
		}else {
			regionGrandTotalsMap.put(DSO_SUB_TOTAL,aitTotalsMap.get(DSO_TOTAL));
		}
	}

	private void populateSegmentCustGrandTotals(HashMap<String, BigDecimal> regionGrandTotalMap,
			HashMap<String, BigDecimal> grandTotalsMap) {
		if(grandTotalsMap.containsKey(CURRENT_BILLING_GRAND_TOTAL)) {
			grandTotalsMap.put(CURRENT_BILLING_GRAND_TOTAL, grandTotalsMap.get(CURRENT_BILLING_GRAND_TOTAL).add(regionGrandTotalMap.get(CURRENT_BILLING_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(CURRENT_BILLING_GRAND_TOTAL,regionGrandTotalMap.get(CURRENT_BILLING_SUB_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_0_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_0_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_0_AMT_GRAND_TOTAL).add(regionGrandTotalMap.get(PAST_DUE_0_AMT_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_0_AMT_GRAND_TOTAL,regionGrandTotalMap.get(PAST_DUE_0_AMT_SUB_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_30_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_30_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_30_AMT_GRAND_TOTAL).add(regionGrandTotalMap.get(PAST_DUE_30_AMT_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_30_AMT_GRAND_TOTAL,regionGrandTotalMap.get(PAST_DUE_30_AMT_SUB_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_60_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_60_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_60_AMT_GRAND_TOTAL).add(regionGrandTotalMap.get(PAST_DUE_60_AMT_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_60_AMT_GRAND_TOTAL,regionGrandTotalMap.get(PAST_DUE_60_AMT_SUB_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_90_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_90_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_90_AMT_GRAND_TOTAL).add(regionGrandTotalMap.get(PAST_DUE_90_AMT_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_90_AMT_GRAND_TOTAL,regionGrandTotalMap.get(PAST_DUE_90_AMT_SUB_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_120_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_120_AMT_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_120_AMT_GRAND_TOTAL).add(regionGrandTotalMap.get(PAST_DUE_120_AMT_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_120_AMT_GRAND_TOTAL,regionGrandTotalMap.get(PAST_DUE_120_AMT_SUB_TOTAL));
		}

		if(grandTotalsMap.containsKey(PAST_DUE_GRAND_TOTAL)) {
			grandTotalsMap.put(PAST_DUE_GRAND_TOTAL, grandTotalsMap.get(PAST_DUE_GRAND_TOTAL).add(regionGrandTotalMap.get(PAST_DUE_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(PAST_DUE_GRAND_TOTAL,regionGrandTotalMap.get(PAST_DUE_SUB_TOTAL));
		}

		if(grandTotalsMap.containsKey(DUE_AMT_GRAND_TOTAL)) {
			grandTotalsMap.put(DUE_AMT_GRAND_TOTAL, grandTotalsMap.get(DUE_AMT_GRAND_TOTAL).add(regionGrandTotalMap.get(DUE_AMT_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(DUE_AMT_GRAND_TOTAL,regionGrandTotalMap.get(DUE_AMT_SUB_TOTAL));
		}

		if(grandTotalsMap.containsKey(DISPUTE_GRAND_TOTAL)) {
			grandTotalsMap.put(DISPUTE_GRAND_TOTAL, grandTotalsMap.get(DISPUTE_GRAND_TOTAL).add(regionGrandTotalMap.get(DISPUTE_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(DISPUTE_GRAND_TOTAL,regionGrandTotalMap.get(DISPUTE_SUB_TOTAL));
		}

		if(grandTotalsMap.containsKey(DSO_GRAND_TOTAL)) {
			grandTotalsMap.put(DSO_GRAND_TOTAL, grandTotalsMap.get(DSO_GRAND_TOTAL).add(regionGrandTotalMap.get(DSO_SUB_TOTAL)));
		}else {
			grandTotalsMap.put(DSO_GRAND_TOTAL,regionGrandTotalMap.get(DSO_SUB_TOTAL));
		}
	}

	@Override
	public ByteArrayInputStream createPdfForRegionStateCustomer(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);

			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream(REGION_REPORT_BY_STATE_CUSTOMER_PDF));
			document.setPageSize(rectangle);
			RegionReportsHeaderFooterEvent event = new RegionReportsHeaderFooterEvent();
			event.setHeader(userDetails,ReportsConstant.STATE + " " + ReportsConstant.CUSTOMER, ReportsConstant.CUSTOMER);
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);

			List<RegionReportByStateCustomerDetails> response = regionReportsStateCustomerRepository.byStateCustomer(
					userDetails.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
					userDetails.getExclusions(), 
					AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
					userDetails.getCustomerChidFlag());

			if(response != null) {
				populateRegionByStateCustomerPdfWithActualValues(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, NO_RECORDS_FOUND);
			}

			document.close();
			writer.close();

			Path path = Paths.get(REGION_REPORT_BY_STATE_CUSTOMER_PDF);
			byte[] bytea = Files.readAllBytes(path);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytea);
			return byteArrayInputStream;
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(REGION_REPORT_BY_STATE_CUSTOMER_PDF);
		}
		return null;
	}

	private void populateRegionByStateCustomerPdfWithActualValues(Document document, List<RegionReportByStateCustomerDetails> response) {
		Map<String, List<RegionReportByStateCustomerDetails>> regionByStateCustomerbyGroupMap = 
				response.stream()
				.collect(Collectors.groupingBy(RegionReportByStateCustomerDetails::getRegion));
		HashMap<String,BigDecimal> grandTotalsMap= new HashMap<>();

		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		try {
			document.add(empty);
		} catch (DocumentException e2) {
			e2.printStackTrace();
		}

		regionByStateCustomerbyGroupMap.forEach((region, regionsByStateCustomerbyGroupList) -> {
			HashMap<String,BigDecimal> regionGrandTotalsMap= new HashMap<>();

			try {
				PdfPTable table1 = new PdfPTable(1);

				float[] columnWidths = { 5f };
				table1.setWidths(columnWidths);
				table1.setTotalWidth(1145);
				table1.setLockedWidth(true);
				table1.getDefaultCell().setFixedHeight(100);
				table1.getDefaultCell().setBorder(Rectangle.TOP);
				table1.getDefaultCell().setBorderColor(BaseColor.BLACK);

				PdfPCell cell3 = new PdfPCell(new Paragraph(region, boldFont));
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.disableBorderSide(0);
				cell3.setHorizontalAlignment(ALIGN_LEFT);
				cell3.setVerticalAlignment(ALIGN_MIDDLE);

				table1.addCell(cell3);
				document.add(table1);
			} catch (DocumentException e1) {
				e1.printStackTrace();
			}


			Map<String, List<RegionReportByStateCustomerDetails>> regionByRegionSegmentbyGroupMap = 
					regionsByStateCustomerbyGroupList.stream()
					.collect(Collectors.groupingBy(RegionReportByStateCustomerDetails::getState));

			regionByRegionSegmentbyGroupMap.forEach((state, stateRows) -> {

				HashMap<String,BigDecimal> aitTotalsMap= new HashMap<>();
				try {
					PdfPTable table1 = new PdfPTable(1);

					float[] columnWidths = { 5f };
					table1.setWidths(columnWidths);
					table1.setTotalWidth(1145);
					table1.setLockedWidth(true);
					table1.getDefaultCell().setFixedHeight(100);
					table1.getDefaultCell().setBorder(Rectangle.TOP);
					table1.getDefaultCell().setBorderColor(BaseColor.BLACK);

					PdfPCell cell3 = new PdfPCell(new Paragraph(state, boldFont));
					cell3.setBorder(Rectangle.NO_BORDER);
					cell3.disableBorderSide(0);
					cell3.setHorizontalAlignment(ALIGN_LEFT);
					cell3.setVerticalAlignment(ALIGN_MIDDLE);

					table1.addCell(cell3);
					document.add(table1);
				} catch (DocumentException e1) {
					e1.printStackTrace();
				}

				stateRows.forEach(customerRow -> {

					PdfPTable table = new PdfPTable(11);
					try {
						populateRegionStateCustomerData(document, aitTotalsMap, customerRow, table);			
					}catch (DocumentException e) {
						e.printStackTrace();
					}
				});
				try {
					calculateSegCustTotals(document, aitTotalsMap, regionGrandTotalsMap, state);
				} catch (DocumentException e) {
					e.printStackTrace();
				}
			});	

			try {
				calculateRegionGrandTotals(document, regionGrandTotalsMap, grandTotalsMap, region);
			}catch(DocumentException de) {
				de.printStackTrace();
			}
		});
		try {
			calculateGrandTotals(document, grandTotalsMap);
		}catch(DocumentException de) {
			de.printStackTrace();
		}
	}

	private void populateRegionStateCustomerData(Document document, HashMap<String, BigDecimal> aitTotalsMap,
			RegionReportByStateCustomerDetails stateRow, PdfPTable table) throws DocumentException {
		float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		table.setWidths(columnWidths);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);
		table.getDefaultCell().setFixedHeight(100);
		table.getDefaultCell().setBorder(Rectangle.TOP);
		table.getDefaultCell().setBorderColor(BaseColor.BLACK);

		PdfPCell cell3 = new PdfPCell(new Paragraph(stateRow.getCustomer()));
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.setHorizontalAlignment(ALIGN_LEFT);

		PdfPCell cell4 = new PdfPCell(
				new Paragraph("$" +stateRow.getCurrentBillingAmount().setScale(2, HALF_UP)));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell5 = new PdfPCell(				
				new Paragraph("$" +stateRow.getPastDue0Amount().setScale(2, HALF_UP)));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell6 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue30Amount().setScale(2, HALF_UP)));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell7 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue60Amount().setScale(2, HALF_UP)));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell8 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue90Amount().setScale(2, HALF_UP)));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell9 = new PdfPCell(
				new Paragraph("$" +stateRow.getPastDue120Amount().setScale(2, HALF_UP)));
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell10 = new PdfPCell(
				new Paragraph("$" +stateRow.getTotalPastDueAmount().setScale(2, HALF_UP)));
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell11 = new PdfPCell(
				new Paragraph("$" +stateRow.getTotalAmount().setScale(2, HALF_UP)));
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell12 = new PdfPCell(
				new Paragraph("$" +stateRow.getDispute().setScale(2, HALF_UP)));
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell13 = new PdfPCell(
				new Paragraph("" +stateRow.getDso().setScale(2, HALF_UP)));
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.setHorizontalAlignment(ALIGN_RIGHT);

		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);

		document.add(table);

		if(aitTotalsMap.containsKey(CURRENT_BILLING_TOTAL)) {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL, aitTotalsMap.get(CURRENT_BILLING_TOTAL).add(stateRow.getCurrentBillingAmount()));
		}else {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL,stateRow.getCurrentBillingAmount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_0_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL).add(stateRow.getPastDue0Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL,stateRow.getPastDue0Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_30_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL).add(stateRow.getPastDue30Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL,stateRow.getPastDue30Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_60_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL).add(stateRow.getPastDue60Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL,stateRow.getPastDue60Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_90_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL).add(stateRow.getPastDue90Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL,stateRow.getPastDue90Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_120_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL).add(stateRow.getPastDue120Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL,stateRow.getPastDue120Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_TOTAL, aitTotalsMap.get(PAST_DUE_TOTAL).add(stateRow.getTotalPastDueAmount()));
		}else {
			aitTotalsMap.put(PAST_DUE_TOTAL,stateRow.getTotalPastDueAmount());
		}

		if(aitTotalsMap.containsKey(DUE_AMT_TOTAL)) {
			aitTotalsMap.put(DUE_AMT_TOTAL, aitTotalsMap.get(DUE_AMT_TOTAL).add(stateRow.getTotalAmount()));
		}else {
			aitTotalsMap.put(DUE_AMT_TOTAL,stateRow.getTotalAmount());
		}

		if(aitTotalsMap.containsKey(DISPUTE_TOTAL)) {
			aitTotalsMap.put(DISPUTE_TOTAL, aitTotalsMap.get(DISPUTE_TOTAL).add(stateRow.getDispute()));
		}else {
			aitTotalsMap.put(DISPUTE_TOTAL,stateRow.getDispute());
		}

		if(aitTotalsMap.containsKey(DSO_TOTAL)) {
			aitTotalsMap.put(DSO_TOTAL, aitTotalsMap.get(DSO_TOTAL).add(stateRow.getDso()));
		}else {
			aitTotalsMap.put(DSO_TOTAL,stateRow.getDso());
		}
	}

	@Override
	public ByteArrayInputStream createPdfForRegionStateSegment(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);

			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream(REGION_REPORT_BY_STATE_SEGMENT_PDF));
			document.setPageSize(rectangle);
			RegionReportsHeaderFooterEvent event = new RegionReportsHeaderFooterEvent();
			event.setHeader(userDetails,ReportsConstant.STATE + " " + ReportsConstant.SEGMENT, ReportsConstant.STATE);
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);

			List<RegionReportByStateSegmentDetails> response = regionReportsStateSegmentRepository.byStateSegment(
					userDetails.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
					userDetails.getExclusions(), 
					AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
					userDetails.getCustomerChidFlag());

			if(response != null) {
				populateRegionByStateSegmentPdfWithActualValues(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, NO_RECORDS_FOUND);
			}

			document.close();
			writer.close();

			Path path = Paths.get(REGION_REPORT_BY_STATE_SEGMENT_PDF);
			byte[] bytea = Files.readAllBytes(path);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytea);
			return byteArrayInputStream;

		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		} finally {
			CommonUtils.deleteFile(REGION_REPORT_BY_STATE_SEGMENT_PDF);
		}
		return null;
	}

	private void populateRegionByStateSegmentPdfWithActualValues(Document document, List<RegionReportByStateSegmentDetails> response) {
		Map<String, List<RegionReportByStateSegmentDetails>> regionByStateSegmentbyGroupMap = 
				response.stream()
				.collect(Collectors.groupingBy(RegionReportByStateSegmentDetails::getRegion));
		HashMap<String,BigDecimal> grandTotalsMap= new HashMap<>();

		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		try {
			document.add(empty);
		} catch (DocumentException e2) {
			e2.printStackTrace();
		}
		regionByStateSegmentbyGroupMap.forEach((region, regionsByStateSegmentbyGroupList) -> {
			HashMap<String,BigDecimal> regionGrandTotalsMap= new HashMap<>();

			try {
				PdfPTable table1 = new PdfPTable(1);

				float[] columnWidths = { 5f };
				table1.setWidths(columnWidths);
				table1.setTotalWidth(1145);
				table1.setLockedWidth(true);
				table1.getDefaultCell().setFixedHeight(100);
				table1.getDefaultCell().setBorder(Rectangle.TOP);
				table1.getDefaultCell().setBorderColor(BaseColor.BLACK);

				PdfPCell cell3 = new PdfPCell(new Paragraph(region, boldFont));
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.disableBorderSide(0);
				cell3.setHorizontalAlignment(ALIGN_LEFT);
				cell3.setVerticalAlignment(ALIGN_MIDDLE);

				table1.addCell(cell3);
				document.add(table1);
			} catch (DocumentException e1) {
				e1.printStackTrace();
			}

			Map<String, List<RegionReportByStateSegmentDetails>> regionByRegionStatebyGroupMap = 
					regionsByStateSegmentbyGroupList.stream()
					.collect(Collectors.groupingBy(RegionReportByStateSegmentDetails::getState));

			regionByRegionStatebyGroupMap.forEach((state, stateRows) -> {

				HashMap<String,BigDecimal> aitTotalsMap= new HashMap<>();
				try {
					PdfPTable table1 = new PdfPTable(1);

					float[] columnWidths = { 5f };
					table1.setWidths(columnWidths);
					table1.setTotalWidth(1145);
					table1.setLockedWidth(true);
					table1.getDefaultCell().setFixedHeight(100);
					table1.getDefaultCell().setBorder(Rectangle.TOP);
					table1.getDefaultCell().setBorderColor(BaseColor.BLACK);

					PdfPCell cell3 = new PdfPCell(new Paragraph(state, boldFont));
					cell3.setBorder(Rectangle.NO_BORDER);
					cell3.disableBorderSide(0);
					cell3.setHorizontalAlignment(ALIGN_LEFT);
					cell3.setVerticalAlignment(ALIGN_MIDDLE);

					table1.addCell(cell3);
					document.add(table1);
				} catch (DocumentException e1) {
					e1.printStackTrace();
				}

				stateRows.forEach(segmentRow -> {

					PdfPTable table = new PdfPTable(11);
					try {
						populateRegionStateSegmentData(document, aitTotalsMap, segmentRow, table);			
					}catch (DocumentException e) {
						e.printStackTrace();
					}
				});
				try {
					calculateSegCustTotals(document, aitTotalsMap, regionGrandTotalsMap, state);
				} catch (DocumentException e) {
					e.printStackTrace();
				}
			});	

			try {
				calculateRegionGrandTotals(document, regionGrandTotalsMap, grandTotalsMap, region);
			}catch(DocumentException de) {
				de.printStackTrace();
			}
		});
		try {		
			calculateGrandTotals(document, grandTotalsMap);
		}catch(DocumentException de) {
			de.printStackTrace();
		}
	}

	private void populateRegionStateSegmentData(Document document, HashMap<String, BigDecimal> aitTotalsMap,
			RegionReportByStateSegmentDetails segmentRow, PdfPTable table) throws DocumentException {
		float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		table.setWidths(columnWidths);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);
		table.getDefaultCell().setFixedHeight(100);
		table.getDefaultCell().setBorder(Rectangle.TOP);
		table.getDefaultCell().setBorderColor(BaseColor.BLACK);

		PdfPCell cell3 = new PdfPCell(new Paragraph(segmentRow.getSegment()));
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.setHorizontalAlignment(ALIGN_LEFT);

		PdfPCell cell4 = new PdfPCell(
				new Paragraph("" +segmentRow.getCurrentBillingAmount().setScale(2, HALF_UP)));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell5 = new PdfPCell(				
				new Paragraph("" +segmentRow.getPastDue0Amount().setScale(2, HALF_UP)));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell6 = new PdfPCell(
				new Paragraph("" +segmentRow.getPastDue30Amount().setScale(2, HALF_UP)));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell7 = new PdfPCell(
				new Paragraph("" +segmentRow.getPastDue60Amount().setScale(2, HALF_UP)));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell8 = new PdfPCell(
				new Paragraph("" +segmentRow.getPastDue90Amount().setScale(2, HALF_UP)));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell9 = new PdfPCell(
				new Paragraph("" +segmentRow.getPastDue120Amount().setScale(2, HALF_UP)));
		cell9.disableBorderSide(0);
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell10 = new PdfPCell(
				new Paragraph("" +segmentRow.getTotalPastDueAmount().setScale(2, HALF_UP)));
		cell10.disableBorderSide(0);
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell11 = new PdfPCell(
				new Paragraph("" +segmentRow.getTotalAmount().setScale(2, HALF_UP)));
		cell11.disableBorderSide(0);
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell12 = new PdfPCell(
				new Paragraph("" +segmentRow.getDispute().setScale(2, HALF_UP)));
		cell12.disableBorderSide(0);
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.setHorizontalAlignment(ALIGN_RIGHT);

		PdfPCell cell13 = new PdfPCell(
				new Paragraph("" +segmentRow.getDso().setScale(2, HALF_UP)));
		cell13.disableBorderSide(0);
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.setHorizontalAlignment(ALIGN_RIGHT);

		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);

		document.add(table);

		if(aitTotalsMap.containsKey(CURRENT_BILLING_TOTAL)) {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL, aitTotalsMap.get(CURRENT_BILLING_TOTAL).add(segmentRow.getCurrentBillingAmount()));
		}else {
			aitTotalsMap.put(CURRENT_BILLING_TOTAL,segmentRow.getCurrentBillingAmount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_0_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_0_AMT_TOTAL).add(segmentRow.getPastDue0Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_0_AMT_TOTAL,segmentRow.getPastDue0Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_30_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_30_AMT_TOTAL).add(segmentRow.getPastDue30Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_30_AMT_TOTAL,segmentRow.getPastDue30Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_60_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_60_AMT_TOTAL).add(segmentRow.getPastDue60Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_60_AMT_TOTAL,segmentRow.getPastDue60Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_90_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_90_AMT_TOTAL).add(segmentRow.getPastDue90Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_90_AMT_TOTAL,segmentRow.getPastDue90Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_120_AMT_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL, aitTotalsMap.get(PAST_DUE_120_AMT_TOTAL).add(segmentRow.getPastDue120Amount()));
		}else {
			aitTotalsMap.put(PAST_DUE_120_AMT_TOTAL,segmentRow.getPastDue120Amount());
		}

		if(aitTotalsMap.containsKey(PAST_DUE_TOTAL)) {
			aitTotalsMap.put(PAST_DUE_TOTAL, aitTotalsMap.get(PAST_DUE_TOTAL).add(segmentRow.getTotalPastDueAmount()));
		}else {
			aitTotalsMap.put(PAST_DUE_TOTAL,segmentRow.getTotalPastDueAmount());
		}

		if(aitTotalsMap.containsKey(DUE_AMT_TOTAL)) {
			aitTotalsMap.put(DUE_AMT_TOTAL, aitTotalsMap.get(DUE_AMT_TOTAL).add(segmentRow.getTotalAmount()));
		}else {
			aitTotalsMap.put(DUE_AMT_TOTAL,segmentRow.getTotalAmount());
		}

		if(aitTotalsMap.containsKey(DISPUTE_TOTAL)) {
			aitTotalsMap.put(DISPUTE_TOTAL, aitTotalsMap.get(DISPUTE_TOTAL).add(segmentRow.getDispute()));
		}else {
			aitTotalsMap.put(DISPUTE_TOTAL,segmentRow.getDispute());
		}

		if(aitTotalsMap.containsKey(DSO_TOTAL)) {
			aitTotalsMap.put(DSO_TOTAL, aitTotalsMap.get(DSO_TOTAL).add(segmentRow.getDso()));
		}else {
			aitTotalsMap.put(DSO_TOTAL,segmentRow.getDso());
		}
	}
}

package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Map;

import com.att.arms.entity.UserDetails;
import com.itextpdf.text.DocumentException;

public interface TemplateReportsPdfService {
	
	public ByteArrayInputStream createPdfWithDbData(UserDetails userDetails, Map<Object, Object> responseMap) throws DocumentException, IOException;


}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.MaintenanceContactDetails;

@Transactional
public interface MaintenanceContactDetailsRepository extends JpaRepository<MaintenanceContactDetails, String> {

	@Query(value = "exec arms_maintenance_fetchcontacts_v22 :customerLoginCd", nativeQuery = true)
	public List<MaintenanceContactDetails> getMaintenanceContactDetailsList(
			@Param("customerLoginCd") String customerLoginCd);

	@Modifying
	@Query(value = "exec arms_maintenance_delcontacts :customerLoginCd,:sequence ,:userLoginCd,:sysProcessName", nativeQuery = true)
	public void deleteMaintenanceContactDetails(@Param("customerLoginCd") String customerLoginCd,
			@Param("sequence") Integer sequence, @Param("userLoginCd") String userLoginCd,
			@Param("sysProcessName") String sysProcessName);

	@Modifying
	@Query(value = "exec arms_maintenance_addcontacts :customerLoginCd,:firstName,:lastName,:address"
			+ ",:city,:state,:zip,:title,:phone,:extension,:fax,:email,:notes,:priority", nativeQuery = true)
	public void saveContacts(@Param("customerLoginCd") String customerLoginCd, @Param("firstName") String firstName,
			@Param("lastName") String lastName, @Param("address") String address, @Param("city") String city,
			@Param("state") String state, @Param("zip") String zip, @Param("title") String title,
			@Param("phone") String phone, @Param("extension") String extension, @Param("fax") String fax,
			@Param("email") String email, @Param("notes") String notes, @Param("priority") Integer priority);

	@Modifying
	@Query(value = "exec arms_maintainance_modifycontacts :customerLoginCd,:sequence ,:firstName,:lastName,:address"
			+ ",:city,:state,:zip,:title,:phone,:extension,:fax,:email,:notes,:priority,:userLoginCd,:sysProcessName", nativeQuery = true)
	public void updateContacts(@Param("customerLoginCd") String customerLoginCd, @Param("sequence") Integer sequence,
			@Param("firstName") String firstName, @Param("lastName") String lastName, @Param("address") String address,
			@Param("city") String city, @Param("state") String state, @Param("zip") String zip,
			@Param("title") String title, @Param("phone") String phone, @Param("extension") String extension,
			@Param("fax") String fax, @Param("email") String email, @Param("notes") String notes,
			@Param("priority") Integer priority, @Param("userLoginCd") String userLoginCd,
			@Param("sysProcessName") String sysProcessName);

	@Query(value = "exec arms_maintenance_cust_ap_sub_grp_billing_period :group,:region", nativeQuery = true)
	public List<Object[]> getMaintenanceSubGroupBillingPeriod(@Param("group") String group,
			@Param("region") String region);

}

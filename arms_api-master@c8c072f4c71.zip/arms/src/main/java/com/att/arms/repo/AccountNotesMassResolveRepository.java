package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.AccountNotesMassResolve;

@Transactional
public interface AccountNotesMassResolveRepository extends JpaRepository<AccountNotesMassResolve, String> {

	@Query(value = "Exec arms_custqry_account_note_select_mass_resolve_v22 :account_number, :originating_system", nativeQuery = true)
	public List<AccountNotesMassResolve> getAccountNotes(@Param("account_number") String accountNumber,
			@Param("originating_system") String originatingSystem);

}

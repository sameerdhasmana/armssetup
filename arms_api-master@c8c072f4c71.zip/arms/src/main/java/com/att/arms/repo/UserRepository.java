package com.att.arms.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.GlobalLogonUsers;
@Transactional
public interface UserRepository extends JpaRepository<GlobalLogonUsers, String> {

	
	@Query(value = "exec arms_login_global_loginuser :userLoginCd, :appname, :environment, :userPcName, :userPcLoginId, :userPcIP, :globalLogonResponseCd", nativeQuery = true)
	public GlobalLogonUsers findUserDetails(@Param("userLoginCd") String userLoginCd, @Param("appname") String appname,
			@Param("environment") String environment, @Param("userPcName") String userPcName,
			@Param("userPcLoginId") String userPcLoginId, @Param("userPcIP") String userPcIP,
			@Param("globalLogonResponseCd") Integer globalLogonResponseCd);
	
	@Query(value = "exec arms_user_appl_availability_w_userid :appname,:userLoginCd", nativeQuery = true)
	public String checkSessionTiming(@Param("appname") String appname,@Param("userLoginCd") String userLoginCd);

}

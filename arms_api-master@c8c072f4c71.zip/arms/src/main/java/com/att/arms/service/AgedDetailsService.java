package com.att.arms.service;

import java.util.List;

import com.att.arms.entity.CustomerAgedDetails;

public interface AgedDetailsService {

	public List<CustomerAgedDetails> getCustomerAgedDetails(String profileName, String profileType,
			String strStateClause, String strOriginatingCompanyCD, String strQueryType, String strGroup,
			String strCustomerGrpCd, String strUserLoginCode, String strBillingPeriod, String strStatusClause,
			String strAccountStatusClause, String strClassClause, String strSegmentClause,
			String strOriginatingSystemClause, String myacctNbr, String rollupFlag, String acctInvFlag);

}

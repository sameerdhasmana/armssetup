package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.CustomerNotesService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class CustomerNotesController {

	@Autowired
	CustomerNotesService customerNotesService;

	@PostMapping("customerNotes")
	public ResponseEntity<Object> customerNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(userDetails.getUserLoginCd()) && StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			responseMap = this.customerNotesService.populateCustomerNotes(userDetails.getUserLoginCd(),userDetails.getCustomerGrpCd(),
					responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("custNotesContactInfo")
	public ResponseEntity<Object> customerNotesContactInfo(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			responseMap = this.customerNotesService.populateCustomerNotesContactInfo(userDetails.getCustomerGrpCd(),
					responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("addCustomerNotes")
	public ResponseEntity<Object> addCustomerNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd()) && StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
			responseMap = this.customerNotesService.addCustomerNote(userDetails.getUserLoginCd(),userDetails.getCustomerGrpCd(),
					responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("saveCustomerNotes")
	public ResponseEntity<Object> saveCustomerNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.customerNotesService.validateSaveNotesQuery(userDetails);
		if (response) {
			responseMap = this.customerNotesService.saveCustomerNote(userDetails,responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("resolveCustomerNotes")
	public ResponseEntity<Object> resolveCustomerNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.customerNotesService.validateNotesQuery(userDetails);
		if (response) {
			responseMap = this.customerNotesService.resolveCustomerNotes(userDetails.getUserLoginCd(),userDetails.getNotes(),userDetails.getNoteId(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("deleteCustomerNotes")
	public ResponseEntity<Object> deleteCustomerNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (userDetails!=null && !CollectionUtils.isEmpty(userDetails.getNoteIdList())) {
			responseMap = this.customerNotesService.deleteCustomerNotes(userDetails.getNoteIdList(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("customerPermNotes")
	public ResponseEntity<Object> customerPermNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (userDetails!=null && StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			responseMap = this.customerNotesService.customerPermNotes(userDetails.getCustomerGrpCd(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("customerNotesHistory")
	public ResponseEntity<Object> customerNotesHistory(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (userDetails!=null && StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			responseMap = this.customerNotesService.customerNotesHistory(userDetails.getCustomerGrpCd(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
}

package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class CustomerNotesNextAction {

	@Id
	@JsonProperty("nxtact_cd")
	@Column(name="nxtact_cd")
	private String nxtactCd;
	@JsonProperty("nxtact_desc")
	@Column(name="nxtact_desc")
	private String nxtactDesc;

}

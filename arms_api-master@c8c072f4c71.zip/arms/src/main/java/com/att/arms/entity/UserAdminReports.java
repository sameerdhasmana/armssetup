package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(UserAdminReports.UserAdminReportsId.class)

@Data
public class UserAdminReports {

	@Id
	@JsonProperty("user_login_cd")
	@Column(name = "user_login_cd")
	private String userLoginCd;
	@JsonProperty("originating_company_cd")
	@Column(name = "originating_company_cd")
	private String originatingCompanyCd;
	@JsonProperty("bus_unit_cd")
	@Column(name = "bus_unit_cd")
	private String busUnitCd;
	private String lname;
	private String fname;
	@JsonProperty("phone_nbr")
	@Column(name = "phone_nbr")
	private String phoneNbr;
	@JsonProperty("last_reviewed_by")
	@Column(name = "last_reviewed_by")
	private String lastReviewedBy;
	@JsonProperty("status_ind")
	@Column(name = "status_ind")
	@Id
	private String statusInd;
	@JsonProperty("status_change_dt")
	@Column(name = "status_change_dt")
	private String statusChangeDt;
	@JsonProperty("last_reviewed_dt")
	@Column(name = "last_reviewed_dt")
	private String lastReviewedDt;
	@JsonProperty("insert_dt")
	@Column(name = "insert_dt")
	private String insertDt;
	@JsonProperty("update_dt")
	@Column(name = "update_dt")
	private String updateDt;
	@JsonProperty("last_logged_in")
	@Column(name = "last_logged_in")
	private String lastLoggedIn;
	@JsonProperty("user_role")
	@Column(name = "user_role")
	private Integer userRole;
	private String description;
	@JsonProperty("SupervisorATTUID")
	@Column(name = "SupervisorATTUID")
	private String supervisorATTUID;
	@JsonProperty("times_logged_in")
	@Column(name = "times_logged_in")
	private Integer timesLoggedIn;

	@Data
	public static class UserAdminReportsId implements Serializable {

		private static final long serialVersionUID = 1L;		
		private String statusInd;		
		private String userLoginCd;

	}
}

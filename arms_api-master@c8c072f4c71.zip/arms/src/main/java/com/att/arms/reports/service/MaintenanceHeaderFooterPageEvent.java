package com.att.arms.reports.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.att.arms.config.ReportsConstant;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;


public class MaintenanceHeaderFooterPageEvent extends PdfPageEventHelper {

	private PdfTemplate t;
	private Image total;
	private static final Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 15, Font.BOLD);
	private static final Font boldFont1 = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);

    String billingPeriodHeader;
    String reportStatus;


    @Override
	public void onOpenDocument(PdfWriter writer, Document document) {
		t = writer.getDirectContent().createTemplate(30, 16);
		try {
			total = Image.getInstance(t);
		} catch (BadElementException e) {
			e.printStackTrace();
		}
		total.setRole(PdfName.ARTIFACT);
	}

	@Override
	public void onEndPage(PdfWriter writer, Document document) {
		addHeader(writer);
		addFooter(writer);
	}

	private void addHeader(PdfWriter writer) {
		try {
			Paragraph titleQdsoLf = new Paragraph("All Customer Q-DSO by Grp And Regn - LF",boldFont);
			Paragraph titleQdsoLfw = new Paragraph("All Customer Q-DSO by Grp And Regn - LFW",boldFont);
			Paragraph billingPeriodAmt = new Paragraph("Billing Period: " + billingPeriodHeader, boldFont1);
			
			PdfPTable title = new PdfPTable(2);
			float[] columnWidth1 = { 8f, 3f };
			title.setWidths(columnWidth1);
			title.setTotalWidth(1150);
			title.setLockedWidth(true);
			PdfPCell cell1 =new PdfPCell();
			PdfPCell cell2 =new PdfPCell();
			if (reportStatus.equals("LF")) {
				
				cell1 = new PdfPCell(
						new Paragraph(titleQdsoLf+"", new Font(Font.FontFamily.HELVETICA, 30, Font.BOLD)));
				cell2 = new PdfPCell(new Paragraph(billingPeriodAmt));
			} else if (reportStatus.equals("LFW")) {
				cell1 = new PdfPCell(
						new Paragraph(titleQdsoLfw+"", new Font(Font.FontFamily.HELVETICA, 30, Font.BOLD)));
				cell2 = new PdfPCell(new Paragraph(billingPeriodAmt));
			}
			cell1.setBorder(Rectangle.NO_BORDER);
			cell2.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell2.setHorizontalAlignment(Element.ALIGN_RIGHT);
			title.addCell(cell1);
			title.addCell(cell2);
			PdfContentByte canvas = writer.getDirectContent();
			canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
			title.writeSelectedRows(0, -1, 80, 1770, canvas);
			canvas.endMarkedContentSequence();
		
			
		PdfPTable table = new PdfPTable(11);

		float[] columnWidth2 = { 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

		table.setWidths(columnWidth2);
		table.setTotalWidth(1150);
		table.setLockedWidth(true);
		table.getDefaultCell().setFixedHeight(100);
		table.getDefaultCell().setBorder(Rectangle.TOP);
		table.getDefaultCell().setBorderColor(BaseColor.BLACK);
		
	
		PdfPCell cell3 = new PdfPCell(new Paragraph(ReportsConstant.SEGMENT,boldFont));
		cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.enableBorderSide(Rectangle.TOP);
		cell3.setPaddingBottom(2f);
		cell3.enableBorderSide(Rectangle.BOTTOM);

		PdfPCell cell4 = new PdfPCell(new Paragraph(ReportsConstant.CURRENT_BILLING,boldFont));
		cell4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.enableBorderSide(Rectangle.TOP);
		cell4.setPaddingBottom(2f);
		cell4.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell5 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_0_DAYS,boldFont));
		cell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.enableBorderSide(Rectangle.TOP);
		cell5.setPaddingBottom(2f);
		cell5.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell6 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_30_DAYS,boldFont));
		cell6.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.enableBorderSide(Rectangle.TOP);
		cell6.setPaddingBottom(2f);
		cell6.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell7 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_60_DAYS,boldFont));
		cell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.enableBorderSide(Rectangle.TOP);
		cell7.setPaddingBottom(2f);
		cell7.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell8 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_90_DAYS,boldFont));
		cell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.enableBorderSide(Rectangle.TOP);
		cell8.setPaddingBottom(2f);
		cell8.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell9 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_120_DAYS,boldFont));
		cell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.enableBorderSide(Rectangle.TOP);
		cell9.setPaddingBottom(2f);
		cell9.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell10 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_PAST_DUE,boldFont));
		cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.enableBorderSide(Rectangle.TOP);
		cell10.setPaddingBottom(2f);
		cell10.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell11 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_DUE,boldFont));
		cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.enableBorderSide(Rectangle.TOP);
		cell11.setPaddingBottom(2f);
		cell11.enableBorderSide(Rectangle.BOTTOM);


		PdfPCell cell12 = new PdfPCell(new Paragraph(ReportsConstant.DISPUTE,boldFont));
		cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.enableBorderSide(Rectangle.TOP);
		cell12.setPaddingBottom(2f);
		cell12.enableBorderSide(Rectangle.BOTTOM);

		PdfPCell cell13 = new PdfPCell(new Paragraph(ReportsConstant.QDSO,boldFont));
		cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.enableBorderSide(Rectangle.TOP);
		cell13.setPaddingBottom(2f);
		cell13.enableBorderSide(Rectangle.BOTTOM);
		
		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);

		canvas = writer.getDirectContent();
		canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
		table.writeSelectedRows(0, -1, 80, 1715, canvas);
		canvas.endMarkedContentSequence();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	private void addFooter(PdfWriter writer) {
		PdfPTable footer = new PdfPTable(4);
		try {
			footer.setWidths(new int[] { 10, 80, 5, 2 });
			footer.setTotalWidth(1150);
			footer.setLockedWidth(true);
			footer.getDefaultCell().setFixedHeight(200);
			footer.getDefaultCell().setBorder(Rectangle.TOP);
			footer.getDefaultCell().setBorderColor(BaseColor.BLACK);

			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");
			String date = formatter.format(new Date());

			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			footer.addCell(new Phrase(date, new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD)));
			
			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			footer.addCell(new Phrase("QDSO =(( Current + Total Due )/ Current)*30\r\n"
					+"SOLELY FOR USE BY EMPLOYEES OF AT&T COMPANIES WHO HAVE A NEED TO KNOW.NOT TO BE DISCLOSED TO OR USED BY ANY OTHER PERSON"
					+"WITHOUT PRIOR AUTHORIZATION CONFIDENTIAL\r\n",new Font(Font.FontFamily.HELVETICA, 10)));
			
					
			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			footer.addCell(new Phrase(String.format("Page %d of", writer.getPageNumber()),
					new Font(Font.FontFamily.HELVETICA, 8)));

			PdfPCell totalPageCount = new PdfPCell(total);
			totalPageCount.setBorder(Rectangle.TOP);
			totalPageCount.setBorderColor(BaseColor.BLACK);
			footer.addCell(totalPageCount);

			PdfContentByte canvas = writer.getDirectContent();
			canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
			footer.writeSelectedRows(0, -1, 74, 50, canvas);
			canvas.endMarkedContentSequence();

		} catch (DocumentException de) {
			throw new ExceptionConverter(de);
		}
	}
	@Override
	public void onCloseDocument(PdfWriter writer, Document document) {

		int totalLength = String.valueOf(writer.getPageNumber()).length();
		int totalWidth = totalLength * 5;
		ColumnText.showTextAligned(t, Element.ALIGN_RIGHT,
				new Phrase(String.valueOf(writer.getPageNumber()), new Font(Font.FontFamily.HELVETICA, 8)), totalWidth,
				6, 0);

	}

	public void setHeader(String billingPeriodHeader, String reportStatus) {
        this.billingPeriodHeader = billingPeriodHeader;
		this.reportStatus=reportStatus;
	}
}
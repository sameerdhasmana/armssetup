package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.PermNotes;

@Transactional
public interface PermNotesRepository extends JpaRepository<PermNotes, String> {

	@Query(value = "Exec arms_custqry_account_perm_notes_history_v22 :account_number, :originating_system", nativeQuery = true)
	public List<PermNotes> getPermNotes(@Param("account_number") String accountNumber,
			@Param("originating_system") String originatingSystem);
	
	@Query(value = "Exec arms_custqry_account_notes_history_v22 :account_number, :originating_system", nativeQuery = true)
	public List<PermNotes> getAccountHistoryNotes(@Param("account_number") String accountNumber,
			@Param("originating_system") String originatingSystem);

	
}

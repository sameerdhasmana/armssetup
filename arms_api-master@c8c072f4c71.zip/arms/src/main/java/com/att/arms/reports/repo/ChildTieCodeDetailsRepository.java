package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.ChildTieCodeDetails;

@Transactional
public interface ChildTieCodeDetailsRepository extends JpaRepository<ChildTieCodeDetails, String>{
	@Query(value = "EXEC arms_rpt_customerwith_ctc_grp_v22 :group", nativeQuery = true)
	public List<ChildTieCodeDetails> findChildTieCodeList(@Param("group") String groupList);
}

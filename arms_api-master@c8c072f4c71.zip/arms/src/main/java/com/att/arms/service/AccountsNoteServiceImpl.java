package com.att.arms.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.APSubGroup;
import com.att.arms.entity.AccountContactDetails;
import com.att.arms.entity.AccountNoteTalkedTo;
import com.att.arms.entity.AccountNotes;
import com.att.arms.entity.AccountNotesMassResolve;
import com.att.arms.entity.ContestedAmtView;
import com.att.arms.entity.CustomerNotesNextAction;
import com.att.arms.entity.CustomerNotesRootCause;
import com.att.arms.entity.NotesTemplate;
import com.att.arms.entity.PermNotes;
import com.att.arms.entity.SubActivity;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.APSubGroupRepository;
import com.att.arms.repo.AccountContactDetailsRepository;
import com.att.arms.repo.AccountNoteTalkedToRepository;
import com.att.arms.repo.AccountNotesMassResolveRepository;
import com.att.arms.repo.AccountNotesRepository;
import com.att.arms.repo.ContestedAmtViewRepository;
import com.att.arms.repo.CustomerNotesNextActionRepository;
import com.att.arms.repo.CustomerNotesRootCauseRepository;
import com.att.arms.repo.NotesTemplateRepository;
import com.att.arms.repo.PermNotesRepository;
import com.att.arms.repo.SubActivityRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class AccountsNoteServiceImpl implements AccountsNoteService {

	@Autowired
	AccountNotesRepository accountNotesRepository;
	@Autowired
	PermNotesRepository permNotesRepository;
	@Autowired
	CustomerNotesNextActionRepository customerNotesNextActionRepository;
	@Autowired
	CustomerNotesRootCauseRepository customerNotesRootCauseRepository;
	@Autowired
	SubActivityRepository subActivityRepository;
	@Autowired
	NotesTemplateRepository notesTemplateRepository;
	@Autowired
	APSubGroupRepository aPSubGroupRepository;
	@Autowired
	ContestedAmtViewRepository contestedAmtViewRepository;
	@Autowired
	AccountNoteTalkedToRepository accountNoteTalkedToRepository;
	@Autowired
	AccountContactDetailsRepository accountContactDetailsRepository;
	@Autowired
	AccountNotesMassResolveRepository accountNotesMassResolveRepository;
	@Autowired
	CommonService commonService;

	@Override
	public boolean validateQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getAccountNumber())
				&& StringUtils.isNotEmpty(userDetails.getAcntNoteOrgSys())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validatePopulateQuery(UserDetails userDetails) {
		boolean response = false;
		if (StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())
				&& !CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateAddNotesQuery(UserDetails userDetails) {
		boolean response = false;
		if (StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& StringUtils.isNotEmpty(userDetails.getAccountNumber())
				&& StringUtils.isNotEmpty(userDetails.getAcntNoteOrgSys())
				&& StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateAddDetailNotesQuery(UserDetails userDetails) {
		boolean response = false;
		if (StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())
				&& !CollectionUtils.isEmpty(userDetails.getOriginatingSystem())
				&& StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateGetNotesTextQuery(UserDetails userDetails) {
		boolean response = false;
		if (StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& StringUtils.isNotEmpty(userDetails.getTemplateName())
				&& StringUtils.isNotEmpty(userDetails.getTemplateType())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSaveNotesQuery(UserDetails userDetails) {
		boolean response = false;
		if (StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& StringUtils.isNotEmpty(userDetails.getAccountNumber())
				&& StringUtils.isNotEmpty(userDetails.getAcntNoteOrgSys())
				&& StringUtils.isNotEmpty(userDetails.getActivityCode())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSaveNotesDetailsQuery(UserDetails userDetails) {
		boolean response = false;
		if (StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())
				&& !CollectionUtils.isEmpty(userDetails.getOriginatingSystem())
				&& !CollectionUtils.isEmpty(userDetails.getSaveOptionList())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> populateAccountNotes(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<AccountNotes> accountNotes = accountNotesRepository.getAccountNotes(userDetails.getAccountNumber().trim(),
				userDetails.getAcntNoteOrgSys().trim());
		responseMap.put(ApplicationConstant.ACCOUNT_NOTES, accountNotes);
		commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(), ApplicationConstant.ACCOUNT_NOTES,
				responseMap);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateAccountNotesContactInfo(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		List<Object[]> accountNotesContactInfo = new ArrayList<>();
		List<Object[]> contactInfoList = accountNotesRepository.getAccountNotesContactInfo(
				userDetails.getAccountNumber().trim(), userDetails.getAcntNoteOrgSys().trim());
		if (!CollectionUtils.isEmpty(contactInfoList)) {
			contactInfoList.stream().forEach(ele -> {
				StringJoiner joiner = new StringJoiner(",");
				Object[] objArr = new Object[1];
				for (Object obj : ele) {
					joiner.add((String) obj);
				}
				if (StringUtils.isNotEmpty(joiner.toString())) {
					objArr[0] = joiner.toString();
					accountNotesContactInfo.add(objArr);
				}
			});
		}
		responseMap.put(ApplicationConstant.ACCOUNT_NOTES_CONTACT_INFO, accountNotesContactInfo);
		return responseMap;
	}

	@Override
	public Map<Object, Object> resolveAccountNotes(String userLoginCd, String notes, Integer noteId,
			Map<Object, Object> responseMap) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDate localDate = LocalDate.now();
		String date = dtf.format(localDate);
		notes = notes + " resolved by " + userLoginCd + " on " + date;
		accountNotesRepository.resolveAccountNotes(noteId, 1, notes);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateInTreatmentDetails(String userLoginCd, List<String> accountNumberList,
			List<String> originatingSystemList, Map<Object, Object> responseMap) {
		List<CustomerNotesNextAction> nextActionList = customerNotesNextActionRepository
				.getCustomerNotesNextAction(userLoginCd);
		responseMap.put(ApplicationConstant.NEXT_ACTION, nextActionList);
		List<CustomerNotesRootCause> rootCauseList = customerNotesRootCauseRepository
				.getCustomerNotesRootCause(userLoginCd);
		responseMap.put(ApplicationConstant.ROOT_CAUSE, rootCauseList);
		String selectedAccountNumbers = CommonUtils.getListToCommaSeparatedString(accountNumberList);
		String selectedOrgSystem = CommonUtils.getListToCommaSeparatedString(originatingSystemList);
		List<SubActivity> subActivityList = subActivityRepository.getAccountSubActivityList(selectedAccountNumbers,
				selectedOrgSystem);
		responseMap.put(ApplicationConstant.SUB_ACTIVITY, subActivityList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> addAccountNote(String userLoginCd, String accountNumber, String originatingSystem,
			Map<Object, Object> responseMap) {
		populateAccountNoteScreen(userLoginCd, accountNumber, originatingSystem, responseMap);
		List<ContestedAmtView> contestedAmtList = contestedAmtViewRepository.getContestedAmtViewList(accountNumber,
				originatingSystem, userLoginCd);
		responseMap.put(ApplicationConstant.CONTESTED_AMT, contestedAmtList);
		return responseMap;
	}

	private void populateAccountNoteScreen(String userLoginCd, String selectedAccountNumbers, String selectedOrgSystem,
			Map<Object, Object> responseMap) {
		List<NotesTemplate> notesTemplateList = notesTemplateRepository.getNotesTemplateList(userLoginCd);
		List<AccountNoteTalkedTo> talkedToList = accountNoteTalkedToRepository
				.getAccountNoteTalkedToList(selectedAccountNumbers, selectedOrgSystem);
		responseMap.put(ApplicationConstant.NOTE_TEMPLATE, notesTemplateList);
		responseMap.put(ApplicationConstant.ACNT_NOTE_TALKED_TO, talkedToList);
	}

	@Override
	public Map<Object, Object> addAccountDetails(String userLoginCd, List<String> accountNumberList,
			List<String> originatingSystemList, String customerGrpCd, Map<Object, Object> responseMap) {
		String selectedAccountNumbers = CommonUtils.getListToCommaSeparatedString(accountNumberList);
		String selectedOrgSystem = CommonUtils.getListToCommaSeparatedString(originatingSystemList);
		populateAccountNoteScreen(userLoginCd, selectedAccountNumbers, selectedOrgSystem, responseMap);
		List<AccountContactDetails> accountContactList = accountContactDetailsRepository
				.getAccountContactDetailsList(userLoginCd, selectedAccountNumbers, selectedOrgSystem);
		responseMap.put(ApplicationConstant.ACNT_CONTACT_LIST, accountContactList);
		List<APSubGroup> apSubGroupList = aPSubGroupRepository.getAPSubGroupList(customerGrpCd);
		responseMap.put(ApplicationConstant.AP_SUB_GROUP, apSubGroupList);
		List<Object[]> hotNoteList = accountNotesRepository.getHotNotes(selectedAccountNumbers, " ", userLoginCd,
				selectedOrgSystem);
		responseMap.put(ApplicationConstant.HOT_NOTE, hotNoteList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> deleteAccountNotes(List<String> noteIdList, String userLoginCd,
			Map<Object, Object> responseMap) {
		String noteList = CommonUtils.getListToCommaSeparatedString(noteIdList);
		accountNotesRepository.deleteAccountNotes(noteList, userLoginCd);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;

	}

	@Override
	public Map<Object, Object> saveAccountNotes(UserDetails userDetails, Map<Object, Object> responseMap) {
		String mode = (userDetails.getModeType() != null && userDetails.getModeType().equals(2)) ? "M" : "I";
		Integer myBringUp = userDetails.getMyBringUp() != null ? userDetails.getMyBringUp() : 0;
		accountNotesRepository.saveAccountNotes(mode, userDetails.getBillingPeriod(), userDetails.getAccountNumber(),
				userDetails.getAcntNoteOrgSys(), userDetails.getNoteId(), userDetails.getTalkedTo(),
				userDetails.getNotes(), userDetails.getUserLoginCd(), userDetails.getNextCallBackDate(),
				userDetails.getCommitmentAmt(), userDetails.getResolved(), userDetails.getActivityCode(),
				userDetails.getSubActivity(), userDetails.getCopyToBiller(), userDetails.getBillerNotePerm(),
				userDetails.getCallType(), userDetails.getPaymentMethod(), userDetails.getCustomerPhoneNumber(),
				userDetails.getCustomerPhoneNumberExtn(), userDetails.getCustomerEmail(), userDetails.getAttuid(),
				userDetails.getBringupType(), userDetails.getSendToAdapt(), userDetails.getContestedAmt(),
				userDetails.getRcCode(), userDetails.getNxtactCode(), userDetails.getCommitmentDate(), myBringUp);
		responseMap.put("msg", ApplicationConstant.SUCCESS);

		return responseMap;
	}

	@Override
	public Map<Object, Object> saveAccountDetails(UserDetails userDetails, Map<Object, Object> responseMap) {
		String mode = (userDetails.getModeType() != null && userDetails.getModeType().equals(2)) ? "M" : "I";
		Integer noteId = (userDetails.getNoteId() != null && userDetails.getNoteId() > 0) ? userDetails.getNoteId()
				: -1;
		Integer myBringUp = userDetails.getMyBringUp() != null ? userDetails.getMyBringUp() : 0;
		List<String> accountNumberList = userDetails.getSelectedAccountNumbers();
		String selectedAccountNumbers = CommonUtils.getListToCommaSeparatedString(accountNumberList);
		String selectedOriginatingSystems = CommonUtils
				.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		if (userDetails.getSaveOptionList().contains(1)) {
			IntStream.range(0, accountNumberList.size()).forEach(i -> accountNotesRepository.saveAccountNotes(mode,
					userDetails.getBillingPeriod(), accountNumberList.get(i), userDetails.getOriginatingSystem().get(i),
					userDetails.getNoteId(), userDetails.getTalkedTo(), userDetails.getNotes(),
					userDetails.getUserLoginCd(), userDetails.getNextCallBackDate(), userDetails.getCommitmentAmtList().get(i),
					userDetails.getResolved(), userDetails.getActivityCode(), userDetails.getSubActivity(),
					userDetails.getCopyToBiller(), userDetails.getBillerNotePerm(), userDetails.getCallType(),
					userDetails.getPaymentMethod(), userDetails.getCustomerPhoneNumber(),
					userDetails.getCustomerPhoneNumberExtn(), userDetails.getCustomerEmail(), userDetails.getAttuid(),
					userDetails.getBringupType(), userDetails.getSendToAdapt(), userDetails.getContestedAmtList().get(i),
					userDetails.getRcCode(), userDetails.getNxtactCode(), userDetails.getCommitmentDateList().get(i), myBringUp));
		}
		if (userDetails.getSaveOptionList().contains(2) && StringUtils.isNotEmpty(userDetails.getApSubGroupName())) {
			accountNotesRepository.saveAPSubGroup(selectedAccountNumbers, userDetails.getApSubGroupName(),
					userDetails.getUserLoginCd(), ApplicationConstant.ACCOUNT_DETAILS_UPDATE,
					selectedOriginatingSystems);
		}
		if (userDetails.getSaveOptionList().contains(3) && StringUtils.isNotEmpty(userDetails.getHotNote())) {
			accountNotesRepository.updateHotNotes(selectedAccountNumbers, userDetails.getHotNote(),
					userDetails.getUserLoginCd(), selectedOriginatingSystems);
		}
		if (userDetails.getSaveOptionList().contains(4) && StringUtils.isNotEmpty(userDetails.getContactInfoFlag())) {
			if (userDetails.getContactInfoFlag().equalsIgnoreCase("A")) {
				accountNotesRepository.addAccountContact(userDetails.getCustomerGrpCd(), userDetails.getFirstName(),
						userDetails.getLastName(), userDetails.getAddress(), userDetails.getCity(),
						userDetails.getState(), userDetails.getZip(), userDetails.getTitle(),
						userDetails.getPhoneNumber(), userDetails.getPhoneNumberExtn(), userDetails.getFaxNumber(),
						userDetails.getEmail(), userDetails.getContactNote(), userDetails.getPhoneNumber2(),
						userDetails.getEmail2(), userDetails.getEmaor(), userDetails.getEmaorPrimary(),
						userDetails.getEmaorEffDate(), selectedAccountNumbers, selectedOriginatingSystems,
						userDetails.getUserLoginCd());
			} else if (userDetails.getContactInfoFlag().equalsIgnoreCase("M")) {
				accountNotesRepository.updateAccountContact(userDetails.getCustomerGrpCd(), userDetails.getSequence(),
						userDetails.getFirstName(), userDetails.getLastName(), userDetails.getAddress(),
						userDetails.getCity(), userDetails.getState(), userDetails.getZip(), userDetails.getTitle(),
						userDetails.getPhoneNumber(), userDetails.getPhoneNumberExtn(), userDetails.getFaxNumber(),
						userDetails.getEmail(), userDetails.getContactNote(), userDetails.getUserLoginCd(),
						ApplicationConstant.ACCOUNT_DETAILS_UPDATE, userDetails.getPhoneNumber2(),
						userDetails.getEmail2(), userDetails.getEmaor(), userDetails.getEmaorPrimary(),
						userDetails.getEmaorEffDate(), selectedAccountNumbers, selectedOriginatingSystems);
			}
			accountNotesRepository.assignAccountContact(selectedAccountNumbers, noteId, userDetails.getUserLoginCd(),
					ApplicationConstant.ACCOUNT_DETAILS_UPDATE, selectedOriginatingSystems);
		}
		responseMap.put("msg", ApplicationConstant.SUCCESS);

		return responseMap;
	}

	@Override
	public Map<Object, Object> getAccountNoteText(String userLoginCd, String templateName, String templateType,
			Map<Object, Object> responseMap) {
		String noteText = accountNotesRepository.getAccountNoteText(userLoginCd, templateName, templateType);
		responseMap.put(ApplicationConstant.ACNT_NOTE_TEXT, noteText);
		return responseMap;
	}

	@Override
	public boolean validateMassNotesQuery(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())
				&& !CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSaveMassNotesQuery(UserDetails userDetails) {
		boolean response = false;
		if (StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& !CollectionUtils.isEmpty(userDetails.getNoteIdList())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> massResolveAccountNotes(List<String> accountNumberList,
			List<String> originatingSystemList, Map<Object, Object> responseMap) {
		List<AccountNotesMassResolve> consolidatedAccountNotes = new ArrayList<>();
		for (int i = 0; i < accountNumberList.size(); i++) {
			List<AccountNotesMassResolve> accountNotes = accountNotesMassResolveRepository
					.getAccountNotes(accountNumberList.get(i), originatingSystemList.get(i));
			if (!CollectionUtils.isEmpty(accountNotes)) {
				consolidatedAccountNotes.addAll(accountNotes);
			}
		}
		responseMap.put(ApplicationConstant.ACCOUNT_NOTES, consolidatedAccountNotes);
		return responseMap;
	}

	@Override
	public Map<Object, Object> saveMassResolveAccountNotes(String userLoginCd, List<String> notesList,
			List<String> noteIdList, Map<Object, Object> responseMap) {
		IntStream.range(0, noteIdList.size()).forEach(i -> {
			String notes = notesList != null && notesList.get(i) != null ? notesList.get(i) : "";
			resolveAccountNotes(userLoginCd, notes, Integer.parseInt(noteIdList.get(i)), responseMap);
		});
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populatePermNotes(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<PermNotes> permNotes = permNotesRepository.getPermNotes(userDetails.getAccountNumber().trim(),
				userDetails.getAcntNoteOrgSys().trim());
		responseMap.put(ApplicationConstant.PERM_NOTES, permNotes);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateAccountHistory(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<PermNotes> permNotes = permNotesRepository.getAccountHistoryNotes(userDetails.getAccountNumber().trim(),
				userDetails.getAcntNoteOrgSys().trim());
		responseMap.put(ApplicationConstant.ACCOUNT_NOTES_HISTORY, permNotes);
		return responseMap;
	}

	@Override
	public boolean validateDeleteQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd()) && userDetails.getSequence() != null
				&& StringUtils.isNotEmpty(userDetails.getContactid())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())
				&& !CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> deleteAccountContacts(UserDetails userDetails, Map<Object, Object> responseMap) {
		String selectedAccountNumbers = CommonUtils
				.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());
		String selectedOriginatingSystems = CommonUtils
				.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		accountNotesRepository.deleteAccountContacts(userDetails.getCustomerGrpCd(), userDetails.getSequence(),
				userDetails.getUserLoginCd(), ApplicationConstant.ACCOUNT_DETAILS_UPDATE, userDetails.getContactid(),
				selectedAccountNumbers, selectedOriginatingSystems);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}
}

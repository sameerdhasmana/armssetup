package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.H1uidDetails;

@Transactional
public interface H1uidDetailsRepository extends JpaRepository<H1uidDetails, String> {

	@Query(value = "select h1uid,h1uid + ' ' + lname + ', ' + fname as userid from arms_rpt_hierarchy"
			+ " inner join users on arms_rpt_hierarchy.h1uid=users.user_login_cd where h2uid =:h2uid"
			+ " order by h1uid asc", nativeQuery = true)
	public List<H1uidDetails> getH1uidDetails(@Param("h2uid") String h2uid);

	
}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.ViewInternalContacts;

@Transactional
public interface ViewInternalContactsRepository extends JpaRepository<ViewInternalContacts, String> {

	@Query(value = "Exec arms_view_ext_contacts_v22 :user_login_cd, :account_numbers, :originating_systems", nativeQuery = true)
	public List<ViewInternalContacts> viewInternalContacts(@Param("user_login_cd") String userLoginCd,
			@Param("account_numbers") String accountNumbers, @Param("originating_systems") String originatingSystems);

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.ManageProfileCustomers;

@Transactional
public interface ManageProfileCustomersRepository extends JpaRepository<ManageProfileCustomers, String> {

	@Query(value = "EXEC arms_profmgt_qry_lb_v22 :queryType,:group,:enteredValue,:originatingSystem,"
			+ ":userLoginCd,:status,:accountStatus,:exclusionClass,:segment,:rollUp", nativeQuery = true)
	public List<ManageProfileCustomers> getCustomersInfo(@Param("queryType") String queryType,
			@Param("group") String group,@Param("enteredValue") String enteredValue,@Param("originatingSystem") String originatingSystem
			,@Param("userLoginCd") String userLoginCd,@Param("status") String status,@Param("accountStatus") String accountStatus
			,@Param("exclusionClass") String exclusionClass,@Param("segment") String segment
			,@Param("rollUp") String rollUp);

}

package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(OpenFlagActivity.OpenFlagActivityId.class)
@Data
public class OpenFlagActivity {

	@Id
	@JsonProperty("account_number")
	@Column(name="ACCTNBR")
	private String accountNumber;
	@JsonProperty("past_due_amt")
	@Column(name="past_due_amt")
	private Double pastDueAmt;
	@JsonProperty("state")
	@Column(name="state_cd")
	private String stateCd;
	@JsonProperty("status")
	@Column(name="status_cd")
	private String status;
	@JsonProperty("Customer")
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	@Id
	@JsonProperty("originating_system")
	@Column(name="originating_system")
	private String originatingSystem;
	@JsonProperty("Assigned_CAS")
	@Column(name="collections_userid")
	private String collectionsUserid;
	@JsonProperty("Bill_Name")
	@Column(name="customer_nm")
	private String customerName;
	@JsonProperty("flag_age")
	@Column(name="flagage")
	private String flagage;
	@JsonProperty("flag_activity")
	private String flagActivity;
	@JsonProperty("current_billing_amt")
	@Column(name="current_billing_amt")
	private Double currentBillingAmt;
	@JsonProperty("current_balance_amt")
	@Column(name="past_due_0_amt")
	private Double currentBalanceAmt;
	@JsonProperty("30_days_amt")
	@Column(name="past_due_30_amt")
	private Double pastDue30Amt;
	@JsonProperty("60_days_amt")
	@Column(name="past_due_60_amt")
	private Double pastDue60Amt;
	@JsonProperty("90_days_amt")
	@Column(name="past_due_90_amt")
	private Double pastDue90Amt;
	@JsonProperty("120_days_amt")
	@Column(name="past_due_120_amt")
	private Double pastDue120Amt;
	@JsonProperty("collectable_amt")
	@Column(name="total_amt")
	private Double totalAmt;
	@JsonProperty("bill_dt")
	@Column(name="last_billing_dt")
	private String billDate;
	@JsonProperty("treatment_step")
	@Column(name="sub_activity_short_description")
	private String treatmentStep;
	@JsonProperty("ap_sub_group")
	@Column(name="ap_sub_grp_nm")
	private String apSubGroup;
	
	@SuppressWarnings("serial")
	@Data
	public static class OpenFlagActivityId implements Serializable {

		private String accountNumber;
		private String originatingSystem;
		
	}
}

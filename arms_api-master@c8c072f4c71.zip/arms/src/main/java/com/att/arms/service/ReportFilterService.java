package com.att.arms.service;

import java.util.List;
import java.util.Map;

import com.att.arms.entity.AccountClassification;
import com.att.arms.entity.ChildTieCodeDetails;
import com.att.arms.entity.CustomerBillingPeriod;
import com.att.arms.entity.CustomerGroupList;
import com.att.arms.entity.CustomerSegment;
import com.att.arms.entity.DispIntervalDetails;
import com.att.arms.entity.OriginatingSystem;
import com.att.arms.entity.RegionDetails;
import com.att.arms.entity.ReportFilterCTCDetailsResponse;
import com.att.arms.entity.ReportFilterResponse;
import com.att.arms.entity.TemplateFieldsDetails;
import com.att.arms.entity.UserDetails;

public interface ReportFilterService {
	public List<CustomerGroupList> findcustomerGroupList(String group);

	public List<CustomerBillingPeriod> findCustomerBillingPeriod(List<String> group);

	public List<CustomerSegment> findCustomerSegmentList(List<String> group);

	public List<AccountClassification> findAccountsClassificationList();

	public List<OriginatingSystem> findOriginatingSystemList();
	
	public ReportFilterResponse populateReportFilter(ReportFilterResponse filter, UserDetails userDetails);
	
	public Map<Object, Object> getAllCustomers(Map<Object, Object> responseMap);
	
	public List<ChildTieCodeDetails> findChildTieCodeList(String groupList);
	
	public List<DispIntervalDetails> findDispIntervalList();
	
	public List<TemplateFieldsDetails> findTemplateFieldsList();
	
	public List<RegionDetails> findRegionDetailsList();
	
	public ReportFilterCTCDetailsResponse populateReportCTCDetailsFilter(ReportFilterCTCDetailsResponse filter, UserDetails userDetails);

	public Map<Object, Object> loadTemplateFiles(String userLoginCd, String reportType, Map<Object, Object> responseMap);

}

package com.att.arms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.AccountClassification;
import com.att.arms.entity.CustomerAgedDetails;
import com.att.arms.entity.CustomerGroupList;
import com.att.arms.entity.CustomerSegment;
import com.att.arms.entity.ManageProfileCustomers;
import com.att.arms.entity.ManageProfileDetails;
import com.att.arms.entity.OriginatingSystem;
import com.att.arms.entity.ProfileClassification;
import com.att.arms.entity.ProfileDetails;
import com.att.arms.entity.ProfileManagementUsers;
import com.att.arms.entity.ProfileModel;
import com.att.arms.entity.RequestModel;
import com.att.arms.entity.SubActivity;
import com.att.arms.repo.CustomerAgedDetailsRepository;
import com.att.arms.repo.ManageProfileCustomersRepository;
import com.att.arms.repo.ManageProfileDetailsRepository;
import com.att.arms.repo.OriginatingSystemRepository;
import com.att.arms.repo.ProfileClassificationRepository;
import com.att.arms.repo.ProfileDetailsRepository;
import com.att.arms.repo.ProfileManagementUsersRepository;
import com.att.arms.repo.SubActivityRepository;
import com.att.arms.reports.repo.GroupFetchingRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class ProfileServiceImpl implements ProfileService {

	@Autowired
	SubActivityRepository subActivityRepository;
	@Autowired
	ProfileDetailsRepository profileDetailsRepository;
	@Autowired
	ProfileManagementUsersRepository profileManagementUsersRepository;
	@Autowired
	OriginatingSystemRepository originatingSystemRepository;
	@Autowired
	GroupFetchingRepository groupFetchingRepository;
	@Autowired
	FilterService filterService;
	@Autowired
	ProfileClassificationRepository profileClassificationRepository;
	@Autowired
	ManageProfileCustomersRepository manageProfileCustomersRepository;
	@Autowired
	ManageProfileDetailsRepository manageProfileDetailsRepository;
	@Autowired
	CustomerAgedDetailsRepository customerAgedDetailsRepository;
	@Autowired
	CommonService commonService;
	
	@Override
	public Map<Object, Object> renderManageProfile(String userLoginCd, String businessGroup,
			Map<Object, Object> responseMap) {
		List<SubActivity> subActivity = subActivityRepository.getManageProfileSubActivityList();
		responseMap.put(ApplicationConstant.FLAG_ACTIVITY, subActivity);
		List<ProfileDetails> profileDetails = profileDetailsRepository.getProfileDetails(userLoginCd);
		responseMap.put(ApplicationConstant.SORT_ORDER, profileDetails);
		List<ProfileManagementUsers> userList = profileManagementUsersRepository
				.getProfileManagementUsersList(userLoginCd);
		responseMap.put(ApplicationConstant.ALL_USERS, userList);
		List<CustomerGroupList> businessGrp = groupFetchingRepository.findcustomerGroupList(businessGroup);
		responseMap.put(ApplicationConstant.BUSINESS_GROUP, businessGrp);
		populateFilters(businessGroup, responseMap);
		populateProfileDetails(userLoginCd, responseMap);
		return responseMap;
	}
	
	private Map<Object,Object> populateFilters(String businessGroup,Map<Object, Object> responseMap){
		List<OriginatingSystem> originatingSystem = originatingSystemRepository.findOriginatingSystemList();
		responseMap.put(ApplicationConstant.ORIGINATING_SYSTEM_LIST, originatingSystem);
		List<String> selectedGrpList = new ArrayList<>();
		selectedGrpList.add(businessGroup);
		List<CustomerSegment> segmentList = filterService.findCustomerSegmentList(selectedGrpList);
		responseMap.put(ApplicationConstant.SEGMENT, segmentList);
		List<AccountClassification> accountsClassificationList = filterService.findAccountsClassificationList();
		responseMap.put(ApplicationConstant.EXCLUSION_CLASS, accountsClassificationList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateProfileDetails(String userLoginCd, Map<Object, Object> responseMap) {
		List<ProfileClassification> profileList = profileClassificationRepository.getProfileDetails(userLoginCd);
		responseMap.put(ApplicationConstant.PROFILE_DETAILS, profileList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateProfileCustomers(RequestModel requestModel, Map<Object, Object> responseMap) {
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(requestModel.getOriginatingSystem());
		String group = CommonUtils.getListToCommaSeparatedString(requestModel.getGroupSelected());
		List<ManageProfileCustomers> customerInfo = manageProfileCustomersRepository.getCustomersInfo(
				requestModel.getQueryType(), group, requestModel.getEnteredValue(), originatingSystem,
				requestModel.getUserLoginCd(), "", "", "", "", "N");
		responseMap.put(ApplicationConstant.CUSTOMER_INFO, customerInfo);
		return responseMap;
	}

	@Override
	public boolean validatePopulateCustomerQuery(RequestModel requestModel) {
		boolean response = false;
		if (requestModel != null && StringUtils.isNotEmpty(requestModel.getQueryType())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSaveManageProfileQuery(ProfileModel profileModel) {
		boolean response = false;
		if (profileModel != null && StringUtils.isNotEmpty(profileModel.getUserLoginCd())
				&& StringUtils.isNotEmpty(profileModel.getCustomerGrpCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> saveManageProfile(ProfileModel profileModel, Map<Object, Object> responseMap) {
		String exclusionClass = CommonUtils.getListToCommaSeparatedString(profileModel.getExclusionClass());
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(profileModel.getOriginatingSystem());
		String group = CommonUtils.getListToCommaSeparatedString(profileModel.getGroupSelected());
		String status = CommonUtils.getListToCommaSeparatedString(profileModel.getStatusClause());
		String segment = CommonUtils.getListToCommaSeparatedString(profileModel.getSegment());
		String flagActivity = CommonUtils.getListToCommaSeparatedString(profileModel.getFlagActivity());
		String flagActivityDesc = CommonUtils.getListToCommaSeparatedString(profileModel.getFlagActivityDesc());
		String h1Logins = CommonUtils.getListToCommaSeparatedString(profileModel.getH1Logins());
		String response = profileDetailsRepository.saveManageProfile(profileModel.getUserLoginCd(), null,
				profileModel.getProfileType(), profileModel.getProfileName(), profileModel.getProfileOwner(),
				profileModel.getQueryType(), profileModel.getCustomerGrpCd(), profileModel.getQueryAcna(),
				profileModel.getQueryAecn(), profileModel.getQueryOcn(), profileModel.getQueryCtc(),
				profileModel.getQueryBillName(), profileModel.getExclusions(), exclusionClass, originatingSystem, group,
				status, segment, profileModel.getRollUptoParent(), profileModel.getBringUpDateRef(),
				profileModel.getBringUpType(), flagActivity, flagActivityDesc, profileModel.getFlagDateRef(),
				profileModel.getAmountType(), profileModel.getAmountOperator(), profileModel.getAmountValue(),
				profileModel.getDisputedAmountRef(), profileModel.getContestedAmountRef(),
				profileModel.getUnappliedAmtOperator(), profileModel.getUnappliedAmtValue(),
				profileModel.getUserAssignmentInd(), profileModel.getSort1Field(), profileModel.getSort1Order(),
				profileModel.getSort2Field(), profileModel.getSort2Order(), profileModel.getSort3Field(),
				profileModel.getSort3Order(), profileModel.getSort4Field(), profileModel.getSort4Order(),
				profileModel.getSort5Field(), profileModel.getSort5Order(), h1Logins);
		if (StringUtils.isEmpty(response)) {
			responseMap.put("msg", ApplicationConstant.SUCCESS);
		} else {
			responseMap.put("msg", response);
		}
		return responseMap;
	}

	@Override
	public boolean validateDefaultProfileQuery(ProfileModel profileModel) {
		boolean response = false;
		if (profileModel != null && StringUtils.isNotEmpty(profileModel.getUserLoginCd())
				&& StringUtils.isNotEmpty(profileModel.getProfileName())
				&& StringUtils.isNotEmpty(profileModel.getProfileType())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> setDefaultProfile(String userLoginCd, String profileName, String profileType,
			Map<Object, Object> responseMap) {
		profileDetailsRepository.setDefaultProfile(userLoginCd, profileName, profileType);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> deleteProfile(String userLoginCd, String profileName, String profileType,
			Map<Object, Object> responseMap) {
		profileDetailsRepository.deleteProfile(userLoginCd, profileName, profileType);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> loadProfile(String userLoginCd, String profileName, String profileType,
			Map<Object, Object> responseMap) {
		ManageProfileDetails profileDetails = manageProfileDetailsRepository.getManageProfileDetails(userLoginCd,
				profileName, profileType);
		if (profileDetails != null) {
			List<String> exclusionClass = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileExclusionClass());
			profileDetails.setExclusionClass(exclusionClass);
			List<String> originatingSystem = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileOriginatingSystem());
			profileDetails.setOriginatingSystem(originatingSystem);
			List<String> businessGroup = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileBusinessGroup());
			profileDetails.setBusinessGroup(businessGroup);
			List<String> statusClause = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileStatusClause());
			profileDetails.setStatusClause(statusClause);
			List<String> segment = CommonUtils.getCommaSeparatedStringToList(profileDetails.getProfileSegment());
			profileDetails.setSegment(segment);
			List<String> flagActivity = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileFlagActivity());
			profileDetails.setFlagActivity(flagActivity);
			List<String> flagActivityDesc = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileFlagDescList());
			profileDetails.setFlagActivityDesc(flagActivityDesc);
			List<String> h1Logins = CommonUtils.getCommaSeparatedStringToList(profileDetails.getProfileH1Logins());
			profileDetails.setH1Logins(h1Logins);
			responseMap.put(ApplicationConstant.PROFILE_DETAILS, profileDetails);
		}
		return responseMap;
	}

	@Override
	public Map<Object, Object> executeProfile(ProfileModel profileModel, Map<Object, Object> responseMap) {
		ManageProfileDetails profileDetails = manageProfileDetailsRepository.getManageProfileDetails(
				profileModel.getUserLoginCd(), profileModel.getProfileName(), profileModel.getProfileType());
		if (profileDetails != null) {
			List<String> exclusionClass = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileExclusionClass());
			profileDetails.setExclusionClass(exclusionClass);
			List<String> originatingSystem = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileOriginatingSystem());
			profileDetails.setOriginatingSystem(originatingSystem);
			List<String> businessGroup = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileBusinessGroup());
			profileDetails.setBusinessGroup(businessGroup);
			List<String> statusClause = CommonUtils
					.getCommaSeparatedStringToList(profileDetails.getProfileStatusClause());
			profileDetails.setStatusClause(statusClause);
			List<String> segment = CommonUtils.getCommaSeparatedStringToList(profileDetails.getProfileSegment());
			profileDetails.setSegment(segment);
			responseMap.put(ApplicationConstant.PROFILE_DETAILS, profileDetails);
			
			  List<CustomerAgedDetails> agedDetail =
			  customerAgedDetailsRepository.getCustomerAgedDetails(profileModel.
			  getProfileName(), profileModel.getProfileType(), "", "",
			  ApplicationConstant.ALL_CUSTOMERS, profileDetails.getProfileBusinessGroup(),
			  profileDetails.getCustomerGrpCd(), profileModel.getUserLoginCd(),
			  profileModel.getBillingPeriod(), profileDetails.getProfileStatusClause(),
			  profileDetails.getProfileExclusions(),
			  profileDetails.getProfileExclusionClass(),
			  profileDetails.getProfileSegment(),
			  profileDetails.getProfileOriginatingSystem(), "", "1", "account");
			  responseMap.put(ApplicationConstant.AGED_DETAIL, agedDetail);
			 
			commonService.populateHeaderParameters(profileModel.getUserLoginCd().trim(),
					ApplicationConstant.AGED_DETAIL, responseMap);
		}
		return responseMap;
	}
}

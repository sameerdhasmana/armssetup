package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.EmailService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class MailController {

	@Autowired
	EmailService emailService;

	@PostMapping("emailTmpltList")
	public ResponseEntity<Object> emailTmpltList() {

		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = this.emailService.emailTmpltList(responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("emailTmpltName")
	public ResponseEntity<Object> emailTmpltName(@RequestBody UserDetails userDetails) {
		boolean response = this.emailService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.emailService.emailTmpltName(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("sendEmail")
	public ResponseEntity<Object> sendEmail(@RequestBody UserDetails userDetails) {
		boolean response = this.emailService.validateMailRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.emailService.sendEmail(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("accountEmailupdate")
	public ResponseEntity<Object> accountEmailupdate(@RequestBody UserDetails userDetails) {
		boolean response = this.emailService.validateMailUpdateRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.emailService.accountEmailupdate(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("accountMailEligibleUpdate")
	public ResponseEntity<Object> mailEligibleUpdate(@RequestBody UserDetails userDetails) {
		boolean response = this.emailService.mailEligibleUpdate(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.emailService.mailEligibleUpdate(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
}

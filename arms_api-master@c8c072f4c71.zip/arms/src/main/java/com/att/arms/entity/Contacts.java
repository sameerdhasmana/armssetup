package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class Contacts {

	@Id
	@JsonProperty("contacts_id")
	@Column(name="contacts_id")
	private Integer contactsId;
	private String contact;
	@JsonProperty("user_msg")
	@Column(name="user_msg")
	private String userMsg;

}

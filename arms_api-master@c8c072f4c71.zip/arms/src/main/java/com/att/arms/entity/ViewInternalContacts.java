package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(ViewInternalContacts.ViewInternalContactsId.class)

@Data
public class ViewInternalContacts {

	@Id
	@JsonProperty("account_number")
	@Column(name = "account_number")
	private String accountNumber;
	@Id
	private String biller;
	private String collector;
	@JsonProperty("center_phone")
	@Column(name = "center_phone")
	private String centerPhone;
	private String extension;
	@JsonProperty("account_name")
	@Column(name = "account_name")
	private String accountName;
	@JsonProperty("ae_attuid")
	@Column(name = "ae_attuid")
	private String aeAttuid;
	@JsonProperty("sales_mgr")
	@Column(name = "sales_mgr")
	private String salesMgr;
	@JsonProperty("branch_mgr")
	@Column(name = "branch_mgr")
	private String branchMgr;

	@Data
	public static class ViewInternalContactsId implements Serializable {
		private static final long serialVersionUID = 1L;
		private String biller;
		private String accountNumber;

	}

}

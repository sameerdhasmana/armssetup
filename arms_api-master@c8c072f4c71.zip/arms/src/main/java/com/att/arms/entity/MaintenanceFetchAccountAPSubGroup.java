package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class MaintenanceFetchAccountAPSubGroup {

	
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("bill_name")
	@Column(name="bill_name")
	private String billName;
	private String system;
	private String segment;
	private String state;
	@Id
	@JsonProperty("account_number")
	@Column(name="account_number")
	private String accountNumber;
	@JsonProperty("sub_group")
	@Column(name="sub_group")
	private String subGroup;


}

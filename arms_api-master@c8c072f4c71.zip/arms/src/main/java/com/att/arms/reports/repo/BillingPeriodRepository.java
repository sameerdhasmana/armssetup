package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerBillingPeriod;

@Transactional
public interface BillingPeriodRepository extends JpaRepository<CustomerBillingPeriod, String> {


	@Query(value = "SELECT DISTINCT billing_period FROM distinct_billing_period with (nolock) where bus_unit_cd in (:group) ORDER BY billing_period DESC", nativeQuery = true)
	public List<CustomerBillingPeriod> findCustomerBillingPeriod(@Param("group") List<String> group);	
}

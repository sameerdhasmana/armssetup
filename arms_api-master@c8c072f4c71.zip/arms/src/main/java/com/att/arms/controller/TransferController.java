package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.TransferService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class TransferController {

	@Autowired
	TransferService transferService;

	@PostMapping("getUsers")
	public ResponseEntity<Object> getUsers() {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = transferService.getUsers(responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("transferNotes")
	public ResponseEntity<Object> transferNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = transferService.validateTransferNotesQueryRequest(userDetails);
		if(response) {
		responseMap = this.transferService.transferNotes(userDetails.getUserLoginCdFrom(),userDetails.getUserLoginCdTo(),responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("transferContacts")
	public ResponseEntity<Object> transferContacts(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = transferService.validateTransferCustomerQueryRequest(userDetails);
		if(response) {
		responseMap = this.transferService.transferCustomer(userDetails.getCustomerGrpCdFrom(),userDetails.getCustomerGrpCdTo(),responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
}
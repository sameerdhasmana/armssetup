package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.RequestModel;
import com.att.arms.service.ManagementService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class ManagementController {

	@Autowired
	ManagementService managementService;

	
	@PostMapping("searchByAccount")
	public ResponseEntity<Object> searchByAccount(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = managementService.validateSearchByAccountQueryRequest(requestModel);
		if(response) {
		responseMap = this.managementService.searchByAccount(requestModel.getUserLoginCd(),requestModel.getAccountNumber(),responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("renderSearchByCustomer")
	public ResponseEntity<Object> renderSearchByCustomer(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if(StringUtils.isNotEmpty(requestModel.getUserLoginCd())) {
		responseMap = this.managementService.renderSearchByCustomer(requestModel.getUserLoginCd(),responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("searchByCustomer")
	public ResponseEntity<Object> searchByCustomer(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = managementService.validateSearchByCustomerRequest(requestModel);
		if(response) {
		responseMap = this.managementService.searchByCustomer(requestModel,responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("populateSegment")
	public ResponseEntity<Object> populateSegment(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if(!CollectionUtils.isEmpty(requestModel.getGroupSelected())) {
		responseMap = this.managementService.populateSegment(requestModel.getGroupSelected(),responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("paymentTermUpdate")
	public ResponseEntity<Object> paymentTermUpdate(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = managementService.validatePaymentTermUpdateRequest(requestModel);
		if(response) {
		responseMap = this.managementService.paymentTermUpdate(requestModel,responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("getAllManagers")
	public ResponseEntity<Object> getAllManagers() {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = managementService.getAllManagers(responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("outstandingBringUpReport")
	public ResponseEntity<Object> outstandingBringUpReport(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if(StringUtils.isNotEmpty(requestModel.getManagerLoginCd())) {
		responseMap = this.managementService.outstandingBringUpReport(requestModel.getManagerLoginCd(),responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("openFlagActivityReport")
	public ResponseEntity<Object> openFlagActivityReport(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if(StringUtils.isNotEmpty(requestModel.getManagerLoginCd())) {
		responseMap = this.managementService.openFlagActivityReport(requestModel.getManagerLoginCd(),responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("notesActivityReport")
	public ResponseEntity<Object> notesActivityReport() {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = managementService.notesActivityReport(responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("populateSubActivityDesc")
	public ResponseEntity<Object> populateSubActivityDesc() {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = managementService.populateSubActivityDesc(responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("populateH1UidDetails")
	public ResponseEntity<Object> populateH1UidDetails(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		if(StringUtils.isNotEmpty(requestModel.getManagerLoginCd())) {
		responseMap = managementService.populateH1UidDetails(requestModel.getManagerLoginCd(),responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("generateNotesActivityReport")
	public ResponseEntity<Object> generateNotesActivityReport(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = managementService.validateNotesActivityReportRequest(requestModel);
		if(response) {
		responseMap = this.managementService.generateNotesActivityReport(requestModel,responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("generateNotesActivityManagerReport")
	public ResponseEntity<Object> generateNotesActivityManagerReport(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = managementService.validateNotesActivityReportRequest(requestModel);
		if(response) {
		responseMap = this.managementService.generateNotesActivityManagerReport(requestModel,responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
}
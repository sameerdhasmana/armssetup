package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.AccountPastDueDetails;

@Transactional
public interface AccountPastDueDetailsRepository extends JpaRepository<AccountPastDueDetails, String> {

	@Query(value = "exec arms_customer_query_account_past_due1_v22 :accountNumber,:originatingSystem", nativeQuery = true)
	public List<AccountPastDueDetails> getAccountPastDueDetails(@Param("accountNumber") String accountNumber,
			@Param("originatingSystem") String originatingSystem);

}

package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(CustomerSegment.CustomerSegmentId.class)
@Data
public class CustomerSegment {

	@Id
	@JsonProperty("segment_cd")
	@Column(name="segment_cd")
	private String segmentCd;
	@JsonProperty("segment_desc")
	@Column(name="segment_desc")
	private String segmentDesc;
	@JsonProperty("segment_grp_cd")
	@Column(name="segment_grp_cd")
	private String segmentGrpCd;
	@Id
	@JsonProperty("bus_unit_cd")
	@Column(name="bus_unit_cd")
	private String busUnitCd;

	@SuppressWarnings("serial")
	@Data
	public static class CustomerSegmentId implements Serializable {

		private String segmentCd;
		private String busUnitCd;
		
	}
	
}

package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.SegmentReportByCustomerResponseModel;
import com.att.arms.reports.entity.SegmentReportByRegionResponseModel;
import com.att.arms.reports.repo.SegmentReportByCustomerRepository;
import com.att.arms.reports.repo.SegmentReportByRegionRepository;
import com.att.arms.utils.CommonReportsUtils;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class SegmentPdfReportServiceImpl implements SegmentPdfReportService{

	@Autowired 
	SegmentReportByCustomerRepository segmentReportByCustomerRepository;
	
	@Autowired 
	SegmentReportByRegionRepository segmentReportByRegionRepository;
	
	private static final Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 13, Font.BOLD,BaseColor.BLACK);

	//byCustomer
	@Override
	public ByteArrayInputStream searchByCustomer(UserDetails requestModel, Map<Object, Object> responseMap) {
			try {
				Document document = new Document(PageSize.A4, 36, 36, 140, 130);
				Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
				
				PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream("SegmentReportByCustomer" + requestModel.getUserLoginCd()+ ".pdf"));
				document.setPageSize(rectangle);
				SegmentHeaderFooterPageEvent event = new SegmentHeaderFooterPageEvent();
				event.setHeader(requestModel, "segment", "byCustomer");
				writer.setPageEvent(event);
				document.open();
				document.setMargins(15, 15, 120, 60);
				
				List<SegmentReportByCustomerResponseModel> response = segmentReportByCustomerRepository.byCustomer(
						requestModel.getBillingPeriod(),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
						CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
						CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
						CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
						requestModel.getExclusions(), 
						"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
						requestModel.getCustomerChidFlag());
					
				if(response != null) {
//					addHeaderContent(document);
					populatePdfWithActualValues(document, response);
					responseMap.put("msg", ApplicationConstant.SUCCESS);
				}else {
					responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Records Found");
				}

				document.close();
				writer.close();

				Path path = Paths.get("SegmentReportByCustomer" + requestModel.getUserLoginCd()+ ".pdf");
				byte[] bytea = Files.readAllBytes(path);
				ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytea);
				return byteArrayInputStream;
					
		//System.out.println("Response = "+ response);
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	//for bycustomer
	private void populatePdfWithActualValues(Document document, List<SegmentReportByCustomerResponseModel> response) throws DocumentException {
		Map<String, List<SegmentReportByCustomerResponseModel>> segmentsByCustomerbyGroupMap = 
				response.stream()
				.collect(Collectors.groupingBy(segmentReport -> segmentReport.getSegment()));
		
		BigDecimal grandTotalCurrentBilling = BigDecimal.ZERO;
		BigDecimal grandTotalCurrentBalance = BigDecimal.ZERO;
		BigDecimal grandTotalPastDue30AmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalPastDue60AmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalPastDue90AmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalPastDue120AmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalPastDueAmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalDueAmtBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalDisputeTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalDsoTotalBySegment = BigDecimal.ZERO;
		
		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		document.add(empty);
		
		for(Map.Entry<String, List<SegmentReportByCustomerResponseModel>> responsePerSegment: segmentsByCustomerbyGroupMap.entrySet())
		  {
			String segment = responsePerSegment.getKey();
			Paragraph segmentPara = new Paragraph("         "+segment, boldFont);
			segmentPara.setAlignment(Chunk.ALIGN_JUSTIFIED);
			segmentPara.setSpacingAfter(5f);
			
			BigDecimal currentBilling = BigDecimal.ZERO;
			BigDecimal currentBalance = BigDecimal.ZERO;
			BigDecimal pastDue30AmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal pastDue60AmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal pastDue90AmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal pastDue120AmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal pastDueAmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal totalDueAmtBySegment = BigDecimal.ZERO;
			BigDecimal disputeTotalBySegment = BigDecimal.ZERO;
			BigDecimal dsoTotalBySegment = BigDecimal.ZERO;
				
				document.add(segmentPara);
				for(SegmentReportByCustomerResponseModel customerRow: responsePerSegment.getValue())
				 {
					PdfPTable table = new PdfPTable(11);
					float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
					table.setWidths(columnWidths);
					table.setTotalWidth(1145);
					table.setLockedWidth(true);
					table.getDefaultCell().setFixedHeight(100);
					table.getDefaultCell().setBorder(Rectangle.TOP);
					table.getDefaultCell().setBorderColor(BaseColor.BLACK);

					PdfPCell cell3 = new PdfPCell(new Paragraph(customerRow.getCustomer()));
					cell3.setBorder(Rectangle.NO_BORDER);
					cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
					cell3.setVerticalAlignment(Element.ALIGN_LEFT);

					PdfPCell cell4 = new PdfPCell(
							new Paragraph("" + customerRow.getCurrentBillingAmount().setScale(2, RoundingMode.HALF_UP)));
					cell4.setBorder(Rectangle.NO_BORDER);
					cell4.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
					currentBilling = currentBilling.add(customerRow.getCurrentBillingAmount());
					
					PdfPCell cell5 = new PdfPCell(
							new Paragraph("" + customerRow.getPastDue0Amount().setScale(2, RoundingMode.HALF_UP)));
					cell5.setBorder(Rectangle.NO_BORDER);
					cell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
					currentBalance = currentBalance.add(customerRow.getPastDue0Amount());

					PdfPCell cell6 = new PdfPCell(
							new Paragraph("" +customerRow.getPastDue30Amount().setScale(2, RoundingMode.HALF_UP)));
					cell6.setBorder(Rectangle.NO_BORDER);
					cell6.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
					pastDue30AmtTotalBySegment = pastDue30AmtTotalBySegment.add(customerRow.getPastDue30Amount());

					PdfPCell cell7 = new PdfPCell(
							new Paragraph("" + customerRow.getPastDue60Amount().setScale(2, RoundingMode.HALF_UP)));
					cell7.setBorder(Rectangle.NO_BORDER);
					cell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
					pastDue60AmtTotalBySegment = pastDue60AmtTotalBySegment.add(customerRow.getPastDue60Amount());
					
					PdfPCell cell8 = new PdfPCell(
							new Paragraph("" + customerRow.getPastDue90Amount().setScale(2, RoundingMode.HALF_UP)));
					cell8.setBorder(Rectangle.NO_BORDER);
					cell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
					pastDue90AmtTotalBySegment = pastDue90AmtTotalBySegment.add(customerRow.getPastDue90Amount());

					PdfPCell cell9 = new PdfPCell(
							new Paragraph("" + customerRow.getPastDue120Amount().setScale(2, RoundingMode.HALF_UP)));
					cell9.setBorder(Rectangle.NO_BORDER);
					cell9.disableBorderSide(0);
					cell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
					pastDue120AmtTotalBySegment = pastDue120AmtTotalBySegment.add(customerRow.getPastDue120Amount());
					

					PdfPCell cell10 = new PdfPCell(
							new Paragraph("" + customerRow.getTotalPastDueAmount().setScale(2, RoundingMode.HALF_UP)));
					cell10.setBorder(Rectangle.NO_BORDER);
					cell10.disableBorderSide(0);
					cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
					pastDueAmtTotalBySegment = pastDueAmtTotalBySegment.add(customerRow.getTotalPastDueAmount());

					PdfPCell cell11 = new PdfPCell(
							new Paragraph("" + customerRow.getTotalAmount().setScale(2, RoundingMode.HALF_UP)));
					cell11.setBorder(Rectangle.NO_BORDER);
					cell11.disableBorderSide(0);
					cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
					totalDueAmtBySegment = totalDueAmtBySegment.add(customerRow.getTotalAmount());

					PdfPCell cell12 = new PdfPCell(
							new Paragraph("" + customerRow.getDispute().setScale(2, RoundingMode.HALF_UP)));
					cell12.setBorder(Rectangle.NO_BORDER);
					cell12.disableBorderSide(0);
					cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
					disputeTotalBySegment = disputeTotalBySegment.add(customerRow.getDispute());

					PdfPCell cell13 = new PdfPCell(
							new Paragraph("" + customerRow.getDso().setScale(2,RoundingMode.HALF_UP)));
					cell13.setBorder(Rectangle.NO_BORDER);
					cell13.disableBorderSide(0);
					cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
					dsoTotalBySegment = dsoTotalBySegment.add(customerRow.getDso());

					table.addCell(cell3);
					table.addCell(cell4);
					table.addCell(cell5);
					table.addCell(cell6);
					table.addCell(cell7);
					table.addCell(cell8);
					table.addCell(cell9);
					table.addCell(cell10);
					table.addCell(cell11);
					table.addCell(cell12);
					table.addCell(cell13);

					document.add(table);
				}
				
				PdfPTable table = new PdfPTable(11);
					
					float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
					table.setWidths(columnWidthsForOverallTotal);
					table.setTotalWidth(1145);
					table.setLockedWidth(true);
					table.getDefaultCell().setFixedHeight(100);
					table.getDefaultCell().setBorder(Rectangle.TOP);
					table.getDefaultCell().setBorderColor(BaseColor.BLACK);
					
					PdfPCell cell3 = new PdfPCell(
							new Paragraph("Total for "+segment, boldFont));
					cell3.setBorder(Rectangle.NO_BORDER);
					cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
					cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell3.enableBorderSide(Rectangle.TOP);
					cell3.setPaddingBottom(5f);
					
					PdfPCell cell4 = new PdfPCell(
							new Paragraph("" + currentBilling.setScale(2, RoundingMode.HALF_UP)));
					grandTotalCurrentBilling = grandTotalCurrentBilling.add(currentBilling);
					cell4.setBorder(Rectangle.NO_BORDER);
					cell4.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell4.enableBorderSide(Rectangle.TOP);
					cell4.setPaddingBottom(5f);
					
					PdfPCell cell5 = new PdfPCell(
							new Paragraph("" + currentBalance.setScale(2, RoundingMode.HALF_UP)));
					grandTotalCurrentBalance = grandTotalCurrentBalance.add(currentBalance);
					cell5.setBorder(Rectangle.NO_BORDER);
					cell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell5.enableBorderSide(Rectangle.TOP);
					cell5.setPaddingBottom(5f);
					
					PdfPCell cell6 = new PdfPCell(
							new Paragraph("" + pastDue30AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
					grandTotalPastDue30AmtTotalBySegment = grandTotalPastDue30AmtTotalBySegment.add(pastDue30AmtTotalBySegment);
					cell6.setBorder(Rectangle.NO_BORDER);
					cell6.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell6.enableBorderSide(Rectangle.TOP);
					cell6.setPaddingBottom(5f);
					
					PdfPCell cell7 = new PdfPCell(
							new Paragraph("" + pastDue60AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
					grandTotalPastDue60AmtTotalBySegment = grandTotalPastDue60AmtTotalBySegment.add(pastDue60AmtTotalBySegment);
					cell7.setBorder(Rectangle.NO_BORDER);
					cell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell7.enableBorderSide(Rectangle.TOP);
					cell7.setPaddingBottom(5f);

					PdfPCell cell8 = new PdfPCell(
							new Paragraph("" + pastDue90AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
					grandTotalPastDue90AmtTotalBySegment = grandTotalPastDue90AmtTotalBySegment.add(pastDue90AmtTotalBySegment);
					cell8.setBorder(Rectangle.NO_BORDER);
					cell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell8.enableBorderSide(Rectangle.TOP);
					cell8.setPaddingBottom(5f);
					
					PdfPCell cell9 = new PdfPCell(
						new Paragraph("" + pastDue120AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
					grandTotalPastDue120AmtTotalBySegment = grandTotalPastDue120AmtTotalBySegment.add(pastDue120AmtTotalBySegment);
					cell9.setBorder(Rectangle.NO_BORDER);
					cell9.disableBorderSide(0);
					cell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell9.enableBorderSide(Rectangle.TOP);
					cell9.setPaddingBottom(5f);
					
					PdfPCell cell10 = new PdfPCell(
							new Paragraph("" + pastDueAmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
					grandTotalPastDueAmtTotalBySegment = grandTotalPastDueAmtTotalBySegment.add(pastDueAmtTotalBySegment);
					cell10.setBorder(Rectangle.NO_BORDER);
					cell10.disableBorderSide(0);
					cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell10.enableBorderSide(Rectangle.TOP);
					cell10.setPaddingBottom(5f);
					
					PdfPCell cell11 = new PdfPCell(
							new Paragraph("" + totalDueAmtBySegment.setScale(2, RoundingMode.HALF_UP)));
					grandTotalDueAmtBySegment = grandTotalDueAmtBySegment.add(totalDueAmtBySegment);
					cell11.setBorder(Rectangle.NO_BORDER);
					cell11.disableBorderSide(0);
					cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell11.enableBorderSide(Rectangle.TOP);
					cell11.setPaddingBottom(5f);
											
					PdfPCell cell12 = new PdfPCell(
							new Paragraph("" + disputeTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
					grandTotalDisputeTotalBySegment = grandTotalDisputeTotalBySegment.add(disputeTotalBySegment);
					cell12.setBorder(Rectangle.NO_BORDER);
					cell12.disableBorderSide(0);
					cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell12.enableBorderSide(Rectangle.TOP);
					cell12.setPaddingBottom(5f);
												
					PdfPCell cell13 = new PdfPCell(
							new Paragraph("" + dsoTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
					grandTotalDsoTotalBySegment = grandTotalDsoTotalBySegment.add(dsoTotalBySegment);
					cell13.setBorder(Rectangle.NO_BORDER);
					cell13.disableBorderSide(0);
					cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
					cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell13.enableBorderSide(Rectangle.TOP);
					cell13.setPaddingBottom(5f);

					table.addCell(cell3);
					table.addCell(cell4);
					table.addCell(cell5);
					table.addCell(cell6);
					table.addCell(cell7);
					table.addCell(cell8);
					table.addCell(cell9);
					table.addCell(cell10);
					table.addCell(cell11);
					table.addCell(cell12);
					table.addCell(cell13);
					document.add(table);
			}	
		PdfPTable table = new PdfPTable(11);
		
		float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		table.setWidths(columnWidthsForOverallTotal);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);
		table.getDefaultCell().setFixedHeight(100);
		table.getDefaultCell().setBorder(Rectangle.TOP);
		table.getDefaultCell().setBorderColor(BaseColor.BLACK);
		
		PdfPCell cell3 = new PdfPCell(
				new Paragraph("Grand Total ", boldFont));
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell3.enableBorderSide(Rectangle.TOP);
		cell3.setPaddingBottom(5f);
		
		PdfPCell cell4 = new PdfPCell(
				new Paragraph("" + grandTotalCurrentBilling.setScale(2, RoundingMode.HALF_UP)));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell4.enableBorderSide(Rectangle.TOP);
		cell4.setPaddingBottom(5f);
		
		PdfPCell cell5 = new PdfPCell(
				new Paragraph("" + grandTotalCurrentBalance.setScale(2, RoundingMode.HALF_UP)));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell5.enableBorderSide(Rectangle.TOP);
		cell5.setPaddingBottom(5f);
		
		PdfPCell cell6 = new PdfPCell(
				new Paragraph("" + grandTotalPastDue30AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell6.enableBorderSide(Rectangle.TOP);
		cell6.setPaddingBottom(5f);
		
		PdfPCell cell7 = new PdfPCell(
				new Paragraph("" + grandTotalPastDue60AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell7.enableBorderSide(Rectangle.TOP);
		cell7.setPaddingBottom(5f);

		PdfPCell cell8 = new PdfPCell(
				new Paragraph("" + grandTotalPastDue90AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell8.enableBorderSide(Rectangle.TOP);
		cell8.setPaddingBottom(5f);
		
		PdfPCell cell9 = new PdfPCell(
			new Paragraph("" + grandTotalPastDue120AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.disableBorderSide(0);
		cell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell9.enableBorderSide(Rectangle.TOP);
		cell9.setPaddingBottom(5f);
		
		PdfPCell cell10 = new PdfPCell(
				new Paragraph("" + grandTotalPastDueAmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.disableBorderSide(0);
		cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell10.enableBorderSide(Rectangle.TOP);
		cell10.setPaddingBottom(5f);
		
		PdfPCell cell11 = new PdfPCell(
				new Paragraph("" + grandTotalDueAmtBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.disableBorderSide(0);
		cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell11.enableBorderSide(Rectangle.TOP);
		cell11.setPaddingBottom(5f);
								
		PdfPCell cell12 = new PdfPCell(
				new Paragraph("" + grandTotalDisputeTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.disableBorderSide(0);
		cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell12.enableBorderSide(Rectangle.TOP);
		cell12.setPaddingBottom(5f);
									
		PdfPCell cell13 = new PdfPCell(
				new Paragraph("" + grandTotalDsoTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.disableBorderSide(0);
		cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell13.enableBorderSide(Rectangle.TOP);
		cell13.setPaddingBottom(5f);

		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);
		document.add(table);
	}

		//byRegion
	@Override
	public ByteArrayInputStream searchByRegion(UserDetails requestModel, Map<Object, Object> responseMap) {
		// TODO Auto-generated method stub
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
			
			PdfWriter writer = PdfWriter.getInstance(document,
				new FileOutputStream("SegmentReportByCustomerRegion" + requestModel.getUserLoginCd()+ ".pdf"));
			document.setPageSize(rectangle);
			SegmentHeaderFooterPageEvent event = new SegmentHeaderFooterPageEvent();
			event.setHeader(requestModel, "segment", "byRegion");
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);
			
			List<SegmentReportByRegionResponseModel> response = segmentReportByRegionRepository.byRegion(
					requestModel.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
					requestModel.getExclusions(), 
					"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
					requestModel.getCustomerChidFlag());
				
			if(response != null) {
				populatePdfForRegionReportWithActualValues(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Records Found");
			}

			document.close();
			writer.close();

			Path path = Paths.get("SegmentReportByCustomerRegion" + requestModel.getUserLoginCd()+ ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	//by region
	private void populatePdfForRegionReportWithActualValues(Document document, List<SegmentReportByRegionResponseModel> response) throws DocumentException {
		Map<String, List<SegmentReportByRegionResponseModel>> segmentsByRegionbyGroupMap = 
				response.stream()
				.collect(Collectors.groupingBy(segmentReport -> segmentReport.getSegment()));
		
		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		document.add(empty);
		
		BigDecimal grandTotalCurrentBilling = BigDecimal.ZERO;
		BigDecimal grandTotalCurrentBalance = BigDecimal.ZERO;
		BigDecimal grandTotalPastDue30AmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalPastDue60AmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalPastDue90AmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalPastDue120AmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalPastDueAmtTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalDueAmtBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalDisputeTotalBySegment = BigDecimal.ZERO;
		BigDecimal grandTotalDsoTotalBySegment = BigDecimal.ZERO;
		
		for(Map.Entry<String, List<SegmentReportByRegionResponseModel>> responsePerSegment: segmentsByRegionbyGroupMap.entrySet())
		{
			BigDecimal currentBilling = BigDecimal.ZERO;
			BigDecimal currentBalance = BigDecimal.ZERO;
			BigDecimal pastDue30AmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal pastDue60AmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal pastDue90AmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal pastDue120AmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal pastDueAmtTotalBySegment = BigDecimal.ZERO;
			BigDecimal totalDueAmtBySegment = BigDecimal.ZERO;
			BigDecimal disputeTotalBySegment = BigDecimal.ZERO;
			BigDecimal dsoTotalBySegment = BigDecimal.ZERO;
			
			String segment = responsePerSegment.getKey();
			Paragraph segmentPara = new Paragraph("          "+segment, boldFont);
			segmentPara.setAlignment(Chunk.ALIGN_JUSTIFIED);
			segmentPara.setSpacingBefore(5f);
			segmentPara.setSpacingAfter(5f);
			
				document.add(segmentPara);
				Map<String, List<SegmentReportByRegionResponseModel>> perRegionGroupMap = 
						responsePerSegment.getValue()
						.stream()
						.collect(Collectors.groupingBy(perSegment -> perSegment.getRegion()));
				
				for(Map.Entry<String, List<SegmentReportByRegionResponseModel>> responsePerRegion: perRegionGroupMap.entrySet()) {
					String region = responsePerRegion.getKey();
					Paragraph regionPara = new Paragraph("                " + region, boldFont);
					regionPara.setAlignment(Chunk.ALIGN_JUSTIFIED);
					regionPara.setSpacingAfter(5f);
					BigDecimal currentBillingPerRegion = BigDecimal.ZERO;
					BigDecimal currentBalancePerRegion = BigDecimal.ZERO;
					BigDecimal pastDue30AmtTotalByRegion = BigDecimal.ZERO;
					BigDecimal pastDue60AmtTotalByRegion = BigDecimal.ZERO;
					BigDecimal pastDue90AmtTotalByRegion = BigDecimal.ZERO;
					BigDecimal pastDue120AmtTotalByRegion = BigDecimal.ZERO;
					BigDecimal pastDueAmtTotalByRegion = BigDecimal.ZERO;
					BigDecimal totalDueAmtByRegion = BigDecimal.ZERO;
					BigDecimal disputeTotalByRegion = BigDecimal.ZERO;
					BigDecimal dsoTotalByRegion = BigDecimal.ZERO;
					
						document.add(regionPara);
					
						for(SegmentReportByRegionResponseModel segmentReportPerRegion: responsePerRegion.getValue()) {
							PdfPTable table = new PdfPTable(11);
								float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
								table.setWidths(columnWidths);
								table.setTotalWidth(1145);
								table.setLockedWidth(true);
								table.getDefaultCell().setFixedHeight(100);
								table.getDefaultCell().setBorder(Rectangle.TOP);
								table.getDefaultCell().setBorderColor(BaseColor.BLACK);
				
								PdfPCell cell3 = new PdfPCell(new Paragraph(segmentReportPerRegion.getCustomer()));
								cell3.setBorder(Rectangle.NO_BORDER);
								cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
								cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
								
								PdfPCell cell4 = new PdfPCell(
										new Paragraph("" +segmentReportPerRegion.getCurrentBillingAmount().setScale(2, RoundingMode.HALF_UP)));
								cell4.setBorder(Rectangle.NO_BORDER);
								cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
								currentBillingPerRegion = currentBillingPerRegion.add(segmentReportPerRegion.getCurrentBillingAmount());
								
								PdfPCell cell5 = new PdfPCell(
										new Paragraph("" +segmentReportPerRegion.getPastDue0Amount().setScale(2, RoundingMode.HALF_UP)));
								cell5.setBorder(Rectangle.NO_BORDER);
								cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
								currentBalancePerRegion = currentBalancePerRegion.add(segmentReportPerRegion.getPastDue0Amount());
								
								PdfPCell cell6 = new PdfPCell(
										new Paragraph("" +segmentReportPerRegion.getPastDue30Amount().setScale(2, RoundingMode.HALF_UP)));
								cell6.setBorder(Rectangle.NO_BORDER);
								cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
								pastDue30AmtTotalByRegion = pastDue30AmtTotalByRegion.add(segmentReportPerRegion.getPastDue30Amount());
								
								PdfPCell cell7 = new PdfPCell(
										new Paragraph("" +segmentReportPerRegion.getPastDue60Amount().setScale(2,RoundingMode.HALF_UP)));
								cell7.setBorder(Rectangle.NO_BORDER);
								cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
								pastDue60AmtTotalByRegion = pastDue60AmtTotalByRegion.add(segmentReportPerRegion.getPastDue60Amount());

								PdfPCell cell8 = new PdfPCell(
										new Paragraph("" +segmentReportPerRegion.getPastDue90Amount().setScale(2, RoundingMode.HALF_UP )));
								cell8.setBorder(Rectangle.NO_BORDER);
								cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
								pastDue90AmtTotalByRegion = pastDue90AmtTotalByRegion.add(segmentReportPerRegion.getPastDue90Amount());

								PdfPCell cell9 = new PdfPCell(
										new Paragraph("" + segmentReportPerRegion.getPastDue120Amount().setScale(2, RoundingMode.HALF_UP )));
								cell9.setBorder(Rectangle.NO_BORDER);
								cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
								pastDue120AmtTotalByRegion = pastDue120AmtTotalByRegion.add(segmentReportPerRegion.getPastDue120Amount());

								PdfPCell cell10 = new PdfPCell(
									new Paragraph("" +segmentReportPerRegion.getTotalPastDueAmount().setScale(2, RoundingMode.HALF_UP )));
								cell10.setBorder(Rectangle.NO_BORDER);
								cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
								pastDueAmtTotalByRegion = pastDueAmtTotalByRegion.add(segmentReportPerRegion.getTotalPastDueAmount());

								PdfPCell cell11 = new PdfPCell(
										new Paragraph("" + segmentReportPerRegion.getTotalAmount().setScale(2, RoundingMode.HALF_UP )));
								cell11.setBorder(Rectangle.NO_BORDER);
								cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
								totalDueAmtByRegion = totalDueAmtByRegion.add(segmentReportPerRegion.getTotalAmount());
								
								PdfPCell cell12 = new PdfPCell(
										new Paragraph("" + (segmentReportPerRegion.getDispute().setScale(2, RoundingMode.HALF_UP))));
								cell12.setBorder(Rectangle.NO_BORDER);
								cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
								disputeTotalByRegion = disputeTotalByRegion.add(segmentReportPerRegion.getDispute());
								
								PdfPCell cell13 = new PdfPCell(
										new Paragraph("" + segmentReportPerRegion.getDso().setScale(2, RoundingMode.HALF_UP )));
								cell13.setBorder(Rectangle.NO_BORDER);
								cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
								dsoTotalByRegion = dsoTotalByRegion.add(segmentReportPerRegion.getDso());

								table.addCell(cell3);
								table.addCell(cell4);
								table.addCell(cell5);
								table.addCell(cell6);
								table.addCell(cell7);
								table.addCell(cell8);
								table.addCell(cell9);
								table.addCell(cell10);
								table.addCell(cell11);
								table.addCell(cell12);
								table.addCell(cell13);

								document.add(table);
						}
						
						PdfPTable totalTable = new PdfPTable(11);
							
							float[] columnWidthsForOverallTotal = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
							totalTable.setWidths(columnWidthsForOverallTotal);
							totalTable.setTotalWidth(1145);
							totalTable.setLockedWidth(true);
							totalTable.getDefaultCell().setFixedHeight(100);
							totalTable.getDefaultCell().setBorder(Rectangle.TOP);
							totalTable.getDefaultCell().setBorderColor(BaseColor.BLACK);
							
							PdfPCell totalRegionCell3 = new PdfPCell(new Paragraph("Total for "+ region, boldFont));
							totalRegionCell3.setBorder(Rectangle.NO_BORDER);
							totalRegionCell3.enableBorderSide(Rectangle.TOP);
							totalRegionCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
							totalRegionCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
							totalRegionCell3.setPaddingBottom(5f);
							
							PdfPCell cell4 = new PdfPCell(
									new Paragraph("" + currentBillingPerRegion.setScale(2, RoundingMode.HALF_UP)));
							cell4.setBorder(Rectangle.NO_BORDER);
							cell4.enableBorderSide(Rectangle.TOP);
							cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell4.setPaddingBottom(5f);
						    currentBilling = currentBillingPerRegion.add(currentBilling);
							
							PdfPCell cell5 = new PdfPCell(
									new Paragraph("" + currentBalancePerRegion.setScale(2, RoundingMode.HALF_UP)));
							cell5.setBorder(Rectangle.NO_BORDER);
							cell5.enableBorderSide(Rectangle.TOP);
							cell5.setPaddingBottom(5f);
							cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
							currentBalance = currentBalance.add(currentBalancePerRegion);
							
							PdfPCell cell6 = new PdfPCell(
									new Paragraph("" + pastDue30AmtTotalByRegion.setScale(2, RoundingMode.HALF_UP)));
							cell6.setBorder(Rectangle.NO_BORDER);
							cell6.enableBorderSide(Rectangle.TOP);
							cell6.setPaddingBottom(5f);
							cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
							pastDue30AmtTotalBySegment = pastDue30AmtTotalBySegment.add(pastDue30AmtTotalByRegion);
							
							PdfPCell cell7 = new PdfPCell(
									new Paragraph("" + pastDue60AmtTotalByRegion.setScale(2, RoundingMode.HALF_UP)));
							cell7.setBorder(Rectangle.NO_BORDER);
							cell7.enableBorderSide(Rectangle.TOP);
							cell7.setPaddingBottom(5f);
							cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
							pastDue60AmtTotalBySegment = pastDue60AmtTotalBySegment.add(pastDue60AmtTotalByRegion);

							PdfPCell cell8 = new PdfPCell(
									new Paragraph("" + pastDue90AmtTotalByRegion.setScale(2, RoundingMode.HALF_UP)));
							cell8.setBorder(Rectangle.NO_BORDER);
							cell8.enableBorderSide(Rectangle.TOP);
							cell8.setPaddingBottom(5f);
							cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
							pastDue90AmtTotalBySegment = pastDue90AmtTotalBySegment.add(pastDue90AmtTotalByRegion);
							
							PdfPCell cell9 = new PdfPCell(
									new Paragraph("" + pastDue120AmtTotalByRegion.setScale(2, RoundingMode.HALF_UP)));
							cell9.setBorder(Rectangle.NO_BORDER);
							cell9.enableBorderSide(Rectangle.TOP);
							cell9.setPaddingBottom(5f);
							cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
							pastDue120AmtTotalBySegment = pastDue120AmtTotalBySegment.add(pastDue120AmtTotalByRegion);
							
							PdfPCell cell10 = new PdfPCell(
									new Paragraph("" + pastDueAmtTotalByRegion.setScale(2, RoundingMode.HALF_UP)));
							cell10.setBorder(Rectangle.NO_BORDER);
							cell10.enableBorderSide(Rectangle.TOP);
							cell10.setPaddingBottom(5f);
							cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
							pastDueAmtTotalBySegment = pastDueAmtTotalBySegment.add(pastDueAmtTotalByRegion);
							
							PdfPCell cell11 = new PdfPCell(
									new Paragraph("" + totalDueAmtByRegion.setScale(2, RoundingMode.HALF_UP)));
							cell11.setBorder(Rectangle.NO_BORDER);
							cell11.enableBorderSide(Rectangle.TOP);
							cell11.setPaddingBottom(5f);
							cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
							totalDueAmtBySegment = totalDueAmtBySegment.add(totalDueAmtByRegion);
													
							PdfPCell cell12 = new PdfPCell(
									new Paragraph("" + disputeTotalByRegion.setScale(2, RoundingMode.HALF_UP)));
							cell12.setBorder(Rectangle.NO_BORDER);
							cell12.enableBorderSide(Rectangle.TOP);
							cell12.setPaddingBottom(5f);
							cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
							disputeTotalBySegment = disputeTotalBySegment.add(disputeTotalByRegion);
														
							PdfPCell cell13 = new PdfPCell(
									new Paragraph("" + dsoTotalByRegion.setScale(2, RoundingMode.HALF_UP)));
							cell13.setBorder(Rectangle.NO_BORDER);
							cell13.enableBorderSide(Rectangle.TOP);
							cell13.setPaddingBottom(5f);
							cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
							dsoTotalBySegment = dsoTotalByRegion.add(dsoTotalBySegment);

							totalTable.addCell(totalRegionCell3);
							totalTable.addCell(cell4);
							totalTable.addCell(cell5);
							totalTable.addCell(cell6);
							totalTable.addCell(cell7);
							totalTable.addCell(cell8);
							totalTable.addCell(cell9);
							totalTable.addCell(cell10);
							totalTable.addCell(cell11);
							totalTable.addCell(cell12);
							totalTable.addCell(cell13);

							document.add(totalTable);
					
				}			
			
			PdfPTable table = new PdfPTable(11);
		
				
				float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
				table.setWidths(columnWidthsForOverallTotal);
				table.setTotalWidth(1145);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(100);
				table.getDefaultCell().setBorder(Rectangle.TOP);
				table.getDefaultCell().setBorderColor(BaseColor.BLACK);
				
				PdfPCell totalSegmentCell3 = new PdfPCell(new Paragraph("Total for "+ segment, boldFont));
				totalSegmentCell3.setBorder(Rectangle.NO_BORDER);
				totalSegmentCell3.enableBorderSide(Rectangle.TOP);
				totalSegmentCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
				totalSegmentCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
				totalSegmentCell3.setPaddingBottom(5f);
				
				PdfPCell cell4 = new PdfPCell(
						new Paragraph("" + currentBilling.setScale(2, RoundingMode.HALF_UP)));
				grandTotalCurrentBilling = grandTotalCurrentBilling.add(currentBilling);
				cell4.setBorder(Rectangle.NO_BORDER);
				cell4.enableBorderSide(Rectangle.TOP);
				cell4.setPaddingBottom(5f);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
				
				PdfPCell cell5 = new PdfPCell(
						new Paragraph("" + currentBalance.setScale(2, RoundingMode.HALF_UP)));
				grandTotalCurrentBalance = grandTotalCurrentBalance.add(currentBalance);
				cell5.setBorder(Rectangle.NO_BORDER);
				cell5.enableBorderSide(Rectangle.TOP);
				cell5.setPaddingBottom(5f);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
				
				PdfPCell cell6 = new PdfPCell(
						new Paragraph("" + pastDue30AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
				grandTotalPastDue30AmtTotalBySegment = grandTotalPastDue30AmtTotalBySegment.add(pastDue30AmtTotalBySegment);
				cell6.setBorder(Rectangle.NO_BORDER);
				cell6.enableBorderSide(Rectangle.TOP);
				cell6.setPaddingBottom(5f);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
				
				PdfPCell cell7 = new PdfPCell(
						new Paragraph("" + pastDue60AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
				grandTotalPastDue60AmtTotalBySegment = grandTotalPastDue60AmtTotalBySegment.add(pastDue60AmtTotalBySegment);
				cell7.setBorder(Rectangle.NO_BORDER);
				cell7.enableBorderSide(Rectangle.TOP);
				cell7.setPaddingBottom(5f);
				cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell8 = new PdfPCell(
						new Paragraph("" + pastDue90AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
				grandTotalPastDue90AmtTotalBySegment = grandTotalPastDue90AmtTotalBySegment.add(pastDue90AmtTotalBySegment);
				cell8.setBorder(Rectangle.NO_BORDER);
				cell8.enableBorderSide(Rectangle.TOP);
				cell8.setPaddingBottom(5f);
				cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
				
				PdfPCell cell9 = new PdfPCell(
						new Paragraph("" + pastDue120AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
				grandTotalPastDue120AmtTotalBySegment = grandTotalPastDue120AmtTotalBySegment.add(pastDue120AmtTotalBySegment);
				cell9.setBorder(Rectangle.NO_BORDER);
				cell9.enableBorderSide(Rectangle.TOP);
				cell9.setPaddingBottom(5f);
				cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
				
				PdfPCell cell10 = new PdfPCell(
						new Paragraph("" + pastDueAmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
				grandTotalPastDueAmtTotalBySegment = grandTotalPastDueAmtTotalBySegment.add(pastDueAmtTotalBySegment);
				cell10.setBorder(Rectangle.NO_BORDER);
				cell10.enableBorderSide(Rectangle.TOP);
				cell10.setPaddingBottom(5f);
				cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
				
				PdfPCell cell11 = new PdfPCell(
						new Paragraph("" + totalDueAmtBySegment.setScale(2, RoundingMode.HALF_UP)));
				grandTotalDueAmtBySegment = grandTotalDueAmtBySegment.add(totalDueAmtBySegment);
				cell11.setBorder(Rectangle.NO_BORDER);
				cell11.enableBorderSide(Rectangle.TOP);
				cell11.setPaddingBottom(5f);
				cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
										
				PdfPCell cell12 = new PdfPCell(
						new Paragraph("" + disputeTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
				grandTotalDisputeTotalBySegment = grandTotalDisputeTotalBySegment.add(disputeTotalBySegment);
				cell12.setBorder(Rectangle.NO_BORDER);
				cell12.enableBorderSide(Rectangle.TOP);
				cell12.setPaddingBottom(5f);
				cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
											
				PdfPCell cell13 = new PdfPCell(
						new Paragraph("" + dsoTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
				grandTotalDsoTotalBySegment = grandTotalDsoTotalBySegment.add(dsoTotalBySegment);
				cell13.setBorder(Rectangle.NO_BORDER);
				cell13.enableBorderSide(Rectangle.TOP);
				cell13.setPaddingBottom(5f);
				cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);

				table.addCell(totalSegmentCell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);
				table.addCell(cell8);
				table.addCell(cell9);
				table.addCell(cell10);
				table.addCell(cell11);
				table.addCell(cell12);
				table.addCell(cell13);
				document.add(table);
		}
		
		PdfPTable table = new PdfPTable(11);
		
		float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		table.setWidths(columnWidthsForOverallTotal);
		table.setTotalWidth(1145);
		table.setLockedWidth(true);
		table.getDefaultCell().setFixedHeight(100);
		table.getDefaultCell().setBorder(Rectangle.TOP);
		table.getDefaultCell().setBorderColor(BaseColor.BLACK);
		
		PdfPCell totalSegmentCell3 = new PdfPCell(new Paragraph("Grand Total ", boldFont));
		totalSegmentCell3.setBorder(Rectangle.NO_BORDER);
		totalSegmentCell3.enableBorderSide(Rectangle.TOP);
		totalSegmentCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
		totalSegmentCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
		totalSegmentCell3.setPaddingBottom(5f);
		
		PdfPCell cell4 = new PdfPCell(
				new Paragraph("" + grandTotalCurrentBilling.setScale(2, RoundingMode.HALF_UP)));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.enableBorderSide(Rectangle.TOP);
		cell4.setPaddingBottom(5f);
		cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		PdfPCell cell5 = new PdfPCell(
				new Paragraph("" + grandTotalCurrentBalance.setScale(2, RoundingMode.HALF_UP)));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.enableBorderSide(Rectangle.TOP);
		cell5.setPaddingBottom(5f);
		cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		PdfPCell cell6 = new PdfPCell(
				new Paragraph("" + grandTotalPastDue30AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.enableBorderSide(Rectangle.TOP);
		cell6.setPaddingBottom(5f);
		cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		PdfPCell cell7 = new PdfPCell(
				new Paragraph("" + grandTotalPastDue60AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.enableBorderSide(Rectangle.TOP);
		cell7.setPaddingBottom(5f);
		cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell cell8 = new PdfPCell(
				new Paragraph("" + grandTotalPastDue90AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.enableBorderSide(Rectangle.TOP);
		cell8.setPaddingBottom(5f);
		cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		PdfPCell cell9 = new PdfPCell(
				new Paragraph("" + grandTotalPastDue120AmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.enableBorderSide(Rectangle.TOP);
		cell9.setPaddingBottom(5f);
		cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		PdfPCell cell10 = new PdfPCell(
				new Paragraph("" + grandTotalPastDueAmtTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.enableBorderSide(Rectangle.TOP);
		cell10.setPaddingBottom(5f);
		cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		PdfPCell cell11 = new PdfPCell(
				new Paragraph("" + grandTotalDueAmtBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.enableBorderSide(Rectangle.TOP);
		cell11.setPaddingBottom(5f);
		cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
								
		PdfPCell cell12 = new PdfPCell(
				new Paragraph("" + grandTotalDisputeTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.enableBorderSide(Rectangle.TOP);
		cell12.setPaddingBottom(5f);
		cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
									
		PdfPCell cell13 = new PdfPCell(
				new Paragraph("" + grandTotalDsoTotalBySegment.setScale(2, RoundingMode.HALF_UP)));
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.enableBorderSide(Rectangle.TOP);
		cell13.setPaddingBottom(5f);
		cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);

		table.addCell(totalSegmentCell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);
		document.add(table);
	}

}

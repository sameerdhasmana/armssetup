package com.att.arms.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.view.RedirectView;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.GlobalLogonUsers;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.UserService;
import com.att.arms.utils.CommonUtils;

@Controller
public class AuthenticationController {

	@Autowired
	UserService userService;

	@GetMapping("/")
	public RedirectView authorizeUser(Principal principal,ModelMap model) {

		try {
			UserDetails userDetails = new UserDetails();
			userDetails = CommonUtils.getCurrentUserDetails(principal.getName(), ApplicationConstant.PRODUCTION,
					ApplicationConstant.ARMS_APP, userDetails);
			boolean validUserDetails = this.userService.validateUser(userDetails);
			if (validUserDetails) {
				GlobalLogonUsers glUser = this.userService.findUserDetails(userDetails.getUserLoginCd(),
						userDetails.getAppName(), userDetails.getEnvironment(), userDetails.getUserPcName(),
						userDetails.getUserPcLoginId(), userDetails.getUserPcIp(), 0);
				if (glUser != null) {
					RedirectView rv = new RedirectView();
					boolean sessionValid=this.userService.checkSessionTiming(userDetails.getUserLoginCd());
					if(sessionValid) {
			        rv.setUrl(ApplicationConstant.URL+"loginUser?userLoginCd="+userDetails.getUserLoginCd());
					}else {
						rv.setUrl(ApplicationConstant.URL+"invalidSession");
					}
					return rv;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		RedirectView rv = new RedirectView();
        rv.setUrl(ApplicationConstant.URL+"error401");
        return rv;
	}

}
package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class APSubGroup {

	@Id
	@JsonProperty("ap_sub_grp_nm")
	@Column(name="ap_sub_grp_nm")
	private String apSubGrpNm;
	@JsonProperty("ap_sub_grp_nm_desc")
	@Column(name="ap_sub_grp_nm_desc")
	private String apSubGrpNmDesc;

}

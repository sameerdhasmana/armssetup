package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.OriginatingSystem;
@Transactional
public interface OriginatingSystemRepository extends JpaRepository<OriginatingSystem, String> {

	@Query(value = "SELECT DISTINCT originating_system FROM CUSTOMER_XREF3 with (nolock)", nativeQuery = true)
	public List<OriginatingSystem> findOriginatingSystemList();
}

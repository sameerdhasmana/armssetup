package com.att.arms.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.AccountClassification;
import com.att.arms.entity.ChildTieCodeDetails;
import com.att.arms.entity.CustomerBillingPeriod;
import com.att.arms.entity.CustomerGroupList;
import com.att.arms.entity.CustomerInfo;
import com.att.arms.entity.CustomerSegment;
import com.att.arms.entity.DispIntervalDetails;
import com.att.arms.entity.GlobalLogonUsers;
import com.att.arms.entity.OriginatingSystem;
import com.att.arms.entity.RegionDetails;
import com.att.arms.entity.ReportFilterCTCDetailsResponse;
import com.att.arms.entity.ReportFilterResponse;
import com.att.arms.entity.TemplateFieldsDetails;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.OriginatingSystemRepository;
import com.att.arms.repo.TemplateFieldsRepository;
import com.att.arms.reports.entity.UserTemplateDetails;
import com.att.arms.reports.repo.BillingPeriodRepository;
import com.att.arms.reports.repo.ChildTieCodeDetailsRepository;
import com.att.arms.reports.repo.CustomerAccountClassificationRepository;
import com.att.arms.reports.repo.CustomerDataFilterRepository;
import com.att.arms.reports.repo.DispIntervalDetailsRepository;
import com.att.arms.reports.repo.GroupFetchingRepository;
import com.att.arms.reports.repo.RegionDetailsRepository;
import com.att.arms.reports.repo.SegmentDataRepository;
import com.att.arms.reports.repo.TemplateFilesDetailsRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class ReportFilterServiceImpl implements ReportFilterService {

	
	@Autowired
	GroupFetchingRepository groupFetchingRepository;
	@Autowired
	BillingPeriodRepository billingPeriodRepository;
	@Autowired
	SegmentDataRepository segmentDataRepository;
	@Autowired
	CustomerAccountClassificationRepository customerAccountClassificationRepository;
	@Autowired
	OriginatingSystemRepository originatingSystemRepository;
	@Autowired
	UserService userService;
	@Autowired
	CustomerDataFilterRepository customerDataFilterRepository;
	@Autowired
	RegionDetailsRepository regionDetailsRepository;
	@Autowired
	DispIntervalDetailsRepository dispIntervalDetailsRepository;
	@Autowired
	TemplateFieldsRepository templateFieldsRepository;
	@Autowired
	ChildTieCodeDetailsRepository childTieCodeDetailsRepository;
	@Autowired
	TemplateFilesDetailsRepository templateFilesDetailsRepository;

	@Override
	public List<CustomerGroupList> findcustomerGroupList(String group) {
		return this.groupFetchingRepository.findcustomerGroupList(group);
	}

	@Override
	public List<CustomerBillingPeriod> findCustomerBillingPeriod(List<String> groupList) {
		return this.billingPeriodRepository.findCustomerBillingPeriod(groupList);
	}

	@Override
	public List<CustomerSegment> findCustomerSegmentList(List<String> groupList) {
		return this.segmentDataRepository.findCustomerSegmentList(groupList);
	}

	@Override
	public List<AccountClassification> findAccountsClassificationList() {
		return this.customerAccountClassificationRepository.findAccountsClassificationList();
	}

	@Override
	public List<OriginatingSystem> findOriginatingSystemList() {
		return this.originatingSystemRepository.findOriginatingSystemList();
	}
	
	@Override
	public List<ChildTieCodeDetails> findChildTieCodeList(String groupList) {
		return this.childTieCodeDetailsRepository.findChildTieCodeList(groupList);
	}
	
	@Override
	public List<DispIntervalDetails> findDispIntervalList() {
		return this.dispIntervalDetailsRepository.findDispIntervalList();
	}
	
	@Override
	public List<TemplateFieldsDetails> findTemplateFieldsList() {
		return this.templateFieldsRepository.findTemplateFieldsList();
	}


	@Override
	public List<RegionDetails> findRegionDetailsList() {
		return this.regionDetailsRepository.findOrginatingCompanyList();
	}


	@Override
	public ReportFilterResponse populateReportFilter(ReportFilterResponse filter, UserDetails userDetails) {
		GlobalLogonUsers glUser = null;

		glUser = this.userService.findUserDetails(userDetails.getUserLoginCd(), userDetails.getAppName(),
				userDetails.getEnvironment(), userDetails.getUserPcName(), userDetails.getUserPcLoginId(),
				userDetails.getUserPcIp(), 0);
		if (glUser != null) {
			List<CustomerGroupList> groupList = null;
			List<CustomerBillingPeriod> billingPeriodList = null;
			List<CustomerSegment> segmentList = null;
			List<AccountClassification> accountsClassificationList = null;
			List<OriginatingSystem> originatingSystemList = null;
			List<RegionDetails> regionDetailsList = null;
			List<String> selectedGrpList = null;
			List<DispIntervalDetails> dispIntervalList = null;
			List<TemplateFieldsDetails> templateFieldsList = null;


			groupList = findcustomerGroupList(glUser.getGroup());
			billingPeriodList = findCustomerBillingPeriod(selectedGrpList);
			segmentList = findCustomerSegmentList(selectedGrpList);
			accountsClassificationList = findAccountsClassificationList();
			originatingSystemList = findOriginatingSystemList();
			regionDetailsList = findRegionDetailsList();
			dispIntervalList=findDispIntervalList();
			templateFieldsList=findTemplateFieldsList();


			filter.setCustomerGroupList(groupList);
			filter.setGlobalLogonUsers(glUser);
			filter.setCustomerBillingPeriod(billingPeriodList);
			filter.setSegmentList(segmentList);
			filter.setRegionDetailsList(regionDetailsList);
			filter.setAccountsClassificationList(accountsClassificationList);
			filter.setOriginatingSystemList(originatingSystemList);
			filter.setDispIntervalDetails(dispIntervalList);
			filter.setTemplateFieldsDetails(templateFieldsList);
		
		} else {
			filter.setErrorMsg("Invalid User");
		}
		return filter;
	}

	
	@Override
	public Map<Object, Object> getAllCustomers(Map<Object, Object> responseMap) {
		List<CustomerInfo> customerInfo = customerDataFilterRepository.getAllCustomerInfo();
		if (!CollectionUtils.isEmpty(customerInfo)) {
			responseMap.put(ApplicationConstant.CUSTOMER_INFO, customerInfo);
		}
		return responseMap;
	}

	@Override
	public ReportFilterCTCDetailsResponse populateReportCTCDetailsFilter(ReportFilterCTCDetailsResponse filter,
			UserDetails userDetails) {
		GlobalLogonUsers glUser = null;

		glUser = this.userService.findUserDetails(userDetails.getUserLoginCd(), userDetails.getAppName(),
				userDetails.getEnvironment(), userDetails.getUserPcName(), userDetails.getUserPcLoginId(),
				userDetails.getUserPcIp(), 0);
		if (glUser != null) {
			filter.setGlobalLogonUsers(glUser);
			List<ChildTieCodeDetails> childTieCodeDetailsList = null;
			String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
			
			childTieCodeDetailsList=findChildTieCodeList(selectedGroups);

			
			filter.setChildTieCodeDetails(childTieCodeDetailsList);
		
		} else {
			filter.setErrorMsg("Invalid User");
		}
		return filter;
	}

	@Override
	public Map<Object, Object> loadTemplateFiles(String userLoginCd, String reportType,
			Map<Object, Object> responseMap) {
			List<UserTemplateDetails> templateDetailsList = templateFilesDetailsRepository.getTemplateFilesDetails(userLoginCd,
					reportType);
				responseMap.put(ReportsConstant.USER_TEMPLATE_DETAILS, templateDetailsList);
			return responseMap;
			}
}

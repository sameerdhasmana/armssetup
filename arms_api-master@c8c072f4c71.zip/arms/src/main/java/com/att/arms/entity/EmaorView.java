package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(EmaorView.EmaorViewId.class)
@Data
public class EmaorView {

	
	private String primary;
	@Id
	private String email;
	@JsonProperty("eff_date")
	@Column(name="eff_date")
	private String effDate;
	@JsonProperty("first_name")
	@Column(name="first_name")
	private String firstName;
	@JsonProperty("last_name")
	@Column(name="last_name")
	private String lastName;
	@Id
	@JsonProperty("account_number")
	@Column(name="account_number")
	private String accountNumber;
	private String notes;
	@Id
	private String system;
	
	@SuppressWarnings("serial")
	@Data
	public static class EmaorViewId implements Serializable {

		private String email;
		private String accountNumber;
		private String system;
		
		
	}

}

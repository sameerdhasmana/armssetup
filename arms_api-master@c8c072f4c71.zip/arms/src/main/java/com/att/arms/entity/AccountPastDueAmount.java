package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(AccountPastDueAmount.AccountPastDueAmountId.class)
@Data
public class AccountPastDueAmount {

	@Id
	@JsonProperty("billing_period")
	@Column(name="billing_period")
	private String billingPeriod;
	@Id
	@JsonProperty("account_number")
	@Column(name="acct_nbr")
	private String accountNumber;
	@Column(name="sumOfcurrent_billing_amt")
	private Double sumOfCurrentBillingAmt;
	@Column(name="sumOfpast_due_0_amt")
	private Double sumOfPastDue0Amt;
	@Column(name="sumOfpast_due_amt")
	private Double sumOfPastDueAmt;
	

	@SuppressWarnings("serial")
	@Data
	public static class AccountPastDueAmountId implements Serializable {

		private String accountNumber;
		private String billingPeriod;
		
	}
}

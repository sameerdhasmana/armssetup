package com.att.arms.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.CustomerInfo;
import com.att.arms.entity.CustomerMaintenance;
import com.att.arms.entity.Message;
import com.att.arms.entity.Segment;
import com.att.arms.entity.SegmentMaintenance;
import com.att.arms.entity.SegmentMaintenanceBusGroup;
import com.att.arms.entity.SegmentMaintenanceGroup;
import com.att.arms.entity.TableMaintenanceAcna;
import com.att.arms.entity.TableMaintenanceAcnaComboBox;
import com.att.arms.entity.TableMaintenanceAecn;
import com.att.arms.entity.TableMaintenanceCustomerUsage;
import com.att.arms.entity.TableMaintenanceModel;
import com.att.arms.repo.CustomerInfoRepository;
import com.att.arms.repo.CustomerMaintenanceRepository;
import com.att.arms.repo.MessageRepository;
import com.att.arms.repo.SegmentMaintenanceBusUnitRepository;
import com.att.arms.repo.SegmentMaintenanceGroupRepository;
import com.att.arms.repo.SegmentMaintenanceRepository;
import com.att.arms.repo.SegmentRepository;
import com.att.arms.repo.TableMaintenanceAcnaRepository;
import com.att.arms.repo.TableMaintenanceAecnRepository;
import com.att.arms.repo.TableMaintenanceCustUsageRepository;
import com.att.arms.repo.TableMaintenanceRepository;

@Service
public class TableMaintenanceServiceImpl implements TableMaintenanceService {

	@Autowired
	TableMaintenanceRepository tableMaintenanceRepository;
	@Autowired
	TableMaintenanceAcnaRepository tableMaintenanceAcnaRepository;
	@Autowired
	CustomerInfoRepository customerInfoRepository;
	@Autowired
	TableMaintenanceCustUsageRepository tableMaintenanceCustUsageRepository;
	@Autowired
	MessageRepository messageRepository;
	@Autowired
	CustomerMaintenanceRepository customerMaintenanceRepository;
	@Autowired
	SegmentMaintenanceRepository segmentMaintenanceRepository;
	@Autowired
	SegmentMaintenanceGroupRepository segmentMaintenanceGroupRepository;
	@Autowired
	SegmentMaintenanceBusUnitRepository segmentMaintenanceBusUnitRepository;
	@Autowired
	SegmentRepository segmentRepository;

	@Autowired
	TableMaintenanceAecnRepository tableMaintenanceAecnRepository;

	@Override
	public boolean validateQueryRequest(TableMaintenanceModel tableMaintModel) {
		return true;
	}

	@Override
	public boolean validateSegmentUpdateQueryRequest(TableMaintenanceModel segmentUpdateModel) {
		boolean response = false;
		if (segmentUpdateModel != null && StringUtils.isNotEmpty(segmentUpdateModel.getFunction())
				&& StringUtils.isNotEmpty(segmentUpdateModel.getSegment())
				&& StringUtils.isNotEmpty(segmentUpdateModel.getDescription())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> getAcnaMaintRecords(TableMaintenanceModel tableMaintenanceModel,
			Map<Object, Object> responseMap) {
		List<TableMaintenanceAcna> acnaRecords = tableMaintenanceRepository
				.getAcnaMaintRecords(tableMaintenanceModel.getStrFilter(), tableMaintenanceModel.getStrSort());
		responseMap.put(ApplicationConstant.TABLE_MAINTENANCE_ACNA_RECORD, acnaRecords);
		List<TableMaintenanceAcnaComboBox> acnaComboRecords = tableMaintenanceAcnaRepository.getMaintAcnaCustomer();
		responseMap.put(ApplicationConstant.TABLE_MAINTENANCE_ACNA_COMBO_RECORD, acnaComboRecords);
		List<Segment> segmentList = segmentRepository.getSegmentList();
		responseMap.put(ApplicationConstant.SEGMENT, segmentList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getAecnMaintRecords(TableMaintenanceModel tableMaintenanceModel,
			Map<Object, Object> responseMap) {
		List<TableMaintenanceAecn> aecnRecords = tableMaintenanceAecnRepository
				.getAenaMaintRecords(tableMaintenanceModel.getStrFilter(), tableMaintenanceModel.getStrSort());
		responseMap.put(ApplicationConstant.TABLE_MAINTENANCE_AECN_RECORD, aecnRecords);
		List<TableMaintenanceAcnaComboBox> aecnComboRecords = tableMaintenanceAcnaRepository.getMaintAcnaCustomer();
		responseMap.put(ApplicationConstant.TABLE_MAINTENANCE_AECN_COMBO_RECORD, aecnComboRecords);
		List<Segment> segmentList = segmentRepository.getSegmentList();
		responseMap.put(ApplicationConstant.SEGMENT, segmentList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getCustomerInfo(Map<Object, Object> responseMap) {
		List<CustomerInfo> custInfo = customerInfoRepository.getAllCustomerInfo();
		responseMap.put(ApplicationConstant.CUSTOMER_INFO, custInfo);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getCustomerUsage(TableMaintenanceModel tableMaintenanceModel,
			Map<Object, Object> responseMap) {
		List<TableMaintenanceCustomerUsage> custUsages = tableMaintenanceCustUsageRepository
				.getCustomerUsage(tableMaintenanceModel.getCustomerGrpCD(), tableMaintenanceModel.getStrSort());
		responseMap.put(ApplicationConstant.CUSTOMER_INFO, custUsages);
		return responseMap;
	}

	@Override
	public Map<Object, Object> fetchMessage(Map<Object, Object> responseMap) {
		List<Message> fetchMessage = messageRepository.fetchMessage();
		responseMap.put(ApplicationConstant.MESSAGE, fetchMessage);
		return responseMap;
	}

	@Override
	public Map<Object, Object> modifyMenuMsg(TableMaintenanceModel tableMaintenanceModel,
			Map<Object, Object> responseMap) {
		messageRepository.modifyMenuMsg(tableMaintenanceModel.getMenuMsg());
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> fetchCustMaintenance(TableMaintenanceModel tableMaintenanceModel,
			Map<Object, Object> responseMap) {
		List<CustomerMaintenance> customerMaint = customerMaintenanceRepository
				.fetchCustMaintenance(tableMaintenanceModel.getStrSort(), tableMaintenanceModel.getStrFilter());
		responseMap.put(ApplicationConstant.CUSTOMER_MAINTENANCE, customerMaint);
		return responseMap;
	}

	@Override
	public Map<Object, Object> fetchSegmentMaintenance(TableMaintenanceModel tableMaintenanceModel,
			Map<Object, Object> responseMap) {
		List<SegmentMaintenance> segmentMaint = segmentMaintenanceRepository
				.fetchSegmentMaintenance(tableMaintenanceModel.getStrSort(), tableMaintenanceModel.getStrFilter());
		responseMap.put(ApplicationConstant.SEGMENT_MAINTENANCE, segmentMaint);
		List<SegmentMaintenanceGroup> segmentMaintGrp = segmentMaintenanceGroupRepository.fetchSegmentMaintenanceGrp();
		responseMap.put(ApplicationConstant.SEGMENT_MAINTENANCE_GROUP, segmentMaintGrp);
		List<SegmentMaintenanceBusGroup> segmentMaintBusUnitGrp = segmentMaintenanceBusUnitRepository
				.fetchSegmentMaintenanceBusUnitGrp(tableMaintenanceModel.getUserLoginCd());
		responseMap.put(ApplicationConstant.BUSINESS_GROUP, segmentMaintBusUnitGrp);
		return responseMap;
	}

	@Override
	public Map<Object, Object> segmentUpdate(TableMaintenanceModel segmentUpdateModel,
			Map<Object, Object> responseMap) {
		tableMaintenanceRepository.segmentUpdate(segmentUpdateModel.getSegment(), segmentUpdateModel.getDescription(),
				segmentUpdateModel.getSegmentGroup(), segmentUpdateModel.getBusinessUnit(),
				segmentUpdateModel.getExcludeWebTaxiFlag(), segmentUpdateModel.getFunction(),
				segmentUpdateModel.getUserLoginCd());
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}
}

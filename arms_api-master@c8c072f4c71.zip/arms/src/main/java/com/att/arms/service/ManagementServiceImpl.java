package com.att.arms.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.CustomerInfo;
import com.att.arms.entity.H1uidDetails;
import com.att.arms.entity.Manager;
import com.att.arms.entity.NotesActivityReport;
import com.att.arms.entity.OpenFlagActivity;
import com.att.arms.entity.OutstandingBringUp;
import com.att.arms.entity.PaymentTerm;
import com.att.arms.entity.RequestModel;
import com.att.arms.entity.Segment;
import com.att.arms.entity.SubActivityDescription;
import com.att.arms.repo.CustomerInfoRepository;
import com.att.arms.repo.CustomerNameRepository;
import com.att.arms.repo.CustomerNotesRepository;
import com.att.arms.repo.H1uidDetailsRepository;
import com.att.arms.repo.LetterProfileRepository;
import com.att.arms.repo.ManagerRepository;
import com.att.arms.repo.NotesActivityReportRepository;
import com.att.arms.repo.OpenFlagActivityRepository;
import com.att.arms.repo.OutstandingBringUpRepository;
import com.att.arms.repo.PaymentTermRepository;
import com.att.arms.repo.SegmentRepository;
import com.att.arms.repo.SubActivityDescriptionRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class ManagementServiceImpl implements ManagementService {

	@Autowired
	PaymentTermRepository paymentTermRepository;
	@Autowired
	LetterProfileRepository letterProfileRepository;
	@Autowired
	CustomerNotesRepository customerNotesRepository;
	@Autowired
	CustomerInfoRepository customerInfoRepository;
	@Autowired
	SegmentRepository segmentRepository;
	@Autowired
	OutstandingBringUpRepository outstandingBringUpRepository;
	@Autowired
	OpenFlagActivityRepository openFlagActivityRepository;
	@Autowired
	ManagerRepository managerRepository;
	@Autowired
	CustomerNameRepository customerNameRepository;
	@Autowired
	H1uidDetailsRepository h1uidDetailsRepository;
	@Autowired
	SubActivityDescriptionRepository subActivityDescriptionRepository;
	@Autowired
	NotesActivityReportRepository notesActivityReportRepository;

	@Override
	public boolean validateSearchByAccountQueryRequest(RequestModel requestModel) {
		boolean response = false;
		if (requestModel != null && StringUtils.isNotEmpty(requestModel.getUserLoginCd())
				&& StringUtils.isNotEmpty(requestModel.getAccountNumber())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validatePaymentTermUpdateRequest(RequestModel requestModel) {
		boolean response = false;
		if (requestModel != null && StringUtils.isNotEmpty(requestModel.getUserLoginCd())
				&& !CollectionUtils.isEmpty(requestModel.getSelectedAccountNumbers())
				&& !CollectionUtils.isEmpty(requestModel.getOriginatingSystem())
				&& requestModel.getPaymentTerm() != null) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSearchByCustomerRequest(RequestModel requestModel) {
		boolean response = false;
		if (requestModel != null && StringUtils.isNotEmpty(requestModel.getUserLoginCd())
				&& !CollectionUtils.isEmpty(requestModel.getCustomerGrpCdList())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateNotesActivityReportRequest(RequestModel requestModel) {
		boolean response = false;
		if (requestModel != null && StringUtils.isNotEmpty(requestModel.getQueryType())
				&& (requestModel.getQueryType().equals("All") || (requestModel.getQueryType().equals("Not All")
						&& !CollectionUtils.isEmpty(requestModel.getCustomerName())))) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> searchByAccount(String userLoginCd, String accountNumber,
			Map<Object, Object> responseMap) {
		List<PaymentTerm> paymentTerms = paymentTermRepository.paymentTermsByAccount(userLoginCd, accountNumber);
		responseMap.put(ApplicationConstant.PAYMENT_TERM, paymentTerms);
		return responseMap;
	}

	@Override
	public Map<Object, Object> renderSearchByCustomer(String userLoginCd, Map<Object, Object> responseMap) {
		List<String> orgSystemList = letterProfileRepository.getOriginatingSystemList(userLoginCd, 1);
		responseMap.put(ApplicationConstant.ORIGINATING_SYSTEM_LIST, orgSystemList);
		List<String> groupList = customerNotesRepository.getBusinessGroupList(userLoginCd, 1);
		responseMap.put(ApplicationConstant.BUSINESS_GROUP, groupList);
		List<CustomerInfo> customerInfo = customerInfoRepository.getAllCustomerForPaymentTerm(userLoginCd);
		responseMap.put(ApplicationConstant.CUSTOMER_INFO, customerInfo);
		return responseMap;
	}

	@Override
	public Map<Object, Object> searchByCustomer(RequestModel requestModel, Map<Object, Object> responseMap) {

		String originatingSystemList = CommonUtils.getListToCommaSeparatedString(requestModel.getOriginatingSystem());
		String segmentList = CommonUtils.getListToCommaSeparatedString(requestModel.getSegment());
		String groupList = CommonUtils.getListToCommaSeparatedString(requestModel.getGroupSelected());
		String customerGrpCdList = CommonUtils.getListToCommaSeparatedString(requestModel.getCustomerGrpCdList());
		List<PaymentTerm> paymentTerms = paymentTermRepository.paymentTermsByContact(requestModel.getUserLoginCd(),
				groupList, originatingSystemList, segmentList, customerGrpCdList);
		responseMap.put(ApplicationConstant.PAYMENT_TERM, paymentTerms);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateSegment(List<String> groupSelected, Map<Object, Object> responseMap) {
		String groupList = CommonUtils.getListToCommaSeparatedString(groupSelected);
		List<Segment> segmentList = segmentRepository.findCustomerSegmentList(groupList);
		responseMap.put(ApplicationConstant.SEGMENT, segmentList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> paymentTermUpdate(RequestModel requestModel, Map<Object, Object> responseMap) {
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(requestModel.getOriginatingSystem());
		String accountNumbers = CommonUtils.getListToCommaSeparatedString(requestModel.getSelectedAccountNumbers());
		paymentTermRepository.updatePaymentTerms(requestModel.getUserLoginCd(), accountNumbers,
				requestModel.getPaymentTerm(), originatingSystem);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getAllManagers(Map<Object, Object> responseMap) {
		List<Manager> managerList = managerRepository.getAllManagers();
		responseMap.put(ApplicationConstant.MANAGERS, managerList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> outstandingBringUpReport(String managerLoginCd, Map<Object, Object> responseMap) {
		List<OutstandingBringUp> outstandingBringUp = outstandingBringUpRepository.outstandingBringUp(managerLoginCd);
		responseMap.put(ApplicationConstant.OUTSTANDING_BRINGUP, outstandingBringUp);
		return responseMap;
	}

	@Override
	public Map<Object, Object> openFlagActivityReport(String managerLoginCd, Map<Object, Object> responseMap) {
		List<OpenFlagActivity> openFlagActivity = openFlagActivityRepository.openFlagActivity(managerLoginCd);
		responseMap.put(ApplicationConstant.OPEN_FLAG_ACTIVITY, openFlagActivity);
		return responseMap;
	}

	@Override
	public Map<Object, Object> notesActivityReport(Map<Object, Object> responseMap) {
		responseMap=getAllManagers(responseMap);
		List<H1uidDetails> h1UidDetails = null;
		if (responseMap.containsKey(ApplicationConstant.MANAGERS) && responseMap.get(ApplicationConstant.MANAGERS)!=null
				&& !CollectionUtils.isEmpty((List<Manager>)responseMap.get(ApplicationConstant.MANAGERS))) {
			List<Manager> managerList=(List<Manager>)responseMap.get(ApplicationConstant.MANAGERS);
			h1UidDetails = h1uidDetailsRepository.getH1uidDetails(managerList.get(0).getManagerUid());
		}
		responseMap.put(ApplicationConstant.H1UID_DETAILS, h1UidDetails);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateSubActivityDesc(Map<Object, Object> responseMap) {
		List<SubActivityDescription> subActivityDesc = subActivityDescriptionRepository.getAllSubActivityDescription();
		responseMap.put(ApplicationConstant.SUB_ACTIVITY, subActivityDesc);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateH1UidDetails(String managerLoginCd, Map<Object, Object> responseMap) {
		List<H1uidDetails> h1UidDetails = h1uidDetailsRepository.getH1uidDetails(managerLoginCd);
		responseMap.put(ApplicationConstant.H1UID_DETAILS, h1UidDetails);
		return responseMap;
	}

	@Override
	public Map<Object, Object> generateNotesActivityReport(RequestModel requestModel, Map<Object, Object> responseMap) {
		String customers = CommonUtils.getListToCommaSeparatedString(requestModel.getCustomerName());
		String h1Uid = CommonUtils.getListToCommaSeparatedString(requestModel.getH1Uid());
		String subActivity = CommonUtils.getListToCommaSeparatedString(requestModel.getSubActivity());
		String activityCode = CommonUtils.getListToCommaSeparatedString(requestModel.getActivityCode());
		String sort = requestModel.getSort() != null && requestModel.getSort().equals(1)
				? ApplicationConstant.CUSTOMER_SORT
				: ApplicationConstant.USERNAME_SORT;

		List<NotesActivityReport> notesActivity = notesActivityReportRepository.fetchNotesActivityReport(
				requestModel.getQueryType(), requestModel.getResolved(), activityCode, requestModel.getStartDate(),
				requestModel.getEndDate(), customers, h1Uid, subActivity, sort, "");
		responseMap.put(ApplicationConstant.NOTES_ACTIVITY, notesActivity);
		return responseMap;
	}
	
	@Override
	public Map<Object, Object> generateNotesActivityManagerReport(RequestModel requestModel, Map<Object, Object> responseMap) {
		String customers = CommonUtils.getListToCommaSeparatedString(requestModel.getCustomerName());
		String h1Uid = CommonUtils.getListToCommaSeparatedString(requestModel.getH1Uid());
		String subActivity = CommonUtils.getListToCommaSeparatedString(requestModel.getSubActivity());
		String activityCode = CommonUtils.getListToCommaSeparatedString(requestModel.getActivityCode());
		String sort = requestModel.getSort() != null && requestModel.getSort().equals(1)
				? ApplicationConstant.CUSTOMER_SORT
				: ApplicationConstant.USERNAME_SORT;

		List<NotesActivityReport> notesActivity = notesActivityReportRepository.fetchNotesActivityManagerReport(
				requestModel.getQueryType(), requestModel.getResolved(), activityCode, requestModel.getStartDate(),
				requestModel.getEndDate(), customers, h1Uid, subActivity, sort, "");
		responseMap.put(ApplicationConstant.NOTES_ACTIVITY, notesActivity);
		return responseMap;
	}

}

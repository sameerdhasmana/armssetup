package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.SegmentMaintenance;

@Transactional
public interface SegmentMaintenanceRepository extends JpaRepository<SegmentMaintenance, String> {

	@Query(value = "Exec arms_table_maint_segmentmaintenance_ex :strFilter,:strSort", nativeQuery = true)
	public List<SegmentMaintenance> fetchSegmentMaintenance(@Param("strFilter") String strFilter,
			@Param("strSort") String strSort);
}

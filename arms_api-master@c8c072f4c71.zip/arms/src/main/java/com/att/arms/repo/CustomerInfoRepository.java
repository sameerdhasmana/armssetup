package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerInfo;

@Transactional
public interface CustomerInfoRepository extends JpaRepository<CustomerInfo, String> {

	@Query(value = "Exec arms_custqry_AIF_Customer_v22 :AcctInvFAN, :billing_period, :group, :indicator, :originating_system", nativeQuery = true)
	public List<CustomerInfo> getAIFCustomerInfo(@Param("AcctInvFAN") String acctInvFAN,
			@Param("billing_period") String billingPeriod, @Param("group") String group,
			@Param("indicator") String indicator, @Param("originating_system") String originatingSystem);
	
	@Query(value = "Exec armsax_customer_query_for_lb", nativeQuery = true)
	public List<CustomerInfo> getAllCustomerInfo();
	
	@Query(value = "Exec arms_maintenance_cust_ap_sub_grp_cust_combo :group", nativeQuery = true)
	public List<CustomerInfo> getMaintenanceCustList(@Param("group") String group);
	
	@Query(value = "Exec arms_custqry_customer_query_customer_list_all :userLoginCd", nativeQuery = true)
	public List<CustomerInfo> getAllCustomerForPaymentTerm(@Param("userLoginCd") String userLoginCd);

}

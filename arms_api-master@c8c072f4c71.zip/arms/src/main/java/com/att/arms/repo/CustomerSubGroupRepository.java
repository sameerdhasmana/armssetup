package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerApSubGroup;

@Transactional
public interface CustomerSubGroupRepository extends JpaRepository<CustomerApSubGroup, String> {

	@Query(value = "exec arms_maintainance_fetch_customer_ap_sub_grp_ex :CUSTOMER_GRP_CD,:strSort,:strFilter", 
			nativeQuery = true)
	public List<CustomerApSubGroup> getCustAPSubGrp(@Param("CUSTOMER_GRP_CD") String customerGrpCd,
			@Param("strSort") String strSort, @Param("strFilter") String strFilter);
	
	@Modifying
	@Query(value = "Exec arms_ap_sub_group_maint_v22 :grp_cd, :group_nm,:group_desc,:insert_user_login_cd, :update_user_login_cd,:function", nativeQuery = true)
	public void apSubGroupUpdate(@Param("grp_cd") String groupCode, @Param("group_nm") String groupName,
			@Param("group_desc") String groupDesc, @Param("insert_user_login_cd") String insertUserLoginCd,
			@Param("update_user_login_cd") String updateUserLoginCd, @Param("function") String function);

}

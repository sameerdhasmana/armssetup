package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.reports.entity.SegmentReportByCustomerResponseModel;

@Transactional
public interface SegmentReportByCustomerRepository extends JpaRepository<SegmentReportByCustomerResponseModel, String> {
	// stored procedure to get segmentInfo by customer
	 @Query(value ="EXEC arms_rpt_mgr_segment_by_customer :billingPeriod,:groupSelected,:originatingSystem,:region,:reportStatus,:segment,:customerClause,:exclusions,:exclusionClass,:customerChildFlag",nativeQuery = true) 
	 public List<SegmentReportByCustomerResponseModel> byCustomer(@Param("billingPeriod") String billingPeriod, @Param("groupSelected") String groupSelected,@Param("originatingSystem") String originatingSystem,@Param("region") String region,@Param("reportStatus") String reportStatus,@Param("segment") String segment,@Param("customerClause") String customerClause,@Param("exclusions") String exclusions,@Param("exclusionClass") String exclusionClass,@Param("customerChildFlag") String customerChildFlag);
	 	
}

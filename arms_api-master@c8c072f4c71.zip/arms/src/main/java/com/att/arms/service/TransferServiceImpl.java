package com.att.arms.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.TransferUserDetails;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.CustomerInfoRepository;
import com.att.arms.repo.TransferRepository;
import com.att.arms.repo.TransferUserDetailsRepository;

@Service
public class TransferServiceImpl implements TransferService {

	@Autowired
	CustomerInfoRepository customerInfoRepository;
	@Autowired
	TransferRepository transferRepository;
	@Autowired
	TransferUserDetailsRepository transferUserDetailsRepository;
	

	@Override
	public boolean validateTransferNotesQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getUserLoginCdFrom())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCdTo())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateTransferCustomerQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getCustomerGrpCdFrom())
				&& StringUtils.isNotEmpty(userDetails.getCustomerGrpCdTo())) {
			response = true;
		}
		return response;
	}
	

	@Override
	public Map<Object, Object> transferNotes(String userLoginCdFrom,String userLoginCdTo, Map<Object, Object> responseMap) {
		transferRepository.transferNotes(userLoginCdFrom, userLoginCdTo);
		responseMap.put("msg", "success");
		return responseMap;
	}
	
	@Override
	public Map<Object, Object> transferCustomer(String customerGrpCdFrom,String customerGrpCdTo, Map<Object, Object> responseMap) {
		Boolean duplicateResult=transferRepository.getDuplicateWatch(customerGrpCdFrom, customerGrpCdTo);
		if(Boolean.FALSE.equals(duplicateResult)) {
		transferRepository.transferCustomer(customerGrpCdFrom, customerGrpCdTo);
		responseMap.put("msg", "success");
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "Duplicate watch is available");
		}
		
		return responseMap;
	}

	@Override
	public Map<Object, Object> getUsers(Map<Object, Object> responseMap) {
		List<TransferUserDetails> users = transferUserDetailsRepository.getUsers();
		if(!CollectionUtils.isEmpty(users)) {
			responseMap.put(ApplicationConstant.ALL_USERS, users);
		}
		return responseMap;
	}
}

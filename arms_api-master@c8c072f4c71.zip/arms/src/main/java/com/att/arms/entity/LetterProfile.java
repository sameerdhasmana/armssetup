package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class LetterProfile {
	@Id
	@JsonProperty("letterProfileFieldId")
	@Column(name = "letter_profile_field_id")
	private Integer letterProfileFieldId;
	@JsonProperty("letterProfileField")
	@Column(name = "letter_profile_field")
	private String letterProfileField;
	@JsonProperty("letterProfileDesc")
	@Column(name = "letter_profile_desc")
	private String letterProfileDesc;
	private String width;
	private String fieldEditable;
	private String fieldRequired;
	private String fieldPrepopulated;
}

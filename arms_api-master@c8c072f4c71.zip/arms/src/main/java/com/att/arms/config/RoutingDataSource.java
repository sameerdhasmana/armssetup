package com.att.arms.config;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.att.arms.enums.DataSourceType;

public class RoutingDataSource extends AbstractRoutingDataSource{

	
	@Override
	protected Object determineCurrentLookupKey() {
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes(); // get
																												// object
		if (attr != null) {
			try {
				String env = attr.getRequest().getHeader("env");
				if(ApplicationConstant.PREPROD.equals(env)) {
					return DataSourceType.PREPROD;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} 
		return null;
	}

	
	
}

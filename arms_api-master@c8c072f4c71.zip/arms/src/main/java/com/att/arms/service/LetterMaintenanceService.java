package com.att.arms.service;

import java.util.Map;

import com.att.arms.entity.LetterModel;

public interface LetterMaintenanceService {

	Map<Object, Object> getLetterTypes(LetterModel letterModel, Map<Object, Object> responseMap);

	Map<Object, Object> saveLetterProfile(LetterModel letterModel, Map<Object, Object> responseMap);

	Map<Object, Object> saveModifyLetter(LetterModel letterModel, Map<Object, Object> responseMap);

	Map<Object, Object> getSegment(LetterModel letterModel, Map<Object, Object> responseMap);

	boolean validateSegment(LetterModel letterModel);

	Map<Object, Object> deleteLetterProfile(LetterModel letterModel, Map<Object, Object> responseMap);

	boolean validateQueryRequest(LetterModel letterModel);

	Map<Object, Object> getLetterProfileField(LetterModel letterModel, Map<Object, Object> responseMap);

	Map<Object, Object> getLetterProfileList(LetterModel letterModel, Map<Object, Object> responseMap);

	boolean validateDelete(LetterModel letterModel);

	boolean modifyLetter(LetterModel letterModel);

	Map<Object, Object> fetchLetterProfileFieldList(LetterModel letterModel, Map<Object, Object> responseMap);

	boolean modifyLetterProperty(LetterModel letterModel);

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CommitmentHistory;

@Transactional
public interface CommitmentHistoryRepository extends JpaRepository<CommitmentHistory, String> {

	@Query(value = "Exec arms_pmtcommit_view_v22 :account_numbers, :originating_systems,:user_login_cd", nativeQuery = true)
	public List<CommitmentHistory> getCommitmentHistory(@Param("account_numbers") String accountNumbers,
			@Param("originating_systems") String originatingSystems, @Param("user_login_cd") String userLoginCd);

	@Modifying
	@Query(value = "Exec arms_pmtcommit_updt_v19 :account_numbers, :originating_systems,:due_date,:amount,:user_login_cd,:strStatus", nativeQuery = true)
	public void closeCommitmentHistory(@Param("account_numbers") String accountNumbers,
			@Param("originating_systems") String originatingSystems, @Param("due_date") String dueDate,
			@Param("amount") String amount, @Param("user_login_cd") String userLoginCd, @Param("strStatus") String strStatus);

}

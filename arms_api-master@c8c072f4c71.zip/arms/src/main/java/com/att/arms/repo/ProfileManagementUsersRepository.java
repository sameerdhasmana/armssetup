package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.ProfileManagementUsers;

@Transactional
public interface ProfileManagementUsersRepository extends JpaRepository<ProfileManagementUsers, String> {

	@Query(value = "exec arms_profmgt_user_list_v22 :userLoginCd", nativeQuery = true)
	public List<ProfileManagementUsers> getProfileManagementUsersList(@Param("userLoginCd") String userLoginCd);

}

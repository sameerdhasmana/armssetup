package com.att.arms.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.TemplateDetailsModel;
import com.att.arms.reports.service.TemplateReportsExcelService;
import com.att.arms.reports.service.TemplateReportsPdfService;
import com.att.arms.reports.service.TemplateReportsService;
import com.att.arms.utils.CommonReportsUtils;
import com.itextpdf.text.DocumentException;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class TemplateReportsController {

	@Autowired
	TemplateReportsService templateReportsService;
	
	@Autowired
	TemplateReportsPdfService templateReportsPdfService;
	
	@Autowired
	TemplateReportsExcelService templateReportsExcelService;
	
	@PostMapping("saveOrUpdateTemplateFile")
	public ResponseEntity<Object> saveOrUpdateTemplateFile(@RequestBody TemplateDetailsModel templateDetailsModel) {
		Map<Object, Object> responseMap = new HashMap<>();
			responseMap = this.templateReportsService.saveOrUpdateTemplateFile(templateDetailsModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("deleteTemplateFile")
	public Map<Object, Object> deleteTemplateFile(@RequestBody TemplateDetailsModel templateDetailsModel) {
		Map<Object, Object> responseMap = new HashMap<>();
			templateReportsService.deleteTemplateFile(templateDetailsModel.getUserLoginCd(),templateDetailsModel.getUpdatedType(),
					templateDetailsModel.getReportType(), templateDetailsModel.getReportName());
			responseMap.put("msg", ReportsConstant.SUCCESSFULLY_DELETED);

		return responseMap;
	}
	
	@PostMapping("loadSelectedTemplateCriteria")
	public ResponseEntity<Object> loadTemplateCriteria(@RequestBody TemplateDetailsModel templateDetailsModel) {
		Map<Object, Object> responseMap = new HashMap<>();
			responseMap = this.templateReportsService.loadSelectedTemplateFile(templateDetailsModel.getUserLoginCd(),
					templateDetailsModel.getReportType(), templateDetailsModel.getReportName(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	
	@PostMapping("downloadTemplateReportPdf")
	public ResponseEntity<Object> getDetailsForPDF(@RequestBody UserDetails userDetails, HttpServletResponse response)
			throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=MaintainanceReports.pdf");
		ByteArrayInputStream stream = templateReportsPdfService.createPdfWithDbData(userDetails, responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("downloadTemplateReportExcel")
	public ResponseEntity<Object> getDetailsForExcel(@RequestBody UserDetails userDetails, HttpServletResponse response)
			throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		String originatingSystem = "";

		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			
			originatingSystem = CommonReportsUtils
					.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem());
		
		}

		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=MaintainanceReports.xlsx");
		ByteArrayInputStream stream = templateReportsExcelService.createExcelWithDbData(
				userDetails.getBillingPeriod(), originatingSystem, userDetails.getReportStatus(), responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	
}
package com.att.arms.entity;

import java.util.List;

import lombok.Data;
@Data
public class RequestModel {
	private String userLoginCd;
	private String region;
	private String billingPeriod;
	private String customerGrpCd;
	private String exclusions;
	private String businessGroup;
	private List<String> statusClause;
	private List<String> exclusionClass;
	private List<String> originatingSystem;
	private List<String> selectedAccountNumbers;
	private List<String> groupSelected;
	private List<String> customerGrpCdList;
	private List<String> segment;
	private List<String> regions;
	private String accountNumber;
	private String acntNoteOrgSys;
	private String templateName;
	private String templateType;
	private String templateOwner;
	private String templateNote;
	private List<String> templateH1Logins;
	private Integer paymentTerm;
	private String managerLoginCd;
	private String queryType;
	private Integer resolved;
	private List<String> activityCode;
	private String startDate;
	private String endDate;
	private List<String> customerName;
	private List<String> h1Uid;
	private List<String> subActivity;
	private Integer sort;
	private String enteredValue;
	private Integer byPayment=0;
	private Integer byAdjustment=0;	
}

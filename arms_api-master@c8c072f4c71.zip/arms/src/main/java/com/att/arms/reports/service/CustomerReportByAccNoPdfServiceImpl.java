package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.CustomerReportByAccount;
import com.att.arms.reports.repo.CustomerReportRepositoryForAccNumber;
import com.att.arms.reports.repo.CustomerReportRepositoryForBillName;
import com.att.arms.utils.CommonReportsUtils;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;

@Service
public class CustomerReportByAccNoPdfServiceImpl implements CustomerRepDetailsByAccNumPdfService {

	@Autowired
	CustomerReportRepositoryForAccNumber customerReportRepositoryForAccNumber;

	@Autowired
	CustomerReportRepositoryForBillName customerReportRepositoryForBillName;

	Font bannerFont = new Font(FontFamily.TIMES_ROMAN, 24f, Font.BOLD, BaseColor.BLACK);
	Font headerFont = new Font(FontFamily.TIMES_ROMAN, 14f, Font.NORMAL, BaseColor.BLACK);
	Font headerFontBold = new Font(FontFamily.TIMES_ROMAN, 14f, Font.BOLD, BaseColor.BLACK);
	Font textFont = new Font(FontFamily.TIMES_ROMAN, 12f, Font.NORMAL, BaseColor.BLACK);
	Font textFontBold = new Font(FontFamily.TIMES_ROMAN, 12f, Font.BOLD, BaseColor.BLACK);
	Font customerFont = new Font(FontFamily.TIMES_ROMAN, 18f, Font.BOLD, BaseColor.BLACK);
	Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

	@Override
	public ByteArrayInputStream getCustRepDetailsByAccNumPdf(UserDetails userDetails, Map<Object, Object> responseMap)
			throws DocumentException, IOException {

		try {
			Document document = new Document();
			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream("CustomerReport-AccountNumber.pdf"));

			String exclusionClasses = "";
			if (userDetails.getExclusionClass().isEmpty()) {
				exclusionClasses = "AND (cx.class_cd IN (" + userDetails.getExclusionClass().get(0) + "))";
			}

			List<CustomerReportByAccount> customerReportAccNumList = customerReportRepositoryForAccNumber
					.findCustomerReportData(userDetails.getBillingPeriod(),
							CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()),
							CommonReportsUtils
									.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()),
							CommonReportsUtils
									.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()),
							CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
							CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
							CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
							userDetails.getExclusions(), exclusionClasses, userDetails.getCustomerChidFlag(),
							userDetails.getDisputeInterval());

			if (customerReportAccNumList != null) {
				documentBuilder(userDetails, document, writer, customerReportAccNumList);
				addHeaderSection(document);
				addActualContent(customerReportAccNumList, document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			} else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Records Found");
			}

			document.close();
			writer.close();

			Path path = Paths.get("CustomerReport-AccountNumber.pdf");
			byte[] pdfBytes = Files.readAllBytes(path);
			return new ByteArrayInputStream(pdfBytes);
			 

		} catch (DocumentException | FileNotFoundException e) {
			e.printStackTrace();
		}  
		return null;
	}

	private void addHeaderSection(Document document) {
		try {
			PdfPTable table = new PdfPTable(15);

			float[] columnWidths = { 100f, 40f, 40f, 40f, 40f, 40f, 40f, 100f, 220f, 90f, 90f, 90f, 90f, 90f, 90f };

			table.setWidths(columnWidths);
			table.setTotalWidth(1200);
			table.setLockedWidth(true);
			table.getDefaultCell().setFixedHeight(100);

			PdfPCell cell1 = new PdfPCell(new Paragraph(ReportsConstant.ACCT_NBR, boldFont));
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell2 = new PdfPCell(new Paragraph(ReportsConstant.SEG, boldFont));
			cell2.setBorder(Rectangle.NO_BORDER);
			cell2.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell3 = new PdfPCell(new Paragraph(ReportsConstant.STATE, boldFont));
			cell3.setBorder(Rectangle.NO_BORDER);
			cell3.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell4 = new PdfPCell(new Paragraph(ReportsConstant.ACNA, boldFont));
			cell4.setBorder(Rectangle.NO_BORDER);
			cell4.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell5 = new PdfPCell(new Paragraph(ReportsConstant.AECN, boldFont));
			cell5.setBorder(Rectangle.NO_BORDER);
			cell5.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell6 = new PdfPCell(new Paragraph(ReportsConstant.OCN, boldFont));
			cell6.setBorder(Rectangle.NO_BORDER);
			cell6.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell7 = new PdfPCell(new Paragraph(ReportsConstant.STATUS, boldFont));
			cell7.setBorder(Rectangle.NO_BORDER);
			cell7.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell8 = new PdfPCell(new Paragraph(ReportsConstant.BILL_DATE, boldFont));
			cell8.setBorder(Rectangle.NO_BORDER);
			cell8.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell9 = new PdfPCell(new Paragraph(ReportsConstant.BILL_NAME, boldFont));
			cell9.setBorder(Rectangle.NO_BORDER);
			cell9.setHorizontalAlignment(Element.ALIGN_LEFT);

			PdfPCell cell10 = new PdfPCell(new Paragraph(ReportsConstant.CURRENT_BILLING, boldFont));
			cell10.setBorder(Rectangle.NO_BORDER);
			cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);

			PdfPCell cell11 = new PdfPCell(new Paragraph(ReportsConstant.CURRENT_BALANCE, boldFont));
			cell11.setBorder(Rectangle.NO_BORDER);
			cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);

			PdfPCell cell12 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_PAST_DUE, boldFont));
			cell12.setBorder(Rectangle.NO_BORDER);
			cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);

			PdfPCell cell13 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_DUE, boldFont));
			cell13.setBorder(Rectangle.NO_BORDER);
			cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);

			PdfPCell cell14 = new PdfPCell(new Paragraph(ReportsConstant.DISPUTE, boldFont));
			cell14.setBorder(Rectangle.NO_BORDER);
			cell14.setHorizontalAlignment(Element.ALIGN_RIGHT);

			PdfPCell cell15 = new PdfPCell(new Paragraph(ReportsConstant.DENIED_DISP_AMOUT, boldFont));
			cell15.setBorder(Rectangle.NO_BORDER);
			cell15.setHorizontalAlignment(Element.ALIGN_RIGHT);

			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);
			table.addCell(cell8);
			table.addCell(cell9);
			table.addCell(cell10);
			table.addCell(cell11);
			table.addCell(cell12);
			table.addCell(cell13);
			table.addCell(cell14);
			table.addCell(cell15);

			LineSeparator thickLine = new LineSeparator();
			thickLine.setLineWidth(2);
			thickLine.setOffset(10);
			PdfPCell pCell = new PdfPCell(new Paragraph(new Chunk(thickLine)));
			pCell.setColspan(15);
			pCell.setBorder(Rectangle.NO_BORDER);

			table.addCell(pCell);

			document.add(table);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	private void documentBuilder(UserDetails userDetails, Document document, PdfWriter writer,
			List<CustomerReportByAccount> customerReportAccNumList) throws DocumentException {
		// Set Page Size
		Rectangle pageSize = new Rectangle(15, 15, 1300, 1800);
		document.setPageSize(pageSize);

		Paragraph accReportName = new Paragraph("Account Level Report By Account Number", bannerFont);
		accReportName.setAlignment(Element.ALIGN_CENTER);

		/*
		 * Handle Empty records
		 */
		String billingPeriod = "";
		Integer disputeInterval = 0;
		if (null != customerReportAccNumList &&  !customerReportAccNumList.isEmpty()) {
			billingPeriod = customerReportAccNumList.get(0).getBillingPeriod();
			disputeInterval = customerReportAccNumList.get(0).getDisputeInterval();
		}

		Paragraph billingPerd = new Paragraph(new Chunk("Billing Period: ") + billingPeriod, headerFont);
		billingPerd.setAlignment(Element.ALIGN_LEFT);

		Paragraph billingDisputeInterval = new Paragraph("Denined Dispute Interval: " + disputeInterval, headerFont);
		billingDisputeInterval.setAlignment(Element.ALIGN_LEFT);

		PdfPTable topSectionTable = new PdfPTable(3);

		float[] columnWidths = { 620, 180, 180 };
		topSectionTable.setWidths(columnWidths);
		topSectionTable.setTotalWidth(1200);
		topSectionTable.setLockedWidth(true);

		PdfPCell cell1 = new PdfPCell(accReportName);
		cell1.setBorder(Rectangle.NO_BORDER);

		PdfPCell cell2 = new PdfPCell(billingPerd);
		cell2.setBorder(Rectangle.NO_BORDER);

		PdfPCell cell3 = new PdfPCell(billingDisputeInterval);
		cell3.setBorder(Rectangle.NO_BORDER);

		topSectionTable.addCell(cell1);
		topSectionTable.addCell(cell2);
		topSectionTable.addCell(cell3);

		Chunk whiteSpace = new Chunk("            ");
		Paragraph groupRegionAndStatus = new Paragraph();
		Phrase groupRegionAndStatusPhrase = new Phrase();
		groupRegionAndStatusPhrase
				.add(new Chunk("Groups(s): " + String.join(", ", userDetails.getGroupSelected()), headerFont));
		groupRegionAndStatusPhrase.add(whiteSpace);
		groupRegionAndStatusPhrase.add(
				new Chunk("Region(s): " + String.join(", ", userDetails.getOriginatingCompanyCdClause()), headerFont));
		groupRegionAndStatusPhrase.add(whiteSpace);
		groupRegionAndStatusPhrase
				.add(new Chunk("Status: " + String.join(", ", userDetails.getStatusClause()), headerFont));
		groupRegionAndStatus.add(groupRegionAndStatusPhrase);

		Paragraph segments = new Paragraph("Segment(s): " + String.join(", ", userDetails.getSegment()), headerFont);
		segments.setSpacingAfter(5f);

		Paragraph classesIncluded = new Paragraph("Class(es): " + userDetails.getExclusions(), headerFont);
		classesIncluded.setSpacingAfter(3f);

		CustomerReportAccNumHeaderEvent accNumHeaderEvent = new CustomerReportAccNumHeaderEvent();
		writer.setPageEvent(accNumHeaderEvent);

		document.open();
		document.setMargins(15, 15, 120, 60);

		document.add(new LineSeparator());
		document.add(topSectionTable);
		LineSeparator lineSeparater = new LineSeparator();
		lineSeparater.setOffset(-10);
		document.add(lineSeparater);

		Paragraph emptyPara = new Paragraph("\n");
		document.add(emptyPara);

		document.add(groupRegionAndStatus);
		document.add(segments);
		document.add(classesIncluded);
		document.add(Chunk.NEWLINE);
		LineSeparator thickLine = new LineSeparator();
		thickLine.setLineWidth(2);
		document.add(thickLine);
	}

	private void addActualContent(List<CustomerReportByAccount> customerReportAccNumList, Document document)
			throws DocumentException {

		/*
		 * Get customers form the list in the order Example: A, B, A, C, A, B, C, where
		 * the original is AAABBAACCCAAAABC
		 */
		List<String> customerNames = new ArrayList<>();
		String previousCustomer = "";
		for (CustomerReportByAccount customer : customerReportAccNumList) {
			if (customer.getCustomer().equals(previousCustomer)) {
				continue;
			} else {
				previousCustomer = customer.getCustomer();
				customerNames.add(customer.getCustomer());
			}
		}

		/*
		 * Get sum of customers in batches in the order using customerNames list
		 */

		int indexPosition = 0;
		for (String customerKey : customerNames) {
			// Display Customer name in the paragraph label
			Paragraph customer = new Paragraph(customerKey, customerFont);
			customer.setAlignment(Element.ALIGN_JUSTIFIED);

			try {
				document.add(customer);
				double currentBillingTotalByGroup = 0.00;
				double currentBalanceTotalByGroup = 0.00;
				double totalPastDueByGroup = 0.00;
				double totalDueByGroup = 0.00;
				double totalDisputeByGroup = 0.00;
				double totalDeniedDisputeAmtByGroup = 0.00;
				NumberFormat nf = new DecimalFormat("#0.00");
				SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

				for (int i = indexPosition; i < customerReportAccNumList.size(); i++) {
					CustomerReportByAccount customerReportByAccount = customerReportAccNumList.get(i);
					if (customerKey.equals(customerReportByAccount.getCustomer())) {
						++indexPosition;
						PdfPTable table = new PdfPTable(15);

						float[] columnWidths = { 100f, 40f, 40f, 40f, 40f, 40f, 40f, 100f, 220f, 90f, 90f, 90f, 90f,
								90f, 90f };

						table.setWidths(columnWidths);
						table.setTotalWidth(1200);
						table.setLockedWidth(true);

						PdfPCell cell1 = new PdfPCell(
								new Paragraph(customerReportByAccount.getAccountNumber(), textFont));
						cell1.setBorder(Rectangle.NO_BORDER);
						cell1.setHorizontalAlignment(Element.ALIGN_LEFT);

						PdfPCell cell2 = new PdfPCell(new Paragraph(customerReportByAccount.getSegment(), textFont));
						cell2.setBorder(Rectangle.NO_BORDER);
						cell2.setHorizontalAlignment(Element.ALIGN_LEFT);

						PdfPCell cell3 = new PdfPCell(new Paragraph(customerReportByAccount.getState(), textFont));
						cell3.setBorder(Rectangle.NO_BORDER);
						cell3.setHorizontalAlignment(Element.ALIGN_LEFT);

						PdfPCell cell4 = new PdfPCell(new Paragraph(customerReportByAccount.getAcna(), textFont));
						cell4.setBorder(Rectangle.NO_BORDER);
						cell4.setHorizontalAlignment(Element.ALIGN_LEFT);

						PdfPCell cell5 = new PdfPCell(new Paragraph(customerReportByAccount.getAecn(), textFont));
						cell5.setBorder(Rectangle.NO_BORDER);
						cell5.setHorizontalAlignment(Element.ALIGN_LEFT);

						PdfPCell cell6 = new PdfPCell(new Paragraph(customerReportByAccount.getOcn(), textFont));
						cell6.setBorder(Rectangle.NO_BORDER);
						cell6.setHorizontalAlignment(Element.ALIGN_LEFT);

						PdfPCell cell7 = new PdfPCell(new Paragraph(customerReportByAccount.getStatus(), textFont));
						cell7.setBorder(Rectangle.NO_BORDER);
						cell7.setHorizontalAlignment(Element.ALIGN_LEFT);

						PdfPCell cell8 = new PdfPCell(
								new Paragraph(dateFormat.format(customerReportByAccount.getBillDate()), textFont));
						cell8.setBorder(Rectangle.NO_BORDER);
						cell8.setHorizontalAlignment(Element.ALIGN_LEFT);

						PdfPCell cell9 = new PdfPCell(new Paragraph(customerReportByAccount.getBillName(), textFont));
						cell9.setBorder(Rectangle.NO_BORDER);
						cell9.setHorizontalAlignment(Element.ALIGN_LEFT);

						PdfPCell cell10 = new PdfPCell(
								new Paragraph("$" + nf.format(customerReportByAccount.getCurrentBillingAmount())));
						cell10.setBorder(Rectangle.NO_BORDER);
						cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);

						PdfPCell cell11 = new PdfPCell(
								new Paragraph("$" + nf.format(customerReportByAccount.getPastDue0Amount())));
						cell11.setBorder(Rectangle.NO_BORDER);
						cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);

						PdfPCell cell12 = new PdfPCell(
								new Paragraph("$" + nf.format(customerReportByAccount.getTotalPastDue())));
						cell12.setBorder(Rectangle.NO_BORDER);
						cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);

						PdfPCell cell13 = new PdfPCell(
								new Paragraph("$" + nf.format(customerReportByAccount.getTotalAmount())));
						cell13.setBorder(Rectangle.NO_BORDER);
						cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);

						PdfPCell cell14 = new PdfPCell(
								new Paragraph("$" + nf.format(customerReportByAccount.getDispute())));
						cell14.setBorder(Rectangle.NO_BORDER);
						cell14.setHorizontalAlignment(Element.ALIGN_RIGHT);

						PdfPCell cell15 = new PdfPCell(
								new Paragraph("$" + nf.format(customerReportByAccount.getDeniedDispAmt())));
						cell15.setBorder(Rectangle.NO_BORDER);
						cell15.setHorizontalAlignment(Element.ALIGN_RIGHT);

						table.addCell(cell1);
						table.addCell(cell2);
						table.addCell(cell3);
						table.addCell(cell4);
						table.addCell(cell5);
						table.addCell(cell6);
						table.addCell(cell7);
						table.addCell(cell8);
						table.addCell(cell9);
						table.addCell(cell10);
						table.addCell(cell11);
						table.addCell(cell12);
						table.addCell(cell13);
						table.addCell(cell14);
						table.addCell(cell15);

						document.add(table);

						currentBillingTotalByGroup = currentBillingTotalByGroup
								+ customerReportByAccount.getCurrentBillingAmount();
						currentBalanceTotalByGroup = currentBalanceTotalByGroup
								+ customerReportByAccount.getPastDue0Amount();
						totalPastDueByGroup = totalPastDueByGroup + customerReportByAccount.getTotalPastDue();
						totalDueByGroup = totalDueByGroup + customerReportByAccount.getTotalAmount();
						totalDisputeByGroup = totalDisputeByGroup + customerReportByAccount.getDispute();
						totalDeniedDisputeAmtByGroup = totalDeniedDisputeAmtByGroup
								+ customerReportByAccount.getDeniedDispAmt();

					} else {
						break;
					}

				}
				/*
				 * Create table for the sum
				 */
				addCustomerSumTableHeader(document, customerKey);
				addGroupSumTableBody(document, currentBillingTotalByGroup, currentBalanceTotalByGroup,
						totalPastDueByGroup, totalDueByGroup, totalDisputeByGroup, totalDeniedDisputeAmtByGroup);
			} catch (DocumentException e) {
				e.printStackTrace();
			}
		}

		/*
		 * Add Grand Total
		 */
		double currentBillingGrandTotalByGroup = customerReportAccNumList.stream()
				.collect(Collectors.summingDouble(CustomerReportByAccount::getCurrentBillingAmount));

		double currentBalanceGrandTotalByGroup = customerReportAccNumList.stream()
				.collect(Collectors.summingDouble(CustomerReportByAccount::getPastDue0Amount));
		double grandTotalPastDueByGroup = customerReportAccNumList.stream()
				.collect(Collectors.summingDouble(CustomerReportByAccount::getTotalPastDue));
		double grandTotalDueByGroup = customerReportAccNumList.stream()
				.collect(Collectors.summingDouble(CustomerReportByAccount::getTotalAmount));
		double grandTotalDisputeByGroup = customerReportAccNumList.stream()
				.collect(Collectors.summingDouble(CustomerReportByAccount::getDispute));
		double grandTotalDeniedDisputeAmtByGroup = customerReportAccNumList.stream()
				.collect(Collectors.summingDouble(CustomerReportByAccount::getDeniedDispAmt));

		addGrandSumTableHeader(document);
		addGroupSumTableBody(document, currentBillingGrandTotalByGroup, currentBalanceGrandTotalByGroup,
				grandTotalPastDueByGroup, grandTotalDueByGroup, grandTotalDisputeByGroup,
				grandTotalDeniedDisputeAmtByGroup);

	}

	private void addCustomerSumTableHeader(Document document, String customerName) throws DocumentException {
		PdfPTable table = new PdfPTable(15);

		float[] columnWidths = { 100f, 40f, 40f, 40f, 40f, 40f, 40f, 100f, 220f, 90f, 90f, 90f, 90f, 90f, 90f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setColspan(9);
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		LineSeparator thickLine = new LineSeparator();
		thickLine.setLineWidth(2);
		thickLine.setOffset(-4);
		PdfPCell lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(6);
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Total for " + customerName, textFontBold));
		totalCustCell.setColspan(6);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);

	}

	private void addGroupSumTableBody(Document document, double currentBillingTotalByGroup,
			double currentBalanceTotalByGroup, double totalPastDueByGroup, double totalDueByGroup,
			double totalDisputeByGroup, double totalDeniedDisputeAmtByGroup) throws DocumentException {

		NumberFormat nf = new DecimalFormat("#0.00");
		PdfPTable table = new PdfPTable(15);

		float[] columnWidths = { 100f, 40f, 40f, 40f, 40f, 40f, 40f, 100f, 220f, 90f, 90f, 90f, 90f, 90f, 90f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setColspan(9);
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		PdfPCell cell10 = new PdfPCell(new Paragraph("$" + nf.format(currentBillingTotalByGroup), textFontBold));
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);

		PdfPCell cell11 = new PdfPCell(new Paragraph("$" + nf.format(currentBalanceTotalByGroup), textFontBold));
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);

		PdfPCell cell12 = new PdfPCell(new Paragraph("$" + nf.format(totalPastDueByGroup), textFontBold));
		cell12.setBorder(Rectangle.NO_BORDER);
		cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);

		PdfPCell cell13 = new PdfPCell(new Paragraph("$" + nf.format(totalDueByGroup), textFontBold));
		cell13.setBorder(Rectangle.NO_BORDER);
		cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);

		PdfPCell cell14 = new PdfPCell(new Paragraph("$" + nf.format(totalDisputeByGroup), textFontBold));
		cell14.setBorder(Rectangle.NO_BORDER);
		cell14.setHorizontalAlignment(Element.ALIGN_RIGHT);

		PdfPCell cell15 = new PdfPCell(new Paragraph("$" + nf.format(totalDeniedDisputeAmtByGroup), textFontBold));
		cell15.setBorder(Rectangle.NO_BORDER);
		cell15.setHorizontalAlignment(Element.ALIGN_RIGHT);

		table.addCell(cell10);
		table.addCell(cell11);
		table.addCell(cell12);
		table.addCell(cell13);
		table.addCell(cell14);
		table.addCell(cell15);

		document.add(table);

	}

	private void addGrandSumTableHeader(Document document) throws DocumentException {
		PdfPTable table = new PdfPTable(15);

		float[] columnWidths = { 100f, 40f, 40f, 40f, 40f, 40f, 40f, 100f, 220f, 90f, 90f, 90f, 90f, 90f, 90f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setColspan(9);
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		LineSeparator thickLine = new LineSeparator();
		thickLine.setLineWidth(2);
		thickLine.setOffset(-4);
		PdfPCell lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(6);
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		// Add second line for grand total
		table.addCell(emptyCells);
		thickLine = new LineSeparator();
		thickLine.setLineWidth(2);
		thickLine.setOffset(4);
		lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(6);
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Grand Total ", textFontBold));
		totalCustCell.setColspan(6);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);

	}

}

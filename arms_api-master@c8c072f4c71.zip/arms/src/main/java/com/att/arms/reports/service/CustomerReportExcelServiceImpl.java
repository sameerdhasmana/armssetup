package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.CustomerReportByAccount;
import com.att.arms.reports.entity.CustomerReportByBillName;
import com.att.arms.reports.entity.CustomerReportByRegionSegment;
import com.att.arms.reports.entity.CustomerReportByRegionSegmentStatus;
import com.att.arms.reports.entity.CustomerReportByRegionState;
import com.att.arms.reports.entity.CustomerReportByRegionStateSegment;
import com.att.arms.reports.repo.CustomerReportRepoByRegionSegment;
import com.att.arms.reports.repo.CustomerReportRepoByRegionSegmentStatus;
import com.att.arms.reports.repo.CustomerReportRepoRegionState;
import com.att.arms.reports.repo.CustomerReportRepoRegionStateSegment;
import com.att.arms.reports.repo.CustomerReportRepositoryForAccNumber;
import com.att.arms.reports.repo.CustomerReportRepositoryForBillName;
import com.att.arms.utils.CommonReportsUtils;
import com.att.arms.utils.CommonUtils;

@Service
public class CustomerReportExcelServiceImpl implements CustomerReportExcelService {

	@Autowired
	CustomerReportRepositoryForAccNumber customerReportRepository;

	@Autowired
	CustomerReportRepositoryForBillName customerReportRepositoryForBillName;

	@Autowired
	CustomerReportRepoByRegionSegment customerReportRepoByRegionSegment;

	@Autowired
	CustomerReportRepoByRegionSegmentStatus customerReportRepoByRegionSegmentStatus;

	@Autowired
	CustomerReportRepoRegionState customerReportRepoRegionState;

	@Autowired
	CustomerReportRepoRegionStateSegment customerReportRepoRegionStateSegment;

	public ByteArrayInputStream getCustRepDetailsByAccNumExcel(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		List<CustomerReportByAccount> customerReportByAccount = customerReportRepository.findCustomerReportData(
				userDetails.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()),
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
				userDetails.getExclusions(), "AND (cx.class_cd IN (" + userDetails.getExclusionClass().get(0) + "))",
				userDetails.getCustomerChidFlag(), userDetails.getDisputeInterval());

		System.out.println("Total records  found :" + customerReportByAccount.size());

		try (Workbook custReportByAccountNumberWorkbook = new XSSFWorkbook()) {
			Sheet custReportByAccountNumberSheet = custReportByAccountNumberWorkbook
					.createSheet("CustReport-AccountNumber");

			if (customerReportByAccount != null) {
				addHeaderContent(custReportByAccountNumberSheet, custReportByAccountNumberWorkbook);
				addActualContent(customerReportByAccount, custReportByAccountNumberSheet,
						custReportByAccountNumberWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			custReportByAccountNumberWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	public ByteArrayInputStream getCustRepDetailsByBillNameExcel(UserDetails userDetails,
			Map<Object, Object> responseMap) {

		String exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		List<CustomerReportByBillName> customerReportByAccount = customerReportRepositoryForBillName
				.findCustomerReportDataByBillName(userDetails.getBillingPeriod(),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
						userDetails.getExclusions(), "AND (cx.class_cd IN (" + exclusionClass + "))",
						userDetails.getCustomerChidFlag());

		System.out.println("Total records  found :" + customerReportByAccount.size());

		try (Workbook custReportByAccountNumberWorkbook = new XSSFWorkbook()) {
			Sheet custReportByAccountNumberSheet = custReportByAccountNumberWorkbook.createSheet("CustReport-BillName");

			if (customerReportByAccount != null) {
				addExcelHeaderContentforBillName(custReportByAccountNumberSheet, custReportByAccountNumberWorkbook);
				addExcelActualContentforBillName(customerReportByAccount, custReportByAccountNumberSheet,
						custReportByAccountNumberWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			custReportByAccountNumberWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	private void addActualContent(List<CustomerReportByAccount> customerReportByAccount,
			Sheet custReportByAccountNumberSheet, Workbook custReportByAccountNumberWorkbook) {

		CellStyle dataCellStyleBlack = custReportByAccountNumberWorkbook.createCellStyle();
		CellStyle dataCellStyleRed = custReportByAccountNumberWorkbook.createCellStyle();
		Font blackColorFont = custReportByAccountNumberWorkbook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = custReportByAccountNumberWorkbook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow;

		String aECN = "";
		String oCN = "";

		for (int i = 0; i < customerReportByAccount.size(); i++) {
			dataRow = custReportByAccountNumberSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = custReportByAccountNumberWorkbook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short) 8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(customerReportByAccount.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(customerReportByAccount.get(i).getCustomer());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(customerReportByAccount.get(i).getCustomerGrpCd());
			cell3.setCellStyle(dataCellStyleBlack);

			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(customerReportByAccount.get(i).getAccountNumber());
			cell4.setCellStyle(styleCurrencyFormat);

			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(customerReportByAccount.get(i).getSegment());
			cell5.setCellStyle(styleCurrencyFormat);

			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(customerReportByAccount.get(i).getState());
			cell6.setCellStyle(styleCurrencyFormat);

			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(customerReportByAccount.get(i).getAcna());
			cell7.setCellStyle(styleCurrencyFormat);

			String aecnVal = customerReportByAccount.get(i).getAecn();
			aECN = StringUtils.isEmpty(aecnVal) ? "" : aecnVal;
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(aECN);
			cell8.setCellStyle(styleCurrencyFormat);

			String ocnVal = customerReportByAccount.get(i).getAecn();
			oCN = StringUtils.isEmpty(ocnVal) ? "" : ocnVal;
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(oCN);
			cell9.setCellStyle(styleCurrencyFormat);

			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(customerReportByAccount.get(i).getStatus());
			cell10.setCellStyle(styleCurrencyFormat);

			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(customerReportByAccount.get(i).getBillDate());
			cell11.setCellStyle(dataCellStyleBlack);

			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(customerReportByAccount.get(i).getBillName());
			cell12.setCellStyle(styleCurrencyFormat);

			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(customerReportByAccount.get(i).getCurrentBillingAmount());
			cell13.setCellStyle(styleCurrencyFormat);

			Cell cell14 = dataRow.createCell(13);
			cell14.setCellValue(customerReportByAccount.get(i).getPastDue0Amount());
			cell14.setCellStyle(styleCurrencyFormat);

			Cell cell15 = dataRow.createCell(14);
			cell15.setCellValue(customerReportByAccount.get(i).getTotalPastDue());
			cell15.setCellStyle(styleCurrencyFormat);

			Cell cell16 = dataRow.createCell(15);
			cell16.setCellValue(customerReportByAccount.get(i).getTotalAmount());
			cell16.setCellStyle(styleCurrencyFormat);

			Cell cell17 = dataRow.createCell(16);
			cell17.setCellValue(customerReportByAccount.get(i).getDispute());
			cell17.setCellStyle(styleCurrencyFormat);

			Cell cell18 = dataRow.createCell(17);
			cell18.setCellValue(customerReportByAccount.get(i).getDso());
			cell18.setCellStyle(styleCurrencyFormat);

			Cell cell19 = dataRow.createCell(18);
			cell19.setCellValue(customerReportByAccount.get(i).getDeniedDispAmt());
			cell19.setCellStyle(dataCellStyleBlack);

			Cell cell20 = dataRow.createCell(19);
			cell20.setCellValue(customerReportByAccount.get(i).getDisputeInterval());
			cell20.setCellStyle(dataCellStyleBlack);

			custReportByAccountNumberSheet.setColumnWidth(i,
					custReportByAccountNumberSheet.getColumnWidth(i) * 23 / 10);

		}
	}

	private void addHeaderContent(Sheet custReportByAccountNumberSheet, Workbook custReportByAccountNumberWorkbook) {
		Row row = custReportByAccountNumberSheet.createRow(0);
		CellStyle headerCellStyle = custReportByAccountNumberWorkbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.CUSTOMER);
		cell2.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.CUSTOMER_GRP_ID);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.ACCOUNT_NUMBER);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.SEGMENT);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.STATE);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.ACNA);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.AECN);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.OCN);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.STATUS);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.BILL_DATE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.BILL_NAME);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.CURRNET_BILLING_AMOUNT);
		cell13.setCellStyle(headerCellStyle);

		Cell cell14 = row.createCell(13);
		cell14.setCellValue(ReportsConstant.PAST_DUE_ZERO_AMOUNT);
		cell14.setCellStyle(headerCellStyle);

		Cell cell15 = row.createCell(14);
		cell15.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell15.setCellStyle(headerCellStyle);

		Cell cell16 = row.createCell(15);
		cell16.setCellValue(ReportsConstant.TOTAL_AMOUNT);
		cell16.setCellStyle(headerCellStyle);

		Cell cell17 = row.createCell(16);
		cell17.setCellValue(ReportsConstant.DISPUTE);
		cell17.setCellStyle(headerCellStyle);

		Cell cell18 = row.createCell(17);
		cell18.setCellValue(ReportsConstant.DSO);
		cell18.setCellStyle(headerCellStyle);

		Cell cell19 = row.createCell(18);
		cell19.setCellValue(ReportsConstant.DENIED_DISP_AMOUT);
		cell19.setCellStyle(headerCellStyle);

		Cell cell20 = row.createCell(19);
		cell20.setCellValue(ReportsConstant.DISPUTE_INTERVAL);
		cell20.setCellStyle(headerCellStyle);

		custReportByAccountNumberSheet.createFreezePane(1, 1);
	}

	private void addExcelHeaderContentforBillName(Sheet custReportByAccountNumberSheet,
			Workbook custReportByAccountNumberWorkbook) {
		Row row = custReportByAccountNumberSheet.createRow(0);
		CellStyle headerCellStyle = custReportByAccountNumberWorkbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.CUSTOMER);
		cell2.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.CUSTOMER_GRP_ID);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.ACCOUNT_NUMBER);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.BILL_NAME);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.BILL_DATE);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.SEGMENT);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.STATE);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.ACNA);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.AECN);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.OCN);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.STATUS);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.CURRNET_BILLING_AMOUNT);
		cell13.setCellStyle(headerCellStyle);

		Cell cell14 = row.createCell(13);
		cell14.setCellValue(ReportsConstant.PAST_DUE_ZERO_AMOUNT);
		cell14.setCellStyle(headerCellStyle);

		Cell cell15 = row.createCell(14);
		cell15.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell15.setCellStyle(headerCellStyle);

		Cell cell16 = row.createCell(15);
		cell16.setCellValue(ReportsConstant.TOTAL_AMOUNT);
		cell16.setCellStyle(headerCellStyle);

		Cell cell17 = row.createCell(16);
		cell17.setCellValue(ReportsConstant.DISPUTE);
		cell17.setCellStyle(headerCellStyle);

		Cell cell18 = row.createCell(17);
		cell18.setCellValue(ReportsConstant.DSO);
		cell18.setCellStyle(headerCellStyle);

		custReportByAccountNumberSheet.createFreezePane(1, 1);
	}

	private void addExcelActualContentforBillName(List<CustomerReportByBillName> customerReportByAccount,
			Sheet custReportByAccountNumberSheet, Workbook custReportByAccountNumberWorkbook) {

		CellStyle dataCellStyleBlack = custReportByAccountNumberWorkbook.createCellStyle();
		CellStyle dataCellStyleRed = custReportByAccountNumberWorkbook.createCellStyle();
		Font blackColorFont = custReportByAccountNumberWorkbook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = custReportByAccountNumberWorkbook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow;

		String aECN = "";
		String oCN = "";

		for (int i = 0; i < customerReportByAccount.size(); i++) {
			dataRow = custReportByAccountNumberSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = custReportByAccountNumberWorkbook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short) 8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(customerReportByAccount.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(customerReportByAccount.get(i).getCustomer());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(customerReportByAccount.get(i).getCustomerGrpCd());
			cell3.setCellStyle(dataCellStyleBlack);

			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(customerReportByAccount.get(i).getAccountNumber());
			cell4.setCellStyle(styleCurrencyFormat);

			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(customerReportByAccount.get(i).getBillName());
			cell5.setCellStyle(styleCurrencyFormat);

			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(customerReportByAccount.get(i).getBillDate());
			cell6.setCellStyle(styleCurrencyFormat);

			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(customerReportByAccount.get(i).getSegment());
			cell7.setCellStyle(styleCurrencyFormat);

			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(customerReportByAccount.get(i).getState());
			cell8.setCellStyle(styleCurrencyFormat);

			String acnaVal = customerReportByAccount.get(i).getAcna();
			aECN = StringUtils.isEmpty(acnaVal) ? "" : acnaVal;
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(acnaVal);
			cell9.setCellStyle(styleCurrencyFormat);

			String aecnVal = customerReportByAccount.get(i).getAecn();
			aECN = StringUtils.isEmpty(aecnVal) ? "" : aecnVal;
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(aecnVal);
			cell10.setCellStyle(styleCurrencyFormat);

			String ocnVal = customerReportByAccount.get(i).getOcn();
			oCN = StringUtils.isEmpty(ocnVal) ? "" : ocnVal;
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(ocnVal);
			cell11.setCellStyle(dataCellStyleBlack);

			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(customerReportByAccount.get(i).getStatus());
			cell12.setCellStyle(styleCurrencyFormat);

			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(customerReportByAccount.get(i).getCurrentBillingAmount());
			cell13.setCellStyle(styleCurrencyFormat);

			Cell cell14 = dataRow.createCell(13);
			cell14.setCellValue(customerReportByAccount.get(i).getPastDue0Amount());
			cell14.setCellStyle(styleCurrencyFormat);

			Cell cell15 = dataRow.createCell(14);
			cell15.setCellValue(customerReportByAccount.get(i).getTotalPastDue());
			cell15.setCellStyle(styleCurrencyFormat);

			Cell cell16 = dataRow.createCell(15);
			cell16.setCellValue(customerReportByAccount.get(i).getTotalAmount());
			cell16.setCellStyle(styleCurrencyFormat);

			Cell cell17 = dataRow.createCell(16);
			cell17.setCellValue(customerReportByAccount.get(i).getDispute());
			cell17.setCellStyle(styleCurrencyFormat);

			Cell cell18 = dataRow.createCell(17);
			cell18.setCellValue(customerReportByAccount.get(i).getDso());
			cell18.setCellStyle(styleCurrencyFormat);

			custReportByAccountNumberSheet.setColumnWidth(i,
					custReportByAccountNumberSheet.getColumnWidth(i) * 23 / 10);

		}
	}

	@Override
	public ByteArrayInputStream getCustRepDetailsByRegSegExcel(UserDetails userDetails,
			Map<Object, Object> responseMap) {

		String exclusionClasses = "";
		if (userDetails.getExclusionClass().size() > 0) {
			exclusionClasses = "AND (cx.class_cd IN (" + userDetails.getExclusionClass().get(0) + "))";
		}

		List<CustomerReportByRegionSegment> customerReportRegionSeg = customerReportRepoByRegionSegment
				.findCustomerReportData(userDetails.getBillingPeriod(),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
						userDetails.getExclusions(), exclusionClasses, userDetails.getCustomerChidFlag());

		try (Workbook custReportByRegSegWorkbook = new XSSFWorkbook()) {
			Sheet custReportByRegSegSheet = custReportByRegSegWorkbook.createSheet("CustReport-RegionSegment");

			if (customerReportRegionSeg != null) {
				addHeaderRegSeg(custReportByRegSegSheet, custReportByRegSegWorkbook);
				addContentRegSeg(customerReportRegionSeg, custReportByRegSegSheet, custReportByRegSegWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			custReportByRegSegWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void addHeaderRegSeg(Sheet custReportByRegSegSheet, Workbook custReportByRegSegWorkbook) {
		Row row = custReportByRegSegSheet.createRow(0);
		CellStyle headerCellStyle = custReportByRegSegWorkbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.CUSTOMER);
		cell2.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.REGION);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.SEGMENT);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.CURRENT_BALANCE);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.TOTAL_DUE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.DISPUTE);
		cell13.setCellStyle(headerCellStyle);

		Cell cell14 = row.createCell(13);
		cell14.setCellValue(ReportsConstant.DSO);
		cell14.setCellStyle(headerCellStyle);

		custReportByRegSegSheet.createFreezePane(1, 1);

	}

	private void addContentRegSeg(List<CustomerReportByRegionSegment> customerReportRegionSeg,
			Sheet custReportByRegSegSheet, Workbook custReportByRegSegWorkbook) {

		CellStyle dataCellStyleBlack = custReportByRegSegWorkbook.createCellStyle();
		CellStyle dataCellStyleRed = custReportByRegSegWorkbook.createCellStyle();
		Font blackColorFont = custReportByRegSegWorkbook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = custReportByRegSegWorkbook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow;

		for (int i = 0; i < customerReportRegionSeg.size(); i++) {
			dataRow = custReportByRegSegSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = custReportByRegSegWorkbook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short) 8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(customerReportRegionSeg.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(customerReportRegionSeg.get(i).getCustomer());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(customerReportRegionSeg.get(i).getCustomerGrpCd());
			cell3.setCellStyle(dataCellStyleBlack);

			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(customerReportRegionSeg.get(i).getSegment());
			cell4.setCellStyle(styleCurrencyFormat);

			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(customerReportRegionSeg.get(i).getCurrentBillingAmount());
			cell5.setCellStyle(styleCurrencyFormat);

			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(customerReportRegionSeg.get(i).getPastDue0Amount());
			cell6.setCellStyle(styleCurrencyFormat);

			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(customerReportRegionSeg.get(i).getPastDue30Amount());
			cell7.setCellStyle(styleCurrencyFormat);

			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(customerReportRegionSeg.get(i).getPastDue60Amount());
			cell8.setCellStyle(styleCurrencyFormat);

			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(customerReportRegionSeg.get(i).getPastDue90Amount());
			cell9.setCellStyle(styleCurrencyFormat);

			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(customerReportRegionSeg.get(i).getPastDue120Amount());
			cell10.setCellStyle(styleCurrencyFormat);

			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(customerReportRegionSeg.get(i).getTotalPastDue());
			cell11.setCellStyle(dataCellStyleBlack);

			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(customerReportRegionSeg.get(i).getTotalAmount());
			cell12.setCellStyle(styleCurrencyFormat);

			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(customerReportRegionSeg.get(i).getDispute());
			cell13.setCellStyle(styleCurrencyFormat);

			Cell cell14 = dataRow.createCell(13);
			cell14.setCellValue(customerReportRegionSeg.get(i).getDso());
			cell14.setCellStyle(styleCurrencyFormat);

			custReportByRegSegSheet.setColumnWidth(i, custReportByRegSegSheet.getColumnWidth(i) * 23 / 10);

		}

	}

	@Override
	public ByteArrayInputStream getCustRepDetailsByRegSegStatusExcel(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		String exclusionClasses = "";
		if (userDetails.getExclusionClass().size() > 0) {
			exclusionClasses = "AND (cx.class_cd IN (" + userDetails.getExclusionClass().get(0) + "))";
		}

		List<CustomerReportByRegionSegmentStatus> customerReportRegionSegStatus = customerReportRepoByRegionSegmentStatus
				.findCustomerReportData(userDetails.getBillingPeriod(),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
						userDetails.getExclusions(), exclusionClasses, userDetails.getCustomerChidFlag());

		try (Workbook custReportByRegSegStatusWorkbook = new XSSFWorkbook()) {
			Sheet custReportByRegSegStatusSheet = custReportByRegSegStatusWorkbook
					.createSheet("CustReport-RegionSegmentStatus");

			if (customerReportRegionSegStatus != null) {
				addHeaderRegSegStatus(custReportByRegSegStatusSheet, custReportByRegSegStatusWorkbook);
				addContentRegSegStatus(customerReportRegionSegStatus, custReportByRegSegStatusSheet,
						custReportByRegSegStatusWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			custReportByRegSegStatusWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void addContentRegSegStatus(List<CustomerReportByRegionSegmentStatus> customerReportRegionSeg,
			Sheet custReportByRegSegStatusSheet, Workbook custReportByRegSegStatusWorkbook) {

		CellStyle dataCellStyleBlack = custReportByRegSegStatusWorkbook.createCellStyle();
		CellStyle dataCellStyleRed = custReportByRegSegStatusWorkbook.createCellStyle();
		Font blackColorFont = custReportByRegSegStatusWorkbook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = custReportByRegSegStatusWorkbook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow;

		for (int i = 0; i < customerReportRegionSeg.size(); i++) {
			dataRow = custReportByRegSegStatusSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = custReportByRegSegStatusWorkbook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short) 8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(customerReportRegionSeg.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(customerReportRegionSeg.get(i).getCustomer());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(customerReportRegionSeg.get(i).getCustomerGrpCd());
			cell3.setCellStyle(dataCellStyleBlack);

			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(customerReportRegionSeg.get(i).getSegment());
			cell4.setCellStyle(styleCurrencyFormat);

			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(customerReportRegionSeg.get(i).getStatus());
			cell5.setCellStyle(styleCurrencyFormat);

			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(customerReportRegionSeg.get(i).getCurrentBillingAmount());
			cell6.setCellStyle(styleCurrencyFormat);

			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(customerReportRegionSeg.get(i).getPastDue0Amount());
			cell7.setCellStyle(styleCurrencyFormat);

			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(customerReportRegionSeg.get(i).getPastDue30Amount());
			cell8.setCellStyle(styleCurrencyFormat);

			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(customerReportRegionSeg.get(i).getPastDue60Amount());
			cell9.setCellStyle(styleCurrencyFormat);

			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(customerReportRegionSeg.get(i).getPastDue90Amount());
			cell10.setCellStyle(styleCurrencyFormat);

			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(customerReportRegionSeg.get(i).getPastDue120Amount());
			cell11.setCellStyle(styleCurrencyFormat);

			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(customerReportRegionSeg.get(i).getTotalPastDue());
			cell12.setCellStyle(dataCellStyleBlack);

			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(customerReportRegionSeg.get(i).getTotalAmount());
			cell13.setCellStyle(styleCurrencyFormat);

			Cell cell14 = dataRow.createCell(13);
			cell14.setCellValue(customerReportRegionSeg.get(i).getDispute());
			cell14.setCellStyle(styleCurrencyFormat);

			Cell cell15 = dataRow.createCell(14);
			cell15.setCellValue(customerReportRegionSeg.get(i).getDso());
			cell15.setCellStyle(styleCurrencyFormat);

			custReportByRegSegStatusSheet.setColumnWidth(i, custReportByRegSegStatusSheet.getColumnWidth(i) * 23 / 10);

		}

	}

	private void addHeaderRegSegStatus(Sheet custReportByRegSegStatusSheet, Workbook custReportByRegSegStatusWorkbook) {
		Row row = custReportByRegSegStatusSheet.createRow(0);
		CellStyle headerCellStyle = custReportByRegSegStatusWorkbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.CUSTOMER);
		cell2.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.REGION);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.SEGMENT);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.STATUS);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.CURRENT_BALANCE);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.TOTAL_DUE);
		cell13.setCellStyle(headerCellStyle);

		Cell cell14 = row.createCell(13);
		cell14.setCellValue(ReportsConstant.DISPUTE);
		cell14.setCellStyle(headerCellStyle);

		Cell cell15 = row.createCell(14);
		cell15.setCellValue(ReportsConstant.DSO);
		cell15.setCellStyle(headerCellStyle);

		custReportByRegSegStatusSheet.createFreezePane(1, 1);

	}

	@Override
	public ByteArrayInputStream getCustRepDetailsByRegStateExcel(UserDetails userDetails,
			Map<Object, Object> responseMap) {

		String exclusionClasses = "";
		if (userDetails.getExclusionClass().size() > 0) {
			exclusionClasses = "AND (cx.class_cd IN (" + userDetails.getExclusionClass().get(0) + "))";
		}

		List<CustomerReportByRegionState> customerReportRegionState = customerReportRepoRegionState
				.findCustomerReportData(userDetails.getBillingPeriod(),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
						userDetails.getExclusions(), exclusionClasses, userDetails.getCustomerChidFlag());

		try (Workbook custReportByRegStateWorkbook = new XSSFWorkbook()) {
			Sheet custReportByRegStateSheet = custReportByRegStateWorkbook.createSheet("CustReport-RegionState");

			if (customerReportRegionState != null) {
				addHeaderRegState(custReportByRegStateSheet, custReportByRegStateWorkbook);
				addContentRegState(customerReportRegionState, custReportByRegStateSheet, custReportByRegStateWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			custReportByRegStateWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public ByteArrayInputStream getCustRepDetailsByRegStateSegExcel(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		String exclusionClasses = "";
		if (userDetails.getExclusionClass().size() > 0) {
			exclusionClasses = "AND (cx.class_cd IN (" + userDetails.getExclusionClass().get(0) + "))";
		}

		List<CustomerReportByRegionStateSegment> customerReportRegionStateSeg = customerReportRepoRegionStateSegment
				.findCustomerReportData(userDetails.getBillingPeriod(),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()),
						CommonReportsUtils
								.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
						CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
						userDetails.getExclusions(), exclusionClasses, userDetails.getCustomerChidFlag());

		try (Workbook custReportByRegStateSegWorkbook = new XSSFWorkbook()) {
			Sheet custReportByRegSegSheet = custReportByRegStateSegWorkbook
					.createSheet("CustReport-RegionStateSegment");

			if (customerReportRegionStateSeg != null) {
				addHeaderRegStateSegment(custReportByRegSegSheet, custReportByRegStateSegWorkbook);
				addContentRegStateSegment(customerReportRegionStateSeg, custReportByRegSegSheet,
						custReportByRegStateSegWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			custReportByRegStateSegWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void addHeaderRegState(Sheet custReportByRegSegSheet, Workbook custReportByRegSegWorkbook) {
		Row row = custReportByRegSegSheet.createRow(0);
		CellStyle headerCellStyle = custReportByRegSegWorkbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.CUSTOMER);
		cell2.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.REGION);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.STATE);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.CURRENT_BALANCE);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.TOTAL_DUE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.DISPUTE);
		cell13.setCellStyle(headerCellStyle);

		Cell cell14 = row.createCell(13);
		cell14.setCellValue(ReportsConstant.DSO);
		cell14.setCellStyle(headerCellStyle);

		custReportByRegSegSheet.createFreezePane(1, 1);

	}

	private void addContentRegState(List<CustomerReportByRegionState> customerReportRegionSeg,
			Sheet custReportByRegSegSheet, Workbook custReportByRegSegWorkbook) {

		CellStyle dataCellStyleBlack = custReportByRegSegWorkbook.createCellStyle();
		CellStyle dataCellStyleRed = custReportByRegSegWorkbook.createCellStyle();
		Font blackColorFont = custReportByRegSegWorkbook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = custReportByRegSegWorkbook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow;

		for (int i = 0; i < customerReportRegionSeg.size(); i++) {
			dataRow = custReportByRegSegSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = custReportByRegSegWorkbook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short) 8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(customerReportRegionSeg.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(customerReportRegionSeg.get(i).getCustomer());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(customerReportRegionSeg.get(i).getRegion());
			cell3.setCellStyle(dataCellStyleBlack);

			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(customerReportRegionSeg.get(i).getState());
			cell4.setCellStyle(styleCurrencyFormat);
			
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(customerReportRegionSeg.get(i).getCurrentBillingAmount());
			cell5.setCellStyle(styleCurrencyFormat);

			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(customerReportRegionSeg.get(i).getPastDue0Amount());
			cell6.setCellStyle(styleCurrencyFormat);

			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(customerReportRegionSeg.get(i).getPastDue30Amount());
			cell7.setCellStyle(styleCurrencyFormat);

			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(customerReportRegionSeg.get(i).getPastDue60Amount());
			cell8.setCellStyle(styleCurrencyFormat);

			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(customerReportRegionSeg.get(i).getPastDue90Amount());
			cell9.setCellStyle(styleCurrencyFormat);

			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(customerReportRegionSeg.get(i).getPastDue120Amount());
			cell10.setCellStyle(styleCurrencyFormat);

			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(customerReportRegionSeg.get(i).getTotalPastDue());
			cell11.setCellStyle(dataCellStyleBlack);

			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(customerReportRegionSeg.get(i).getTotalAmount());
			cell12.setCellStyle(styleCurrencyFormat);

			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(customerReportRegionSeg.get(i).getDispute());
			cell13.setCellStyle(styleCurrencyFormat);

			Cell cell14 = dataRow.createCell(13);
			cell14.setCellValue(customerReportRegionSeg.get(i).getDso());
			cell14.setCellStyle(styleCurrencyFormat);

			custReportByRegSegSheet.setColumnWidth(i, custReportByRegSegSheet.getColumnWidth(i) * 23 / 10);

		}

	}

	private void addHeaderRegStateSegment(Sheet custReportByRegStateSegSheet,
			Workbook custReportByRegStateSegWorkbook) {
		Row row = custReportByRegStateSegSheet.createRow(0);
		CellStyle headerCellStyle = custReportByRegStateSegWorkbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.CUSTOMER);
		cell2.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.REGION);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.STATE);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.SEGMENT);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.CURRENT_BALANCE);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.TOTAL_DUE);
		cell13.setCellStyle(headerCellStyle);

		Cell cell14 = row.createCell(13);
		cell14.setCellValue(ReportsConstant.DISPUTE);
		cell14.setCellStyle(headerCellStyle);

		Cell cell15 = row.createCell(14);
		cell15.setCellValue(ReportsConstant.DSO);
		cell15.setCellStyle(headerCellStyle);

		custReportByRegStateSegSheet.createFreezePane(1, 1);

	}

	private void addContentRegStateSegment(List<CustomerReportByRegionStateSegment> customerReportRegionStateSeg,
			Sheet custReportByRegStateSegSheet, Workbook custReportByRegStateSegWorkbook) {

		CellStyle dataCellStyleBlack = custReportByRegStateSegWorkbook.createCellStyle();
		CellStyle dataCellStyleRed = custReportByRegStateSegWorkbook.createCellStyle();
		Font blackColorFont = custReportByRegStateSegWorkbook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = custReportByRegStateSegWorkbook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow;

		for (int i = 0; i < customerReportRegionStateSeg.size(); i++) {
			dataRow = custReportByRegStateSegSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = custReportByRegStateSegWorkbook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short) 8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(customerReportRegionStateSeg.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(customerReportRegionStateSeg.get(i).getCustomer());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(customerReportRegionStateSeg.get(i).getRegion());
			cell3.setCellStyle(dataCellStyleBlack);

			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(customerReportRegionStateSeg.get(i).getState());
			cell4.setCellStyle(styleCurrencyFormat);
			
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(customerReportRegionStateSeg.get(i).getSegment());
			cell5.setCellStyle(styleCurrencyFormat);

			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(customerReportRegionStateSeg.get(i).getCurrentBillingAmount());
			cell6.setCellStyle(styleCurrencyFormat);

			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(customerReportRegionStateSeg.get(i).getPastDue0Amount());
			cell7.setCellStyle(styleCurrencyFormat);

			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(customerReportRegionStateSeg.get(i).getPastDue30Amount());
			cell8.setCellStyle(styleCurrencyFormat);

			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(customerReportRegionStateSeg.get(i).getPastDue60Amount());
			cell9.setCellStyle(styleCurrencyFormat);

			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(customerReportRegionStateSeg.get(i).getPastDue90Amount());
			cell10.setCellStyle(styleCurrencyFormat);

			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(customerReportRegionStateSeg.get(i).getPastDue120Amount());
			cell11.setCellStyle(styleCurrencyFormat);

			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(customerReportRegionStateSeg.get(i).getTotalPastDue());
			cell12.setCellStyle(dataCellStyleBlack);

			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(customerReportRegionStateSeg.get(i).getTotalAmount());
			cell13.setCellStyle(styleCurrencyFormat);

			Cell cell14 = dataRow.createCell(13);
			cell14.setCellValue(customerReportRegionStateSeg.get(i).getDispute());
			cell14.setCellStyle(styleCurrencyFormat);

			Cell cell15 = dataRow.createCell(14);
			cell15.setCellValue(customerReportRegionStateSeg.get(i).getDso());
			cell15.setCellStyle(styleCurrencyFormat);

			custReportByRegStateSegSheet.setColumnWidth(i, custReportByRegStateSegSheet.getColumnWidth(i) * 23 / 10);

		}

	}

}

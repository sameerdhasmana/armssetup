package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(SummaryDetails.SummaryDetailsId.class)
@Data
public class SummaryDetails {
	@Id
	@JsonProperty("billing_period")
	@Column(name = "billing_period")
	private String billingPeriod;
	@Id
	private String seg;
	@JsonProperty("current_billing_amt")
	@Column(name = "current_billing_amt")
	private Double currentBillingAmt;
	@JsonProperty("current_balance_amt")
	@Column(name = "current_balance_amt")
	private Double currentBalanceAmt;
	@JsonProperty("past_due_amt")
	@Column(name = "past_due_amt")
	private Double pastDueAmt;
	@JsonProperty("dispute_amt")
	@Column(name = "dispute_amt")
	private Double disputeAmt;
	@JsonProperty("past_due_30_amt")
	@Column(name = "past_due_30_amt")
	private Double pastDue30Amt;
	@JsonProperty("past_due_60_amt")
	@Column(name = "past_due_60_amt")
	private Double pastDue60Amt;
	@JsonProperty("past_due_90_amt")
	@Column(name = "past_due_90_amt")
	private Double pastDue90Amt;
	@JsonProperty("past_due_120_amt")
	@Column(name = "past_due_120_amt")
	private Double pastDue120Amt;
	@JsonProperty("total_amt")
	@Column(name = "total_amt")
	private Double totalAmt;

	@Data
	public static class SummaryDetailsId implements Serializable {

		private static final long serialVersionUID = 1L;
		private String seg;
		private String billingPeriod;
	}
}

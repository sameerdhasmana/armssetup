package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.EmaorView;

@Transactional
public interface EmaorViewRepository extends JpaRepository<EmaorView, String> {

	@Query(value = "Exec arms_emaor_view_v22 :account_numbers, :originating_systems,:user_login_cd", nativeQuery = true)
	public List<EmaorView> getEmaorView(@Param("account_numbers") String accountNumbers,
			@Param("originating_systems") String originatingSystems, @Param("user_login_cd") String userLoginCd);

}

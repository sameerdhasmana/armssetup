package com.att.arms.reports.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.reports.entity.TemplateCriteriaDetails;

@Transactional
public interface TemplateReportSaveDetailsRepository extends JpaRepository<TemplateCriteriaDetails, String> {

	@Modifying    
	@Query(value = "EXEC arms_rpt_user_rpt_details_v22 :user_login_cd,:updt_type,:rpt_type,:fav_tmplt_name,"
			+ ":acct_status,:bus_unit_cd,:region,:cust_ctc_ind,:cust_ctc_list,"
			+ ":segment_list,:acct_class_status,:acct_class_list,:orig_sys_list,:tmplt_selected_fields,"
			+ ":tmplt_group_by_list,:tmplt_sort_list,:tmplt_sort_order,:tmplt_criteria", nativeQuery = true)
	public int saveTemplateCriteriaDetails(@Param("user_login_cd") String userLoginCd, @Param("updt_type") String updatedType,
			@Param("rpt_type") String reportType, @Param("fav_tmplt_name") String reportName, 
			@Param("acct_status") String statusClause, @Param("bus_unit_cd") String groupSelected,
			@Param("region") String originatingCompanyCdClause, @Param("cust_ctc_ind") String customerChildFlag,
			@Param("cust_ctc_list") String customerGrpCd, @Param("segment_list") String segment,
			@Param("acct_class_status") String exclusions, @Param("acct_class_list") String exclusionClass,
			@Param("orig_sys_list") String originatingSystem, @Param("tmplt_selected_fields") String templateSelectedFields,
			@Param("tmplt_group_by_list") String groupByFields, @Param("tmplt_sort_list") String sortByFields,
			@Param("tmplt_sort_order") String sortOrder, @Param("tmplt_criteria") String criteriaClause);

	@Modifying
	@Query(value = "EXEC arms_rpt_user_rpt_details_v22 :user_login_cd,:updt_type,:rpt_type,:fav_tmplt_name,'','','','','','','','','','','','','',''", nativeQuery = true)
	public void deleteTemplateFile(@Param("user_login_cd") String userLoginCd, @Param("updt_type") String updatedType,@Param("rpt_type") String reportType,
			@Param("fav_tmplt_name") String reportName);
	
	@Modifying    
	@Query(value = "EXEC arms_rpt_user_rpt_details_v22 :user_login_cd,:updt_type,:rpt_type,:fav_tmplt_name,"
			+ ":acct_status,:bus_unit_cd,:region,:cust_ctc_ind,:cust_ctc_list,"
			+ ":segment_list,:acct_class_status,:acct_class_list,:orig_sys_list,:tmplt_selected_fields,"
			+ ":tmplt_group_by_list,:tmplt_sort_list,:tmplt_sort_order,:tmplt_criteria", nativeQuery = true)
	public int updateTemplateCriteriaDetails(@Param("user_login_cd") String userLoginCd, @Param("updt_type") String updatedType,
			@Param("rpt_type") String reportType, @Param("fav_tmplt_name") String reportName, 
			@Param("acct_status") String statusClause, @Param("bus_unit_cd") String groupSelected,
			@Param("region") String originatingCompanyCdClause, @Param("cust_ctc_ind") String customerChildFlag,
			@Param("cust_ctc_list") String customerGrpCd, @Param("segment_list") String segment,
			@Param("acct_class_status") String exclusions, @Param("acct_class_list") String exclusionClass,
			@Param("orig_sys_list") String originatingSystem, @Param("tmplt_selected_fields") String templateSelectedFields,
			@Param("tmplt_group_by_list") String groupByFields, @Param("tmplt_sort_list") String sortByFields,
			@Param("tmplt_sort_order") String sortOrder, @Param("tmplt_criteria") String criteriaClause);


}

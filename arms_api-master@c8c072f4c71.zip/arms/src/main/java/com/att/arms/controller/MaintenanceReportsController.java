package com.att.arms.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.service.MaintenanceExcelReportsService;
import com.att.arms.reports.service.MaintenancePdfReportsService;
import com.att.arms.utils.CommonReportsUtils;
import com.itextpdf.text.DocumentException;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class MaintenanceReportsController {

	@Autowired
	MaintenancePdfReportsService maintenancePdfReportsService;

	@Autowired
	MaintenanceExcelReportsService maintenanceExcelReportsService;

	@PostMapping("downloadMaintainanceQdsoLfwReportPdf")
	public ResponseEntity<Object> getDetailsForPDF(@RequestBody UserDetails userDetails, HttpServletResponse response)
			throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=MaintainanceReports.pdf");
		ByteArrayInputStream stream = maintenancePdfReportsService.createPdfWithDbData(userDetails, responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("downloadMaintainanceQdsoLfwReportExcel")
	public ResponseEntity<Object> getDetailsForExcel(@RequestBody UserDetails userDetails, HttpServletResponse response)
			throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		String originatingSystem = "";

		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			
			originatingSystem = CommonReportsUtils
					.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem());
		
		}

		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=MaintainanceReports.xlsx");
		ByteArrayInputStream stream = maintenanceExcelReportsService.createExcelWithDbData(
				userDetails.getBillingPeriod(), originatingSystem, userDetails.getReportStatus(), responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

}

package com.att.arms.enums;

public enum DataSourceType {

	PREPROD("preprod"),PROD("prod");


	DataSourceType(String name) {
		this.name=name;
	}

	private final String name;

	public String getName() {
		return name;
	}
}

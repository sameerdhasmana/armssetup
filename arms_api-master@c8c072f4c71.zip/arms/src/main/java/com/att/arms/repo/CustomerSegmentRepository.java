package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerSegment;
@Transactional
public interface CustomerSegmentRepository extends JpaRepository<CustomerSegment, String> {

	@Query(value = "SELECT DISTINCT segment_cd, segment_desc, segment_grp_cd, bus_unit_cd FROM segment  with (nolock) where bus_unit_cd in (:group)  ORDER BY segment_cd ", nativeQuery = true)
	public List<CustomerSegment> findCustomerSegmentList(@Param("group") List<String> group);
}

package com.att.arms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class CustomerBringUpDetails {

	@Id
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("customer_legal_nm")
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	@JsonProperty("ExcludedAccountsExists")
	@Column(name="ExcludedAccountsExists")
	private String excludedAccountsExists;
	@JsonProperty("past_due_amt")
	@Column(name="past_due_amt")
	private Double pastDueAmt;
	private Integer priority;
	@JsonProperty("commit_amt")
	@Column(name="commit_amt")
	private Double commitAmt;
	@Column(name="callback_date")
	private Date callbackDate;
	

}

package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class SegmentMaintenanceBusGroup {
	@Id
	@JsonProperty("busUnitCode")
	@Column(name = "bus_unit_cd")
	private String segmentGrpCd;
	@JsonProperty("busUnitDesc")
	@Column(name = "bus_unit_desc")
	private String busUnitDesc;
}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.CustomerName;

@Transactional
public interface CustomerNameRepository extends JpaRepository<CustomerName, String> {

	@Query(value = "select customer_legal_nm from customer with (nolock) order by customer_legal_nm asc", nativeQuery = true)
	public List<CustomerName> getAllCustomers();

	
}

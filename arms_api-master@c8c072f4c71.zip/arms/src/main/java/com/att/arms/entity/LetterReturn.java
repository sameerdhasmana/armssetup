package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class LetterReturn {
	@Id
	@JsonProperty("letter_return_id")
	@Column(name="letter_return_id")
	private Integer letterReturnId;
	@JsonProperty("letter_return_add")
	@Column(name="letter_return_add")
	private String letterReturnAdd;
}

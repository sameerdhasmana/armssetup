package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class RegionDetails {

	@Id
	@JsonProperty("originating_company_cd")
	@Column(name="originating_company_cd")
	private String originatingCompanyCd;
	@JsonProperty("originating_company_nm")
	@Column(name="originating_company_nm")
	private String originatingCompanyNm;
	
	

}

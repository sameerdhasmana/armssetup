package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.SegmentMaintenanceGroup;

@Transactional
public interface SegmentMaintenanceGroupRepository extends JpaRepository<SegmentMaintenanceGroup, String> {

	@Query(value = "Exec arms_tblmaint_segmentmaint_getsegmentgrp", nativeQuery = true)
	public List<SegmentMaintenanceGroup> fetchSegmentMaintenanceGrp();
}

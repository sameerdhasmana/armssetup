package com.att.arms.service;

import java.util.Map;
import com.att.arms.entity.UserDetails;

public interface ContactsService {

	boolean validateQueryRequest(UserDetails userDetails);

	Map<Object, Object> getSearchContacts(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getDisplayContacts(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getSearchAccount(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getContactAssign(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getAccountDisplay(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getContactUnAssign(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getFetchContact(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getEditContact(UserDetails userDetails, Map<Object, Object> responseMap);

	Map<Object, Object> getdeleteContact(UserDetails userDetails, Map<Object, Object> responseMap);



}

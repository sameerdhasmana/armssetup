package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class AccountClassification {

	@Id
	@JsonProperty("class_cd")
	@Column(name="class_cd")
	private String classCd;
	@JsonProperty("class_desc")
	@Column(name="class_desc")
	private String classDesc;
}

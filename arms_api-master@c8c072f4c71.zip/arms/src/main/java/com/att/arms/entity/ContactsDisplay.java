package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class ContactsDisplay {

	
	@Id
	@JsonProperty("contacts_id")
	@Column(name="contacts_id")
	private Integer contactsId;
	private String contact;

}

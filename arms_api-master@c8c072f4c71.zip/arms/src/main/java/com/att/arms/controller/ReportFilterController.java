package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.ReportFilterCTCDetailsResponse;
import com.att.arms.entity.ReportFilterResponse;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.TemplateDetailsModel;
import com.att.arms.service.ReportFilterService;
import com.att.arms.service.UserService;
import com.att.arms.utils.CommonUtils;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class ReportFilterController {

	@Autowired
	UserService userService;
	@Autowired
	ReportFilterService reportFilterService;
	
	@PostMapping("populateReportFilter")
	public ResponseEntity<ReportFilterResponse> populateReportFilter(@RequestBody UserDetails userDetails) {
		userDetails = CommonUtils.getCurrentUserDetails(userDetails.getUserLoginCd(), userDetails.getEnvironment(),
				userDetails.getAppName(), userDetails);
		boolean validUserDetails = this.userService.validateUser(userDetails);
		ReportFilterResponse filter = new ReportFilterResponse();
		if (validUserDetails) {
			filter = this.reportFilterService.populateReportFilter(filter, userDetails);
			if (StringUtils.isEmpty(filter.getErrorMsg())) {
				return new ResponseEntity<>(filter, HttpStatus.OK);
			}
    	}
		filter.setErrorMsg("Invalid User");
		return new ResponseEntity<>(filter, HttpStatus.BAD_REQUEST);
	}
	
	
	@PostMapping("getAllCustomers")
	public ResponseEntity<Object> getContacts() {

		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = this.reportFilterService.getAllCustomers(responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("getChildTieCodeDetails")
	public ResponseEntity<ReportFilterCTCDetailsResponse> getChildTieCodeDetails(@RequestBody UserDetails userDetails) {

		userDetails = CommonUtils.getCurrentUserDetails(userDetails.getUserLoginCd(), userDetails.getEnvironment(),
				userDetails.getAppName(), userDetails);
		boolean validUserDetails = this.userService.validateUser(userDetails);
		ReportFilterCTCDetailsResponse filter = new ReportFilterCTCDetailsResponse();
		if (validUserDetails) {
			filter = this.reportFilterService.populateReportCTCDetailsFilter(filter, userDetails);
			if (StringUtils.isEmpty(filter.getErrorMsg())) {
				return new ResponseEntity<>(filter, HttpStatus.OK);
			}
		}
		filter.setErrorMsg("Invalid User");
		return new ResponseEntity<>(filter, HttpStatus.BAD_REQUEST);
	}
	
	
	
	@PostMapping("loadUserTemplateFiles")
	public ResponseEntity<Object> loadTemplateCriteria(@RequestBody TemplateDetailsModel templateDetailsModel) {
		Map<Object, Object> responseMap = new HashMap<>();
			responseMap = reportFilterService.loadTemplateFiles(templateDetailsModel.getUserLoginCd(),
					templateDetailsModel.getReportType(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	

}

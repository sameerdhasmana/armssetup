package com.att.arms.entity;

import java.util.List;

import lombok.Data;

@Data
public class FilterResponse {

	private GlobalLogonUsers globalLogonUsers;
	private List<CustomerGroupList> customerGroupList;
	private List<CustomerBillingPeriod> customerBillingPeriod;
	private List<CustomerSegment> segmentList;
	private List<AccountClassification> accountsClassificationList;
	List<OriginatingSystem> originatingSystemList;
	private String errorMsg;
	private List<String> taskList;
	private String helpUrl;
}

package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class ChildTieCodeDetails {

	@Id
	@JsonProperty("customer_grp_child_cd")
	@Column(name="customer_grp_child_cd")
	private String customerGroupChildCd;
	
	@JsonProperty("customer_legal_nm")
	@Column(name="customer_legal_nm")
	private String customerLegalName;
	
	@JsonProperty("customer_nm")
	@Column(name="customer_nm")
	private String customerName;

}

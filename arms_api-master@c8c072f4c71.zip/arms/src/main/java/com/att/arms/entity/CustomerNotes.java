package com.att.arms.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(CustomerNotes.CustomerNotesId.class)
@Data
public class CustomerNotes {

	@Id
	@JsonProperty("notes_id")
	@Column(name="notes_id")
	private Integer notesId;
	@Id
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@Id
	@JsonProperty("billing_period")
	@Column(name="billing_period")
	private String billingPeriod;
	private Integer resolved;
	@JsonProperty("next_call_back_date")
	@Column(name="next_call_back_date")
	private String nextCallBackDate;
	@JsonProperty("commitment_amt")
	@Column(name="commitment_amt")
	private Double commitmentAmt;
	@JsonProperty("talked_to")
	@Column(name="talked_to")
	private String talkedTo;
	private String notes;
	@JsonProperty("user_login_cd")
	@Column(name="user_login_cd")
	private String userLoginCd;
	@JsonProperty("insert_date")
	@Column(name="insert_date")
	private Date insertDate;
	@JsonProperty("logged_by")
	@Column(name="logged_by")
	private String loggedBy;
	@JsonProperty("activity_cd")
	@Column(name="activity_cd")
	private String activityCd;
	private String subdesc;
	private String group;
	@JsonProperty("contested_amt")
	@Column(name="contested_amt")
	private Double contestedAmt;
	@JsonProperty("root_cause")
	@Column(name="root_cause")
	private String rootCause;
	@JsonProperty("next_action")
	@Column(name="next_action")
	private String nextAction;
	@JsonProperty("commitment_date")
	@Column(name="commitment_date")
	private String commitmentDate;
	
	@SuppressWarnings("serial")
	@Data
	public static class CustomerNotesId implements Serializable {

		private Integer notesId;
		private String customerGrpCd;
		private String billingPeriod;
		
		
	}

}

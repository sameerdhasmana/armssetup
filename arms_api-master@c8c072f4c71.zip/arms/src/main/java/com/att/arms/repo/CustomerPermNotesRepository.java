package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerPermNotes;

@Transactional
public interface CustomerPermNotesRepository extends JpaRepository<CustomerPermNotes, String> {

	@Query(value = "Exec arms_qry_customer_tab_perm_notes_history_2_v22 :customerGrpCd", nativeQuery = true)
	public List<CustomerPermNotes> getCustomerPermNotes(@Param("customerGrpCd") String customerGrpCd);
	
	@Query(value = "Exec arms_qry_customer_tab_notes_history_2_v22 :customerGrpCd", nativeQuery = true)
	public List<CustomerPermNotes> getCustomerHistoryNotes(@Param("customerGrpCd") String customerGrpCd);

	
}

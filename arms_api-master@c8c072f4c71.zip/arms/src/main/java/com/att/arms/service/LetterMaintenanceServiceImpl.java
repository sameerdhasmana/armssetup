package com.att.arms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.LetterModel;
import com.att.arms.entity.LetterModifyDetails;
import com.att.arms.entity.LetterProfile;
import com.att.arms.entity.LetterProfileList;
import com.att.arms.entity.LetterProfilePropertiesDetails;
import com.att.arms.entity.LetterReturn;
import com.att.arms.entity.LetterTypes;
import com.att.arms.entity.Segment;
import com.att.arms.repo.CustomerNotesRepository;
import com.att.arms.repo.LetterModifyDetailsRepository;
import com.att.arms.repo.LetterProfileListRepository;
import com.att.arms.repo.LetterProfilePropertiesDetailsRepository;
import com.att.arms.repo.LetterProfileRepository;
import com.att.arms.repo.LetterReturnRepository;
import com.att.arms.repo.LetterTypeRepository;
import com.att.arms.repo.SegmentRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class LetterMaintenanceServiceImpl implements LetterMaintenanceService {

	@Autowired
	LetterTypeRepository letterTypeRepository;
	@Autowired
	LetterReturnRepository letterReturnRepository;
	@Autowired
	LetterProfileRepository letterProfileRepository;
	@Autowired
	CustomerNotesRepository customerNotesRepository;
	@Autowired
	LetterProfileListRepository letterProfileListRepository;
	@Autowired
	SegmentRepository segmentRepository;
	@Autowired
	LetterModifyDetailsRepository letterModifyDetailsRepository;
	@Autowired
	LetterProfilePropertiesDetailsRepository letterProfilePropertiesDetailsRepository;

	@Override
	public boolean validateQueryRequest(LetterModel letterModel) {
		boolean response = false;
		if (letterModel != null && letterModel.getUserLoginCd() != null) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean modifyLetter(LetterModel letterModel) {
		boolean response = false;
		if (letterModel != null && letterModel.getLetterProfilesId() != null) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean modifyLetterProperty(LetterModel letterModel) {
		boolean response = false;
		if (letterModel != null && letterModel.getLetterProfilesIdList() != null) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSegment(LetterModel letterModel) {
		boolean response = false;
		if (letterModel != null && !CollectionUtils.isEmpty(letterModel.getGroupSelected())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateDelete(LetterModel letterModel) {
		boolean response = false;
		if (letterModel.getUserLoginCd() != null && letterModel.getLetterProfilesId() != null) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> getLetterTypes(LetterModel letterModel, Map<Object, Object> responseMap) {

		List<String> groupList = customerNotesRepository.getBusinessGroupList(letterModel.getUserLoginCd(),
				letterModel.getBlank());
		responseMap.put(ApplicationConstant.GROUP_LIST, groupList);
		List<String> orgSystemList = letterProfileRepository.getOriginatingSystemList(letterModel.getUserLoginCd(),
				letterModel.getBlank());
		responseMap.put(ApplicationConstant.ORIGINATING_SYSTEM_LIST, orgSystemList);
		List<String> stateCode = letterProfileRepository.getStateCode(letterModel.getUserLoginCd(),
				letterModel.getBlank());
		responseMap.put(ApplicationConstant.STATE_CODE, stateCode);
		List<LetterReturn> letterAddress = letterReturnRepository.getLetterReturnAddress(letterModel.getUserLoginCd(),
				letterModel.getBlank());
		responseMap.put(ApplicationConstant.LETTER_RETURN_ADDRESS, letterAddress);
		List<LetterTypes> letterType = letterTypeRepository.getLetterTypes(letterModel.getUserLoginCd(),
				letterModel.getBlank());
		responseMap.put(ApplicationConstant.LETTER_TYPES, letterType);

		return responseMap;
	}

	@Override
	public Map<Object, Object> getLetterProfileField(LetterModel letterModel, Map<Object, Object> responseMap) {

		List<LetterProfile> letterProfile = letterProfileRepository.getLetterProfileField(letterModel.getUserLoginCd(),
				letterModel.getBlank());
		responseMap.put(ApplicationConstant.LETTER_PROFILE_FIELD, letterProfile);

		return responseMap;
	}

	@Override
	public Map<Object, Object> getLetterProfileList(LetterModel letterModel, Map<Object, Object> responseMap) {

		List<LetterProfileList> letterProfile = letterProfileListRepository
				.getLetterProfileList(letterModel.getUserLoginCd(), letterModel.getBlank());
		responseMap.put(ApplicationConstant.LETTER_PROFILE_FIELD, letterProfile);

		return responseMap;
	}

	@Override
	public Map<Object, Object> saveLetterProfile(LetterModel letterModel, Map<Object, Object> responseMap) {
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(letterModel.getOriginatingSystem());
		String busUnitCD = CommonUtils.getListToCommaSeparatedString(letterModel.getBusUnitCdList());
		String stateCodeList = CommonUtils.getListToCommaSeparatedString(letterModel.getStateCdList());
		String segment = CommonUtils.getListToCommaSeparatedString(letterModel.getSegment());

		letterProfileRepository.saveLetterProfile(letterModel.getLetterProfileName(),
				letterModel.getLetterProfilesDesc(), letterModel.getUserLoginCd(), letterModel.getLetterTypeId(),
				letterModel.getAcctApplicability(), letterModel.getReturnAddrId(), busUnitCD, segment,
				originatingSystem, stateCodeList);
		letterModel.getLetterProfileList().stream()
				.forEach(letter -> letterProfileRepository.saveFieldProperties(letterModel.getLetterProfileName(),
						letter.getLetterProfileFieldId(), letter.getFieldEditable(), letter.getFieldRequired(),
						letter.getFieldPrepopulated()));

		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> saveModifyLetter(LetterModel letterModel, Map<Object, Object> responseMap) {
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(letterModel.getOriginatingSystem());
		String busUnitCD = CommonUtils.getListToCommaSeparatedString(letterModel.getBusUnitCdList());
		String stateCodeList = CommonUtils.getListToCommaSeparatedString(letterModel.getStateCdList());
		String segment = CommonUtils.getListToCommaSeparatedString(letterModel.getSegment());

		letterProfileRepository.saveModifyLetter(letterModel.getLetterProfilesId(), letterModel.getLetterProfileName(),
				letterModel.getLetterProfilesDesc(), letterModel.getUserLoginCd(), letterModel.getLetterTypeId(),
				letterModel.getAcctApplicability(), letterModel.getReturnAddrId(), busUnitCD, segment,
				originatingSystem, stateCodeList);
		letterModel.getLetterProfileList().stream()
				.forEach(letter -> letterProfileRepository.saveModifyProfileField(letterModel.getLetterProfilesId(),
						letter.getLetterProfileFieldId(), letter.getFieldEditable(), letter.getFieldRequired(),
						letter.getFieldPrepopulated()));
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> fetchLetterProfileFieldList(LetterModel letterModel, Map<Object, Object> responseMap) {
		List<LetterModifyDetails> letterProfileFieldSelect = letterModifyDetailsRepository
				.fetchModifyLetterDetails(letterModel.getLetterProfilesId());
		List<String> orgSys = CommonUtils
				.getCommaSeparatedStringToList(letterProfileFieldSelect.get(0).getOriginatingSystemList());
		letterProfileFieldSelect.get(0).setOriginatingSystem(orgSys);

		List<String> busUnitCD = CommonUtils
				.getCommaSeparatedStringToList(letterProfileFieldSelect.get(0).getBusUnitCdList());
		letterProfileFieldSelect.get(0).setBusUnitCd(busUnitCD);

		List<String> segmentCD = CommonUtils
				.getCommaSeparatedStringToList(letterProfileFieldSelect.get(0).getSegmentCdList());
		letterProfileFieldSelect.get(0).setSegmentCd(segmentCD);
		List<String> stateCode = CommonUtils
				.getCommaSeparatedStringToList(letterProfileFieldSelect.get(0).getStateCdList());
		letterProfileFieldSelect.get(0).setStateCd(stateCode);

		responseMap.put(ApplicationConstant.LETTER_PROFILE_FIELD, letterProfileFieldSelect);
		List<String> letterModifyDetails = letterModifyDetailsRepository
				.fetchLetterProfileFieldList(letterModel.getLetterProfilesId());

		List<LetterProfilePropertiesDetails> letterProperty = new ArrayList<>();
		letterModifyDetails.stream().forEach(ele -> {

			List<LetterProfilePropertiesDetails> letterPro = letterProfilePropertiesDetailsRepository
					.getLetterPropertyDetails(ele);
			if (!CollectionUtils.isEmpty(letterPro)) {
				letterProperty.addAll(letterPro);
			}

		});
		responseMap.put(ApplicationConstant.LETTER_PROFILE_FIELD_SELECTED, letterProperty);

		return responseMap;
	}

	@Override
	public Map<Object, Object> getSegment(LetterModel letterModel, Map<Object, Object> responseMap) {
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(letterModel.getGroupSelected());
		List<Segment> letterSegment = segmentRepository.findCustomerSegmentList(selectedGroups);
		responseMap.put(ApplicationConstant.LETTER_SEGMENT_LIST, letterSegment);
		return responseMap;
	}

	@Override
	public Map<Object, Object> deleteLetterProfile(LetterModel letterModel, Map<Object, Object> responseMap) {
		letterProfileRepository.deleteLetterProfile(letterModel.getUserLoginCd(), letterModel.getLetterProfilesId());
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

}

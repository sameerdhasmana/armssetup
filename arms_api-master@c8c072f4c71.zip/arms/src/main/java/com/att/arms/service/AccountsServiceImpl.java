package com.att.arms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.AIFBillPeriodGroup;
import com.att.arms.entity.CommitmentHistory;
import com.att.arms.entity.CustomerAgedDetails;
import com.att.arms.entity.CustomerInfo;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.AIFAlternateBillPeriodGroupRepository;
import com.att.arms.repo.CommitmentHistoryRepository;
import com.att.arms.repo.CustomerAgedDetailsRepository;
import com.att.arms.repo.CustomerInfoRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class AccountsServiceImpl implements AccountsService {

	@Autowired
	CustomerInfoRepository customerInfoRepository;
	@Autowired
	CommitmentHistoryRepository commitmentHistoryRepository;
	@Autowired
	CustomerAgedDetailsRepository customerAgedDetailsRepository;
	@Autowired
	AIFAlternateBillPeriodGroupRepository aIFAlternateBillPeriodGroupRepository;
	@Autowired
	CommonService commonService;
	@Override
	public boolean validateQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getAccountNumber())
				&& StringUtils.isNotEmpty(userDetails.getAcntNoteOrgSys())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateCloseQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getOriginatingSystem())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedDueDate())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedAmount())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateAIFCustomerInfo(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getAcctInvFan())
				&& StringUtils.isNotEmpty(userDetails.getAcctInvFanType())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> getAIFCustomerInfo(UserDetails userDetails, Map<Object, Object> responseMap) {
		String originatingSystem = "";
		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());

		}
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		if (StringUtils.isNotEmpty(selectedGroups)) {
			List<CustomerInfo> aifCustomerInfo = customerInfoRepository.getAIFCustomerInfo(userDetails.getAcctInvFan(),
					userDetails.getBillingPeriod(), selectedGroups, userDetails.getAcctInvFanType(), originatingSystem);
			if (!CollectionUtils.isEmpty(aifCustomerInfo)) {
				responseMap.put(ApplicationConstant.AIF_CUSTOMER_INFO, aifCustomerInfo);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.GROUP_NOT_SELECTED);
		}
		return responseMap;
	}

	@Override
	public Map<Object, Object> getAIFAlternateBillperiodGroup(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		if (StringUtils.isNotEmpty(selectedGroups)) {
			List<AIFBillPeriodGroup> aifAlternateBill = aIFAlternateBillPeriodGroupRepository
					.getAIFAlternateBillperiodGroup(userDetails.getAcctInvFan(), userDetails.getAcctInvFanType(), "",
							userDetails.getUserLoginCd());
			if (!CollectionUtils.isEmpty(aifAlternateBill)) {
				responseMap.put(ApplicationConstant.AIF_ALTERNATE_BILLER_PERIOD_GROUP, aifAlternateBill);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.GROUP_NOT_SELECTED);
		}
		return responseMap;
	}

	@Override
	public Map<Object, Object> getAIFValidCheck(UserDetails userDetails, Map<Object, Object> responseMap) {
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		if (StringUtils.isNotEmpty(selectedGroups)) {
			List<Object[]> aifAIFValidCheck = aIFAlternateBillPeriodGroupRepository
					.getAIFValidCheck(userDetails.getAcctInvFan(), userDetails.getAcctInvFanType(), "");
			if (!CollectionUtils.isEmpty(aifAIFValidCheck)) {
				responseMap.put(ApplicationConstant.AIFVALIDCHECK, aifAIFValidCheck);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.GROUP_NOT_SELECTED);
		}
		return responseMap;
	}

	@Override
	public Map<Object, Object> getCommitmentHistory(UserDetails userDetails, Map<Object, Object> responseMap) {
		String selectedAccountNumbers = CommonUtils
				.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());
		String originatingSystems = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());

		if (StringUtils.isNotEmpty(selectedAccountNumbers) && StringUtils.isNotEmpty(originatingSystems)) {
			List<CommitmentHistory> commitmentHistoryList = commitmentHistoryRepository
					.getCommitmentHistory(selectedAccountNumbers, originatingSystems, userDetails.getUserLoginCd());
			responseMap.put(ApplicationConstant.COMMITMENT_HISTORY, commitmentHistoryList);

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "Please select the necessary inputs");
		}

		return responseMap;
	}

	@Override
	public Map<Object, Object> closeCommitmentHistory(UserDetails userDetails, Map<Object, Object> responseMap) {
		String selectedAccountNumbers = CommonUtils
				.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());
		String originatingSystems = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		String selectedAmounts = CommonUtils.getListToCommaSeparatedString(userDetails.getSelectedAmount());
		String selectedDueDate = CommonUtils.getListToCommaSeparatedString(userDetails.getSelectedDueDate());
		if (StringUtils.isNotEmpty(selectedAccountNumbers) && StringUtils.isNotEmpty(originatingSystems)
				&& StringUtils.isNotEmpty(selectedAmounts) && StringUtils.isNotEmpty(selectedDueDate)) {
			commitmentHistoryRepository.closeCommitmentHistory(selectedAccountNumbers, originatingSystems,
					selectedDueDate, selectedAmounts, userDetails.getUserLoginCd(), "Closed");
			responseMap.put("msg", "success");

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "Please select the necessary inputs");
		}
		return responseMap;
	}

	// arms_custqry_AIF_collection_userid
	@Override
	public Map<Object, Object> getAIFCollectionUserId(UserDetails userDetails, Map<Object, Object> responseMap) {
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		if (StringUtils.isNotEmpty(selectedGroups)) {
			List<Object[]> aIFCollectionUserId = aIFAlternateBillPeriodGroupRepository
					.getAIFCollectionUserId(userDetails.getAcctInvFan(), userDetails.getAcctInvFanType(), "");
			if (!CollectionUtils.isEmpty(aIFCollectionUserId)) {
				responseMap.put(ApplicationConstant.AIFCOLLECTIONUSERID, aIFCollectionUserId);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.GROUP_NOT_SELECTED);
		}
		return responseMap;
	}

	@Override
	public Map<Object, Object> getAIFCustomerDetails(Map<Object, Object> responseMap, UserDetails userDetails) {
		List<CustomerAgedDetails> agedDetail =new ArrayList<>();
		if (StringUtils.isEmpty(userDetails.getCustomerGrpCd())) {
			responseMap = getAIFCustomerInfo(userDetails, responseMap);
			if (responseMap.isEmpty()) {
				responseMap = getAIFCustomerValidate(responseMap, userDetails);
				return responseMap;
			}
		}
		String customerGrpCd = "";
		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			customerGrpCd = userDetails.getCustomerGrpCd();
		} else if (!responseMap.isEmpty() && responseMap.containsKey(ApplicationConstant.AIF_CUSTOMER_INFO)) {
			@SuppressWarnings("unchecked")
			List<CustomerInfo> customerInfoList = (List<CustomerInfo>) responseMap.get(ApplicationConstant.AIF_CUSTOMER_INFO);
			if (!CollectionUtils.isEmpty(customerInfoList) && customerInfoList.size()==1) {
				customerGrpCd = customerInfoList.get(0).getCustomerGrpCd().trim();
			}
		}
		if (StringUtils.isNotEmpty(customerGrpCd)) {
			String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
			String originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
			String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
			String exclusionClass = "";
			String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
			Integer rollUp=userDetails.getRollUp()!=null?userDetails.getRollUp():0;
			if (!userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
				exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
			}
			 agedDetail = customerAgedDetailsRepository.getCustomerAgedDetails(
					userDetails.getProfileName(), userDetails.getProfileType(), "", "", ApplicationConstant.ALL_CUSTOMERS, selectedGroups,
					customerGrpCd, userDetails.getUserLoginCd().trim(), userDetails.getBillingPeriod().trim(),
					statusClause, userDetails.getExclusions().trim(), exclusionClass, segment, originatingSystem, userDetails.getAcctInvFan(),
					rollUp.toString(),userDetails.getAcctInvFanType());
			
		}
		responseMap.put(ApplicationConstant.AGED_DETAIL, agedDetail);
		commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(),
				ApplicationConstant.AGED_DETAIL, responseMap);
		return responseMap;
	}

	private Map<Object, Object> getAIFCustomerValidate(Map<Object, Object> responseMap, UserDetails userDetails) {
		responseMap = getAIFAlternateBillperiodGroup(userDetails, responseMap);
		if (responseMap.isEmpty()) {
			responseMap = getAIFValidCheck(userDetails, responseMap);
			if (responseMap.isEmpty()) {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "Please Enter Valid Account Number !");
			} else {

				responseMap = getAIFCollectionUserId(userDetails, responseMap);
				if (responseMap.isEmpty()) {
					responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "you do not have access to view this "
							+ userDetails.getAcctInvFanType() + " is unassigned !");
				} else {
					responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "you do not have access to view this"
							+ userDetails.getAcctInvFanType() + " . Please refer to :");
				}
			}
		}
		return responseMap;
	}
}

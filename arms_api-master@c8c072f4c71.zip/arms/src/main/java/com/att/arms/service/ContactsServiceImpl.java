package com.att.arms.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.AccountDisplay;
import com.att.arms.entity.AccountSearch;
import com.att.arms.entity.Contacts;
import com.att.arms.entity.ContactsDisplay;
import com.att.arms.entity.FetchContact;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.AccountDisplayRepository;
import com.att.arms.repo.AccountSearchRepository;
import com.att.arms.repo.ContactsDisplayRepository;
import com.att.arms.repo.ContactsRepository;
import com.att.arms.repo.FetchContactRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class ContactsServiceImpl implements ContactsService {

	@Autowired
	ContactsRepository contactsRepository;
	@Autowired
	ContactsDisplayRepository contactsDisplayRepository;
	@Autowired
	AccountSearchRepository accountSearchRepository;
	@Autowired
	AccountDisplayRepository accountDisplayRepository;
	@Autowired
	FetchContactRepository fetchContactRepository;

	@Override
	public boolean validateQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> getSearchContacts(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<Contacts> searchContact = contactsRepository.getSearchContacts(userDetails.getFirstName(),
				userDetails.getLastName(), userDetails.getPhoneNumber(), userDetails.getEmail(),
				userDetails.getHeadquaters(), userDetails.getUserLoginCd());
		responseMap.put(ApplicationConstant.SEARCH_CONTACTS, searchContact);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getDisplayContacts(UserDetails userDetails, Map<Object, Object> responseMap) {
		String originatingSystem = "";
		String customerGrpCdList = CommonUtils.getListToCommaSeparatedString(userDetails.getCustomerGrpCdList());
		String accountList = CommonUtils.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());
		String fan = CommonUtils.getListToCommaSeparatedString(userDetails.getFan());
		String svid = CommonUtils.getListToCommaSeparatedString(userDetails.getSvid());

		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		}
		List<ContactsDisplay> displayContact = contactsDisplayRepository.getDisplayContacts(accountList, fan, svid,
				customerGrpCdList, originatingSystem, userDetails.getUserLoginCd(), userDetails.getAcctLvl(),
				userDetails.getEmaor());
		responseMap.put(ApplicationConstant.DISPLAY_CONTACTS, displayContact);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getSearchAccount(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<AccountSearch> searchAccount = accountSearchRepository.getSearchAccount(userDetails.getCustomerName(),
				userDetails.getAcctInvFan(), userDetails.getServiceId(), userDetails.getAccountNumber(),
				userDetails.getAcntNoteOrgSys(), userDetails.getEmaor(), userDetails.getAccountDetailIndia(),
				userDetails.getUserLoginCd());
		responseMap.put(ApplicationConstant.SEARCH_ACCOUNT, searchAccount);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getContactAssign(UserDetails userDetails, Map<Object, Object> responseMap) {
		String originatingSystem = "";
		String customerGroupList = CommonUtils.getListToCommaSeparatedString(userDetails.getCustomerGroupList());
		String contactIdList = CommonUtils.getListToCommaSeparatedString(userDetails.getContactsIdLst());
		String fan = CommonUtils.getListToCommaSeparatedString(userDetails.getFan());
		String svid = CommonUtils.getListToCommaSeparatedString(userDetails.getSvid());
		String accountNumbers = CommonUtils.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());

		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		}
		List<Object[]> contactAssign = accountSearchRepository.getContactAssign(contactIdList, accountNumbers, fan,
				svid, customerGroupList, originatingSystem, userDetails.getUserLoginCd());
		responseMap.put(ApplicationConstant.CONTACT_ASSIGN, contactAssign);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getContactUnAssign(UserDetails userDetails, Map<Object, Object> responseMap) {
		String originatingSystem = "";
		String customerGroupList = CommonUtils.getListToCommaSeparatedString(userDetails.getCustomerGroupList());
		String contactIdList = CommonUtils.getListToCommaSeparatedString(userDetails.getContactsIdLst());
		String fan = CommonUtils.getListToCommaSeparatedString(userDetails.getFan());
		String svid = CommonUtils.getListToCommaSeparatedString(userDetails.getSvid());
		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		}
		List<Object[]> contactUnAssign = accountSearchRepository.getContactUnAssign(contactIdList, contactIdList, fan,
				svid, customerGroupList, originatingSystem, userDetails.getUserLoginCd());
		responseMap.put(ApplicationConstant.CONTACT_UN_ASSIGN, contactUnAssign);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getAccountDisplay(UserDetails userDetails, Map<Object, Object> responseMap) {
		String contactIdList = "";
		if (!CollectionUtils.isEmpty(userDetails.getContactsIdLst())) {
			contactIdList = CommonUtils.getListToCommaSeparatedString(userDetails.getContactsIdLst());
		}
		List<AccountDisplay> accountDisplay = accountDisplayRepository.getSearchAccount(contactIdList,
				userDetails.getUserLoginCd(), userDetails.getEmaor());
		responseMap.put(ApplicationConstant.ACCOUNT_DISPLAY, accountDisplay);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getFetchContact(UserDetails userDetails, Map<Object, Object> responseMap) {

		String contactIdList = CommonUtils.getListToCommaSeparatedString(userDetails.getContactsIdLst());
		String fan = CommonUtils.getListToCommaSeparatedString(userDetails.getFan());
		String svid = CommonUtils.getListToCommaSeparatedString(userDetails.getSvid());

		List<FetchContact> accountDisplay = fetchContactRepository.getFetchContact(userDetails.getUserLoginCd(),
				contactIdList, userDetails.getConfirmNum(), userDetails.getAccountNumber(), fan, svid,
				userDetails.getCustomerGrpCd(), userDetails.getAcntNoteOrgSys());

		responseMap.put(ApplicationConstant.FETCH_CONTACT, accountDisplay);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getEditContact(UserDetails userDetails, Map<Object, Object> responseMap) {
		String customerGroupList = CommonUtils.getListToCommaSeparatedString(userDetails.getCustomerGroupList());
		fetchContactRepository.getEditContact(userDetails.getFirstName(), userDetails.getLastName(),
				userDetails.getAddress(), userDetails.getCity(), userDetails.getState(), userDetails.getZip(),
				userDetails.getTitle(), userDetails.getPhoneNumber(), userDetails.getExtension(),
				userDetails.getPhoneNumber2(), userDetails.getExtension2(), userDetails.getFaxNumber(),
				userDetails.getEmail(), userDetails.getEmail2(), userDetails.getNotes(), userDetails.getContactid(),
				userDetails.getHeadquaters(), userDetails.getUserLoginCd(), userDetails.getEmaor(),
				userDetails.getEmaorPrimary(), userDetails.getEmaorEffDate(), userDetails.getColumnid(),
				userDetails.getAccountNumber(), userDetails.getAcctInvFan(), userDetails.getServiceId(),
				customerGroupList, userDetails.getAcntNoteOrgSys());

		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getdeleteContact(UserDetails userDetails, Map<Object, Object> responseMap) {
		fetchContactRepository.getDeleteContact(userDetails.getUserLoginCd(), userDetails.getContactid());
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

}

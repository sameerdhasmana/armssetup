package com.att.arms.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.MaintenanceContactDetails;

@Transactional
public interface TransferRepository extends JpaRepository<MaintenanceContactDetails, String> {

	@Modifying
	@Query(value = "exec arms_transfer_usernotes :userLoginCdFrom ,:userLoginCdTo", nativeQuery = true)
	public void transferNotes(@Param("userLoginCdFrom") String userLoginCdFrom,
			 @Param("userLoginCdTo") String userLoginCdTo);
	
	@Query(value = "exec arms_transfer_getduplicatewatch :customerGrpCdFrom ,:customerGrpCdTo", nativeQuery = true)
	public Boolean getDuplicateWatch(@Param("customerGrpCdFrom") String customerGrpCdFrom,
			 @Param("customerGrpCdTo") String customerGrpCdTo);

	@Modifying
	@Query(value = "exec arms_transfer_customer :customerGrpCdFrom ,:customerGrpCdTo", nativeQuery = true)
	public void transferCustomer(@Param("customerGrpCdFrom") String customerGrpCdFrom,
			 @Param("customerGrpCdTo") String customerGrpCdTo);

}

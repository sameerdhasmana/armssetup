package com.att.arms.service;

import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface EmailService {

	boolean validateQueryRequest(UserDetails userDetails);
	boolean validateMailRequest(UserDetails userDetails);
	boolean validateMailUpdateRequest(UserDetails userDetails);

	Map<Object, Object> emailTmpltList(Map<Object, Object> responseMap);
	Map<Object, Object> emailTmpltName(UserDetails userDetails, Map<Object, Object> responseMap);
	Map<Object, Object> sendEmail(UserDetails userDetails, Map<Object, Object> responseMap);
	Map<Object, Object> accountEmailupdate(UserDetails userDetails, Map<Object, Object> responseMap);
	Map<Object, Object> mailEligibleUpdate(UserDetails userDetails, Map<Object, Object> responseMap);
	boolean mailEligibleUpdate(UserDetails userDetails);
}

package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.Data;

@Entity
@IdClass(BreakdownDetails.BreakdownDetailsId.class)
@Data
public class BreakdownDetails {

	@Id
	@Column(name="billing_period")
	private String billingPeriod;
	@Id
	private Double occ;
	@Id
	private Double usge;
	@Id
	private Double lpc;
	@Id
	private Double rc;
	@Id
	private Double nrc;
	@Id
	private Double taxes;
	@Id
	private Double other;

	@SuppressWarnings("serial")
	@Data
	public static class BreakdownDetailsId implements Serializable {

		private String billingPeriod;
		private Double occ;
		private Double usge;
		private Double lpc;
		private Double rc;
		private Double nrc;
		private Double taxes;
		private Double other;
	}
}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.MaintenanceFetchAccountAPSubGroup;

@Transactional
public interface MaintenanceFetchAccountAPSubGroupRepository
		extends JpaRepository<MaintenanceFetchAccountAPSubGroup, String> {

	@Query(value = "exec arms_maintenance_fetch_account_ap_sub_group_maintenance_v22 :customerLoginCd,"
			+ ":billingPeriod,:userLoginCd,:group,:region,:strSort,:strWhere", nativeQuery = true)
	public List<MaintenanceFetchAccountAPSubGroup> getMaintenanceAccountApSubGroup(@Param("customerLoginCd") String customerLoginCd,
			@Param("billingPeriod") String billingPeriod,@Param("userLoginCd") String userLoginCd,@Param("group") String group,
			@Param("region") String region,@Param("strSort") String strSort,@Param("strWhere") String strWhere);

}

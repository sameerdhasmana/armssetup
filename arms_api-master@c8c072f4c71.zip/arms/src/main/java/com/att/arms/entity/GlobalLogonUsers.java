package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class GlobalLogonUsers {
	@Id
	@JsonProperty("user_login_cd")
	@Column(name="user_login_cd")
	private String userLoginCd;
	private String firstname;
	private String lastname;
	private String userstatus;
	private Integer userrole;
	private String group;
	private String region;
	private String sbclocationcode;

	
}

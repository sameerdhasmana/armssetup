package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@IdClass(SubActivity.SubActivityId.class)
@Entity
@Data
public class SubActivity {

	@Id
	@JsonProperty("sub_activity_cd")
	@Column(name = "sub_activity_cd")
	private String subActivityCd;
	@Id
	@JsonProperty("sub_activity_short_description")
	@Column(name = "sub_activity_short_description")
	private String subActivityShortDescription;

	@Data
	public static class SubActivityId implements Serializable {
		
		private static final long serialVersionUID = 1L;
		private String subActivityCd;
		private String subActivityShortDescription;

	}
}

package com.att.arms.service;

import java.util.List;
import java.util.Map;

import com.att.arms.entity.RequestModel;

public interface ManagementService {

	boolean validateSearchByAccountQueryRequest(RequestModel requestModel);

	Map<Object, Object> searchByAccount(String userLoginCd, String accountNumber, Map<Object, Object> responseMap);

	Map<Object, Object> renderSearchByCustomer(String userLoginCd, Map<Object, Object> responseMap);

	Map<Object, Object> searchByCustomer(RequestModel requestModel, Map<Object, Object> responseMap);

	Map<Object, Object> populateSegment(List<String> groupSelected, Map<Object, Object> responseMap);

	boolean validatePaymentTermUpdateRequest(RequestModel requestModel);

	Map<Object, Object> paymentTermUpdate(RequestModel requestModel, Map<Object, Object> responseMap);

	Map<Object, Object> getAllManagers(Map<Object, Object> responseMap);

	Map<Object, Object> outstandingBringUpReport(String managerLoginCd, Map<Object, Object> responseMap);

	Map<Object, Object> openFlagActivityReport(String managerLoginCd, Map<Object, Object> responseMap);

	boolean validateSearchByCustomerRequest(RequestModel requestModel);

	Map<Object, Object> notesActivityReport(Map<Object, Object> responseMap);

	Map<Object, Object> populateSubActivityDesc(Map<Object, Object> responseMap);

	Map<Object, Object> populateH1UidDetails(String managerLoginCd, Map<Object, Object> responseMap);

	boolean validateNotesActivityReportRequest(RequestModel requestModel);

	Map<Object, Object> generateNotesActivityReport(RequestModel requestModel, Map<Object, Object> responseMap);

	Map<Object, Object> generateNotesActivityManagerReport(RequestModel requestModel, Map<Object, Object> responseMap);

}

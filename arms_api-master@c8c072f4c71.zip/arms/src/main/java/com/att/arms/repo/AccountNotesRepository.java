package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.AccountNotes;

@Transactional
public interface AccountNotesRepository extends JpaRepository<AccountNotes, String> {

	@Query(value = "Exec arms_custqry_account_note_select_v22 :account_number, :originating_system", nativeQuery = true)
	public List<AccountNotes> getAccountNotes(@Param("account_number") String accountNumber,
			@Param("originating_system") String originatingSystem);

	@Query(value = "Exec arms_account_notes_talkedto_cb :account_number, :originating_system", nativeQuery = true)
	public List<Object[]> getAccountNotesContactInfo(@Param("account_number") String accountNumber,
			@Param("originating_system") String originatingSystem);

	@Modifying
	@Query(value = "Exec arms_custqry_notes_details_chkresolved :note_id, :resolved,:notes", nativeQuery = true)
	public void resolveAccountNotes(@Param("note_id") Integer noteId, @Param("resolved") Integer resolved,
			@Param("notes") String notes);

	@Query(value = "EXEC arms_hotnote_view_v19 :account_number,:hotNoteText,:userLoginCd,:originating_system", nativeQuery = true)
	public List<Object[]> getHotNotes(@Param("account_number") String accountNumber,
			@Param("hotNoteText") String hotNoteText, @Param("userLoginCd") String userLoginCd,
			@Param("originating_system") String originatingSystem);

	@Modifying
	@Query(value = "Exec arms_account_notes_delete_v22 :note_id,:userLoginCd", nativeQuery = true)
	public void deleteAccountNotes(@Param("note_id") String noteId, @Param("userLoginCd") String userLoginCd);

	@Modifying
	@Query(value = "Exec arms_custqry_account_note_v22 :modeType,:billingPeriod,:account_number, :originating_system, :noteId,:talkedTo"
			+ ",:notes,:userLoginCd,:next_call_back_dt,:commitmentAmt,:resolved,:activityCode,:subActivity,:copy_to_biller,:biller_note_perm"
			+ ",:call_type,:payment_method,:cust_phone_num,:cust_phone_num_ext,:cust_email,:attuid,:bring_up_type,:send_to_adapt,:contestedAmt,"
			+ ":rcCd,:nxtactCd,:commitmentDate,:my_bring_up", nativeQuery = true)
	public void saveAccountNotes(@Param("modeType") String modeType, @Param("billingPeriod") String billingPeriod,
			@Param("account_number") String accountNumber, @Param("originating_system") String originatingSystem,
			@Param("noteId") Integer noteId, @Param("talkedTo") String talkedTo, @Param("notes") String notes,
			@Param("userLoginCd") String userLoginCd, @Param("next_call_back_dt") String nextCallBackDt,
			@Param("commitmentAmt") Double commitmentAmt, @Param("resolved") Integer resolved,
			@Param("activityCode") String activityCode, @Param("subActivity") String subActivity,
			@Param("copy_to_biller") Integer copyToBiller, @Param("biller_note_perm") Integer billerNotePerm,
			@Param("call_type") String callType, @Param("payment_method") String paymentMethod,
			@Param("cust_phone_num") String custPhoneNum, @Param("cust_phone_num_ext") String custPhoneNumExt,
			@Param("cust_email") String custEmail, @Param("attuid") String attuid,
			@Param("bring_up_type") String bringUpType, @Param("send_to_adapt") Integer sendToAdapt,
			@Param("contestedAmt") Double contestedAmt, @Param("rcCd") String rcCd, @Param("nxtactCd") String nxtactCd,
			@Param("commitmentDate") String commitmentDate, @Param("my_bring_up") Integer myBringUp);

	@Modifying
	@Query(value = "EXEC arms_hotnote_updt_v19 :account_number,:hotNoteText,:userLoginCd,:originating_system", nativeQuery = true)
	public void updateHotNotes(@Param("account_number") String accountNumber, @Param("hotNoteText") String hotNoteText,
			@Param("userLoginCd") String userLoginCd, @Param("originating_system") String originatingSystem);

	@Modifying
	@Query(value = "EXEC arms_acct_contact_assign_v19 :account_number,:note_id,:userLoginCd,:sys_process_name,:originating_system", nativeQuery = true)
	public void assignAccountContact(@Param("account_number") String accountNumber, @Param("note_id") Integer noteId,
			@Param("userLoginCd") String userLoginCd, @Param("sys_process_name") String sysProcessName,
			@Param("originating_system") String originatingSystem);

	@Modifying
	@Query(value = "EXEC arms_acct_contact_add_v19 :customer_grp_cd,:first_nm,:last_nm,:addr,:city,:state,:zip,:title,:phone_number,:extension,:fax_number,"
			+ ":email,:notes,:phone_number2,:email2,:emaor,:emaor_primary,:emaor_eff_dt,:account_number,:originating_system,:userLoginCd", nativeQuery = true)
	public void addAccountContact(@Param("customer_grp_cd") String customerGrpCd, @Param("first_nm") String firstNm,
			@Param("last_nm") String lastNm, @Param("addr") String addr, @Param("city") String city,
			@Param("state") String state, @Param("zip") String zip, @Param("title") String title,
			@Param("phone_number") String phoneNumber, @Param("extension") String extension,
			@Param("fax_number") String faxNumber, @Param("email") String email, @Param("notes") String notes,
			@Param("phone_number2") String phoneNumber2, @Param("email2") String email2, @Param("emaor") String emaor,
			@Param("emaor_primary") String emaorPrimary, @Param("emaor_eff_dt") String emaorEffDt,
			@Param("account_number") String accountNumber, @Param("originating_system") String originatingSystem,
			@Param("userLoginCd") String userLoginCd);

	@Modifying
	@Query(value = "EXEC arms_acct_contact_modify_v19 :customer_grp_cd,:sequence,:first_nm,:last_nm,:addr,:city,:state,:zip,:title,:phone_number,:extension,:fax_number,"
			+ ":email,:notes,:userLoginCd,:sys_process_name,:phone_number2,:email2,:emaor,:emaor_primary,:emaor_eff_dt,:account_number,:originating_system", nativeQuery = true)
	public void updateAccountContact(@Param("customer_grp_cd") String customerGrpCd,
			@Param("sequence") Integer sequence, @Param("first_nm") String firstNm, @Param("last_nm") String lastNm,
			@Param("addr") String addr, @Param("city") String city, @Param("state") String state,
			@Param("zip") String zip, @Param("title") String title, @Param("phone_number") String phoneNumber,
			@Param("extension") String extension, @Param("fax_number") String faxNumber, @Param("email") String email,
			@Param("notes") String notes, @Param("userLoginCd") String userLoginCd,
			@Param("sys_process_name") String sysProcessName, @Param("phone_number2") String phoneNumber2,
			@Param("email2") String email2, @Param("emaor") String emaor, @Param("emaor_primary") String emaorPrimary,
			@Param("emaor_eff_dt") String emaorEffDt, @Param("account_number") String accountNumber,
			@Param("originating_system") String originatingSystem);

	@Query(value = "exec arms_ntstmplt_view_v20 :userLoginCd,:templateName,:templateType", nativeQuery = true)
	public String getAccountNoteText(@Param("userLoginCd") String userLoginCd,
			@Param("templateName") String templateName, @Param("templateType") String templateType);

	@Modifying
	@Query(value = "EXEC ARMS_MAINTENANCE_MODIFY_ACCOUNT_AP_SUB_GROUP_V22 :account_number,:ap_sub_grp_nm,:userLoginCd,:sys_process_name,:originating_system", nativeQuery = true)
	public void saveAPSubGroup(@Param("account_number") String accountNumber, @Param("ap_sub_grp_nm") String apSubGrpNm,
			@Param("userLoginCd") String userLoginCd, @Param("sys_process_name") String sysProcessName,
			@Param("originating_system") String originatingSystem);

	@Modifying
	@Query(value = "Exec arms_acct_contact_delete_v19 :customerGrpCd,:sequence,:userLoginCd,:sysProcessName,:contactsId,:accountNumber,:originatingSystem", nativeQuery = true)
	public void deleteAccountContacts(@Param("customerGrpCd") String customerGrpCd, @Param("sequence") Integer sequence,
			@Param("userLoginCd") String userLoginCd, @Param("sysProcessName") String sysProcessName,
			@Param("contactsId") String contactsId, @Param("accountNumber") String accountNumber,
			@Param("originatingSystem") String originatingSystem);
}

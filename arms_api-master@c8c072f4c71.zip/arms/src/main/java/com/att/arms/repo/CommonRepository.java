package com.att.arms.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.AccountNotes;

@Transactional
public interface CommonRepository extends JpaRepository<AccountNotes, String> {

	@Query(value = "exec arms_usrpref_view_v22 :userLoginCd,:moduleName", nativeQuery = true)
	public String getHeaderparameters(@Param("userLoginCd") String userLoginCd,@Param("moduleName") String moduleName);
}

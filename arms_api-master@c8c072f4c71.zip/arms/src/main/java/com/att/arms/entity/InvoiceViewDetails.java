package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class InvoiceViewDetails {

	@Id
	@JsonProperty("invoice_number")
	@Column(name="invoice_number")
	private String invoiceNumber;
	@JsonProperty("billing_period")
	@Column(name="billing_period")
	private String billingPeriod;
	private String region;
	private String macna;
	private String acna;
	private String seg;
	private String state;
	@JsonProperty("account_number")
	@Column(name="account_number")
	private String accountNumber;
	private String status;
	@JsonProperty("current_billing_amt")
	@Column(name="current_billing_amt")
	private Double currentBillingAmt;
	@JsonProperty("current_balance_amt")
	@Column(name="current_balance_amt")
	private Double currentBalanceAmt;
	@JsonProperty("amt_30")
	@Column(name="amt_30")
	private Double amt30;
	@JsonProperty("amt_30_days")
	@Column(name="amt_30_days")
	private Double amt30Days;
	@JsonProperty("amt_60_days")
	@Column(name="amt_60_days")
	private Double amt60Days;
	@JsonProperty("amt_90_days")
	@Column(name="amt_90_days")
	private Double amt90Days;
	@JsonProperty("amt_120_days")
	@Column(name="amt_120_days")
	private Double amt120Days;
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	private String customer;
	@JsonProperty("class_desc")
	@Column(name="class_desc")
	private String classDesc;
	private Integer excluded;
	@JsonProperty("bill_date")
	@Column(name="bill_date")
	private String billDate;
	@JsonProperty("originating_system")
	@Column(name="originating_system")
	private String originatingSystem;
	@JsonProperty("bill_name")
	@Column(name="bill_name")
	private String billName;
	private String zbu;

}

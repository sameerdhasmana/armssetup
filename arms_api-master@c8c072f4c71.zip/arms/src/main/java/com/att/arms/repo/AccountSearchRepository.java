package com.att.arms.repo;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.att.arms.entity.AccountSearch;

@Transactional
public interface AccountSearchRepository extends JpaRepository<AccountSearch, String> {

	@Query(value = "Exec arms_vc_accts_search_v22 :cust_name, :fan, :svid, :acct_nbr, :org_sys, :maor_ind, :acct_dtls_ind, :strlogincd", nativeQuery = true)
	public List<AccountSearch> getSearchAccount(@Param("cust_name") String custName, @Param("fan") String fan,
			@Param("svid") String svid, @Param("acct_nbr") String acctNbr, @Param("org_sys") String orgSys,
			@Param("maor_ind") String maorInd, @Param("acct_dtls_ind") String acctDtlsInd,
			@Param("strlogincd") String strlogincd);

	@Query(value = "Exec arms_vc_contacts_assign_v19 :contacts_id_lst, :acct_nbr, :fan, :svid, :custgrpcd, :origsys, :user_login_cd", nativeQuery = true)
	public List<Object[]> getContactAssign(@Param("contacts_id_lst") String contactsIdLst,
			@Param("acct_nbr") String acctNbr, @Param("fan") String fan, @Param("svid") String svid,
			@Param("custgrpcd") String custgrpcd, @Param("origsys") String origsys,
			@Param("user_login_cd") String userLoginCd);

	@Query(value = "Exec arms_vc_accts_assign_v19 :contacts_id_lst, :acct_nbr, :fan, :svid, :custgrpcd, :origsys, :user_login_cd", nativeQuery = true)
	public List<Object[]> getContactUnAssign(@Param("contacts_id_lst") String contactsIdLst,
			@Param("acct_nbr") String acctNbr, @Param("fan") String fan, @Param("svid") String svid,
			@Param("custgrpcd") String custgrpcd, @Param("origsys") String origsys,
			@Param("user_login_cd") String userLoginCd);
}

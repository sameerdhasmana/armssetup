package com.att.arms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.entity.CustomerAgedDetails;
import com.att.arms.repo.CustomerAgedDetailsRepository;

@Service
public class AgedDetailsServiceImpl implements AgedDetailsService {

	@Autowired
	CustomerAgedDetailsRepository customerAgedDetailsRepository;

	@Override
	public List<CustomerAgedDetails> getCustomerAgedDetails(String profileName, String profileType,
			String strStateClause, String strOriginatingCompanyCD, String strQueryType, String strGroup,
			String strCustomerGrpCd, String strUserLoginCode, String strBillingPeriod, String strStatusClause,
			String strAccountStatusClause, String strClassClause, String strSegmentClause,
			String strOriginatingSystemClause, String myacctNbr, String rollupFlag, String acctInvFlag) {
		return this.customerAgedDetailsRepository.getCustomerAgedDetails(profileName, profileType, strStateClause,
				strOriginatingCompanyCD, strQueryType, strGroup, strCustomerGrpCd, strUserLoginCode, strBillingPeriod,
				strStatusClause, strAccountStatusClause, strClassClause, strSegmentClause, strOriginatingSystemClause,
				myacctNbr, rollupFlag, acctInvFlag);
	}

}

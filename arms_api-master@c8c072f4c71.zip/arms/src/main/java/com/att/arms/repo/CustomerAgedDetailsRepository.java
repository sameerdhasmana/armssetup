package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerAgedDetails;

@Transactional
public interface CustomerAgedDetailsRepository extends JpaRepository<CustomerAgedDetails, String> {

	@Query(value = "Exec ARMS_AgedDetailSQLForCustomerLegal_v22 :profile_name, :profile_type, :strStateClause, "
			+ ":strOriginatingCompanyCD, :strQueryType, :strGroup, :strCustomerGrpCd, :strUserLoginCode,"
			+ " :strBillingPeriod, :strStatusClause, :strAccountStatusClause, :strClassClause, :strSegmentClause,"
			+ " :strOriginatingSystemClause, :myacct_nbr, :rollup_flag, :AcctInv_flag", nativeQuery = true)
	public List<CustomerAgedDetails> getCustomerAgedDetails(@Param("profile_name") String profileName,
			@Param("profile_type") String profileType, @Param("strStateClause") String strStateClause,
			@Param("strOriginatingCompanyCD") String strOriginatingCompanyCD,
			@Param("strQueryType") String strQueryType, @Param("strGroup") String strGroup,
			@Param("strCustomerGrpCd") String strCustomerGrpCd, @Param("strUserLoginCode") String strUserLoginCode,
			@Param("strBillingPeriod") String strBillingPeriod, @Param("strStatusClause") String strStatusClause,
			@Param("strAccountStatusClause") String strAccountStatusClause,
			@Param("strClassClause") String strClassClause, @Param("strSegmentClause") String strSegmentClause,
			@Param("strOriginatingSystemClause") String strOriginatingSystemClause,
			@Param("myacct_nbr") String myacctNbr, @Param("rollup_flag") String rollupFlag,
			@Param("AcctInv_flag") String acctInvFlag);

	@Query(value = "Exec ARMS_AgedDetailSQLForACNAQuery_v22 :profile_name, :profile_type, :strStateClause, "
			+ ":strOriginatingCompanyCD, :strGroup, :strCustomerGrpCd, :strUserLoginCode,"
			+ " :strBillingPeriod, :strStatusClause, :strAccountStatusClause, :strClassClause, :strSegmentClause,"
			+ " :strOriginatingSystemClause, :strACNACriteriaType,:strACNASubType,:strACNAValue,:strChildTieCd, :rollup_flag", nativeQuery = true)
	public List<CustomerAgedDetails> getACNAAgedDetails(@Param("profile_name") String profileName,
			@Param("profile_type") String profileType, @Param("strStateClause") String strStateClause,
			@Param("strOriginatingCompanyCD") String strOriginatingCompanyCD, @Param("strGroup") String strGroup,
			@Param("strCustomerGrpCd") String strCustomerGrpCd, @Param("strUserLoginCode") String strUserLoginCode,
			@Param("strBillingPeriod") String strBillingPeriod, @Param("strStatusClause") String strStatusClause,
			@Param("strAccountStatusClause") String strAccountStatusClause,
			@Param("strClassClause") String strClassClause, @Param("strSegmentClause") String strSegmentClause,
			@Param("strOriginatingSystemClause") String strOriginatingSystemClause,
			@Param("strACNACriteriaType") String strACNACriteriaType, @Param("strACNASubType") String strACNASubType,
			@Param("strACNAValue") String strACNAValue, @Param("strChildTieCd") String strChildTieCd,
			@Param("rollup_flag") Integer rollupFlag);

	@Query(value = "Exec ARMS_AgedDetailSQLForBillName_v22 :profile_name, :profile_type, :strStateClause, "
			+ ":strOriginatingCompanyCD, :strGroup, :strCustomerGrpCd, :strUserLoginCode,"
			+ " :strBillingPeriod, :strStatusClause, :strAccountStatusClause, :strClassClause, :strSegmentClause,"
			+ " :strOriginatingSystemClause, :strBillName", nativeQuery = true)
	public List<CustomerAgedDetails> getBillNameAgedDetails(@Param("profile_name") String profileName,
			@Param("profile_type") String profileType, @Param("strStateClause") String strStateClause,
			@Param("strOriginatingCompanyCD") String strOriginatingCompanyCD, @Param("strGroup") String strGroup,
			@Param("strCustomerGrpCd") String strCustomerGrpCd, @Param("strUserLoginCode") String strUserLoginCode,
			@Param("strBillingPeriod") String strBillingPeriod, @Param("strStatusClause") String strStatusClause,
			@Param("strAccountStatusClause") String strAccountStatusClause,
			@Param("strClassClause") String strClassClause, @Param("strSegmentClause") String strSegmentClause,
			@Param("strOriginatingSystemClause") String strOriginatingSystemClause,
			@Param("strBillName") String strBillName);


}

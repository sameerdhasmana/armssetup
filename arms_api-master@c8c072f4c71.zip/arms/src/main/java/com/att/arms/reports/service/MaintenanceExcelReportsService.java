package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.util.Map;

import com.itextpdf.text.DocumentException;

public interface MaintenanceExcelReportsService {
	
	public ByteArrayInputStream createExcelWithDbData(String billingPeriod, String originatingSystem,
			String reportStatus, Map<Object, Object> responseMap) throws DocumentException,FileNotFoundException;
}

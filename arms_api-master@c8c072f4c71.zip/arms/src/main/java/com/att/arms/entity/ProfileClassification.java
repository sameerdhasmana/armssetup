package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.Data;

@Entity
@IdClass(ProfileClassification.ProfileClassificationId.class)
@Data
public class ProfileClassification {

	@Id
	private String profileType;
	@Id
	private String profileName;
	private String defaultInd;

	@SuppressWarnings("serial")
	@Data
	public static class ProfileClassificationId implements Serializable {

		private String profileType;
		private String profileName;

	}

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.UserRole;

@Transactional
public interface UserRoleRepository extends JpaRepository<UserRole, String> {

	@Query(value = "exec arms_user_task_list_v22 :userLoginCd", nativeQuery = true)
	public List<UserRole> getUserRole(@Param("userLoginCd") String userLoginCd);

}

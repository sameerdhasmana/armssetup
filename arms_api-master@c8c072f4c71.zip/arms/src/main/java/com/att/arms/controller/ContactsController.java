package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.ContactsService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class ContactsController {

	@Autowired
	ContactsService contactsService;

	@PostMapping("searchContacts")
	public ResponseEntity<Object> getSearchContacts(@RequestBody UserDetails userDetails) {
		boolean response = this.contactsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.contactsService.getSearchContacts(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("displayContacts")
	public ResponseEntity<Object> getDisplayContacts(@RequestBody UserDetails userDetails) {
		boolean response = this.contactsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.contactsService.getDisplayContacts(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("searchAccount")
	public ResponseEntity<Object> getSearchAccount(@RequestBody UserDetails userDetails) {
		boolean response = this.contactsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.contactsService.getSearchAccount(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}

	@PostMapping("contactAssign")
	public ResponseEntity<Object> getContactAssign(@RequestBody UserDetails userDetails) {
		boolean response = this.contactsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.contactsService.getContactAssign(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("contactUnAssign")
	public ResponseEntity<Object> getContactUnAssign(@RequestBody UserDetails userDetails) {
		boolean response = this.contactsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.contactsService.getContactUnAssign(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("accountDisplay")
	public ResponseEntity<Object> getAccountDisplay(@RequestBody UserDetails userDetails) {
		boolean response = this.contactsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.contactsService.getAccountDisplay(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	@PostMapping("fetchContact")
	public ResponseEntity<Object> getFecthContact(@RequestBody UserDetails userDetails) {
		boolean response = this.contactsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.contactsService.getFetchContact(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	@PostMapping("editAddContact")
	public ResponseEntity<Object> getModifyContact(@RequestBody UserDetails userDetails) {
		boolean response = this.contactsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.contactsService.getEditContact(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	@PostMapping("deleteContact")
	public ResponseEntity<Object> getdeleteContact(@RequestBody UserDetails userDetails) {
		boolean response = this.contactsService.validateQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.contactsService.getdeleteContact(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
}
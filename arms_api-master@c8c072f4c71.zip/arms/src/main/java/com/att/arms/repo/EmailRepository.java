package com.att.arms.repo;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.AIFBillPeriodGroup;

@Transactional
public interface EmailRepository extends JpaRepository<AIFBillPeriodGroup, String> {

	@Query(value = "Exec arms_email_tmplt_list_v22", nativeQuery = true)
	public List<Object[]> emailTmpltList();

	@Query(value = "Exec arms_email_view_tmplt_v19 :strTmpltName", nativeQuery = true)
	public List<Object[]> getTmpltName(@Param("strTmpltName") String strTmpltName);

	@Query(value = "Exec arms_email_create_v19 :strAcct_Nbr_list,:strorig_sys_list,"
			+ ":strUserLoginCd,:tmpltdesc,:duedate,:padeadline,:pastDue,:total_amt,:PayArrangeDate,"
			+ ":ConfirmByDate,:AmountPaid,:DatePaid,:ConfirmNum,:PCFamount,:PayAddrInd,:amountlist,:datelist", nativeQuery = true)

	public String armsEmailCreate(@Param("strAcct_Nbr_list") String strAcctNbrList,
			@Param("strorig_sys_list") String strorigSysList, @Param("strUserLoginCd") String strUserLoginCd,
			@Param("tmpltdesc") String tmpltdesc, @Param("duedate") Date duedate,
			@Param("padeadline") Date padeadline, @Param("pastDue") BigDecimal pastDue,
			@Param("total_amt") BigDecimal totalAmt, @Param("PayArrangeDate") Date payArrangeDate			
			, @Param("ConfirmByDate") Date confirmByDate, @Param("AmountPaid") BigDecimal amountPaid,			
			@Param("DatePaid") Date datePaid, @Param("ConfirmNum") String confirmNum,
			@Param("PCFamount") BigDecimal pCFamount, @Param("PayAddrInd") String payAddrInd,
			@Param("amountlist") String amountlist, @Param("datelist") String datelist);

@Modifying
	@Query(value = "Exec arms_custqry_account_email_or_mail_update_v22 :user_login_id, :acct_nbr,:mail_or_mail,:originating_system", nativeQuery = true)
	public void accountEmailupdate(@Param("user_login_id") String userLoginId, @Param("acct_nbr") String acctNbr,
			@Param("mail_or_mail") String mailOrMail, @Param("originating_system") String originatingSystem);

	@Modifying
	@Query(value = "Exec arms_custqry_account_mail_merge_eligible_update_v22 :user_login_id, :acct_nbr,:mail_merge_eligible,:originating_system", nativeQuery = true)
	public void mailEligibleUpdate(@Param("user_login_id") String userLoginId, @Param("acct_nbr") String acctNbr,
			@Param("mail_merge_eligible") Integer mailMergeEligible,
			@Param("originating_system") String originatingSystem);
}
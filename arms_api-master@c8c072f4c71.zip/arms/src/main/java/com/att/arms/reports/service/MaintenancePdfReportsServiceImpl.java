package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.MaintainanceReportAllCustomerQDSODetails;
import com.att.arms.reports.repo.MaintenanceReportsAllCustomerQDSORepository;
import com.att.arms.utils.CommonReportsUtils;
import com.att.arms.utils.CommonUtils;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class MaintenancePdfReportsServiceImpl implements MaintenancePdfReportsService {

	private static final Font boldFont = new Font(Font.FontFamily.HELVETICA, 15, Font.BOLD);
	private static final Font boldFont1 = new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD);
	private static final String CURRENT_BILLING_TOTAL_BY_GROUP = "currentBillingTotalByGroup";
	private static final String PAST_DUE_0AMT_TOTAL_BY_GROUP = "pastDue0AmtTotalByGroup";
	private static final String PAST_DUE_30AMT_TOTAL_BY_GROUP = "pastDue30AmtTotalByGroup";
	private static final String PAST_DUE_60AMT_TOTAL_BY_GROUP= "pastDue60AmtTotalByGroup";
	private static final String PAST_DUE_90AMT_TOTAL_BY_GROUP = "pastDue90AmtTotalByGroup";
	private static final String PAST_DUE_120AMT_TOTAL_BY_GROUP = "pastDue120AmtTotalByGroup";
	private static final String PAST_DUE_AMT_TOTAL_BY_GROUP = "pastDueAmtTotalByGroup";
	private static final String TOTAL_DUE_AMT_BY_GROUP = "totalDueAmtByGroup";
	private static final String DISPUTE_TOTAL_BY_GROUP = "disputeTotalByGroup";
	private static final String QDSO_TOTAL_BY_GROUP = "qdsoTotalByGroup";
	private static final String CURRENT_BILLING_TOTAL = "currentBillingTotal";
	private static final String PAST_DUE_0AMT_TOTAL = "pastDue0AmtTotal";
	private static final String PAST_DUE_30AMT_TOTAL = "pastDue30AmtTotal";
	private static final String PAST_DUE_60AMT_TOTAL = "pastDue60AmtTotal";
	private static final String PAST_DUE_90AMT_TOTAL = "pastDue90AmtTotal";
	private static final String PAST_DUE_120AMT_TOTAL = "pastDue120AmtTotal";
	private static final String PAST_DUE_AMT_TOTAL = "pastDueAmtTotal";
	private static final String TOTAL_DUE_AMT = "totalDueAmt";
	private static final String DISPUTE_TOTAL = "disputeTotal";
	private static final String QDSO_TOTAL = "qdsoTotal";
	private static final String QDSO_REPORT = "QDSOReports_";

	NumberFormat nf = NumberFormat.getInstance();


	@Autowired
	MaintenanceReportsAllCustomerQDSORepository maintenanceReportsAllCustomerQDSORepository;

	@Override
	public ByteArrayInputStream createPdfWithDbData(UserDetails userDetails,
			Map<Object, Object> responseMap) throws DocumentException, IOException {

		try {
			List<MaintainanceReportAllCustomerQDSODetails> allCustomerQDSODetailsList = null;
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			

			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
			
			PdfWriter writer = PdfWriter.getInstance(document,
				new FileOutputStream(QDSO_REPORT + userDetails.getUserLoginCd()+ ".pdf"));
			document.setPageSize(rectangle);
			MaintenanceHeaderFooterPageEvent event = new MaintenanceHeaderFooterPageEvent();
			event.setHeader(userDetails.getBillingPeriod(),userDetails.getReportStatus());
			writer.setPageEvent(event);
		
			document.open();

			document.setMargins(15, 15, 120, 60);
			String originatingSystem = "";
			if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
				originatingSystem = CommonReportsUtils
						.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem());		
			}
			allCustomerQDSODetailsList = maintenanceReportsAllCustomerQDSORepository
					.findMaintainanceReportAllCustomerQDSODetailsList(userDetails.getBillingPeriod(), originatingSystem, userDetails.getReportStatus());
			if (allCustomerQDSODetailsList != null) {

				addActualContent(allCustomerQDSODetailsList, document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found");
			}

			document.close();
			writer.close();

			Path path = Paths.get(QDSO_REPORT + userDetails.getUserLoginCd()+ ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);

		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		}  finally {
			CommonUtils.deleteFile(QDSO_REPORT + userDetails.getUserLoginCd()+ ".pdf");
		}
		return null;
	}

	private void addActualContent(List<MaintainanceReportAllCustomerQDSODetails> allCustomerQDSODetailsList,
			Document document) throws DocumentException {
		
		Map<String, Map<String, List<MaintainanceReportAllCustomerQDSODetails>>> allCustomerQDSODetailsbyGroupMap = allCustomerQDSODetailsList.stream().collect(Collectors.groupingBy(MaintainanceReportAllCustomerQDSODetails::getBusUnitCd,Collectors.groupingBy(MaintainanceReportAllCustomerQDSODetails::getOriginatingCompanyCd)));
		HashMap<String, Double> summationMap = new HashMap<>();
		double currentBillingTotal = 0;
		double pastDue0AmtTotal = 0;
		double pastDue30AmtTotal = 0;
		double pastDue60AmtTotal = 0;
		double pastDue90AmtTotal = 0;
		double pastDue120AmtTotal = 0;
		double pastDueAmtTotal = 0;
		double totalDueAmt = 0;
		double disputeTotal = 0;
		double qdsoTotal = 0;
		TreeMap<String, Map<String, List<MaintainanceReportAllCustomerQDSODetails>>> groupSortedQdsoDetailsMap = new TreeMap<>();
		groupSortedQdsoDetailsMap.putAll(allCustomerQDSODetailsbyGroupMap);
	
		groupSortedQdsoDetailsMap.forEach((groupKey , qdsoDetailsByGroupList) -> {
			TreeMap<String, List<MaintainanceReportAllCustomerQDSODetails>> regionSorted = new TreeMap<>();
			regionSorted.putAll(qdsoDetailsByGroupList);

			Paragraph group = new Paragraph("Group: "+groupKey, boldFont);
			group.setAlignment(Element.ALIGN_JUSTIFIED);

			try {
				document.add(group);
				double currentBillingTotalByGroup = 0;
				if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_GROUP)
						&& summationMap.get(CURRENT_BILLING_TOTAL_BY_GROUP) != null) {
					currentBillingTotalByGroup = currentBillingTotalByGroup
							+ summationMap.get(CURRENT_BILLING_TOTAL_BY_GROUP);
				}
				double pastDue0AmtTotalByGroup = 0;
				if (summationMap.containsKey(PAST_DUE_0AMT_TOTAL_BY_GROUP)
						&& summationMap.get(PAST_DUE_0AMT_TOTAL_BY_GROUP) != null) {
					pastDue0AmtTotalByGroup = pastDue0AmtTotalByGroup + summationMap.get(PAST_DUE_0AMT_TOTAL_BY_GROUP);
				}
				double pastDue30AmtTotalByGroup = 0;
				if (summationMap.containsKey(PAST_DUE_30AMT_TOTAL_BY_GROUP)
						&& summationMap.get(PAST_DUE_30AMT_TOTAL_BY_GROUP) != null) {
					pastDue30AmtTotalByGroup = pastDue30AmtTotalByGroup + summationMap.get(PAST_DUE_30AMT_TOTAL_BY_GROUP);
				}
				double pastDue60AmtTotalByGroup = 0;
				if (summationMap.containsKey(PAST_DUE_60AMT_TOTAL_BY_GROUP)
						&& summationMap.get(PAST_DUE_60AMT_TOTAL_BY_GROUP) != null) {
					pastDue60AmtTotalByGroup = pastDue60AmtTotalByGroup + summationMap.get(PAST_DUE_60AMT_TOTAL_BY_GROUP);
				}
				double pastDue90AmtTotalByGroup = 0;
				if (summationMap.containsKey(PAST_DUE_90AMT_TOTAL_BY_GROUP)
						&& summationMap.get(PAST_DUE_90AMT_TOTAL_BY_GROUP) != null) {
					pastDue90AmtTotalByGroup = pastDue90AmtTotalByGroup + summationMap.get(PAST_DUE_90AMT_TOTAL_BY_GROUP);
				}
				double pastDue120AmtTotalByGroup = 0;
				if (summationMap.containsKey(PAST_DUE_120AMT_TOTAL_BY_GROUP)
						&& summationMap.get(PAST_DUE_120AMT_TOTAL_BY_GROUP) != null) {
					pastDue120AmtTotalByGroup = pastDue120AmtTotalByGroup + summationMap.get(PAST_DUE_120AMT_TOTAL_BY_GROUP);
				}
				
				double pastDueAmtTotalByGroup = 0;
				if (summationMap.containsKey(PAST_DUE_AMT_TOTAL_BY_GROUP)
						&& summationMap.get(PAST_DUE_AMT_TOTAL_BY_GROUP) != null) {
					pastDueAmtTotalByGroup = pastDueAmtTotalByGroup + summationMap.get(PAST_DUE_AMT_TOTAL_BY_GROUP);
				}
				double totalDueAmtByGroup = 0;
				if (summationMap.containsKey(TOTAL_DUE_AMT_BY_GROUP)
						&& summationMap.get(TOTAL_DUE_AMT_BY_GROUP) != null) {
					totalDueAmtByGroup = totalDueAmtByGroup + summationMap.get(TOTAL_DUE_AMT_BY_GROUP);
				}
				double disputeTotalByGroup = 0;
				if (summationMap.containsKey(DISPUTE_TOTAL_BY_GROUP)
						&& summationMap.get(DISPUTE_TOTAL_BY_GROUP) != null) {
					disputeTotalByGroup = disputeTotalByGroup + summationMap.get(DISPUTE_TOTAL_BY_GROUP);
				}
				double qdsoTotalByGroup = 0;
				if (summationMap.containsKey(QDSO_TOTAL_BY_GROUP)
						&& summationMap.get(QDSO_TOTAL_BY_GROUP) != null) {
					qdsoTotalByGroup = qdsoTotalByGroup + summationMap.get(QDSO_TOTAL_BY_GROUP);
				}


				regionSorted.forEach((regionKey, qdsoDetailsByRegionKeyList) -> {
					Paragraph region = new Paragraph("   Region: "+regionKey, boldFont);
					region.setAlignment(Element.ALIGN_JUSTIFIED);

					try {
						document.add(region);
						double currentBillingTotalByRegion = 0;
						double pastDue0AmtTotalByRegion = 0;
						double pastDue30AmtTotalByRegion = 0;
						double pastDue60AmtTotalByRegion = 0;
						double pastDue90AmtTotalByRegion = 0;
						double pastDue120AmtTotalByRegion = 0;
						double pastDueAmtTotalByRegion = 0;
						double totalDueAmtByRegion = 0;
						double disputeTotalByRegion = 0;
						double qdsoTotalByRegion = 0;
					
					
						for (MaintainanceReportAllCustomerQDSODetails qdsoDetail : qdsoDetailsByRegionKeyList) {
							PdfPTable table = new PdfPTable(11);

							float[] columnWidths = { 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };


							table.setWidths(columnWidths);
							table.setTotalWidth(1145);
							table.setLockedWidth(true);
							table.getDefaultCell().setFixedHeight(100);
							table.getDefaultCell().setBorder(Rectangle.TOP);
							table.getDefaultCell().setBorderColor(BaseColor.BLACK);
							
							PdfPCell cell3 = new PdfPCell(new Paragraph(qdsoDetail.getSegmentCd(),boldFont1));
							cell3.setBorder(Rectangle.NO_BORDER);
							cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
							cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell4 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getCurrentBillingAmt()))));
							cell4.setBorder(Rectangle.NO_BORDER);
							cell4.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell5 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getPastDue0Amt()))));
							cell5.setBorder(Rectangle.NO_BORDER);
							cell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell6 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getPastDue30Amt()))));
							cell6.setBorder(Rectangle.NO_BORDER);
							cell6.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell7 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getPastDue60Amt()))));
							cell7.setBorder(Rectangle.NO_BORDER);
							cell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell8 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getPastDue90Amt()))));
							cell8.setBorder(Rectangle.NO_BORDER);
							cell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell9 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getPastDue120Amt()))));
							cell9.setBorder(Rectangle.NO_BORDER);
							cell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell10 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getPastDueAmt()))));
							cell10.setBorder(Rectangle.NO_BORDER);
							cell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell11 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getTotalAmt()))));
							cell11.setBorder(Rectangle.NO_BORDER);
							cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell12 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getDispute()))));
							cell12.setBorder(Rectangle.NO_BORDER);
							cell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);

							PdfPCell cell13 = new PdfPCell(
									new Paragraph("" + nf.format(Math.round(qdsoDetail.getQdso()))));
							cell13.setBorder(Rectangle.NO_BORDER);
							cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
							cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);

							table.addCell(cell3);
							table.addCell(cell4);
							table.addCell(cell5);
							table.addCell(cell6);
							table.addCell(cell7);
							table.addCell(cell8);
							table.addCell(cell9);
							table.addCell(cell10);
							table.addCell(cell11);
							table.addCell(cell12);
							table.addCell(cell13);

							document.add(table);

							currentBillingTotalByRegion = currentBillingTotalByRegion
									+ qdsoDetail.getCurrentBillingAmt();
							pastDue0AmtTotalByRegion = pastDue0AmtTotalByRegion + qdsoDetail.getPastDue0Amt();
							pastDue30AmtTotalByRegion = pastDue30AmtTotalByRegion + qdsoDetail.getPastDue30Amt();
							pastDue60AmtTotalByRegion = pastDue60AmtTotalByRegion + qdsoDetail.getPastDue60Amt();
							pastDue90AmtTotalByRegion = pastDue90AmtTotalByRegion + qdsoDetail.getPastDue90Amt();
							pastDue120AmtTotalByRegion = pastDue120AmtTotalByRegion + qdsoDetail.getPastDue120Amt();
							pastDueAmtTotalByRegion = pastDueAmtTotalByRegion + qdsoDetail.getPastDueAmt();
							totalDueAmtByRegion = totalDueAmtByRegion + qdsoDetail.getTotalAmt();
							disputeTotalByRegion = disputeTotalByRegion + qdsoDetail.getDispute();
							qdsoTotalByRegion = qdsoTotalByRegion + qdsoDetail.getQdso();

						}

						PdfPTable totalTable = new PdfPTable(11);

						float[] columnWidths2 = { 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

						totalTable.setWidths(columnWidths2);
						totalTable.setTotalWidth(1145);
						totalTable.setLockedWidth(true);
						totalTable.getDefaultCell().setFixedHeight(100);
						totalTable.getDefaultCell().setBorder(Rectangle.TOP);
						totalTable.getDefaultCell().setBorderColor(BaseColor.BLACK);
						


						PdfPCell totalRegionCell3 = new PdfPCell(new Paragraph(regionKey + " Total: ", boldFont1));
						totalRegionCell3.setBorder(Rectangle.NO_BORDER);
						totalRegionCell3.enableBorderSide(Rectangle.TOP);
						totalRegionCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
						totalRegionCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell3.setPaddingBottom(5f);

						PdfPCell totalRegionCell4 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(currentBillingTotalByRegion))));
						totalRegionCell4.setBorder(Rectangle.NO_BORDER);
						totalRegionCell4.enableBorderSide(Rectangle.TOP);
						totalRegionCell4.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell4.setPaddingBottom(5f);

						PdfPCell totalRegionCell5 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(pastDue0AmtTotalByRegion))));
						totalRegionCell5.setBorder(Rectangle.NO_BORDER);
						totalRegionCell5.enableBorderSide(Rectangle.TOP);
						totalRegionCell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell5.setPaddingBottom(5f);

						PdfPCell totalRegionCell6 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(pastDue30AmtTotalByRegion))));
						totalRegionCell6.setBorder(Rectangle.NO_BORDER);
						totalRegionCell6.enableBorderSide(Rectangle.TOP);
						totalRegionCell6.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell6.setPaddingBottom(5f);

						PdfPCell totalRegionCell7 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(pastDue60AmtTotalByRegion))));
						totalRegionCell7.setBorder(Rectangle.NO_BORDER);
						totalRegionCell7.enableBorderSide(Rectangle.TOP);
						totalRegionCell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell7.setPaddingBottom(5f);

						PdfPCell totalRegionCell8 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(pastDue90AmtTotalByRegion))));
						totalRegionCell8.setBorder(Rectangle.NO_BORDER);
						totalRegionCell8.enableBorderSide(Rectangle.TOP);
						totalRegionCell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell8.setPaddingBottom(5f);

						PdfPCell totalRegionCell9 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(pastDue120AmtTotalByRegion))));
						totalRegionCell9.setBorder(Rectangle.NO_BORDER);
						totalRegionCell9.enableBorderSide(Rectangle.TOP);
						totalRegionCell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell9.setPaddingBottom(5f);

						PdfPCell totalRegionCell10 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(pastDueAmtTotalByRegion))));
						totalRegionCell10.setBorder(Rectangle.NO_BORDER);
						totalRegionCell10.enableBorderSide(Rectangle.TOP);
						totalRegionCell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell10.setPaddingBottom(5f);

						PdfPCell totalRegionCell11 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(totalDueAmtByRegion))));
						totalRegionCell11.setBorder(Rectangle.NO_BORDER);
						totalRegionCell11.enableBorderSide(Rectangle.TOP);
						totalRegionCell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell11.setPaddingBottom(5f);

						PdfPCell totalRegionCell12 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(disputeTotalByRegion))));
						totalRegionCell12.setBorder(Rectangle.NO_BORDER);
						totalRegionCell12.enableBorderSide(Rectangle.TOP);
						totalRegionCell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell12.setPaddingBottom(5f);

						PdfPCell totalRegionCell13 = new PdfPCell(
								new Paragraph("" + nf.format(Math.round(qdsoTotalByRegion))));
						totalRegionCell13.setBorder(Rectangle.NO_BORDER);
						totalRegionCell13.enableBorderSide(Rectangle.TOP);
						totalRegionCell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
						totalRegionCell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
						totalRegionCell13.setPaddingBottom(5f);

						totalTable.addCell(totalRegionCell3);
						totalTable.addCell(totalRegionCell4);
						totalTable.addCell(totalRegionCell5);
						totalTable.addCell(totalRegionCell6);
						totalTable.addCell(totalRegionCell7);
						totalTable.addCell(totalRegionCell8);
						totalTable.addCell(totalRegionCell9);
						totalTable.addCell(totalRegionCell10);
						totalTable.addCell(totalRegionCell11);
						totalTable.addCell(totalRegionCell12);
						totalTable.addCell(totalRegionCell13);
						if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_GROUP)) {
							summationMap.put(CURRENT_BILLING_TOTAL_BY_GROUP,
									summationMap.get(CURRENT_BILLING_TOTAL_BY_GROUP) + currentBillingTotalByRegion);
						} else {
							summationMap.put(CURRENT_BILLING_TOTAL_BY_GROUP, currentBillingTotalByRegion);
						}
						if (summationMap.containsKey(PAST_DUE_0AMT_TOTAL_BY_GROUP)) {
							summationMap.put(PAST_DUE_0AMT_TOTAL_BY_GROUP,
									summationMap.get(PAST_DUE_0AMT_TOTAL_BY_GROUP) + pastDue0AmtTotalByRegion);
						} else {
							summationMap.put(PAST_DUE_0AMT_TOTAL_BY_GROUP, pastDue0AmtTotalByRegion);
						}

						if (summationMap.containsKey(PAST_DUE_30AMT_TOTAL_BY_GROUP)) {
							summationMap.put(PAST_DUE_30AMT_TOTAL_BY_GROUP,
									summationMap.get(PAST_DUE_30AMT_TOTAL_BY_GROUP) + pastDue30AmtTotalByRegion);
						} else {
							summationMap.put(PAST_DUE_30AMT_TOTAL_BY_GROUP, pastDue30AmtTotalByRegion);
						}

						if (summationMap.containsKey(PAST_DUE_60AMT_TOTAL_BY_GROUP)) {
							summationMap.put(PAST_DUE_60AMT_TOTAL_BY_GROUP,
									summationMap.get(PAST_DUE_60AMT_TOTAL_BY_GROUP) + pastDue60AmtTotalByRegion);
						} else {
							summationMap.put(PAST_DUE_60AMT_TOTAL_BY_GROUP, pastDue60AmtTotalByRegion);
						}
						
						if (summationMap.containsKey(PAST_DUE_90AMT_TOTAL_BY_GROUP)) {
							summationMap.put(PAST_DUE_90AMT_TOTAL_BY_GROUP,
									summationMap.get(PAST_DUE_90AMT_TOTAL_BY_GROUP) + pastDue90AmtTotalByRegion);
						} else {
							summationMap.put(PAST_DUE_90AMT_TOTAL_BY_GROUP, pastDue90AmtTotalByRegion);
						}

						if (summationMap.containsKey(PAST_DUE_120AMT_TOTAL_BY_GROUP)) {
							summationMap.put(PAST_DUE_120AMT_TOTAL_BY_GROUP,
									summationMap.get(PAST_DUE_120AMT_TOTAL_BY_GROUP) + pastDue120AmtTotalByRegion);
						} else {
							summationMap.put(PAST_DUE_120AMT_TOTAL_BY_GROUP, pastDue120AmtTotalByRegion);
						}

						if (summationMap.containsKey(PAST_DUE_AMT_TOTAL_BY_GROUP)) {
							summationMap.put(PAST_DUE_AMT_TOTAL_BY_GROUP,
									summationMap.get(PAST_DUE_AMT_TOTAL_BY_GROUP) + pastDueAmtTotalByRegion);
						} else {
							summationMap.put(PAST_DUE_AMT_TOTAL_BY_GROUP, pastDueAmtTotalByRegion);
						}
						if (summationMap.containsKey(TOTAL_DUE_AMT_BY_GROUP)) {
							summationMap.put(TOTAL_DUE_AMT_BY_GROUP,
									summationMap.get(TOTAL_DUE_AMT_BY_GROUP) + totalDueAmtByRegion);
						} else {
							summationMap.put(TOTAL_DUE_AMT_BY_GROUP, totalDueAmtByRegion);
						}
						if (summationMap.containsKey(DISPUTE_TOTAL_BY_GROUP)) {
							summationMap.put(DISPUTE_TOTAL_BY_GROUP,
									summationMap.get(DISPUTE_TOTAL_BY_GROUP) + disputeTotalByRegion);
						} else {
							summationMap.put(DISPUTE_TOTAL_BY_GROUP, disputeTotalByRegion);
						}
						if (summationMap.containsKey(QDSO_TOTAL_BY_GROUP)) {
							summationMap.put(QDSO_TOTAL_BY_GROUP,
									summationMap.get(QDSO_TOTAL_BY_GROUP) + qdsoTotalByRegion);
						} else {
							summationMap.put(QDSO_TOTAL_BY_GROUP, qdsoTotalByRegion);
						}


						document.add(totalTable);
						document.add(Chunk.NEWLINE);
					} catch (DocumentException e) {
						e.printStackTrace();
					}

				});

				PdfPTable totalTable2 = new PdfPTable(11);

				float[] columnWidth2 = { 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

				totalTable2.setWidths(columnWidth2);
				totalTable2.setTotalWidth(1145);
				totalTable2.setLockedWidth(true);
				totalTable2.getDefaultCell().setFixedHeight(100);
				totalTable2.getDefaultCell().setBorder(Rectangle.TOP);
				totalTable2.getDefaultCell().setBorderColor(BaseColor.BLACK);
				

				if (summationMap.containsKey(CURRENT_BILLING_TOTAL_BY_GROUP)) {
					currentBillingTotalByGroup = summationMap.get(CURRENT_BILLING_TOTAL_BY_GROUP);
					summationMap.remove(CURRENT_BILLING_TOTAL_BY_GROUP);
				}

				if (summationMap.containsKey(PAST_DUE_0AMT_TOTAL_BY_GROUP)) {
					pastDue0AmtTotalByGroup = summationMap.get(PAST_DUE_0AMT_TOTAL_BY_GROUP);
					summationMap.remove(PAST_DUE_0AMT_TOTAL_BY_GROUP);
				}
				if (summationMap.containsKey(PAST_DUE_30AMT_TOTAL_BY_GROUP)) {
					pastDue30AmtTotalByGroup = summationMap.get(PAST_DUE_30AMT_TOTAL_BY_GROUP);
					summationMap.remove(PAST_DUE_30AMT_TOTAL_BY_GROUP);
				}

				if (summationMap.containsKey(PAST_DUE_60AMT_TOTAL_BY_GROUP)) {
					pastDue60AmtTotalByGroup = summationMap.get(PAST_DUE_60AMT_TOTAL_BY_GROUP);
					summationMap.remove(PAST_DUE_60AMT_TOTAL_BY_GROUP);
				}
				if (summationMap.containsKey(PAST_DUE_90AMT_TOTAL_BY_GROUP)) {
					pastDue90AmtTotalByGroup = summationMap.get(PAST_DUE_90AMT_TOTAL_BY_GROUP);
					summationMap.remove(PAST_DUE_90AMT_TOTAL_BY_GROUP);
				}
				if (summationMap.containsKey(PAST_DUE_120AMT_TOTAL_BY_GROUP)) {
					pastDue120AmtTotalByGroup = summationMap.get(PAST_DUE_120AMT_TOTAL_BY_GROUP);
					summationMap.remove(PAST_DUE_120AMT_TOTAL_BY_GROUP);
				}
				if (summationMap.containsKey(PAST_DUE_AMT_TOTAL_BY_GROUP)) {
					pastDueAmtTotalByGroup = summationMap.get(PAST_DUE_AMT_TOTAL_BY_GROUP);
					summationMap.remove(PAST_DUE_AMT_TOTAL_BY_GROUP);
				}
				if (summationMap.containsKey(TOTAL_DUE_AMT_BY_GROUP)) {
					totalDueAmtByGroup = summationMap.get(TOTAL_DUE_AMT_BY_GROUP);
					summationMap.remove(TOTAL_DUE_AMT_BY_GROUP);
				}
				if (summationMap.containsKey(DISPUTE_TOTAL_BY_GROUP)) {
					disputeTotalByGroup = summationMap.get(DISPUTE_TOTAL_BY_GROUP);
					summationMap.remove(DISPUTE_TOTAL_BY_GROUP);
				}
				if (summationMap.containsKey(QDSO_TOTAL_BY_GROUP)) {
					qdsoTotalByGroup = summationMap.get(QDSO_TOTAL_BY_GROUP);
					summationMap.remove(QDSO_TOTAL_BY_GROUP);
				}

				
				PdfPCell totalGroupCell3 = new PdfPCell(new Paragraph(groupKey + " Total: ", boldFont1));
				totalGroupCell3.setBorder(Rectangle.NO_BORDER);
				totalGroupCell3.enableBorderSide(Rectangle.TOP);
				totalGroupCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
				totalGroupCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell4 = new PdfPCell(new Paragraph("" + nf.format(Math.round(currentBillingTotalByGroup))));
				totalGroupCell4.setBorder(Rectangle.NO_BORDER);
				totalGroupCell4.enableBorderSide(Rectangle.TOP);
				totalGroupCell4.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell5 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue0AmtTotalByGroup))));
				totalGroupCell5.setBorder(Rectangle.NO_BORDER);
				totalGroupCell5.enableBorderSide(Rectangle.TOP);
				totalGroupCell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell5.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell6 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue30AmtTotalByGroup))));
				totalGroupCell6.setBorder(Rectangle.NO_BORDER);
				totalGroupCell6.enableBorderSide(Rectangle.TOP);
				totalGroupCell6.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell7 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue60AmtTotalByGroup))));
				totalGroupCell7.setBorder(Rectangle.NO_BORDER);
				totalGroupCell7.enableBorderSide(Rectangle.TOP);
				totalGroupCell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell8 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue90AmtTotalByGroup))));
				totalGroupCell8.setBorder(Rectangle.NO_BORDER);
				totalGroupCell8.enableBorderSide(Rectangle.TOP);
				totalGroupCell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell8.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell9 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue120AmtTotalByGroup))));
				totalGroupCell9.setBorder(Rectangle.NO_BORDER);
				totalGroupCell9.enableBorderSide(Rectangle.TOP);
				totalGroupCell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell9.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell10 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDueAmtTotalByGroup))));
				totalGroupCell10.setBorder(Rectangle.NO_BORDER);
				totalGroupCell10.enableBorderSide(Rectangle.TOP);
				totalGroupCell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell10.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell11 = new PdfPCell(new Paragraph("" + nf.format(Math.round(totalDueAmtByGroup))));
				totalGroupCell11.setBorder(Rectangle.NO_BORDER);
				totalGroupCell11.enableBorderSide(Rectangle.TOP);
				totalGroupCell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell11.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell12 = new PdfPCell(new Paragraph("" + nf.format(Math.round(disputeTotalByGroup))));
				totalGroupCell12.setBorder(Rectangle.NO_BORDER);
				totalGroupCell12.enableBorderSide(Rectangle.TOP);
				totalGroupCell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell12.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell totalGroupCell13 = new PdfPCell(new Paragraph("" + nf.format(Math.round(qdsoTotalByGroup))));
				totalGroupCell13.setBorder(Rectangle.NO_BORDER);
				totalGroupCell13.enableBorderSide(Rectangle.TOP);
				totalGroupCell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
				totalGroupCell13.setVerticalAlignment(Element.ALIGN_MIDDLE);

				totalTable2.addCell(totalGroupCell3);
				totalTable2.addCell(totalGroupCell4);
				totalTable2.addCell(totalGroupCell5);
				totalTable2.addCell(totalGroupCell6);
				totalTable2.addCell(totalGroupCell7);
				totalTable2.addCell(totalGroupCell8);
				totalTable2.addCell(totalGroupCell9);
				totalTable2.addCell(totalGroupCell10);
				totalTable2.addCell(totalGroupCell11);
				totalTable2.addCell(totalGroupCell12);
				totalTable2.addCell(totalGroupCell13);

				if (summationMap.containsKey(CURRENT_BILLING_TOTAL)) {
					summationMap.put(CURRENT_BILLING_TOTAL,
							summationMap.get(CURRENT_BILLING_TOTAL) + currentBillingTotalByGroup);
				} else {
					summationMap.put(CURRENT_BILLING_TOTAL, currentBillingTotalByGroup);
				}

				if (summationMap.containsKey(PAST_DUE_0AMT_TOTAL)) {
					summationMap.put(PAST_DUE_0AMT_TOTAL,
							summationMap.get(PAST_DUE_0AMT_TOTAL) + pastDue0AmtTotalByGroup);
				} else {
					summationMap.put(PAST_DUE_0AMT_TOTAL, pastDue0AmtTotalByGroup);
				}

				if (summationMap.containsKey(PAST_DUE_30AMT_TOTAL)) {
					summationMap.put(PAST_DUE_30AMT_TOTAL,
							summationMap.get(PAST_DUE_30AMT_TOTAL) + pastDue30AmtTotalByGroup);
				} else {
					summationMap.put(PAST_DUE_30AMT_TOTAL, pastDue30AmtTotalByGroup);
				}

				if (summationMap.containsKey(PAST_DUE_60AMT_TOTAL)) {
					summationMap.put(PAST_DUE_60AMT_TOTAL,
							summationMap.get(PAST_DUE_60AMT_TOTAL) + pastDue60AmtTotalByGroup);
				} else {
					summationMap.put(PAST_DUE_60AMT_TOTAL, pastDue60AmtTotalByGroup);
				}
				
				if (summationMap.containsKey(PAST_DUE_90AMT_TOTAL)) {
					summationMap.put(PAST_DUE_90AMT_TOTAL,
							summationMap.get(PAST_DUE_90AMT_TOTAL) + pastDue90AmtTotalByGroup);
				} else {
					summationMap.put(PAST_DUE_90AMT_TOTAL, pastDue90AmtTotalByGroup);
				}

				if (summationMap.containsKey(PAST_DUE_120AMT_TOTAL)) {
					summationMap.put(PAST_DUE_120AMT_TOTAL,
							summationMap.get(PAST_DUE_120AMT_TOTAL) + pastDue120AmtTotalByGroup);
				} else {
					summationMap.put(PAST_DUE_120AMT_TOTAL, pastDue120AmtTotalByGroup);
				}

				if (summationMap.containsKey(PAST_DUE_AMT_TOTAL)) {
					summationMap.put(PAST_DUE_AMT_TOTAL,
							summationMap.get(PAST_DUE_AMT_TOTAL) + pastDueAmtTotalByGroup);
				} else {
					summationMap.put(PAST_DUE_AMT_TOTAL, pastDueAmtTotalByGroup);
				}
				if (summationMap.containsKey(TOTAL_DUE_AMT)) {
					summationMap.put(TOTAL_DUE_AMT,
							summationMap.get(TOTAL_DUE_AMT) + totalDueAmtByGroup);
				} else {
					summationMap.put(TOTAL_DUE_AMT, totalDueAmtByGroup);
				}
				if (summationMap.containsKey(DISPUTE_TOTAL)) {
					summationMap.put(DISPUTE_TOTAL,
							summationMap.get(DISPUTE_TOTAL) + disputeTotalByGroup);
				} else {
					summationMap.put(DISPUTE_TOTAL, disputeTotalByGroup);
				}
				if (summationMap.containsKey(QDSO_TOTAL)) {
					summationMap.put(QDSO_TOTAL,
							summationMap.get(QDSO_TOTAL) + qdsoTotalByGroup);
				} else {
					summationMap.put(QDSO_TOTAL, qdsoTotalByGroup);
				}

				document.add(totalTable2);
				document.add(Chunk.NEWLINE);
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
		});
		PdfPTable totalTable3 = new PdfPTable(11);

		float[] columnWidth3 = { 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };

		totalTable3.setWidths(columnWidth3);
		totalTable3.setTotalWidth(1145);
		totalTable3.setLockedWidth(true);
		totalTable3.getDefaultCell().setFixedHeight(100);
		totalTable3.getDefaultCell().setBorder(Rectangle.TOP);
		totalTable3.getDefaultCell().setBorderColor(BaseColor.BLACK);
		

		if (summationMap.containsKey(CURRENT_BILLING_TOTAL)) {
			currentBillingTotal = summationMap.get(CURRENT_BILLING_TOTAL);
			summationMap.remove(CURRENT_BILLING_TOTAL);
		}
		if (summationMap.containsKey(PAST_DUE_0AMT_TOTAL)) {
			pastDue0AmtTotal = summationMap.get(PAST_DUE_0AMT_TOTAL);
			summationMap.remove(PAST_DUE_0AMT_TOTAL);
		}
		if (summationMap.containsKey(PAST_DUE_30AMT_TOTAL)) {
			pastDue30AmtTotal = summationMap.get(PAST_DUE_30AMT_TOTAL);
			summationMap.remove(PAST_DUE_30AMT_TOTAL);
		}
		if (summationMap.containsKey(PAST_DUE_60AMT_TOTAL)) {
			pastDue60AmtTotal = summationMap.get(PAST_DUE_60AMT_TOTAL);
			summationMap.remove(PAST_DUE_60AMT_TOTAL);
		}
		if (summationMap.containsKey(PAST_DUE_90AMT_TOTAL)) {
			pastDue90AmtTotal = summationMap.get(PAST_DUE_90AMT_TOTAL);
			summationMap.remove(PAST_DUE_90AMT_TOTAL);
		}
		if (summationMap.containsKey(PAST_DUE_120AMT_TOTAL)) {
			pastDue120AmtTotal = summationMap.get(PAST_DUE_120AMT_TOTAL);
			summationMap.remove(PAST_DUE_120AMT_TOTAL);
		}
		if (summationMap.containsKey(PAST_DUE_AMT_TOTAL)) {
			pastDueAmtTotal = summationMap.get(PAST_DUE_AMT_TOTAL);
			summationMap.remove(PAST_DUE_AMT_TOTAL);
		}
		if (summationMap.containsKey(TOTAL_DUE_AMT)) {
			totalDueAmt = summationMap.get(TOTAL_DUE_AMT);
			summationMap.remove(TOTAL_DUE_AMT);
		}
		if (summationMap.containsKey(DISPUTE_TOTAL)) {
			disputeTotal = summationMap.get(DISPUTE_TOTAL);
			summationMap.remove(DISPUTE_TOTAL);
		}
		if (summationMap.containsKey(QDSO_TOTAL)) {
			qdsoTotal = summationMap.get(QDSO_TOTAL);
			summationMap.remove(QDSO_TOTAL);
		}

		PdfPCell totalGroupCell3 = new PdfPCell(new Paragraph("Report Total:", boldFont1));
		totalGroupCell3.setBorder(Rectangle.NO_BORDER);
		totalGroupCell3.enableBorderSide(Rectangle.TOP);
		totalGroupCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
		totalGroupCell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell4 = new PdfPCell(new Paragraph("" + nf.format(Math.round(currentBillingTotal))));
		totalGroupCell4.setBorder(Rectangle.NO_BORDER);
		totalGroupCell4.enableBorderSide(Rectangle.TOP);
		totalGroupCell4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell5 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue0AmtTotal))));
		totalGroupCell5.setBorder(Rectangle.NO_BORDER);
		totalGroupCell5.enableBorderSide(Rectangle.TOP);
		totalGroupCell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell5.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell6 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue30AmtTotal))));
		totalGroupCell6.setBorder(Rectangle.NO_BORDER);
		totalGroupCell6.enableBorderSide(Rectangle.TOP);
		totalGroupCell6.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell7 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue60AmtTotal))));
		totalGroupCell7.setBorder(Rectangle.NO_BORDER);
		totalGroupCell7.enableBorderSide(Rectangle.TOP);
		totalGroupCell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell7.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell8 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue90AmtTotal))));
		totalGroupCell8.setBorder(Rectangle.NO_BORDER);
		totalGroupCell8.enableBorderSide(Rectangle.TOP);
		totalGroupCell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell8.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell9 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDue120AmtTotal))));
		totalGroupCell9.setBorder(Rectangle.NO_BORDER);
		totalGroupCell9.enableBorderSide(Rectangle.TOP);
		totalGroupCell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell9.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell10 = new PdfPCell(new Paragraph("" + nf.format(Math.round(pastDueAmtTotal))));
		totalGroupCell10.setBorder(Rectangle.NO_BORDER);
		totalGroupCell10.enableBorderSide(Rectangle.TOP);
		totalGroupCell10.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell10.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell11 = new PdfPCell(new Paragraph("" + nf.format(Math.round(totalDueAmt))));
		totalGroupCell11.setBorder(Rectangle.NO_BORDER);
		totalGroupCell11.enableBorderSide(Rectangle.TOP);
		totalGroupCell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell11.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell12 = new PdfPCell(new Paragraph("" + nf.format(Math.round(disputeTotal))));
		totalGroupCell12.setBorder(Rectangle.NO_BORDER);
		totalGroupCell12.enableBorderSide(Rectangle.TOP);
		totalGroupCell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell12.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalGroupCell13 = new PdfPCell(new Paragraph("" + nf.format(Math.round(qdsoTotal))));
		totalGroupCell13.setBorder(Rectangle.NO_BORDER);
		totalGroupCell13.enableBorderSide(Rectangle.TOP);
		totalGroupCell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
		totalGroupCell13.setVerticalAlignment(Element.ALIGN_MIDDLE);

		totalTable3.addCell(totalGroupCell3);
		totalTable3.addCell(totalGroupCell4);
		totalTable3.addCell(totalGroupCell5);
		totalTable3.addCell(totalGroupCell6);
		totalTable3.addCell(totalGroupCell7);
		totalTable3.addCell(totalGroupCell8);
		totalTable3.addCell(totalGroupCell9);
		totalTable3.addCell(totalGroupCell10);
		totalTable3.addCell(totalGroupCell11);
		totalTable3.addCell(totalGroupCell12);
		totalTable3.addCell(totalGroupCell13);
		document.add(totalTable3);
	}
}

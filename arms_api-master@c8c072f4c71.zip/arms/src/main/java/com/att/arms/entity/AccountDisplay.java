package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Entity
@IdClass(AccountDisplay.AccountDisplayId.class)
@Data
public class AccountDisplay {

	@Id
	@JsonProperty("account_number")
	@Column(name="acct_nbr")
	private String acctNbr;
	@JsonProperty("zbu")
	private String fan;
	private String svid;
	@JsonProperty("customer_name")
	@Column(name="cust_name")
	private String custName;
	@Id
	@JsonProperty("originating_system")
	private String system;
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@SuppressWarnings("serial")
	@Data
	public static class AccountDisplayId implements Serializable {
		
		private String acctNbr;
		private String system;
	}
}

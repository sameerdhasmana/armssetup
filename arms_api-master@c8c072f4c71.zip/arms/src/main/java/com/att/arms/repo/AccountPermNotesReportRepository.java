package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.AccountPermNotesReport;

@Transactional
public interface AccountPermNotesReportRepository extends JpaRepository<AccountPermNotesReport, String> {

	@Query(value = "exec arms_rpt_acct_perm_notes :accountNumber,:system", nativeQuery = true)
	public List<AccountPermNotesReport> getAccountPermNotesReport(@Param("accountNumber") String accountNumber,
			@Param("system") String system);

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.AccountClassification;

@Transactional
public interface AccountsClassificationRepository extends JpaRepository<AccountClassification, String> {

	@Query(value = "SELECT DISTINCT class_desc, class_cd FROM account_classification with (nolock) ORDER BY class_desc", nativeQuery = true)
	public List<AccountClassification> findAccountsClassificationList();
}

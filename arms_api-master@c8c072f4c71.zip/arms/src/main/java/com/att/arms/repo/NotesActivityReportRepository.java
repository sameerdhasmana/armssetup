package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.NotesActivityReport;

@Transactional
public interface NotesActivityReportRepository extends JpaRepository<NotesActivityReport, String> {

	@Query(value = "exec arms_notes_reportactivity_user_v22 :queryType,:resolved,:activityCode,"
			+ " :startDate,:endDate,:customers,:h1Uid,:subActivity,:sort,:strFilter", nativeQuery = true)
	public List<NotesActivityReport> fetchNotesActivityReport(@Param("queryType") String queryType,
			@Param("resolved") Integer resolved, @Param("activityCode") String activityCode,
			@Param("startDate") String startDate, @Param("endDate") String endDate,
			@Param("customers") String customers, @Param("h1Uid") String h1Uid,
			@Param("subActivity") String subActivity, @Param("sort") String sort, @Param("strFilter") String strFilter);
	
	@Query(value = "exec arms_notes_reportactivity_manager_v22 :queryType,:resolved,:activityCode,"
			+ " :startDate,:endDate,:customers,:mgrUid,:subActivity,:sort,:strFilter", nativeQuery = true)
	public List<NotesActivityReport> fetchNotesActivityManagerReport(@Param("queryType") String queryType,
			@Param("resolved") Integer resolved, @Param("activityCode") String activityCode,
			@Param("startDate") String startDate, @Param("endDate") String endDate,
			@Param("customers") String customers, @Param("mgrUid") String mgrUid,
			@Param("subActivity") String subActivity, @Param("sort") String sort, @Param("strFilter") String strFilter);

}

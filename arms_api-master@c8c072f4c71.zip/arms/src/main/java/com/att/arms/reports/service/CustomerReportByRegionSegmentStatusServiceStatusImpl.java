package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.CustomerReportByRegionSegmentStatus;
import com.att.arms.reports.repo.CustomerReportRepoByRegionSegmentStatus;
import com.att.arms.utils.CommonReportsUtils;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;

@Service
public class CustomerReportByRegionSegmentStatusServiceStatusImpl
		implements CustomerReportByRegionSegmentStatusService {

	@Autowired
	CustomerReportRepoByRegionSegmentStatus customerReportRepoByRegionSegmentStatus;

	Font bannerFont = new Font(FontFamily.TIMES_ROMAN, 24f, Font.BOLD, BaseColor.BLACK);
	Font headerFont = new Font(FontFamily.TIMES_ROMAN, 14f, Font.NORMAL, BaseColor.BLACK);
	Font headerFontBold = new Font(FontFamily.TIMES_ROMAN, 14f, Font.BOLD, BaseColor.BLACK);
	Font textFont = new Font(FontFamily.TIMES_ROMAN, 12f, Font.NORMAL, BaseColor.BLACK);
	Font textFontBold = new Font(FontFamily.TIMES_ROMAN, 12f, Font.BOLD, BaseColor.BLACK);
	Font customerFont = new Font(FontFamily.TIMES_ROMAN, 16f, Font.BOLD, BaseColor.BLACK);

	NumberFormat nf = new DecimalFormat("#0.00");

	double currentBillingTotalByRegion = 0;
	double currentBalanceTotalByRegion = 0;
	double pastDue30AmtTotalByRegion = 0;
	double pastDue60AmtTotalByRegion = 0;
	double pastDue90AmtTotalByRegion = 0;
	double pastDue120AmtTotalByRegion = 0;
	double pastDueAmtTotalByRegion = 0;
	double totalDueAmtByRegion = 0;
	double disputeTotalByRegion = 0;

	double currentBillingTotalByRegionSegment = 0;
	double currentBalanceTotalByRegionSegment = 0;
	double pastDue30AmtTotalByRegionSegment = 0;
	double pastDue60AmtTotalByRegionSegment = 0;
	double pastDue90AmtTotalByRegionSegment = 0;
	double pastDue120AmtTotalByRegionSegment = 0;
	double pastDueAmtTotalByRegionSegment = 0;
	double totalDueAmtByRegionSegment = 0;
	double disputeTotalByRegionSegment = 0;

	double currentBillingTotalByRegionSegmentStatus = 0;
	double currentBalanceTotalByRegionSegmentStatus = 0;
	double pastDue30AmtTotalByRegionSegmentStatus = 0;
	double pastDue60AmtTotalByRegionSegmentStatus = 0;
	double pastDue90AmtTotalByRegionSegmentStatus = 0;
	double pastDue120AmtTotalByRegionSegmentStatus = 0;
	double pastDueAmtTotalByRegionSegmentStatus = 0;
	double totalDueAmtByRegionSegmentStatus = 0;
	double disputeTotalByRegionSegmentStatus = 0;

	@Override
	public ByteArrayInputStream getCustRepDetailsByRegSegStatusPdf(UserDetails userDetails,
			Map<Object, Object> responseMap) throws DocumentException, IOException {

		try {
			Document document = new Document();
			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream("CustomerReport-RegionSegmentStatus.pdf"));

			String exclusionClasses = "";
			if (userDetails.getExclusionClass().size() > 0) {
				exclusionClasses = "AND (cx.class_cd IN (" + userDetails.getExclusionClass().get(0) + "))";
			}

			List<CustomerReportByRegionSegmentStatus> customerReportRegionList = customerReportRepoByRegionSegmentStatus
					.findCustomerReportData(userDetails.getBillingPeriod(),
							CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()),
							CommonReportsUtils
									.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()),
							CommonReportsUtils
									.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()),
							CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
							CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
							CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
							userDetails.getExclusions(), exclusionClasses, userDetails.getCustomerChidFlag());

			if (customerReportRegionList != null) {
				documentBuilder(userDetails, document, writer, customerReportRegionList);
				addHeaderSection(document, userDetails);
				addActualContent(customerReportRegionList, document);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			} else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Records Found");
			}

			document.close();
			writer.close();

			Path path = Paths.get("CustomerReport-RegionSegmentStatus.pdf");
			byte[] pdfBytes = Files.readAllBytes(path);
			return new ByteArrayInputStream(pdfBytes);
		} catch (DocumentException | FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void addHeaderSection(Document document, UserDetails userDetails) {
		try {
			PdfPTable table = new PdfPTable(11);

			float[] columnWidths = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

			table.setWidths(columnWidths);
			table.setTotalWidth(1200);
			table.setLockedWidth(true);
			table.getDefaultCell().setFixedHeight(100);

			PdfPCell cell1 = new PdfPCell(new Paragraph(ReportsConstant.STATUS, textFontBold));
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);

			PdfPCell cell2 = new PdfPCell(new Paragraph(ReportsConstant.CURRENT_BILLING, textFontBold));
			cell2.setBorder(Rectangle.NO_BORDER);
			cell2.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell3 = new PdfPCell(new Paragraph(ReportsConstant.CURRENT_BALANCE, textFontBold));
			cell3.setBorder(Rectangle.NO_BORDER);
			cell3.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell4 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_30_DAYS, textFontBold));
			cell4.setBorder(Rectangle.NO_BORDER);
			cell4.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell5 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_60_DAYS, textFontBold));
			cell5.setBorder(Rectangle.NO_BORDER);
			cell5.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell6 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_90_DAYS, textFontBold));
			cell6.setBorder(Rectangle.NO_BORDER);
			cell6.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell7 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_120_DAYS, textFontBold));
			cell7.setBorder(Rectangle.NO_BORDER);
			cell7.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell8 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_PAST_DUE, textFontBold));
			cell8.setBorder(Rectangle.NO_BORDER);
			cell8.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell9 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_DUE, textFontBold));
			cell9.setBorder(Rectangle.NO_BORDER);
			cell9.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell10 = new PdfPCell(new Paragraph(ReportsConstant.DISPUTE, textFontBold));
			cell10.setBorder(Rectangle.NO_BORDER);
			cell10.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell11 = new PdfPCell(new Paragraph(ReportsConstant.DSO, textFontBold));
			cell11.setBorder(Rectangle.NO_BORDER);
			cell11.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);
			table.addCell(cell8);
			table.addCell(cell9);
			table.addCell(cell10);
			table.addCell(cell11);

			LineSeparator thickLine = new LineSeparator();
			thickLine.setLineWidth(2);
			thickLine.setOffset(10);
			PdfPCell pCell = new PdfPCell(new Paragraph(new Chunk(thickLine)));
			pCell.setColspan(15);
			pCell.setBorder(Rectangle.NO_BORDER);

			table.addCell(pCell);

			document.add(table);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	private void documentBuilder(UserDetails userDetails, Document document, PdfWriter writer,
			List<CustomerReportByRegionSegmentStatus> CustomerReportRegionList) throws DocumentException {
		// Set Page Size
		Rectangle pageSize = new Rectangle(15, 15, 1300, 1800);
		document.setPageSize(pageSize);

		Paragraph accReportName = new Paragraph("Customer Report (by Region, Segment, Status)", bannerFont);
		accReportName.setAlignment(Chunk.ALIGN_CENTER);

		/*
		 * Handle Empty records
		 */
		String billingPeriod = "";
		if (null != CustomerReportRegionList && CustomerReportRegionList.size() > 0) {
			billingPeriod = CustomerReportRegionList.get(0).getBillingPeriod();

		}

		Paragraph billingPeriodPara = new Paragraph(new Chunk("Billing Period: ") + billingPeriod, headerFont);
		billingPeriodPara.setAlignment(Chunk.ALIGN_LEFT);

		PdfPTable topSectionTable = new PdfPTable(2);

		float[] columnWidths = { 800, 180, };
		topSectionTable.setWidths(columnWidths);
		topSectionTable.setTotalWidth(1200);
		topSectionTable.setLockedWidth(true);

		PdfPCell cell1 = new PdfPCell(accReportName);
		cell1.setBorder(Rectangle.NO_BORDER);

		PdfPCell cell2 = new PdfPCell(billingPeriodPara);
		cell2.setBorder(Rectangle.NO_BORDER);

		topSectionTable.addCell(cell1);
		topSectionTable.addCell(cell2);

		Chunk whiteSpace = new Chunk("            ");
		Paragraph groupRegionAndStatus = new Paragraph();
		Phrase groupRegionAndStatusPhrase = new Phrase();
		groupRegionAndStatusPhrase
				.add(new Chunk("Groups(s): " + String.join(", ", userDetails.getGroupSelected()), headerFont));
		groupRegionAndStatusPhrase.add(whiteSpace);
		groupRegionAndStatusPhrase.add(
				new Chunk("Region(s): " + String.join(", ", userDetails.getOriginatingCompanyCdClause()), headerFont));
		groupRegionAndStatusPhrase.add(whiteSpace);
		groupRegionAndStatusPhrase
				.add(new Chunk("Status: " + String.join(", ", userDetails.getStatusClause()), headerFont));
		groupRegionAndStatus.add(groupRegionAndStatusPhrase);

		Paragraph segments = new Paragraph("Segment(s): " + String.join(", ", userDetails.getSegment()), headerFont);
		segments.setSpacingAfter(5f);

		Paragraph classesIncluded = new Paragraph("Class(es): " + userDetails.getExclusions(), headerFont);
		classesIncluded.setSpacingAfter(3f);

		CustomerReportRegionSegmentStatusHeaderEvent regionSegmentHeaderEvent = new CustomerReportRegionSegmentStatusHeaderEvent();
		writer.setPageEvent(regionSegmentHeaderEvent);

		document.open();
		document.setMargins(15, 15, 120, 60);

		document.add(new LineSeparator());
		document.add(topSectionTable);
		LineSeparator lineSeparater = new LineSeparator();
		lineSeparater.setOffset(-4);
		document.add(lineSeparater);

		Paragraph emptyPara = new Paragraph("\n");
		document.add(emptyPara);

		document.add(groupRegionAndStatus);
		document.add(segments);
		document.add(classesIncluded);
		document.add(Chunk.NEWLINE);
		LineSeparator thickLine = new LineSeparator();
		thickLine.setLineWidth(2);
		document.add(thickLine);
	}

	private void addActualContent(List<CustomerReportByRegionSegmentStatus> customerReportRegionList, Document document)
			throws DocumentException {
		/*
		 * Get customers map grouped by customer as key
		 */
		// PART - A
		Map<String, List<CustomerReportByRegionSegmentStatus>> customersMap = customerReportRegionList.stream()
				.collect(Collectors.groupingBy(p -> p.getCustomer()));

		// Sort the Map by customer
		Map<String, List<CustomerReportByRegionSegmentStatus>> allCustomeDetailsbyGroupMap = new TreeMap<>();
		allCustomeDetailsbyGroupMap.putAll(customersMap);

		allCustomeDetailsbyGroupMap.forEach((customer, allCustomeDetailsbyGroupList) -> {
			Paragraph customerName = new Paragraph(customer, customerFont);
			customerName.setAlignment(Chunk.ALIGN_LEFT);

			try {
				PdfPTable customerTable = new PdfPTable(1);

				float[] columnWidths = { 1200f };

				customerTable.setWidths(columnWidths);
				customerTable.setTotalWidth(1200);
				customerTable.setLockedWidth(true);

				PdfPCell customerCell = new PdfPCell(customerName);
				customerCell.setBorder(Rectangle.NO_BORDER);
				customerTable.addCell(customerCell);
				document.add(customerTable);

				/*
				 * PART - B
				 * 
				 * Get Regions map for the given customer
				 */
				Map<String, List<CustomerReportByRegionSegmentStatus>> allRegionMap = allCustomeDetailsbyGroupList
						.stream().collect(Collectors.groupingBy(p -> p.getRegion()));
				// Sort the Map by region
				Map<String, List<CustomerReportByRegionSegmentStatus>> perCustomerRegionMap = new TreeMap<>();
				perCustomerRegionMap.putAll(allRegionMap);

				perCustomerRegionMap.forEach((region, perCustomerRegionList) -> {
					try {
						addRegiontable(document, region);

						// PART - C
						/*
						 * Get Segments map for the given region
						 */
						Map<String, List<CustomerReportByRegionSegmentStatus>> allRegionSegmentMap = perCustomerRegionList
								.stream().collect(Collectors.groupingBy(p -> p.getSegment()));

						// Sort the Map by segment
						Map<String, List<CustomerReportByRegionSegmentStatus>> perRegionSegmentMap = new TreeMap<>();
						perRegionSegmentMap.putAll(allRegionSegmentMap);

						perRegionSegmentMap.forEach((segment, perRegionSegmentList) -> {

							try {
								addSegmentTable(document, segment);

								// PART - D
								/*
								 * Get Status map for the given segment
								 */
								Map<String, List<CustomerReportByRegionSegmentStatus>> allRegionSegmentStatusMap = perRegionSegmentList
										.stream().collect(Collectors.groupingBy(p -> p.getStatus()));

								// Sort the Map by status
								Map<String, List<CustomerReportByRegionSegmentStatus>> perRegionSegmentStatusMap = new TreeMap<>();
								perRegionSegmentStatusMap.putAll(allRegionSegmentStatusMap);

								perRegionSegmentStatusMap.forEach((status, perRegionSegmentStatusList) -> {

									try {
										addStatusTable(document, perRegionSegmentStatusList, status);

									} catch (DocumentException e) {
										e.printStackTrace();
									}

								});

								/*
								 * Create table for the sum of status in segment
								 */
								addStatusSumTableHeader(document, segment);

								addStatusSumTableBody(document, currentBillingTotalByRegionSegmentStatus,
										currentBalanceTotalByRegionSegmentStatus,
										pastDue30AmtTotalByRegionSegmentStatus, pastDue60AmtTotalByRegionSegmentStatus,
										pastDue90AmtTotalByRegionSegment, pastDue120AmtTotalByRegionSegmentStatus,
										pastDueAmtTotalByRegionSegmentStatus, totalDueAmtByRegionSegmentStatus,
										disputeTotalByRegionSegmentStatus);

								/*
								 * reset the values back to zero
								 */

								currentBillingTotalByRegionSegmentStatus = 0;
								currentBalanceTotalByRegionSegmentStatus = 0;
								pastDue30AmtTotalByRegionSegmentStatus = 0;
								pastDue60AmtTotalByRegionSegmentStatus = 0;
								pastDue90AmtTotalByRegionSegmentStatus = 0;
								pastDue120AmtTotalByRegionSegmentStatus = 0;
								pastDueAmtTotalByRegionSegmentStatus = 0;
								totalDueAmtByRegionSegmentStatus = 0;
								disputeTotalByRegionSegmentStatus = 0;

							} catch (DocumentException e) {
								e.printStackTrace();
							}

						});

						/*
						 * Create table for the sum of segments in region
						 */
						addRegionSumTableHeader(document, region);
						addRegionSumTableBody(document);

						/*
						 * reset the values back to zero
						 */

						currentBillingTotalByRegionSegment = 0;
						currentBalanceTotalByRegionSegment = 0;
						pastDue30AmtTotalByRegionSegment = 0;
						pastDue60AmtTotalByRegionSegment = 0;
						pastDue90AmtTotalByRegionSegment = 0;
						pastDue120AmtTotalByRegionSegment = 0;
						pastDueAmtTotalByRegionSegment = 0;
						totalDueAmtByRegionSegment = 0;
						disputeTotalByRegionSegment = 0;

					} catch (DocumentException e) {
						e.printStackTrace();
					}

				});

				/*
				 * Create table for the sum
				 */
				addCustomerRegionSumTableHeader(document, customer);
				addCustomerRegionSumTableBody(document, currentBillingTotalByRegion, currentBalanceTotalByRegion,
						pastDue30AmtTotalByRegion, pastDue60AmtTotalByRegion, pastDue90AmtTotalByRegion,
						pastDue120AmtTotalByRegion, pastDueAmtTotalByRegion, totalDueAmtByRegion, disputeTotalByRegion);

				/*
				 * reset the values back to zero
				 */

				currentBillingTotalByRegion = 0;
				currentBalanceTotalByRegion = 0;
				pastDue30AmtTotalByRegion = 0;
				pastDue60AmtTotalByRegion = 0;
				pastDue90AmtTotalByRegion = 0;
				pastDue120AmtTotalByRegion = 0;
				pastDueAmtTotalByRegion = 0;
				totalDueAmtByRegion = 0;
				disputeTotalByRegion = 0;

			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
		});

		/*
		 * Add Grand Total
		 */

		double currentBillingGrandTotalByRegionSegment = customerReportRegionList.stream()
				.collect(Collectors.summingDouble(CustomerReportByRegionSegmentStatus::getCurrentBillingAmount));
		double currentBalanceGrandTotalByRegion = customerReportRegionList.stream()
				.collect(Collectors.summingDouble(CustomerReportByRegionSegmentStatus::getPastDue0Amount));
		double pastDue30GrandTotalByRegionSegment = customerReportRegionList.stream()
				.collect(Collectors.summingDouble(CustomerReportByRegionSegmentStatus::getPastDue30Amount));
		double pastDue60GrandTotalByRegionSegment = customerReportRegionList.stream()
				.collect(Collectors.summingDouble(CustomerReportByRegionSegmentStatus::getPastDue60Amount));
		double pastDue90GrandTotalByRegionSegment = customerReportRegionList.stream()
				.collect(Collectors.summingDouble(CustomerReportByRegionSegmentStatus::getPastDue90Amount));
		double pastDue120GrandTotalByRegionSegment = customerReportRegionList.stream()
				.collect(Collectors.summingDouble(CustomerReportByRegionSegmentStatus::getPastDue120Amount));
		double grandTotalPastDueByRegionSegment = customerReportRegionList.stream()
				.collect(Collectors.summingDouble(CustomerReportByRegionSegmentStatus::getTotalPastDue));
		double grandTotalDueByRegionSegment = customerReportRegionList.stream()
				.collect(Collectors.summingDouble(CustomerReportByRegionSegmentStatus::getTotalAmount));
		double grandTotalDisputeByRegionSegment = customerReportRegionList.stream()
				.collect(Collectors.summingDouble(CustomerReportByRegionSegmentStatus::getDispute));

		addGrandSumTableHeader(document);
		// Re-using the method for grand sum
		addCustomerRegionSumTableBody(document, currentBillingGrandTotalByRegionSegment,
				currentBalanceGrandTotalByRegion, pastDue30GrandTotalByRegionSegment,
				pastDue60GrandTotalByRegionSegment, pastDue90GrandTotalByRegionSegment,
				pastDue120GrandTotalByRegionSegment, grandTotalPastDueByRegionSegment, grandTotalDueByRegionSegment,
				grandTotalDisputeByRegionSegment);

	}

	private void addRegiontable(Document document, String region) throws DocumentException {
		Paragraph regionName = new Paragraph(region, textFontBold);
		regionName.setAlignment(Chunk.ALIGN_LEFT);

		PdfPTable regionTable = new PdfPTable(2);

		float[] regionColumnWidths = { 40f, 1160f };

		regionTable.setWidths(regionColumnWidths);
		regionTable.setTotalWidth(1200);
		regionTable.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setBorder(Rectangle.NO_BORDER);

		PdfPCell regionCell = new PdfPCell(regionName);
		regionCell.setBorder(Rectangle.NO_BORDER);

		regionTable.addCell(emptyCells);
		regionTable.addCell(regionCell);

		document.add(regionTable);

	}

	private void addSegmentTable(Document segmentDoc, String segment) throws DocumentException {

		Paragraph segmentName = new Paragraph(segment, textFontBold);
		segmentName.setAlignment(Chunk.ALIGN_LEFT);

		PdfPTable segmentTable = new PdfPTable(3);

		float[] segmentColumnWidths = { 40f, 40f, 1120f };

		segmentTable.setWidths(segmentColumnWidths);
		segmentTable.setTotalWidth(1200);
		segmentTable.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setBorder(Rectangle.NO_BORDER);

		PdfPCell segmentCell = new PdfPCell(segmentName);
		segmentCell.setBorder(Rectangle.NO_BORDER);

		segmentTable.addCell(emptyCells);
		segmentTable.addCell(emptyCells);
		segmentTable.addCell(segmentCell);

		segmentDoc.add(segmentTable);

	}

	private void addStatusTable(Document document, List<CustomerReportByRegionSegmentStatus> perRegionSegmentStatusList,
			String status) throws DocumentException {

		for (CustomerReportByRegionSegmentStatus customerRegionSegmentStatus : perRegionSegmentStatusList) {
			Paragraph statusPara = new Paragraph(status, textFont);
			statusPara.setAlignment(Chunk.ALIGN_LEFT);

			PdfPTable statusTable = new PdfPTable(11);

			float[] statusColumnWidth = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

			statusTable.setWidths(statusColumnWidth);
			statusTable.setTotalWidth(1200);
			statusTable.setLockedWidth(true);
			statusTable.getDefaultCell().setFixedHeight(100);

			PdfPCell statusCell = new PdfPCell(statusPara);
			statusCell.setBorder(Rectangle.NO_BORDER);
			statusTable.addCell(statusCell);

			PdfPCell cell2 = new PdfPCell(
					new Paragraph("$" + nf.format(customerRegionSegmentStatus.getCurrentBillingAmount()), textFont));
			cell2.setBorder(Rectangle.NO_BORDER);
			cell2.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell3 = new PdfPCell(
					new Paragraph("$" + nf.format(customerRegionSegmentStatus.getPastDue0Amount()), textFont));
			cell3.setBorder(Rectangle.NO_BORDER);
			cell3.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell4 = new PdfPCell(
					new Paragraph("$" + nf.format(customerRegionSegmentStatus.getPastDue30Amount()), textFont));
			cell4.setBorder(Rectangle.NO_BORDER);
			cell4.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell5 = new PdfPCell(
					new Paragraph("$" + nf.format(customerRegionSegmentStatus.getPastDue60Amount()), textFont));
			cell5.setBorder(Rectangle.NO_BORDER);
			cell5.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell6 = new PdfPCell(
					new Paragraph("$" + nf.format(customerRegionSegmentStatus.getPastDue90Amount()), textFont));
			cell6.setBorder(Rectangle.NO_BORDER);
			cell6.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell7 = new PdfPCell(
					new Paragraph("$" + nf.format(customerRegionSegmentStatus.getPastDue120Amount()), textFont));
			cell7.setBorder(Rectangle.NO_BORDER);
			cell7.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell8 = new PdfPCell(
					new Paragraph("$" + nf.format(customerRegionSegmentStatus.getTotalPastDue()), textFont));
			cell8.setBorder(Rectangle.NO_BORDER);
			cell8.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell9 = new PdfPCell(
					new Paragraph("$" + nf.format(customerRegionSegmentStatus.getTotalAmount()), textFont));
			cell9.setBorder(Rectangle.NO_BORDER);
			cell9.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell10 = new PdfPCell(
					new Paragraph("$" + nf.format(customerRegionSegmentStatus.getDispute()), textFont));
			cell10.setBorder(Rectangle.NO_BORDER);
			cell10.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell11 = new PdfPCell(new Paragraph(customerRegionSegmentStatus.getDso().toString(), textFont));
			cell11.setBorder(Rectangle.NO_BORDER);
			cell11.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			statusTable.addCell(cell2);
			statusTable.addCell(cell3);
			statusTable.addCell(cell4);
			statusTable.addCell(cell5);
			statusTable.addCell(cell6);
			statusTable.addCell(cell7);
			statusTable.addCell(cell8);
			statusTable.addCell(cell9);
			statusTable.addCell(cell10);
			statusTable.addCell(cell11);
			document.add(statusTable);

			/*
			 * Get the total for all status within a segment
			 */
			currentBillingTotalByRegionSegmentStatus += customerRegionSegmentStatus.getCurrentBillingAmount();
			currentBalanceTotalByRegionSegmentStatus += customerRegionSegmentStatus.getPastDue0Amount();
			pastDue30AmtTotalByRegionSegmentStatus += customerRegionSegmentStatus.getPastDue30Amount();
			pastDue60AmtTotalByRegionSegmentStatus += customerRegionSegmentStatus.getPastDue60Amount();
			pastDue90AmtTotalByRegionSegmentStatus += customerRegionSegmentStatus.getPastDue90Amount();
			pastDue120AmtTotalByRegionSegmentStatus += customerRegionSegmentStatus.getPastDue120Amount();
			pastDueAmtTotalByRegionSegmentStatus += customerRegionSegmentStatus.getTotalPastDue();
			totalDueAmtByRegionSegmentStatus += customerRegionSegmentStatus.getTotalAmount();
			disputeTotalByRegionSegmentStatus += customerRegionSegmentStatus.getDispute();

			/*
			 * Add the sum at region level for all segments
			 */
			currentBillingTotalByRegionSegment += currentBillingTotalByRegionSegmentStatus;
			currentBalanceTotalByRegionSegment += currentBalanceTotalByRegionSegmentStatus;
			pastDue30AmtTotalByRegionSegment += pastDue30AmtTotalByRegionSegmentStatus;
			pastDue60AmtTotalByRegionSegment += pastDue60AmtTotalByRegionSegmentStatus;
			pastDue90AmtTotalByRegionSegment += pastDue90AmtTotalByRegionSegmentStatus;
			pastDue120AmtTotalByRegionSegment += pastDue120AmtTotalByRegionSegmentStatus;
			pastDueAmtTotalByRegionSegment += pastDueAmtTotalByRegionSegmentStatus;
			totalDueAmtByRegionSegment += totalDueAmtByRegionSegmentStatus;
			disputeTotalByRegionSegment += disputeTotalByRegionSegmentStatus;

		}

	}

	private void addCustomerRegionSumTableBody(Document document, double currentBillingTotalByRegion,
			double currentBalanceTotalByRegion, double pastDue30AmtTotalByRegion, double pastDue60AmtTotalByRegion,
			double pastDue90AmtTotalByRegion, double pastDue120AmtTotalByRegion, double pastDueAmtTotalByRegion,
			double totalDueAmtByRegion, double disputeTotalByRegion) throws DocumentException {
		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setBorder(Rectangle.NO_BORDER);

		PdfPCell cell2 = new PdfPCell(new Paragraph("$" + nf.format(currentBillingTotalByRegion), textFontBold));
		cell2.setBorder(Rectangle.NO_BORDER);
		cell2.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell3 = new PdfPCell(new Paragraph("$" + nf.format(currentBalanceTotalByRegion), textFontBold));
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell4 = new PdfPCell(new Paragraph("$" + nf.format(pastDue30AmtTotalByRegion), textFontBold));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell5 = new PdfPCell(new Paragraph("$" + nf.format(pastDue60AmtTotalByRegion), textFontBold));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell6 = new PdfPCell(new Paragraph("$" + nf.format(pastDue90AmtTotalByRegion), textFontBold));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell7 = new PdfPCell(new Paragraph("$" + nf.format(pastDue120AmtTotalByRegion), textFontBold));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell8 = new PdfPCell(new Paragraph("$" + nf.format(pastDueAmtTotalByRegion), textFontBold));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell9 = new PdfPCell(new Paragraph("$" + nf.format(totalDueAmtByRegion), textFontBold));
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell10 = new PdfPCell(new Paragraph("$" + nf.format(disputeTotalByRegion), textFontBold));
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		String dsoTotalByRegion = "";
		if (currentBillingTotalByRegion == 0 && totalDueAmtByRegion == 0) {
			dsoTotalByRegion = "-nan(ind)";
		} else if (currentBillingTotalByRegion == 0) {
			dsoTotalByRegion = "-inf";
		} else {
			double computedValue = Math.round((totalDueAmtByRegion / currentBillingTotalByRegion) * 30);
			dsoTotalByRegion = String.format("%.0f", computedValue);
		}

		PdfPCell cell11 = new PdfPCell(new Paragraph(dsoTotalByRegion, textFontBold));
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		table.addCell(emptyCells);
		table.addCell(cell2);
		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);

		document.add(table);

	}

	private void addStatusSumTableBody(Document document, double currentBillingTotalByRegionSegmentStatus,
			double currentBalanceTotalByRegionSegmentStatus, double pastDue30AmtTotalByRegionSegmentStatus,
			double pastDue60AmtTotalByRegionSegmentStatus, double pastDue90AmtTotalByRegionSegmentStatus,
			double pastDue120AmtTotalByRegionSegmentStatus, double pastDueAmtTotalByRegionSegmentStatus,
			double totalDueAmtByRegionSegmentStatus, double disputeTotalByRegionSegmentStatus)
			throws DocumentException {

		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setBorder(Rectangle.NO_BORDER);

		PdfPCell cell2 = new PdfPCell(
				new Paragraph("$" + nf.format(currentBillingTotalByRegionSegmentStatus), textFontBold));
		cell2.setBorder(Rectangle.NO_BORDER);
		cell2.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell3 = new PdfPCell(
				new Paragraph("$" + nf.format(currentBalanceTotalByRegionSegmentStatus), textFontBold));
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell4 = new PdfPCell(
				new Paragraph("$" + nf.format(pastDue30AmtTotalByRegionSegmentStatus), textFontBold));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell5 = new PdfPCell(
				new Paragraph("$" + nf.format(pastDue60AmtTotalByRegionSegmentStatus), textFontBold));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell6 = new PdfPCell(
				new Paragraph("$" + nf.format(pastDue90AmtTotalByRegionSegmentStatus), textFontBold));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell7 = new PdfPCell(
				new Paragraph("$" + nf.format(pastDue120AmtTotalByRegionSegmentStatus), textFontBold));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell8 = new PdfPCell(
				new Paragraph("$" + nf.format(pastDueAmtTotalByRegionSegmentStatus), textFontBold));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell9 = new PdfPCell(new Paragraph("$" + nf.format(totalDueAmtByRegionSegmentStatus), textFontBold));
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell10 = new PdfPCell(new Paragraph("$" + nf.format(disputeTotalByRegionSegmentStatus), textFontBold));
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		String dsoTotalByRegionSegmentStatus = "";
		if (currentBillingTotalByRegionSegmentStatus == 0 && totalDueAmtByRegionSegmentStatus == 0) {
			dsoTotalByRegionSegmentStatus = "-nan(ind)";
		} else if (currentBillingTotalByRegionSegmentStatus == 0) {
			dsoTotalByRegionSegmentStatus = "-inf";
		} else {
			double computedValue = Math.round((totalDueAmtByRegionSegmentStatus / currentBillingTotalByRegionSegmentStatus) * 30);
			dsoTotalByRegionSegmentStatus =  String.format("%.0f", computedValue);
		}

		PdfPCell cell11 = new PdfPCell(new Paragraph(dsoTotalByRegionSegmentStatus, textFontBold));
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		table.addCell(emptyCells);
		table.addCell(cell2);
		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);

		document.add(table);

	}

	private void addStatusSumTableHeader(Document document, String segment) throws DocumentException {

		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		LineSeparator thickLine = new LineSeparator();
		thickLine.setLineWidth(2);
		thickLine.setOffset(-4);
		PdfPCell lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(10);
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Total for " + segment, textFontBold));
		totalCustCell.setColspan(10);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);

	}

	private void addCustomerRegionSumTableHeader(Document document, String customerName) throws DocumentException {
		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		LineSeparator thickLine = new LineSeparator();
		thickLine.setLineWidth(2);
		thickLine.setOffset(-4);
		PdfPCell lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(10);
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Total for " + customerName, textFontBold));
		totalCustCell.setColspan(10);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);

	}

	private void addRegionSumTableHeader(Document document, String regionName) throws DocumentException {
		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		LineSeparator thickLine = new LineSeparator();
		thickLine.setLineWidth(1);
		thickLine.setOffset(-4);
		PdfPCell lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(10);
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Total for " + regionName, textFontBold));
		totalCustCell.setColspan(10);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);

	}

	private void addRegionSumTableBody(Document document) throws DocumentException {

		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setBorder(Rectangle.NO_BORDER);

		PdfPCell cell2 = new PdfPCell(new Paragraph("$" + nf.format(currentBillingTotalByRegionSegment), textFontBold));
		cell2.setBorder(Rectangle.NO_BORDER);
		cell2.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell3 = new PdfPCell(new Paragraph("$" + nf.format(currentBalanceTotalByRegionSegment), textFontBold));
		cell3.setBorder(Rectangle.NO_BORDER);
		cell3.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell4 = new PdfPCell(new Paragraph("$" + nf.format(pastDue30AmtTotalByRegionSegment), textFontBold));
		cell4.setBorder(Rectangle.NO_BORDER);
		cell4.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell5 = new PdfPCell(new Paragraph("$" + nf.format(pastDue60AmtTotalByRegionSegment), textFontBold));
		cell5.setBorder(Rectangle.NO_BORDER);
		cell5.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell6 = new PdfPCell(new Paragraph("$" + nf.format(pastDue90AmtTotalByRegionSegment), textFontBold));
		cell6.setBorder(Rectangle.NO_BORDER);
		cell6.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell7 = new PdfPCell(new Paragraph("$" + nf.format(pastDue120AmtTotalByRegionSegment), textFontBold));
		cell7.setBorder(Rectangle.NO_BORDER);
		cell7.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell8 = new PdfPCell(new Paragraph("$" + nf.format(pastDueAmtTotalByRegionSegment), textFontBold));
		cell8.setBorder(Rectangle.NO_BORDER);
		cell8.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell9 = new PdfPCell(new Paragraph("$" + nf.format(totalDueAmtByRegionSegment), textFontBold));
		cell9.setBorder(Rectangle.NO_BORDER);
		cell9.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		PdfPCell cell10 = new PdfPCell(new Paragraph("$" + nf.format(disputeTotalByRegionSegment), textFontBold));
		cell10.setBorder(Rectangle.NO_BORDER);
		cell10.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);


		String dsoTotalByRegionSegment = "";
		if (currentBillingTotalByRegionSegment == 0 && totalDueAmtByRegionSegment == 0) {
			dsoTotalByRegionSegment = "-nan(ind)";
		} else if (currentBillingTotalByRegionSegment == 0) {
			dsoTotalByRegionSegment = "-inf";
		} else {
			double computedValue = Math.round((totalDueAmtByRegionSegment / currentBillingTotalByRegionSegment) * 30);
			dsoTotalByRegionSegment =  String.format("%.0f", computedValue);
		}

		PdfPCell cell11 = new PdfPCell(new Paragraph(dsoTotalByRegionSegment, textFontBold));
		cell11.setBorder(Rectangle.NO_BORDER);
		cell11.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

		table.addCell(emptyCells);
		table.addCell(cell2);
		table.addCell(cell3);
		table.addCell(cell4);
		table.addCell(cell5);
		table.addCell(cell6);
		table.addCell(cell7);
		table.addCell(cell8);
		table.addCell(cell9);
		table.addCell(cell10);
		table.addCell(cell11);

		document.add(table);

		/*
		 * Add sum at customer level for all regions
		 */
		currentBillingTotalByRegion += currentBillingTotalByRegionSegment;
		currentBalanceTotalByRegion += currentBalanceTotalByRegionSegment;
		pastDue30AmtTotalByRegion += pastDue30AmtTotalByRegionSegment;
		pastDue60AmtTotalByRegion += pastDue60AmtTotalByRegionSegment;
		pastDue90AmtTotalByRegion += pastDue90AmtTotalByRegionSegment;
		pastDue120AmtTotalByRegion += pastDue120AmtTotalByRegionSegment;
		pastDueAmtTotalByRegion += pastDueAmtTotalByRegionSegment;
		totalDueAmtByRegion += totalDueAmtByRegionSegment;
		disputeTotalByRegion += disputeTotalByRegionSegment;

	}

	private void addGrandSumTableHeader(Document document) throws DocumentException {
		PdfPTable table = new PdfPTable(11);

		float[] columnWidths = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

		table.setWidths(columnWidths);
		table.setTotalWidth(1200);
		table.setLockedWidth(true);

		PdfPCell emptyCells = new PdfPCell(new Paragraph(new Chunk(" ")));
		emptyCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(emptyCells);

		LineSeparator thickLine = new LineSeparator();
		thickLine.setLineWidth(2);
		thickLine.setOffset(-4);
		PdfPCell lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(10);
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		// Add second line for grand total
		table.addCell(emptyCells);
		thickLine = new LineSeparator();
		thickLine.setLineWidth(2);
		thickLine.setOffset(6);
		lineCells = new PdfPCell(new Paragraph(new Chunk(thickLine)));
		lineCells.setColspan(10);
		lineCells.setBorder(Rectangle.NO_BORDER);
		table.addCell(lineCells);

		table.addCell(emptyCells);
		PdfPCell totalCustCell = new PdfPCell(new Paragraph("Grand Total ", textFontBold));
		totalCustCell.setColspan(10);
		totalCustCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(totalCustCell);

		document.add(table);

	}

}

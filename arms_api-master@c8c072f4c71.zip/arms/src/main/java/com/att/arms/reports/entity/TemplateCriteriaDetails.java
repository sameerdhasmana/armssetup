package com.att.arms.reports.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Entity
@IdClass(TemplateCriteriaDetails.TemplateCriteriaId.class)
@Data
public class TemplateCriteriaDetails {

	
	@Column(name = "user_login_cd")
	private String userLoginCd;
	@Id	
	@Column(name = "rpt_type")
	private String reportType;
	
	@Id	
	@Column(name = "rpt_name")
	private String reportName;
	
	@JsonIgnore
	@Column(name = "rpt_acct_stat")
	private String reportStatusClause;
	@Transient
	private List<String> statusClause;
	
	@JsonIgnore
	@Column(name = "rpt_bus_unit")
	private String reportBusinessGroup;
	@Transient
	private List<String> businessGroup;
	
	@Column(name = "rpt_originating_company")
	private String originatingCompanyCdClause;
	
	@Column(name = "rpt_cust_ctc_ind")
	private String customerChildFlag;
	
	@JsonIgnore
	@Column(name = "rpt_cust_ctc_list")
	private String reportCustomerGrpCd;
	@Transient
	private List<String> customerGrpCd;
	
	@JsonIgnore
	@Column(name = "rpt_segment_cd")
	private String reportSegment;
	@Transient
	private List<String> segment;
	
	@Column(name = "rpt_excl_incl")
	private String exclusions;
	@JsonIgnore
	@Column(name = "rpt_class_cd")
	private String reportExclusionClass;
	@Transient
	private List<String> exclusionClass;
	
	
	@JsonIgnore
	@Column(name = "rpt_orig_sys")
	private String reportOriginatingSystem;
	@Transient
	private List<String> originatingSystem;
	
	@JsonIgnore
	@Column(name = "rpt_tmplt_fields")
	private String reportTemplateFields;
	@Transient
	private List<String> templateSelectedFields;
	
	
	@JsonIgnore
	@Column(name = "rpt_tmplt_group_by")
	private String reportGroupByFields;
	@Transient
	private List<String> groupByFields;
	
	
	@JsonIgnore
	@Column(name = "rpt_tmplt_sort")
	private String reportSortByFields;
	@Transient
	private List<String> sortByFields;
	
	@Column(name = "rpt_tmplt_sort_order")
	private String sortOrder;
	
	@JsonIgnore
	@Column(name = "rpt_tmplt_criteria")
	private String reportCriteriaClause;
	@Transient
	private List<String> criteriaClause;


	@SuppressWarnings("serial")
	@Data
	public static class TemplateCriteriaId implements Serializable {

		private String reportType;
		private String reportName;
		private String userLoginCd;		
	}

}

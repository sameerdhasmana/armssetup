package com.att.arms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class MaintenanceContactDetails {

	@Id
	private Integer sequence;
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	private Integer priority;
	@JsonProperty("first_name")
	@Column(name="first_name")
	private String firstName;
	@JsonProperty("last_name")
	@Column(name="last_name")
	private String lastName;
	private String title;
	private String phone;
	private String extension;
	@JsonProperty("fax_number")
	@Column(name="fax_number")
	private String faxNumber;
	private String email;
	private String address;
	private String city;
	private String state;
	private String zip;
	private String notes;
	@JsonProperty("insert_date")
	@Column(name="insert_date")
	private Date insertDate;
	@JsonProperty("update_date")
	@Column(name="update_date")
	private Date updateDate;
	@JsonProperty("contacts_id")
	@Column(name="contacts_id")
	private Integer contactsId;

}

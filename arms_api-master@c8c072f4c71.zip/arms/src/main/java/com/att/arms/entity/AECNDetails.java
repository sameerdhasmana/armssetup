package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(AECNDetails.AECNDetailsId.class)
@Data
public class AECNDetails {

	@Id
	@JsonProperty("customer_grp_cd")
	@Column(name = "customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("customer_legal_nm")
	@Column(name = "customer_legal_nm")
	private String customerLegalNm;
	@Id
	@JsonProperty("aecn_cd")
	@Column(name = "aecn_cd")
	private String aecnCd;
	
	@SuppressWarnings("serial")
	@Data
	public static class AECNDetailsId implements Serializable {

		private String customerGrpCd;
		private String aecnCd;
	}

}

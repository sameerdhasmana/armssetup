package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface SegmentPdfReportService {

	ByteArrayInputStream searchByCustomer(UserDetails requestModel, Map<Object, Object> responseMap);
	
	ByteArrayInputStream searchByRegion(UserDetails requestModel, Map<Object, Object> responseMap);
	
}

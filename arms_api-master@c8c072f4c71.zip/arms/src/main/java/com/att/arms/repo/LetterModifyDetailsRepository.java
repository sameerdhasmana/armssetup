package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.LetterModifyDetails;

@Transactional
public interface LetterModifyDetailsRepository extends JpaRepository<LetterModifyDetails, String> {

	@Query(value = "Exec arms_letter_profile_details :letter_profiles_id", nativeQuery = true)
	public List<LetterModifyDetails> fetchModifyLetterDetails(@Param("letter_profiles_id") Integer letterProfilesId);

	@Query(value = "Exec arms_letter_profile_field_select :letter_profiles_id", nativeQuery = true)
	public List<String> fetchLetterProfileFieldList(@Param("letter_profiles_id") Integer letterProfilesId);
}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.OutstandingBringUp;

@Transactional
public interface OutstandingBringUpRepository extends JpaRepository<OutstandingBringUp, String> {

	@Query(value = "exec arms_rpt_outstanding_bring_ups :managerLoginCd", nativeQuery = true)
	public List<OutstandingBringUp> outstandingBringUp(@Param("managerLoginCd") String managerLoginCd);

}

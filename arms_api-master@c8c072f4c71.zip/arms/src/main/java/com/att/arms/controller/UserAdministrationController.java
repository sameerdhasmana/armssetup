package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.UserAdministrationService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class UserAdministrationController {

	@Autowired
	UserAdministrationService userAdministrationService;

	@PostMapping("maintenanceUsers")
	public ResponseEntity<Object> getMaintenanceUsers(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = this.userAdministrationService.getMaintenanceUsers(userDetails, responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("userAdminReports")
	public ResponseEntity<Object> getUserAdminReports(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = this.userAdministrationService.getUserAdminReports(userDetails, responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("adminRoleList")
	public ResponseEntity<Object> getAdminRoleList() {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = this.userAdministrationService.getAdminRoleList( responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.NotesTemplate;

@Transactional
public interface NotesTemplateRepository extends JpaRepository<NotesTemplate, String> {

	@Query(value = "exec arms_ntstmplt_list_v22 :userLoginCd", nativeQuery = true)
	public List<NotesTemplate> getNotesTemplateList(@Param("userLoginCd") String userLoginCd);

	@Query(value = "exec arms_ntstmplt_delete_v20 :userLoginCd,:templateName,:templateType", nativeQuery = true)
	public String deleteNoteTemplate(@Param("userLoginCd") String userLoginCd,
			@Param("templateName") String templateName, @Param("templateType") String templateType);

	@Query(value = "exec arms_ntstmplt_isrt_updt_v20 :userLoginCd,:templateName,:templateType,"
			+ ":templateOwner,:templateNote,:templateH1Logins", nativeQuery = true)
	public String saveNoteTemplate(@Param("userLoginCd") String userLoginCd, @Param("templateName") String templateName,
			@Param("templateType") String templateType, @Param("templateOwner") String templateOwner,
			@Param("templateNote") String templateNote, @Param("templateH1Logins") String templateH1Logins);

}

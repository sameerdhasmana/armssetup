package com.att.arms.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(CustomerAgedDetails.CustomerAgedDetailsId.class)
@Data
public class CustomerAgedDetails {

	@Id
	@JsonProperty("account_number")
	@Column(name="account_number")
	private String accountNumber;
	private String seg;
	@JsonProperty("check_digit")
	@Column(name="check_digit")
	private String checkDigit;
	private String acna;
	private String aecn;
	private String ocn;
	private String status;
	@JsonProperty("current_billing_amt")
	@Column(name="current_billing_amt")
	private Double currentBillingAmt;
	@JsonProperty("current_balance_amt")
	@Column(name="current_balance_amt")
	private Double currentBalanceAmt;
	@JsonProperty("past_due_amt")
	@Column(name="past_due_amt")
	private Double pastDueAmt;
	@JsonProperty("dispute_amt")
	@Column(name="dispute_amt")
	private Double disputeAmt;
	private Double collectable;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("bill_date")
	@Column(name="bill_date")
	private Date billDate;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("final_bill_date")
	@Column(name="final_bill_date")
	private Date finalBillDate;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("write_off_date")
	@Column(name="write_off_date")
	private Date writeOffDate;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("last_payment_date")
	@Column(name="last_payment_date")
	private Date lastPaymentDate;
	@JsonProperty("last_payment_amt")
	@Column(name="last_payment_amt")
	private Double lastPaymentAmt;
	@JsonProperty("payment_applied_amt")
	@Column(name="payment_applied_amt")
	private Double paymentAppliedAmt;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("last_adjustment_date")
	@Column(name="last_adjustment_date")
	private Date lastAdjustmentDate;
	@JsonProperty("last_adjustment_amt")
	@Column(name="last_adjustment_amt")
	private Double lastAdjustmentAmt;
	@JsonProperty("adjustment_applied_amt")
	@Column(name="adjustment_applied_amt")
	private Double adjustmentAppliedAmt;
	@JsonProperty("total_nd_amt")
	@Column(name="total_nd_amt")
	private Double totalNdAmt;
	@JsonProperty("past_due_30_amt")
	@Column(name="past_due_30_amt")
	private Double pastDue30Amt;
	@JsonProperty("past_due_60_amt")
	@Column(name="past_due_60_amt")
	private Double pastDue60Amt;
	@JsonProperty("past_due_90_amt")
	@Column(name="past_due_90_amt")
	private Double pastDue90Amt;
	@JsonProperty("past_due_120_amt")
	@Column(name="past_due_120_amt")
	private Double pastDue120Amt;
	@JsonProperty("ap_sub_grp_nm")
	@Column(name="ap_sub_grp_nm")
	private String apSubGrpNm;
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("state_cd")
	@Column(name="state_cd")
	private String stateCd;
	@JsonProperty("total_amt")
	@Column(name="total_amt")
	private Double totalAmt;
	@JsonProperty("class_cd")
	@Column(name="class_cd")
	private Integer classCd;
	@JsonProperty("billing_period_stop_copy_forward")
	@Column(name="billing_period_stop_copy_forward")
	private String billingPeriodStopCopyForward;
	@JsonProperty("class_desc")
	@Column(name="class_desc")
	private String classDesc;
	private Integer excluded;
	@JsonProperty("notes_exists")
	@Column(name="notes_exists")
	private Integer notesExists;
	@JsonProperty("billing_period")
	@Column(name="billing_period")
	private String billingPeriod;
	@JsonProperty("customer_legal_nm")
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	@Id
	@JsonProperty("originating_system")
	@Column(name="originating_system")
	private String originatingSystem;
	@JsonProperty("bill_name")
	@Column(name="bill_name")
	private String billName;
	private String region;
	@JsonProperty("macna_cd")
	@Column(name="macna_cd")
	private String macnaCd;
	private String zbu;
	@JsonProperty("promo_cr")
	@Column(name="promo_cr")
	private Double promoCr;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("last_dt_worked")
	@Column(name="last_dt_worked")
	private Date lastDtWorked;
	@JsonProperty("collections_userid")
	@Column(name="collections_userid")
	private String collectionsUserid;
	@JsonProperty("payment_terms")
	@Column(name="payment_terms")
	private String paymentTerms;
	@JsonProperty("email_or_mail")
	@Column(name="email_or_mail")
	private String emailOrMail;
	@JsonProperty("mail_merge_eligible")
	@Column(name="mail_merge_eligible")
	private String mailMergeEligible;
	@JsonProperty("invoice_billed")
	@Column(name="invoice_billed")
	private String invoiceBilled;
	@JsonProperty("age_0_30")
	@Column(name="age_0_30")
	private Integer age030;
	@JsonProperty("age_31_60")
	@Column(name="age_31_60")
	private Integer age3160;
	@JsonProperty("age_61_90")
	@Column(name="age_61_90")
	private Integer age6190;
	@JsonProperty("age_91_120")
	@Column(name="age_91_120")
	private Integer age91120;
	@JsonProperty("sub_activity_cd")
	@Column(name="sub_activity_cd")
	private String subActivityCd;
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date nextcall;
	@JsonProperty("flag_age")
	@Column(name="flag_age")
	private Integer flagAge;
	@JsonProperty("flag_activity")
	@Column(name="flag_activity")
	private String flagActivity;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("flag_activity_date")
	@Column(name="flag_activity_date")
	private Date flagActivityDate;
	@JsonProperty("customer_name")
	@Column(name="customer_name")
	private String customerName;
	@JsonProperty("bill_name_cx")
	@Column(name="bill_name_cx")
	private String billNameCx;
	@JsonProperty("bill_address_2")
	@Column(name="bill_address_2")
	private String billAddress2;
	@JsonProperty("bill_address_3")
	@Column(name="bill_address_3")
	private String billAddress3;
	@JsonProperty("bill_address_4")
	@Column(name="bill_address_4")
	private String billAddress4;
	@JsonProperty("bill_city")
	@Column(name="bill_city")
	private String billCity;
	@JsonProperty("bill_state")
	@Column(name="bill_state")
	private String billState;
	@JsonProperty("bill_zip")
	@Column(name="bill_zip")
	private String billZip;
	@JsonProperty("contact_name")
	@Column(name="contact_name")
	private String contactName;
	@JsonProperty("contact_tn")
	@Column(name="contact_tn")
	private String contactTn;
	@JsonProperty("contact_email")
	@Column(name="contact_email")
	private String contactEmail;
	@JsonProperty("amt_60")
	@Column(name="amt_60")
	private Double amt60;
	@JsonProperty("amt_90")
	@Column(name="amt_90")
	private Double amt90;
	@JsonProperty("unapplied_amt")
	@Column(name="unapplied_amt")
	private Double unappliedAmt;
	private String ctc;
	private String svid;
	@JsonProperty("svid_name")
	@Column(name="svid_name")
	private String svidName;
	@JsonProperty("next_action")
	@Column(name="next_action")
	private String nextAction;
	private String emaor;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("emaor_eff_dt")
	@Column(name="emaor_eff_dt")
	private Date emaorEffDt;
	@JsonProperty("emaor_cnt")
	@Column(name="emaor_cnt")
	private Integer emaorCnt;
	@JsonProperty("biller_status")
	@Column(name="biller_status")
	private String billerStatus;
	@JsonProperty("hot_note")
	@Column(name="hot_note")
	private String hotNote;
	@JsonProperty("avg_age")
	@Column(name="avg_age")
	private Integer avgAge;
	@JsonProperty("commitment_amt")
	@Column(name="commitment_amt")
	private Double commitmentAmt;
	@JsonProperty("contested_charges")
	@Column(name="contested_charges")
	private Double contestedCharges;
	@JsonProperty("root_cause")
	@Column(name="root_cause")
	private String rootCause;
	@JsonProperty("collectable_pd")
	@Column(name="collectable_pd")
	private Double collectablePd;
	@JsonProperty("past_due")
	@Column(name="past_due")
	private Double pastDue;

	@SuppressWarnings("serial")
	@Data
	public static class CustomerAgedDetailsId implements Serializable {

		private String accountNumber;
		private String originatingSystem;
		
	}
}

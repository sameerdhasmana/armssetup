package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(AccountSearch.AccountSearchId.class)
@Data
public class AccountSearch {
	
	@Id
	@JsonProperty("account_number")
	@Column(name="acct_nbr")
	private String acctNbr;
	@JsonProperty("zbu")
	private String fan;
	private String svid;
	@JsonProperty("customer_name")
	@Column(name="cust_name")
	private String custName;
	@Id
	@JsonProperty("originating_system")
	private String system;
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("user_msg")
	@Column(name="user_msg")
	private String userMsg;
	
	@SuppressWarnings("serial")
	@Data
	public static class AccountSearchId implements Serializable {

		private String acctNbr;
		private String system;
		
	}

}

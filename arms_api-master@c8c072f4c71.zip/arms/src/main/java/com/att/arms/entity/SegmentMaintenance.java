package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class SegmentMaintenance {
	@Id
	@Column(name = "segment")
	private String segment;
	@Column(name = "description")
	private String description;
	@Column(name = "segmentGroup")
	private String segmentGroup;
	@Column(name = "businessUnit")
	private String businessUnit;
	@Column(name = "excludeWebTaxiFlag")
	private String excludeWebTaxiFlag;
}

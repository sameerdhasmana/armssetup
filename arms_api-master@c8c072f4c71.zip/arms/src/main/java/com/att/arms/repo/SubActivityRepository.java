package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.SubActivity;

@Transactional
public interface SubActivityRepository extends JpaRepository<SubActivity, String> {

	@Query(value = "select sub_activity_cd,sub_activity_short_description from "
			+ "sub_activities where sub_activity_type = :activityType and day is NULL order by 2", nativeQuery = true)
	public List<SubActivity> getSubActivityList(@Param("activityType") String activityType);
	
	@Query(value = "exec arms_account_notes_sub_activity_cb_v22 :accountNumber,:originatingSystem", nativeQuery = true)
	public List<SubActivity> getAccountSubActivityList(@Param("accountNumber") String accountNumber,@Param("originatingSystem") String originatingSystem);
	
	@Query(value = "EXEC arms_profmgt_flagact_list_v19 '','','','','','','' ", nativeQuery = true)
	public List<SubActivity> getManageProfileSubActivityList();

}

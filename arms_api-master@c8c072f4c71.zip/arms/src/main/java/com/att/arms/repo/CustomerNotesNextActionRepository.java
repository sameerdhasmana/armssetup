package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerNotesNextAction;

@Transactional
public interface CustomerNotesNextActionRepository extends JpaRepository<CustomerNotesNextAction, String> {

	@Query(value = "Exec arms_account_notes_next_action_cb_v19 :userLoginCd", nativeQuery = true)
	public List<CustomerNotesNextAction> getCustomerNotesNextAction(@Param("userLoginCd") String userLoginCd);
	

}

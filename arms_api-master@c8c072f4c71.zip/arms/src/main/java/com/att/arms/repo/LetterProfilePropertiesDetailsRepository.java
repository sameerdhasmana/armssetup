package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.LetterProfilePropertiesDetails;

@Transactional
public interface LetterProfilePropertiesDetailsRepository extends JpaRepository<LetterProfilePropertiesDetails, Integer> {

	@Query(value = "Exec arms_letter_profile_field_properties_details :letter_profiles_field_properties_id", nativeQuery = true)
	public List<LetterProfilePropertiesDetails> getLetterPropertyDetails(
			@Param("letter_profiles_field_properties_id") String letterProfilesFieldPropertiesId);

}

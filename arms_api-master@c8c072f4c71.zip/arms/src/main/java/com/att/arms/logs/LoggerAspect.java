package com.att.arms.logs;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@Aspect
@Configuration
public class LoggerAspect {

	private static final Logger log = LogManager.getLogger(LoggerAspect.class);
	

	@Pointcut(value = "execution(* com.att.arms.controller.*.*(..) )")
	public void armsApp() {

	}
	
	@Around("armsApp()")
	public Object applicationLogger(ProceedingJoinPoint joinpoint) throws Throwable {
		log.debug("Request for {}.{}()",joinpoint.getSignature().getDeclaringTypeName(), 
				joinpoint.getSignature().getName());
		
		ObjectMapper mapper = new ObjectMapper();
		JavaTimeModule module = new JavaTimeModule();
		mapper.registerModule(module);
		
		String methodName = joinpoint.getSignature().getName();
		String className = joinpoint.getTarget().getClass().toString();
		
		Instant start = Instant.now();
		Object returnValue = joinpoint.proceed();
		log.info("Request for {}.{}" , className , methodName);
		
		
		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis();
		String duration=new SimpleDateFormat("ss:SSS").format(new Date(timeElapsed));
		log.info("Request for {}.{}() Execution Time={}",joinpoint.getSignature().getDeclaringTypeName(), joinpoint.getSignature().getName() ,duration);
		return returnValue;
	}

	
	@AfterThrowing(pointcut = "armsApp()",throwing = "e")
	public void logAfterThrowing(JoinPoint joinpoint, Throwable e) {
		log.error("Exception in {}.{} with cause = {} , with message = {}",
				joinpoint.getSignature().getDeclaringTypeName(),joinpoint.getSignature().getName(),
				e.getCause() !=null ? e.getCause() : "NULL",
				e.getMessage() !=null ? e.getMessage() : "NULL"
				);
	}
}

package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.SummaryReportByCustomerResponseModel;
import com.att.arms.reports.entity.SummaryReportByCustomerStatusResponseModel;
import com.att.arms.reports.entity.SummaryReportBySegmentResponseModel;
import com.att.arms.reports.entity.SummaryReportByStateResponseModel;
import com.att.arms.reports.repo.SummaryReportByCustomerRepository;
import com.att.arms.reports.repo.SummaryReportByCustomerStatusRepository;
import com.att.arms.reports.repo.SummaryReportBySegmentRepository;
import com.att.arms.reports.repo.SummaryReportByStateRepository;
import com.att.arms.utils.CommonReportsUtils;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class SummaryPdfReportServiceImpl implements SummaryPdfReportService{

	@Autowired 
	SummaryReportByCustomerRepository summaryReportByCustomerRepository;
	
	@Autowired 
	SummaryReportByCustomerStatusRepository summaryReportByCustomerStatusRepository;
	
	@Autowired 
	SummaryReportBySegmentRepository summaryReportBySegmentRepository;
	
	@Autowired 
	SummaryReportByStateRepository summaryReportByStateRepository;
	
	private static final Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 13, Font.BOLD,BaseColor.BLACK);

	//byCustomer
	@Override
	public ByteArrayInputStream searchByCustomer(UserDetails requestModel, Map<Object, Object> responseMap) {
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
			
			PdfWriter writer = PdfWriter.getInstance(document,
				new FileOutputStream("SummaryReportByCustomer" + requestModel.getUserLoginCd()+ ".pdf"));
			document.setPageSize(rectangle);
			SegmentHeaderFooterPageEvent event = new SegmentHeaderFooterPageEvent();
			event.setHeader(requestModel, "summary", "byCustomer");
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);
			
			List<SummaryReportByCustomerResponseModel> response = summaryReportByCustomerRepository.byCustomer(
					requestModel.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
					requestModel.getExclusions(), 
					"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
					requestModel.getCustomerChidFlag());
				
			if(response != null) {
				populatePdfGroupingByCustomer(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Records Found");
			}

			document.close();
			writer.close();

			Path path = Paths.get("SummaryReportByCustomer" + requestModel.getUserLoginCd()+ ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	//by Customer
	private void populatePdfGroupingByCustomer(Document document, List<SummaryReportByCustomerResponseModel> response) throws DocumentException {
			BigDecimal currentBilling = BigDecimal.ZERO;
			BigDecimal currentBalance = BigDecimal.ZERO;
			BigDecimal pastDue30AmtTotalByCustomer = BigDecimal.ZERO;
			BigDecimal pastDue60AmtTotalByCustomer = BigDecimal.ZERO;
			BigDecimal pastDue90AmtTotalByCustomer = BigDecimal.ZERO;
			BigDecimal pastDue120AmtTotalByCustomer = BigDecimal.ZERO;
			BigDecimal pastDueAmtTotalByCustomer = BigDecimal.ZERO;
			BigDecimal totalDueAmtByCustomer = BigDecimal.ZERO;
			BigDecimal disputeTotalByCustomer = BigDecimal.ZERO;
			BigDecimal dsoTotalByCustomer = BigDecimal.ZERO;
			
			Paragraph empty = new Paragraph(" ");
			empty.setLeading(30f);
			document.add(empty);
			
				for(SummaryReportByCustomerResponseModel customerRow: response)
				 {
					PdfPTable table = new PdfPTable(11);
					float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
					table.setWidths(columnWidths);
					table.setTotalWidth(1145);
					table.setLockedWidth(true);
					table.getDefaultCell().setFixedHeight(100);
					table.getDefaultCell().setBorder(Rectangle.TOP);
					table.getDefaultCell().setBorderColor(BaseColor.BLACK);

					PdfPCell cell3 = new PdfPCell(new Paragraph(customerRow.getCustomer()));
					cell3.setBorder(Rectangle.NO_BORDER);
					cell3.disableBorderSide(0);
					cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
					cell3.setVerticalAlignment(Element.ALIGN_LEFT);
					cell3.setPaddingBottom(5f);
					
					PdfPCell cell4 = new PdfPCell(
							new Paragraph("" + customerRow.getCurrentBillingAmount().setScale(2, RoundingMode.HALF_UP)));
					cell4.setBorder(Rectangle.NO_BORDER);
					cell4.disableBorderSide(0);
					cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell4.setPaddingBottom(5f);
					currentBilling = currentBilling.add(customerRow.getCurrentBillingAmount());
					
					PdfPCell cell5 = new PdfPCell(
							new Paragraph("" + customerRow.getPastDue0Amount().setScale(2, RoundingMode.HALF_UP)));
					cell5.setBorder(Rectangle.NO_BORDER);
					cell5.disableBorderSide(0);
					cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell5.setPaddingBottom(5f);
					currentBalance = currentBalance.add(customerRow.getPastDue0Amount());

					PdfPCell cell6 = new PdfPCell(
							new Paragraph("" +customerRow.getPastDue30Amount().setScale(2, RoundingMode.HALF_UP)));
					cell6.setBorder(Rectangle.NO_BORDER);
					cell6.disableBorderSide(0);
					cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell6.setPaddingBottom(5f);
					pastDue30AmtTotalByCustomer = pastDue30AmtTotalByCustomer.add(customerRow.getPastDue30Amount());

					PdfPCell cell7 = new PdfPCell(
							new Paragraph("" + customerRow.getPastDue60Amount().setScale(2, RoundingMode.HALF_UP)));
					cell7.setBorder(Rectangle.NO_BORDER);
					cell7.disableBorderSide(0);
					cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell7.setPaddingBottom(5f);
					pastDue60AmtTotalByCustomer = pastDue60AmtTotalByCustomer.add(customerRow.getPastDue60Amount());
					
					PdfPCell cell8 = new PdfPCell(
							new Paragraph("" + customerRow.getPastDue90Amount().setScale(2, RoundingMode.HALF_UP)));
					cell8.setBorder(Rectangle.NO_BORDER);
					cell8.disableBorderSide(0);
					cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell8.setPaddingBottom(5f);
					pastDue90AmtTotalByCustomer= pastDue90AmtTotalByCustomer.add(customerRow.getPastDue90Amount());

					PdfPCell cell9 = new PdfPCell(
							new Paragraph("" + customerRow.getPastDue120Amount().setScale(2, RoundingMode.HALF_UP)));
					cell9.setBorder(Rectangle.NO_BORDER);
					cell9.disableBorderSide(0);
					cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell9.setPaddingBottom(5f);
					pastDue120AmtTotalByCustomer= pastDue120AmtTotalByCustomer.add(customerRow.getPastDue120Amount());	

					PdfPCell cell10 = new PdfPCell(
							new Paragraph("" + customerRow.getTotalPastDueAmount().setScale(2, RoundingMode.HALF_UP)));
					cell10.setBorder(Rectangle.NO_BORDER);
					cell10.disableBorderSide(0);
					cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell10.setPaddingBottom(5f);
					pastDueAmtTotalByCustomer= pastDueAmtTotalByCustomer.add(customerRow.getTotalPastDueAmount());

					PdfPCell cell11 = new PdfPCell(
							new Paragraph("" + customerRow.getTotalAmount().setScale(2, RoundingMode.HALF_UP)));
					cell11.setBorder(Rectangle.NO_BORDER);
					cell11.disableBorderSide(0);
					cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell11.setPaddingBottom(5f);
					totalDueAmtByCustomer= totalDueAmtByCustomer.add(customerRow.getTotalAmount());

					PdfPCell cell12 = new PdfPCell(
							new Paragraph("" + customerRow.getDispute().setScale(2, RoundingMode.HALF_UP)));
					cell12.setBorder(Rectangle.NO_BORDER);
					cell12.disableBorderSide(0);
					cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell12.setPaddingBottom(5f);
					disputeTotalByCustomer= disputeTotalByCustomer.add(customerRow.getDispute());

					PdfPCell cell13 = new PdfPCell(
							new Paragraph("" + customerRow.getDso().setScale(2,RoundingMode.HALF_UP)));
					cell13.setBorder(Rectangle.NO_BORDER);
					cell13.disableBorderSide(0);
					cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell13.setPaddingBottom(5f);
					dsoTotalByCustomer= dsoTotalByCustomer.add(customerRow.getDso());

					table.addCell(cell3);
					table.addCell(cell4);
					table.addCell(cell5);
					table.addCell(cell6);
					table.addCell(cell7);
					table.addCell(cell8);
					table.addCell(cell9);
					table.addCell(cell10);
					table.addCell(cell11);
					table.addCell(cell12);
					table.addCell(cell13);

					document.add(table);
				}
				
				PdfPTable table = new PdfPTable(11);
					
					float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
					table.setWidths(columnWidthsForOverallTotal);
					table.setTotalWidth(1145);
					table.setLockedWidth(true);
					table.getDefaultCell().setFixedHeight(100);
					table.getDefaultCell().setBorder(Rectangle.TOP);
					table.getDefaultCell().setBorderColor(BaseColor.BLACK);
					
					PdfPCell cell3 = new PdfPCell(
							new Paragraph("Grand Total ", boldFont));
					cell3.setBorder(Rectangle.NO_BORDER);
					cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
					cell3.setVerticalAlignment(Element.ALIGN_LEFT);
					cell3.enableBorderSide(Rectangle.TOP);
					cell3.setPaddingBottom(5f);
					
					PdfPCell cell4 = new PdfPCell(
							new Paragraph("" + currentBilling.setScale(2, RoundingMode.HALF_UP)));
					cell4.setBorder(Rectangle.NO_BORDER);
					cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell4.enableBorderSide(Rectangle.TOP);
					cell4.setPaddingBottom(5f);
					
					PdfPCell cell5 = new PdfPCell(
							new Paragraph("" + currentBalance.setScale(2, RoundingMode.HALF_UP)));
					cell5.setBorder(Rectangle.NO_BORDER);
					cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell5.enableBorderSide(Rectangle.TOP);
					cell5.setPaddingBottom(5f);
					
					PdfPCell cell6 = new PdfPCell(
							new Paragraph("" + pastDue30AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
					cell6.setBorder(Rectangle.NO_BORDER);
					cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell6.enableBorderSide(Rectangle.TOP);
					cell6.setPaddingBottom(5f);
					
					PdfPCell cell7 = new PdfPCell(
							new Paragraph("" + pastDue60AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
					cell7.setBorder(Rectangle.NO_BORDER);
					cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell7.enableBorderSide(Rectangle.TOP);
					cell7.setPaddingBottom(5f);

					PdfPCell cell8 = new PdfPCell(
							new Paragraph("" + pastDue90AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
					cell8.setBorder(Rectangle.NO_BORDER);
					cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell8.enableBorderSide(Rectangle.TOP);
					cell8.setPaddingBottom(5f);
					
					PdfPCell cell9 = new PdfPCell(
						new Paragraph("" + pastDue120AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
					cell9.setBorder(Rectangle.NO_BORDER);
					cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell9.enableBorderSide(Rectangle.TOP);
					cell9.setPaddingBottom(5f);
					
					PdfPCell cell10 = new PdfPCell(
							new Paragraph("" + pastDueAmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
					cell10.setBorder(Rectangle.NO_BORDER);
					cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell10.enableBorderSide(Rectangle.TOP);
					cell10.setPaddingBottom(5f);
					
					PdfPCell cell11 = new PdfPCell(
							new Paragraph("" + totalDueAmtByCustomer.setScale(2, RoundingMode.HALF_UP)));
					cell11.setBorder(Rectangle.NO_BORDER);
					cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell11.enableBorderSide(Rectangle.TOP);
					cell11.setPaddingBottom(5f);
											
					PdfPCell cell12 = new PdfPCell(
							new Paragraph("" + disputeTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
					cell12.setBorder(Rectangle.NO_BORDER);
					cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell12.enableBorderSide(Rectangle.TOP);
					cell12.setPaddingBottom(5f);
												
					PdfPCell cell13 = new PdfPCell(
							new Paragraph("" + dsoTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
					cell13.setBorder(Rectangle.NO_BORDER);
					cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell13.enableBorderSide(Rectangle.TOP);
					cell13.setPaddingBottom(5f);
					
					table.addCell(cell3);
					table.addCell(cell4);
					table.addCell(cell5);
					table.addCell(cell6);
					table.addCell(cell7);
					table.addCell(cell8);
					table.addCell(cell9);
					table.addCell(cell10);
					table.addCell(cell11);
					table.addCell(cell12);
					table.addCell(cell13);
					document.add(table);
	}

	@Override
	public ByteArrayInputStream searchByCustomerStatus(UserDetails requestModel, Map<Object, Object> responseMap) {
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
			
			PdfWriter writer = PdfWriter.getInstance(document,
				new FileOutputStream("SummaryReportByCustomerStatus" + requestModel.getUserLoginCd()+ ".pdf"));
			document.setPageSize(rectangle);
			SegmentHeaderFooterPageEvent event = new SegmentHeaderFooterPageEvent();
			event.setHeader(requestModel, "summary", "byCustomerStatus");
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);
			
			List<SummaryReportByCustomerStatusResponseModel> response = summaryReportByCustomerStatusRepository.byCustomerStatus(
					requestModel.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
					requestModel.getExclusions(), 
					"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
					requestModel.getCustomerChidFlag());
				
			if(response != null) {
				populatePdfGroupingByCustomerStatus(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Records Found");
			}

			document.close();
			writer.close();

			Path path = Paths.get("SummaryReportByCustomerStatus" + requestModel.getUserLoginCd()+ ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	private void populatePdfGroupingByCustomerStatus(Document document,
			List<SummaryReportByCustomerStatusResponseModel> response) throws DocumentException {
		Map<String, List<SummaryReportByCustomerStatusResponseModel>> summaryByCustomerGroupMap = 
				response.stream()
				.collect(Collectors.groupingBy(summaryReport -> summaryReport.getCustomer()));
		
		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		document.add(empty);
		
		BigDecimal currentBilling = BigDecimal.ZERO;
		BigDecimal currentBalance = BigDecimal.ZERO;
		BigDecimal pastDue30AmtTotalBySummary = BigDecimal.ZERO;
		BigDecimal pastDue60AmtTotalBySummary = BigDecimal.ZERO;
		BigDecimal pastDue90AmtTotalBySummary = BigDecimal.ZERO;
		BigDecimal pastDue120AmtTotalBySummary = BigDecimal.ZERO;
		BigDecimal pastDueAmtTotalBySummary = BigDecimal.ZERO;
		BigDecimal totalDueAmtBySummary = BigDecimal.ZERO;
		BigDecimal disputeTotalBySummary = BigDecimal.ZERO;
		BigDecimal dsoTotalBySummary = BigDecimal.ZERO;
		
		
		for(Map.Entry<String, List<SummaryReportByCustomerStatusResponseModel>> responsePerCustomer: summaryByCustomerGroupMap.entrySet())
		{
			String customer = responsePerCustomer.getKey();
			Paragraph summaryPara = new Paragraph("          "+customer, boldFont);
			summaryPara.setAlignment(Chunk.ALIGN_JUSTIFIED);
			summaryPara.setSpacingAfter(5f);
			
				document.add(summaryPara);
				Map<String, List<SummaryReportByCustomerStatusResponseModel>> perStatusGroupMap = 
						responsePerCustomer.getValue()
						.stream()
						.collect(Collectors.groupingBy(perCustomer -> perCustomer.getStatus()));
				
				for(Map.Entry<String, List<SummaryReportByCustomerStatusResponseModel>> responsePerStatus: perStatusGroupMap.entrySet()) {
					BigDecimal currentBillingPerStatus = BigDecimal.ZERO;
					BigDecimal currentBalancePerStatus = BigDecimal.ZERO;
					BigDecimal pastDue30AmtTotalByStatus = BigDecimal.ZERO;
					BigDecimal pastDue60AmtTotalByStatus = BigDecimal.ZERO;
					BigDecimal pastDue90AmtTotalByStatus = BigDecimal.ZERO;
					BigDecimal pastDue120AmtTotalByStatus = BigDecimal.ZERO;
					BigDecimal pastDueAmtTotalByStatus = BigDecimal.ZERO;
					BigDecimal totalDueAmtByStatus = BigDecimal.ZERO;
					BigDecimal disputeTotalByStatus = BigDecimal.ZERO;
					BigDecimal dsoTotalByStatus = BigDecimal.ZERO;
										
						for(SummaryReportByCustomerStatusResponseModel summaryReportPerStatus: responsePerStatus.getValue()) {
							PdfPTable table = new PdfPTable(11);
								float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
								table.setWidths(columnWidths);
								table.setTotalWidth(1145);
								table.setLockedWidth(true);
								table.getDefaultCell().setFixedHeight(100);
								table.getDefaultCell().setBorder(Rectangle.TOP);
								table.getDefaultCell().setBorderColor(BaseColor.BLACK);

								PdfPCell cell3 = new PdfPCell(new Paragraph(summaryReportPerStatus.getStatus()));
								cell3.setBorder(Rectangle.NO_BORDER);
								cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
								cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell3.disableBorderSide(0);
								cell3.setPaddingBottom(5f);
								
								PdfPCell cell4 = new PdfPCell(
										new Paragraph("" +summaryReportPerStatus.getCurrentBillingAmount().setScale(2, RoundingMode.HALF_UP)));
								cell4.setBorder(Rectangle.NO_BORDER);
								cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell4.disableBorderSide(0);
								cell4.setPaddingBottom(5f);
								currentBillingPerStatus = currentBillingPerStatus.add(summaryReportPerStatus.getCurrentBillingAmount());
								
								PdfPCell cell5 = new PdfPCell(
										new Paragraph("" +summaryReportPerStatus.getPastDue0Amount().setScale(2, RoundingMode.HALF_UP)));
								cell5.setBorder(Rectangle.NO_BORDER);
								cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell5.disableBorderSide(0);
								cell5.setPaddingBottom(5f);
								currentBalancePerStatus = currentBalancePerStatus.add(summaryReportPerStatus.getPastDue0Amount());
								
								PdfPCell cell6 = new PdfPCell(
										new Paragraph("" +summaryReportPerStatus.getPastDue30Amount().setScale(2, RoundingMode.HALF_UP)));
								cell6.setBorder(Rectangle.NO_BORDER);
								cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell6.disableBorderSide(0);
								cell6.setPaddingBottom(5f);
								pastDue30AmtTotalByStatus = pastDue30AmtTotalByStatus.add(summaryReportPerStatus.getPastDue30Amount());
								
								PdfPCell cell7 = new PdfPCell(
										new Paragraph("" +summaryReportPerStatus.getPastDue60Amount().setScale(2,RoundingMode.HALF_UP)));
								cell7.setBorder(Rectangle.NO_BORDER);
								cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell7.disableBorderSide(0);
								cell7.setPaddingBottom(5f);
								pastDue60AmtTotalByStatus = pastDue60AmtTotalByStatus.add(summaryReportPerStatus.getPastDue60Amount());

								PdfPCell cell8 = new PdfPCell(
										new Paragraph("" +summaryReportPerStatus.getPastDue90Amount().setScale(2, RoundingMode.HALF_UP )));
								cell8.setBorder(Rectangle.NO_BORDER);
								cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell8.disableBorderSide(0);
								cell8.setPaddingBottom(5f);
								pastDue90AmtTotalByStatus = pastDue90AmtTotalByStatus.add(summaryReportPerStatus.getPastDue90Amount());

								PdfPCell cell9 = new PdfPCell(
										new Paragraph("" + summaryReportPerStatus.getPastDue120Amount().setScale(2, RoundingMode.HALF_UP )));
								cell9.setBorder(Rectangle.NO_BORDER);
								cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell9.disableBorderSide(0);
								cell9.setPaddingBottom(5f);
								pastDue120AmtTotalByStatus = pastDue120AmtTotalByStatus.add(summaryReportPerStatus.getPastDue120Amount());

								PdfPCell cell10 = new PdfPCell(
									new Paragraph("" +summaryReportPerStatus.getTotalPastDueAmount().setScale(2, RoundingMode.HALF_UP )));
								cell10.setBorder(Rectangle.NO_BORDER);
								cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell10.disableBorderSide(0);
								cell10.setPaddingBottom(5f);
								pastDueAmtTotalByStatus = pastDueAmtTotalByStatus.add(summaryReportPerStatus.getTotalPastDueAmount());

								PdfPCell cell11 = new PdfPCell(
										new Paragraph("" + summaryReportPerStatus.getTotalAmount().setScale(2, RoundingMode.HALF_UP )));
								cell11.setBorder(Rectangle.NO_BORDER);
								cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell11.disableBorderSide(0);
								cell11.setPaddingBottom(5f);
								totalDueAmtByStatus = totalDueAmtByStatus.add(summaryReportPerStatus.getTotalAmount());
								
								PdfPCell cell12 = new PdfPCell(
										new Paragraph("" + (summaryReportPerStatus.getDispute().setScale(2, RoundingMode.HALF_UP))));
								cell12.setBorder(Rectangle.NO_BORDER);
								cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell12.disableBorderSide(0);
								cell12.setPaddingBottom(5f);
								disputeTotalByStatus = disputeTotalByStatus.add(summaryReportPerStatus.getDispute());
								
								PdfPCell cell13 = new PdfPCell(
										new Paragraph("" + summaryReportPerStatus.getDso().setScale(2, RoundingMode.HALF_UP )));
								cell13.setBorder(Rectangle.NO_BORDER);
								cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
								cell13.disableBorderSide(0);
								cell13.setPaddingBottom(5f);
								dsoTotalByStatus = dsoTotalByStatus.add(summaryReportPerStatus.getDso());

								table.addCell(cell3);
								table.addCell(cell4);
								table.addCell(cell5);
								table.addCell(cell6);
								table.addCell(cell7);
								table.addCell(cell8);
								table.addCell(cell9);
								table.addCell(cell10);
								table.addCell(cell11);
								table.addCell(cell12);
								table.addCell(cell13);

								document.add(table);
						}
						
						PdfPTable table = new PdfPTable(11);
							
							float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
							table.setWidths(columnWidthsForOverallTotal);
							table.setTotalWidth(1145);
							table.setLockedWidth(true);
							table.getDefaultCell().setFixedHeight(100);
							table.getDefaultCell().setBorder(Rectangle.TOP);
							table.getDefaultCell().setBorderColor(BaseColor.BLACK);
							
							PdfPCell cell3 = new PdfPCell(
									new Paragraph("Total for "+customer, boldFont));
							cell3.setBorder(Rectangle.NO_BORDER);
							cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
							cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell3.enableBorderSide(Rectangle.TOP);
							cell3.setPaddingBottom(5f);
							
							PdfPCell cell4 = new PdfPCell(
									new Paragraph("" + currentBillingPerStatus.setScale(2, RoundingMode.HALF_UP)));
							cell4.setBorder(Rectangle.NO_BORDER);
							cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell4.enableBorderSide(Rectangle.TOP);
							cell4.setPaddingBottom(5f);
						    currentBilling = currentBillingPerStatus.add(currentBilling);
							
							PdfPCell cell5 = new PdfPCell(
									new Paragraph("" + currentBalancePerStatus.setScale(2, RoundingMode.HALF_UP)));
							cell5.setBorder(Rectangle.NO_BORDER);
							cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell5.enableBorderSide(Rectangle.TOP);
							cell5.setPaddingBottom(5f);
							currentBalance = currentBalance.add(currentBalancePerStatus);
							
							PdfPCell cell6 = new PdfPCell(
									new Paragraph("" + pastDue30AmtTotalByStatus.setScale(2, RoundingMode.HALF_UP)));
							cell6.setBorder(Rectangle.NO_BORDER);
							cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell6.enableBorderSide(Rectangle.TOP);
							cell6.setPaddingBottom(5f);
							pastDue30AmtTotalBySummary = pastDue30AmtTotalBySummary.add(pastDue30AmtTotalByStatus);
							
							PdfPCell cell7 = new PdfPCell(
									new Paragraph("" + pastDue60AmtTotalByStatus.setScale(2, RoundingMode.HALF_UP)));
							cell7.setBorder(Rectangle.NO_BORDER);
							cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell7.enableBorderSide(Rectangle.TOP);
							cell7.setPaddingBottom(5f);
							pastDue60AmtTotalBySummary = pastDue60AmtTotalBySummary.add(pastDue60AmtTotalByStatus);

							PdfPCell cell8 = new PdfPCell(
									new Paragraph("" + pastDue90AmtTotalByStatus.setScale(2, RoundingMode.HALF_UP)));
							cell8.setBorder(Rectangle.NO_BORDER);
							cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell8.enableBorderSide(Rectangle.TOP);
							cell8.setPaddingBottom(5f);
							pastDue90AmtTotalBySummary = pastDue90AmtTotalBySummary.add(pastDue90AmtTotalByStatus);
							
							PdfPCell cell9 = new PdfPCell(
									new Paragraph("" + pastDue120AmtTotalByStatus.setScale(2, RoundingMode.HALF_UP)));
							cell9.setBorder(Rectangle.NO_BORDER);
							cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell9.enableBorderSide(Rectangle.TOP);
							cell9.setPaddingBottom(5f);
							pastDue120AmtTotalBySummary = pastDue120AmtTotalBySummary.add(pastDue120AmtTotalByStatus);
							
							PdfPCell cell10 = new PdfPCell(
									new Paragraph("" + pastDueAmtTotalByStatus.setScale(2, RoundingMode.HALF_UP)));
							cell10.setBorder(Rectangle.NO_BORDER);
							cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell10.enableBorderSide(Rectangle.TOP);
							cell10.setPaddingBottom(5f);
							pastDueAmtTotalBySummary = pastDueAmtTotalBySummary.add(pastDueAmtTotalByStatus);
							
							PdfPCell cell11 = new PdfPCell(
									new Paragraph("" + totalDueAmtByStatus.setScale(2, RoundingMode.HALF_UP)));
							cell11.setBorder(Rectangle.NO_BORDER);
							cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell11.enableBorderSide(Rectangle.TOP);
							cell11.setPaddingBottom(5f);
							totalDueAmtBySummary = totalDueAmtBySummary.add(totalDueAmtByStatus);
													
							PdfPCell cell12 = new PdfPCell(
									new Paragraph("" + disputeTotalByStatus.setScale(2, RoundingMode.HALF_UP)));
							cell12.setBorder(Rectangle.NO_BORDER);
							cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell12.enableBorderSide(Rectangle.TOP);
							cell12.setPaddingBottom(5f);
							disputeTotalBySummary = disputeTotalBySummary.add(disputeTotalByStatus);
														
							PdfPCell cell13 = new PdfPCell(
									new Paragraph("" + dsoTotalByStatus.setScale(2, RoundingMode.HALF_UP)));
							cell13.setBorder(Rectangle.NO_BORDER);
							cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
							cell13.enableBorderSide(Rectangle.TOP);
							cell13.setPaddingBottom(5f);
							dsoTotalBySummary = dsoTotalByStatus.add(dsoTotalBySummary);

							table.addCell(cell3);
							table.addCell(cell4);
							table.addCell(cell5);
							table.addCell(cell6);
							table.addCell(cell7);
							table.addCell(cell8);
							table.addCell(cell9);
							table.addCell(cell10);
							table.addCell(cell11);
							table.addCell(cell12);
							table.addCell(cell13);
							document.add(table);
				}			
		}
		
			PdfPTable table = new PdfPTable(11);
			
			float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
			table.setWidths(columnWidthsForOverallTotal);
			table.setTotalWidth(1145);
			table.setLockedWidth(true);
			table.getDefaultCell().setFixedHeight(100);
			table.getDefaultCell().setBorder(Rectangle.TOP);
			table.getDefaultCell().setBorderColor(BaseColor.BLACK);
			
			PdfPCell cell3 = new PdfPCell(
					new Paragraph("Grand Total ", boldFont));
			cell3.setBorder(Rectangle.NO_BORDER);
			cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell3.enableBorderSide(Rectangle.TOP);
			cell3.setPaddingBottom(5f);
			
			PdfPCell cell4 = new PdfPCell(
					new Paragraph("" + currentBilling.setScale(2, RoundingMode.HALF_UP)));
			cell4.setBorder(Rectangle.NO_BORDER);
			cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell4.enableBorderSide(Rectangle.TOP);
			cell4.setPaddingBottom(5f);
			
			PdfPCell cell5 = new PdfPCell(
					new Paragraph("" + currentBalance.setScale(2, RoundingMode.HALF_UP)));
			cell5.setBorder(Rectangle.NO_BORDER);
			cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell5.enableBorderSide(Rectangle.TOP);
			cell5.setPaddingBottom(5f);
			
			PdfPCell cell6 = new PdfPCell(
					new Paragraph("" + pastDue30AmtTotalBySummary.setScale(2, RoundingMode.HALF_UP)));
			cell6.setBorder(Rectangle.NO_BORDER);
			cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell6.enableBorderSide(Rectangle.TOP);
			cell6.setPaddingBottom(5f);
			
			PdfPCell cell7 = new PdfPCell(
					new Paragraph("" + pastDue60AmtTotalBySummary.setScale(2, RoundingMode.HALF_UP)));
			cell7.setBorder(Rectangle.NO_BORDER);
			cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell7.enableBorderSide(Rectangle.TOP);
			cell7.setPaddingBottom(5f);

			PdfPCell cell8 = new PdfPCell(
					new Paragraph("" + pastDue90AmtTotalBySummary.setScale(2, RoundingMode.HALF_UP)));
			cell8.setBorder(Rectangle.NO_BORDER);
			cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell8.enableBorderSide(Rectangle.TOP);
			cell8.setPaddingBottom(5f);
			
			PdfPCell cell9 = new PdfPCell(
					new Paragraph("" + pastDue120AmtTotalBySummary.setScale(2, RoundingMode.HALF_UP)));
			cell9.setBorder(Rectangle.NO_BORDER);
			cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell9.enableBorderSide(Rectangle.TOP);
			cell9.setPaddingBottom(5f);
			
			PdfPCell cell10 = new PdfPCell(
					new Paragraph("" + pastDueAmtTotalBySummary.setScale(2, RoundingMode.HALF_UP)));
			cell10.setBorder(Rectangle.NO_BORDER);
			cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell10.enableBorderSide(Rectangle.TOP);
			cell10.setPaddingBottom(5f);
			
			PdfPCell cell11 = new PdfPCell(
					new Paragraph("" + totalDueAmtBySummary.setScale(2, RoundingMode.HALF_UP)));
			cell11.setBorder(Rectangle.NO_BORDER);
			cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell11.enableBorderSide(Rectangle.TOP);
			cell11.setPaddingBottom(5f);
									
			PdfPCell cell12 = new PdfPCell(
					new Paragraph("" + disputeTotalBySummary.setScale(2, RoundingMode.HALF_UP)));
			cell12.setBorder(Rectangle.NO_BORDER);
			cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell12.enableBorderSide(Rectangle.TOP);
			cell12.setPaddingBottom(5f);
										
			PdfPCell cell13 = new PdfPCell(
					new Paragraph("" + dsoTotalBySummary.setScale(2, RoundingMode.HALF_UP)));
			cell13.setBorder(Rectangle.NO_BORDER);
			cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell13.enableBorderSide(Rectangle.TOP);
			cell13.setPaddingBottom(5f);

			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);
			table.addCell(cell8);
			table.addCell(cell9);
			table.addCell(cell10);
			table.addCell(cell11);
			table.addCell(cell12);
			table.addCell(cell13);
			document.add(table);
		
	}

	@Override
	public ByteArrayInputStream searchBySegment(UserDetails requestModel, Map<Object, Object> responseMap) {
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
			
			PdfWriter writer = PdfWriter.getInstance(document,
				new FileOutputStream("SummaryReportBySegment" + requestModel.getUserLoginCd()+ ".pdf"));
			document.setPageSize(rectangle);
			SegmentHeaderFooterPageEvent event = new SegmentHeaderFooterPageEvent();
			event.setHeader(requestModel, "summary", "bySegment");
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);
			
			List<SummaryReportBySegmentResponseModel> response = summaryReportBySegmentRepository.bySegment(
					requestModel.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
					requestModel.getExclusions(), 
					"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
					requestModel.getCustomerChidFlag());
				
			if(response != null) {
				populatePdfGroupingBySegment(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Records Found");
			}

			document.close();
			writer.close();

			Path path = Paths.get("SummaryReportBySegment" + requestModel.getUserLoginCd()+ ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);	
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	private void populatePdfGroupingBySegment(Document document, List<SummaryReportBySegmentResponseModel> response) throws DocumentException {
		BigDecimal currentBilling = BigDecimal.ZERO;
		BigDecimal currentBalance = BigDecimal.ZERO;
		BigDecimal pastDue30AmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal pastDue60AmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal pastDue90AmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal pastDue120AmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal pastDueAmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal totalDueAmtByCustomer = BigDecimal.ZERO;
		BigDecimal disputeTotalByCustomer = BigDecimal.ZERO;
		BigDecimal dsoTotalByCustomer = BigDecimal.ZERO;
		
		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		document.add(empty);
		
			for(SummaryReportBySegmentResponseModel segmentRow: response)
			 {
				PdfPTable table = new PdfPTable(11);
				float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
				table.setWidths(columnWidths);
				table.setTotalWidth(1145);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(100);
				table.getDefaultCell().setBorder(Rectangle.TOP);
				table.getDefaultCell().setBorderColor(BaseColor.BLACK);

				PdfPCell cell3 = new PdfPCell(new Paragraph(segmentRow.getSegment()));
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
				cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell3.disableBorderSide(0);
				cell3.setPaddingBottom(5f);

				PdfPCell cell4 = new PdfPCell(
						new Paragraph("" + segmentRow.getCurrentBillingAmount().setScale(2, RoundingMode.HALF_UP)));
				cell4.setBorder(Rectangle.NO_BORDER);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell4.disableBorderSide(0);
				cell4.setPaddingBottom(5f);
				currentBilling = currentBilling.add(segmentRow.getCurrentBillingAmount());
				
				PdfPCell cell5 = new PdfPCell(
						new Paragraph("" + segmentRow.getPastDue0Amount().setScale(2, RoundingMode.HALF_UP)));
				cell5.setBorder(Rectangle.NO_BORDER);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell5.disableBorderSide(0);
				cell5.setPaddingBottom(5f);
				currentBalance = currentBalance.add(segmentRow.getPastDue0Amount());

				PdfPCell cell6 = new PdfPCell(
						new Paragraph("" +segmentRow.getPastDue30Amount().setScale(2, RoundingMode.HALF_UP)));
				cell6.setBorder(Rectangle.NO_BORDER);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell6.disableBorderSide(0);
				cell6.setPaddingBottom(5f);
				pastDue30AmtTotalByCustomer = pastDue30AmtTotalByCustomer.add(segmentRow.getPastDue30Amount());

				PdfPCell cell7 = new PdfPCell(
						new Paragraph("" + segmentRow.getPastDue60Amount().setScale(2, RoundingMode.HALF_UP)));
				cell7.setBorder(Rectangle.NO_BORDER);
				cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell7.disableBorderSide(0);
				cell7.setPaddingBottom(5f);
				pastDue60AmtTotalByCustomer = pastDue60AmtTotalByCustomer.add(segmentRow.getPastDue60Amount());
				
				PdfPCell cell8 = new PdfPCell(
						new Paragraph("" + segmentRow.getPastDue90Amount().setScale(2, RoundingMode.HALF_UP)));
				cell8.setBorder(Rectangle.NO_BORDER);
				cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell8.disableBorderSide(0);
				cell8.setPaddingBottom(5f);
				pastDue90AmtTotalByCustomer= pastDue90AmtTotalByCustomer.add(segmentRow.getPastDue90Amount());

				PdfPCell cell9 = new PdfPCell(
						new Paragraph("" + segmentRow.getPastDue120Amount().setScale(2, RoundingMode.HALF_UP)));
				cell9.setBorder(Rectangle.NO_BORDER);
				cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell9.disableBorderSide(0);
				cell9.setPaddingBottom(5f);
				pastDue120AmtTotalByCustomer= pastDue120AmtTotalByCustomer.add(segmentRow.getPastDue120Amount());
				

				PdfPCell cell10 = new PdfPCell(
						new Paragraph("" + segmentRow.getTotalPastDueAmount().setScale(2, RoundingMode.HALF_UP)));
				cell10.setBorder(Rectangle.NO_BORDER);
				cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell10.disableBorderSide(0);
				cell10.setPaddingBottom(5f);
				pastDueAmtTotalByCustomer= pastDueAmtTotalByCustomer.add(segmentRow.getTotalPastDueAmount());

				PdfPCell cell11 = new PdfPCell(
						new Paragraph("" + segmentRow.getTotalAmount().setScale(2, RoundingMode.HALF_UP)));
				cell11.setBorder(Rectangle.NO_BORDER);
				cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell11.disableBorderSide(0);
				cell11.setPaddingBottom(5f);
				totalDueAmtByCustomer= totalDueAmtByCustomer.add(segmentRow.getTotalAmount());

				PdfPCell cell12 = new PdfPCell(
						new Paragraph("" + segmentRow.getDispute().setScale(2, RoundingMode.HALF_UP)));
				cell12.setBorder(Rectangle.NO_BORDER);
				cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell12.disableBorderSide(0);
				cell12.setPaddingBottom(5f);
				disputeTotalByCustomer= disputeTotalByCustomer.add(segmentRow.getDispute());

				PdfPCell cell13 = new PdfPCell(
						new Paragraph("" + segmentRow.getDso().setScale(2,RoundingMode.HALF_UP)));
				cell13.setBorder(Rectangle.NO_BORDER);
				cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell13.disableBorderSide(0);
				cell13.setPaddingBottom(5f);
				dsoTotalByCustomer= dsoTotalByCustomer.add(segmentRow.getDso());

				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);
				table.addCell(cell8);
				table.addCell(cell9);
				table.addCell(cell10);
				table.addCell(cell11);
				table.addCell(cell12);
				table.addCell(cell13);

				document.add(table);
			}
			PdfPTable table = new PdfPTable(11);
				
				float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
				table.setWidths(columnWidthsForOverallTotal);
				table.setTotalWidth(1145);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(100);
				table.getDefaultCell().setBorder(Rectangle.TOP);
				table.getDefaultCell().setBorderColor(BaseColor.BLACK);
				
				PdfPCell cell3 = new PdfPCell(
						new Paragraph("Grand Total ", boldFont));
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
				cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell3.enableBorderSide(Rectangle.TOP);
				cell3.setPaddingBottom(5f);
				
				PdfPCell cell4 = new PdfPCell(
						new Paragraph("" + currentBilling.setScale(2, RoundingMode.HALF_UP)));
				cell4.setBorder(Rectangle.NO_BORDER);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell4.enableBorderSide(Rectangle.TOP);
				cell4.setPaddingBottom(5f);
				
				PdfPCell cell5 = new PdfPCell(
						new Paragraph("" + currentBalance.setScale(2, RoundingMode.HALF_UP)));
				cell5.setBorder(Rectangle.NO_BORDER);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell5.enableBorderSide(Rectangle.TOP);
				cell5.setPaddingBottom(5f);
				
				PdfPCell cell6 = new PdfPCell(
						new Paragraph("" + pastDue30AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell6.setBorder(Rectangle.NO_BORDER);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell6.enableBorderSide(Rectangle.TOP);
				cell6.setPaddingBottom(5f);
				
				PdfPCell cell7 = new PdfPCell(
						new Paragraph("" + pastDue60AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell7.setBorder(Rectangle.NO_BORDER);
				cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell7.enableBorderSide(Rectangle.TOP);
				cell7.setPaddingBottom(5f);

				PdfPCell cell8 = new PdfPCell(
						new Paragraph("" + pastDue90AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell8.setBorder(Rectangle.NO_BORDER);
				cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell8.enableBorderSide(Rectangle.TOP);
				cell8.setPaddingBottom(5f);
				
				PdfPCell cell9 = new PdfPCell(
					new Paragraph("" + pastDue120AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell9.setBorder(Rectangle.NO_BORDER);
				cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell9.enableBorderSide(Rectangle.TOP);
				cell9.setPaddingBottom(5f);
				
				PdfPCell cell10 = new PdfPCell(
						new Paragraph("" + pastDueAmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell10.setBorder(Rectangle.NO_BORDER);
				cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell10.enableBorderSide(Rectangle.TOP);
				cell10.setPaddingBottom(5f);
				
				PdfPCell cell11 = new PdfPCell(
						new Paragraph("" + totalDueAmtByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell11.setBorder(Rectangle.NO_BORDER);
				cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell11.enableBorderSide(Rectangle.TOP);
				cell11.setPaddingBottom(5f);
										
				PdfPCell cell12 = new PdfPCell(
						new Paragraph("" + disputeTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell12.setBorder(Rectangle.NO_BORDER);
				cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell12.enableBorderSide(Rectangle.TOP);
				cell12.setPaddingBottom(5f);
											
				PdfPCell cell13 = new PdfPCell(
						new Paragraph("" + dsoTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell13.setBorder(Rectangle.NO_BORDER);
				cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell13.enableBorderSide(Rectangle.TOP);
				cell13.setPaddingBottom(5f);

				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);
				table.addCell(cell8);
				table.addCell(cell9);
				table.addCell(cell10);
				table.addCell(cell11);
				table.addCell(cell12);
				table.addCell(cell13);
				document.add(table);
		
	}

	@Override
	public ByteArrayInputStream searchByState(UserDetails requestModel, Map<Object, Object> responseMap) {
		try {
			Document document = new Document(PageSize.A4, 36, 36, 140, 130);
			Rectangle rectangle = new Rectangle(15, 15, 1300, 1800);
			
			PdfWriter writer = PdfWriter.getInstance(document,
				new FileOutputStream("SummaryReportByState" + requestModel.getUserLoginCd()+ ".pdf"));
			document.setPageSize(rectangle);
			SegmentHeaderFooterPageEvent event = new SegmentHeaderFooterPageEvent();
			event.setHeader(requestModel, "summary", "byState");
			writer.setPageEvent(event);
			document.open();
			document.setMargins(15, 15, 120, 60);
			
			List<SummaryReportByStateResponseModel> response = summaryReportByStateRepository.byState(
					requestModel.getBillingPeriod(),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getGroupSelected()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(requestModel.getOriginatingSystem()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getOriginatingCompanyCdClause()), 
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getStatusClause()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getSegment()),
					CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getCustomerClause()),
					requestModel.getExclusions(), 
					"AND (cx.class_cd IN ("+CommonReportsUtils.getListToCommaQuotesSeparatedString(requestModel.getExclusionClass())+"))",
					requestModel.getCustomerChidFlag());
				
			if(response != null) {
				populatePdfGroupingByState(document, response);
				responseMap.put("msg", ApplicationConstant.SUCCESS);
			}else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Records Found");
			}

			document.close();
			writer.close();

			Path path = Paths.get("SummaryReportByState" + requestModel.getUserLoginCd()+ ".pdf");
			byte[] bytea = Files.readAllBytes(path);
			return new ByteArrayInputStream(bytea);
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	private void populatePdfGroupingByState(Document document, List<SummaryReportByStateResponseModel> response) throws DocumentException {
		BigDecimal currentBilling = BigDecimal.ZERO;
		BigDecimal currentBalance = BigDecimal.ZERO;
		BigDecimal pastDue30AmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal pastDue60AmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal pastDue90AmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal pastDue120AmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal pastDueAmtTotalByCustomer = BigDecimal.ZERO;
		BigDecimal totalDueAmtByCustomer = BigDecimal.ZERO;
		BigDecimal disputeTotalByCustomer = BigDecimal.ZERO;
		BigDecimal dsoTotalByCustomer = BigDecimal.ZERO;
		
		Paragraph empty = new Paragraph(" ");
		empty.setLeading(30f);
		document.add(empty);
		
			for(SummaryReportByStateResponseModel stateRow: response)
			 {
				PdfPTable table = new PdfPTable(11);
				float[] columnWidths = { 5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
				table.setWidths(columnWidths);
				table.setTotalWidth(1145);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(100);
				table.getDefaultCell().setBorder(Rectangle.TOP);
				table.getDefaultCell().setBorderColor(BaseColor.BLACK);

				PdfPCell cell3 = new PdfPCell(new Paragraph(stateRow.getState()));
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
				cell3.setVerticalAlignment(Element.ALIGN_LEFT);
				cell3.disableBorderSide(0);
				cell3.setPaddingBottom(5f);

				PdfPCell cell4 = new PdfPCell(
						new Paragraph("" + stateRow.getCurrentBillingAmount().setScale(2, RoundingMode.HALF_UP)));
				cell4.setBorder(Rectangle.NO_BORDER);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell4.disableBorderSide(0);
				cell4.setPaddingBottom(5f);
				currentBilling = currentBilling.add(stateRow.getCurrentBillingAmount());
				
				PdfPCell cell5 = new PdfPCell(
						new Paragraph("" + stateRow.getPastDue0Amount().setScale(2, RoundingMode.HALF_UP)));
				cell5.setBorder(Rectangle.NO_BORDER);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell5.disableBorderSide(0);
				cell5.setPaddingBottom(5f);
				currentBalance = currentBalance.add(stateRow.getPastDue0Amount());

				PdfPCell cell6 = new PdfPCell(
						new Paragraph("" +stateRow.getPastDue30Amount().setScale(2, RoundingMode.HALF_UP)));
				cell6.setBorder(Rectangle.NO_BORDER);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell6.disableBorderSide(0);
				cell6.setPaddingBottom(5f);
				pastDue30AmtTotalByCustomer = pastDue30AmtTotalByCustomer.add(stateRow.getPastDue30Amount());

				PdfPCell cell7 = new PdfPCell(
						new Paragraph("" + stateRow.getPastDue60Amount().setScale(2, RoundingMode.HALF_UP)));
				cell7.setBorder(Rectangle.NO_BORDER);
				cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell7.disableBorderSide(0);
				cell7.setPaddingBottom(5f);
				pastDue60AmtTotalByCustomer = pastDue60AmtTotalByCustomer.add(stateRow.getPastDue60Amount());
				
				PdfPCell cell8 = new PdfPCell(
						new Paragraph("" + stateRow.getPastDue90Amount().setScale(2, RoundingMode.HALF_UP)));
				cell8.setBorder(Rectangle.NO_BORDER);
				cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell8.disableBorderSide(0);
				cell8.setPaddingBottom(5f);
				pastDue90AmtTotalByCustomer= pastDue90AmtTotalByCustomer.add(stateRow.getPastDue90Amount());

				PdfPCell cell9 = new PdfPCell(
						new Paragraph("" + stateRow.getPastDue120Amount().setScale(2, RoundingMode.HALF_UP)));
				cell9.setBorder(Rectangle.NO_BORDER);
				cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell9.disableBorderSide(0);
				cell9.setPaddingBottom(5f);
				pastDue120AmtTotalByCustomer= pastDue120AmtTotalByCustomer.add(stateRow.getPastDue120Amount());
				
				PdfPCell cell10 = new PdfPCell(
						new Paragraph("" + stateRow.getTotalPastDueAmount().setScale(2, RoundingMode.HALF_UP)));
				cell10.setBorder(Rectangle.NO_BORDER);
				cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell10.disableBorderSide(0);
				cell10.setPaddingBottom(5f);
				pastDueAmtTotalByCustomer= pastDueAmtTotalByCustomer.add(stateRow.getTotalPastDueAmount());

				PdfPCell cell11 = new PdfPCell(
						new Paragraph("" + stateRow.getTotalAmount().setScale(2, RoundingMode.HALF_UP)));
				cell11.setBorder(Rectangle.NO_BORDER);
				cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell11.disableBorderSide(0);
				cell11.setPaddingBottom(5f);
				totalDueAmtByCustomer= totalDueAmtByCustomer.add(stateRow.getTotalAmount());

				PdfPCell cell12 = new PdfPCell(
						new Paragraph("" + stateRow.getDispute().setScale(2, RoundingMode.HALF_UP)));
				cell12.setBorder(Rectangle.NO_BORDER);
				cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell12.disableBorderSide(0);
				cell12.setPaddingBottom(5f);
				disputeTotalByCustomer= disputeTotalByCustomer.add(stateRow.getDispute());

				PdfPCell cell13 = new PdfPCell(
						new Paragraph("" + stateRow.getDso().setScale(2,RoundingMode.HALF_UP)));
				cell13.setBorder(Rectangle.NO_BORDER);
				cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell13.disableBorderSide(0);
				cell13.setPaddingBottom(5f);
				dsoTotalByCustomer= dsoTotalByCustomer.add(stateRow.getDso());

				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);
				table.addCell(cell8);
				table.addCell(cell9);
				table.addCell(cell10);
				table.addCell(cell11);
				table.addCell(cell12);
				table.addCell(cell13);

				document.add(table);
			}
			
			PdfPTable table = new PdfPTable(11);
				
				float[] columnWidthsForOverallTotal = {5f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
				table.setWidths(columnWidthsForOverallTotal);
				table.setTotalWidth(1145);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(100);
				table.getDefaultCell().setBorder(Rectangle.TOP);
				table.getDefaultCell().setBorderColor(BaseColor.BLACK);
				
				PdfPCell cell3 = new PdfPCell(
						new Paragraph("Grand Total ", boldFont));
				cell3.setBorder(Rectangle.NO_BORDER);
				cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
				cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell3.enableBorderSide(Rectangle.TOP);
				cell3.setPaddingBottom(5f);
				
				PdfPCell cell4 = new PdfPCell(
						new Paragraph("" + currentBilling.setScale(2, RoundingMode.HALF_UP)));
				cell4.setBorder(Rectangle.NO_BORDER);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell4.enableBorderSide(Rectangle.TOP);
				cell4.setPaddingBottom(5f);
				
				PdfPCell cell5 = new PdfPCell(
						new Paragraph("" + currentBalance.setScale(2, RoundingMode.HALF_UP)));
				cell5.setBorder(Rectangle.NO_BORDER);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell5.enableBorderSide(Rectangle.TOP);
				cell5.setPaddingBottom(5f);
				
				PdfPCell cell6 = new PdfPCell(
						new Paragraph("" + pastDue30AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell6.setBorder(Rectangle.NO_BORDER);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell6.enableBorderSide(Rectangle.TOP);
				cell6.setPaddingBottom(5f);
				
				PdfPCell cell7 = new PdfPCell(
						new Paragraph("" + pastDue60AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell7.setBorder(Rectangle.NO_BORDER);
				cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell7.enableBorderSide(Rectangle.TOP);
				cell7.setPaddingBottom(5f);

				PdfPCell cell8 = new PdfPCell(
						new Paragraph("" + pastDue90AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell8.setBorder(Rectangle.NO_BORDER);
				cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell8.enableBorderSide(Rectangle.TOP);
				cell8.setPaddingBottom(5f);
				
				PdfPCell cell9 = new PdfPCell(
					new Paragraph("" + pastDue120AmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell9.setBorder(Rectangle.NO_BORDER);
				cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell9.enableBorderSide(Rectangle.TOP);
				cell9.setPaddingBottom(5f);
				
				PdfPCell cell10 = new PdfPCell(
						new Paragraph("" + pastDueAmtTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell10.setBorder(Rectangle.NO_BORDER);
				cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell10.enableBorderSide(Rectangle.TOP);
				cell10.setPaddingBottom(5f);
				
				PdfPCell cell11 = new PdfPCell(
						new Paragraph("" + totalDueAmtByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell11.setBorder(Rectangle.NO_BORDER);
				cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell11.enableBorderSide(Rectangle.TOP);
				cell11.setPaddingBottom(5f);
										
				PdfPCell cell12 = new PdfPCell(
						new Paragraph("" + disputeTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell12.setBorder(Rectangle.NO_BORDER);
				cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell12.enableBorderSide(Rectangle.TOP);
				cell12.setPaddingBottom(5f);
											
				PdfPCell cell13 = new PdfPCell(
						new Paragraph("" + dsoTotalByCustomer.setScale(2, RoundingMode.HALF_UP)));
				cell13.setBorder(Rectangle.NO_BORDER);
				cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell13.enableBorderSide(Rectangle.TOP);
				cell13.setPaddingBottom(5f);

				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);
				table.addCell(cell8);
				table.addCell(cell9);
				table.addCell(cell10);
				table.addCell(cell11);
				table.addCell(cell12);
				table.addCell(cell13);
				document.add(table);
	}
}
package com.att.arms.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.service.RegionExcelReportsService;
import com.att.arms.reports.service.RegionPdfReportsService;
import com.itextpdf.text.DocumentException;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class RegionReportsController {
	
	private static final String CONTENT_DISPOSITION = "Content-Disposition";
	private static final String APPLICATION_OCTET_STREAM = "application/octet-stream";
	@Autowired
	RegionPdfReportsService regionPdfReportsService;
	@Autowired
	RegionExcelReportsService regionExcelReportsService;

	@PostMapping("regionPdfReportByRegionSegment")
	public ResponseEntity<Object> regionPdfReportByRegionSegment(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();

		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionSegmentReport.pdf");

		ByteArrayInputStream stream =
				regionPdfReportsService.createPdfForRegionSegment(userDetails, responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}


	@PostMapping("regionExcelReportByRegionSegment")
	public ResponseEntity<Object> regionExcelReportByRegionSegment(@RequestBody UserDetails userDetails,HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionSegmentReport.xlsx");
		ByteArrayInputStream stream = regionExcelReportsService.createExcelForRegionSegment(userDetails,
				responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("regionPdfReportByRegionCustomer")
	public ResponseEntity<Object> regionPdfReportByRegionCustomer(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();

		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionCustomerReport.pdf");

		ByteArrayInputStream stream =
				regionPdfReportsService.createPdfForRegionCustomer(userDetails, responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}


	@PostMapping("regionExcelReportByRegionCustomer")
	public ResponseEntity<Object> regionExcelReportByRegionCustomer(@RequestBody UserDetails userDetails,HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionCustomerReport.xlsx");
		ByteArrayInputStream stream = regionExcelReportsService.createExcelForRegionCustomer(userDetails,
				responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("regionPdfReportByRegionState")
	public ResponseEntity<Object> regionPdfReportByRegionState(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();

		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionStateReport.pdf");

		ByteArrayInputStream stream =
				regionPdfReportsService.createPdfForRegionState(userDetails, responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("regionPdfReportByRegionSegmentCustomer")
	public ResponseEntity<Object> regionPdfReportByRegionSegmentCustomer(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();

		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionSegmentCustomerReport.pdf");

		ByteArrayInputStream stream =
				regionPdfReportsService.createPdfForRegionSegmentCustomer(userDetails, responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("regionPdfReportByRegionStateCustomer")
	public ResponseEntity<Object> regionPdfReportByRegionStateCustomer(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();

		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionStateCustomerReport.pdf");

		ByteArrayInputStream stream =
				regionPdfReportsService.createPdfForRegionStateCustomer(userDetails, responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("regionPdfReportByRegionStateSegment")
	public ResponseEntity<Object> regionPdfReportByRegionStateSegment(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws DocumentException, IOException {
		Map<Object, Object> responseMap = new HashMap<>();

		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionStateSegmentReport.pdf");

		ByteArrayInputStream stream =
				regionPdfReportsService.createPdfForRegionStateSegment(userDetails, responseMap);

		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("regionExcelReportByRegionState")
	public ResponseEntity<Object> regionExcelReportByRegionState(@RequestBody UserDetails userDetails,HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionStateReport.xlsx");
		ByteArrayInputStream stream = regionExcelReportsService.createExcelForRegionState(userDetails,
				responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("regionExcelReportByRegionStateSegment")
	public ResponseEntity<Object> regionExcelReportByRegionStateSegment(@RequestBody UserDetails userDetails,HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionStateSegmentReport.xlsx");
		ByteArrayInputStream stream = regionExcelReportsService.createExcelForRegionStateSegment(userDetails,
				responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("regionExcelReportByRegionStateCustomer")
	public ResponseEntity<Object> regionExcelReportByRegionStateCustomer(@RequestBody UserDetails userDetails,HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionStateCustomerReport.xlsx");
		ByteArrayInputStream stream = regionExcelReportsService.createExcelForRegionStateCustomer(userDetails,
				responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("regionExcelReportByRegionSegmentCustomer")
	public ResponseEntity<Object> regionExcelReportByRegionSegmentCustomer(@RequestBody UserDetails userDetails,HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		response.setContentType(APPLICATION_OCTET_STREAM);
		response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RegionByRegionSegmentCustomerReport.xlsx");
		ByteArrayInputStream stream = regionExcelReportsService.createExcelForRegionSegmentCustomer(userDetails,
				responseMap);
		IOUtils.copy(stream, response.getOutputStream());
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
}

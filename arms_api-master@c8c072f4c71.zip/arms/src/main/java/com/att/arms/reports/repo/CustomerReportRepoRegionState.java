package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.reports.entity.CustomerReportByRegionState;

@Transactional
public interface CustomerReportRepoRegionState extends JpaRepository<CustomerReportByRegionState, String> {

	@Query(value = "exec arms_rpt_mgr_customer_by_region_state :billingPeriod,:groupSelected,:originatingSystem,:originatingCompanyCdClause,:statusClause,:segment,:customerClause,:accountStatusClause, :classClause,:customerChidFlag", nativeQuery = true)
	public List<CustomerReportByRegionState> findCustomerReportData(@Param("billingPeriod") String billingPeriod,
			@Param("groupSelected") String groupSelected, @Param("originatingSystem") String originatingSystem,
			@Param("originatingCompanyCdClause") String originatingCompanyCdClause,
			@Param("statusClause") String statusClause, @Param("segment") String segment,
			@Param("customerClause") String customerClause, @Param("accountStatusClause") String accountStatusClause,
			@Param("classClause") String classClause, @Param("customerChidFlag") String customerChidFlag);

}
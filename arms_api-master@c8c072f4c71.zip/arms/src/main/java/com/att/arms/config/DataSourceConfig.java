package com.att.arms.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.att.arms.enums.DataSourceType;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DataSourceConfig {

	@Autowired Environment env;
	
	@Bean
	public DataSource getDataSources() {
		final Map<Object,Object> dataSources = this.buildDataSources();
		final RoutingDataSource routingDataSource= new RoutingDataSource();
		routingDataSource.setTargetDataSources(dataSources);
		routingDataSource.setDefaultTargetDataSource(dataSources.get(DataSourceType.PROD));
		
		return routingDataSource;
	}
	
	private DataSource buildDataSource(DataSourceType sourceType) {
		final HikariConfig config = new HikariConfig();
		config.setJdbcUrl(this.env.getProperty(String.format("spring.%s.datasource.url",sourceType.getName())));
		config.setUsername(this.env.getProperty(String.format("spring.%s.datasource.username",sourceType.getName())));
		config.setPassword(this.env.getProperty(String.format("spring.%s.datasource.password",sourceType.getName())));
		config.setDriverClassName(this.env.getProperty(String.format("spring.%s.datasource.driverClassName",sourceType.getName())));
		config.setAutoCommit(false);
		return new HikariDataSource(config);
	}
	private Map<Object,Object> buildDataSources(){
		final Map<Object,Object> result=new HashMap<>();
		for (DataSourceType sourceType : DataSourceType.values()) {
			result.put(sourceType, this.buildDataSource(sourceType));
		}
		return result;
	}
}

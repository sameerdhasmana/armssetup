package com.att.arms.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.service.SegmentExcelReportService;
import com.att.arms.reports.service.SegmentPdfReportService;
import com.itextpdf.text.DocumentException;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class SegmentReportController {

	@Autowired
	SegmentExcelReportService segmentExcelReportService;
	
	@Autowired
	SegmentPdfReportService segmentPdfReportService;
	
	@PostMapping("segmentExcelReportByCustomer")
	public ResponseEntity<Object> segmentExcelReportByCustomer(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.segmentExcelReportService.searchByCustomer(requestModel, responseMap);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=segmentReportByCustomer.xlsx");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("segmentExcelReportByRegion")
	public ResponseEntity<Object> segmentExcelReportByRegion(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.segmentExcelReportService.searchByRegion(requestModel, responseMap);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=SegmentExcelReportByRegion.xlsx");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	private boolean isValidUserData(UserDetails requestModel) {
		return requestModel.getBillingPeriod() != null && !requestModel.getBillingPeriod().isEmpty();
	}

	@PostMapping("segmentPdfReportByCustomer")
	public ResponseEntity<Object> segmentPdfReportByCustomer(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.segmentPdfReportService.searchByCustomer(requestModel, responseMap);
			response.setContentType("application/octet-stream");
	    	response.setHeader("Content-Disposition", "attachment; filename=segmentReportByCustomer.pdf");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("segmentPdfReportByRegion")
	public ResponseEntity<Object> segmentPdfReportByRegion(@RequestBody UserDetails requestModel, HttpServletResponse response) throws IOException, DocumentException {
		Map<Object, Object> responseMap = new HashMap<>();
		if(isValidUserData(requestModel)) {
			ByteArrayInputStream stream = this.segmentPdfReportService.searchByRegion(requestModel, responseMap);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=segmentReportByRegion.pdf");
		
			IOUtils.copy(stream, response.getOutputStream());
		}else {
			return new ResponseEntity<>("Invalid Billing Period Provided ", HttpStatus.BAD_REQUEST);
		}
		
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
}

package com.att.arms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.AccountPastDueAmount;
import com.att.arms.entity.AccountPastDueDetails;
import com.att.arms.entity.AccountsBringUpDetails;
import com.att.arms.entity.BreakdownDetails;
import com.att.arms.entity.CashDataDetails;
import com.att.arms.entity.CustomerAgedDetails;
import com.att.arms.entity.CustomerApSubGroup;
import com.att.arms.entity.CustomerBringUpDetails;
import com.att.arms.entity.CustomerDetails;
import com.att.arms.entity.EmaorView;
import com.att.arms.entity.InvoiceViewDetails;
import com.att.arms.entity.MyCustomerDetails;
import com.att.arms.entity.SummaryDetails;
import com.att.arms.entity.TableMaintenanceAcnaComboBox;
import com.att.arms.entity.TaxiClaimDetails;
import com.att.arms.entity.UserDetails;
import com.att.arms.entity.ViewInternalContacts;
import com.att.arms.repo.AccountPastDueAmountRepository;
import com.att.arms.repo.AccountPastDueDetailsRepository;
import com.att.arms.repo.AccountsBringUpDetailsRepository;
import com.att.arms.repo.BreakdownDetailsRepository;
import com.att.arms.repo.CashDataDetailsRepository;
import com.att.arms.repo.CustomerAgedDetailsRepository;
import com.att.arms.repo.CustomerBringUpDetailsRepository;
import com.att.arms.repo.CustomerDetailsRepository;
import com.att.arms.repo.CustomerSubGroupRepository;
import com.att.arms.repo.EmaorViewRepository;
import com.att.arms.repo.InvoiceViewRepository;
import com.att.arms.repo.MyCustomerDetailsRepository;
import com.att.arms.repo.SummaryDetailsRepository;
import com.att.arms.repo.TableMaintenanceAcnaRepository;
import com.att.arms.repo.TaxiClaimDetailsRepository;
import com.att.arms.repo.ViewInternalContactsRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class CustomerDetailsServiceImpl implements CustomerDetailsService {

	@Autowired
	CustomerDetailsRepository customerDetailsRepository;
	@Autowired
	MyCustomerDetailsRepository myCustomerDetailsRepository;
	@Autowired
	CustomerBringUpDetailsRepository customerBringUpDetailsRepository;
	@Autowired
	AccountsBringUpDetailsRepository accountsBringUpDetailsRepository;
	@Autowired
	CustomerAgedDetailsRepository customerAgedDetailsRepository;
	@Autowired
	InvoiceViewRepository invoiceViewRepository;
	@Autowired
	SummaryDetailsRepository summaryDetailsRepository;
	@Autowired
	ViewInternalContactsRepository viewInternalContactsRepository;
	@Autowired
	EmaorViewRepository emaorViewRepository;
	@Autowired
	CommonService commonService;
	@Autowired
	AccountPastDueAmountRepository accountPastDueAmountRepository;
	@Autowired
	AccountPastDueDetailsRepository accountPastDueDetailsRepository;
	@Autowired
	CashDataDetailsRepository cashDataDetailsRepository;
	@Autowired
	BreakdownDetailsRepository breakdownDetailsRepository;
	@Autowired
	TaxiClaimDetailsRepository taxiClaimDetailsRepository;
	@Autowired
	CustomerSubGroupRepository customerSubGroupRepository;
	@Autowired
	TableMaintenanceAcnaRepository tableMaintenanceAcnaRepository;

	@Override
	public List<CustomerDetails> getCustomerDetails(String billingPeriod, String group, String strVal) {
		return this.customerDetailsRepository.getCustomerDetails(billingPeriod, group, strVal);
	}

	@Override
	public List<MyCustomerDetails> getCustomerDetailsPersonal(String group, String region, String billingPeriod,
			String userLoginCode, String strVal) {
		return this.myCustomerDetailsRepository.getCustomerDetailsPersonal(group, region, billingPeriod, userLoginCode,
				strVal);
	}

	@Override
	public List<CustomerBringUpDetails> getCustomerDetailsBringUp(String group, String region, String billingPeriod,
			String userLoginCode, String strVal, String bringUpType) {
		return this.customerBringUpDetailsRepository.getCustomerDetailsBringUp(group, region, billingPeriod,
				userLoginCode, strVal, bringUpType);
	}

	@Override
	public List<AccountsBringUpDetails> getAccountDetailsBringUp(String group, String region, String billingPeriod,
			String userLoginCode, String strVal, String bringUpType) {
		return this.accountsBringUpDetailsRepository.getAccountDetailsBringUp(group, region, billingPeriod,
				userLoginCode, strVal, bringUpType);
	}

	@Override
	public boolean validateQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& userDetails.getCustomerType() != null && StringUtils.isNotEmpty(userDetails.getBillingPeriod())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validatesubGrp(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateInvoiceQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& userDetails.getCustomerType() != null && StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateViewQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getOriginatingSystem())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())
				&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> getQueryResponse(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<CustomerDetails> customerDetailsList = new ArrayList<>();
		List<MyCustomerDetails> myCustomerDetailsList = new ArrayList<>();
		List<AccountsBringUpDetails> accountsBringUpDetailsList = new ArrayList<>();
		List<CustomerBringUpDetails> customerBringUpDetailsList = new ArrayList<>();
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String customerType = "";
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		String exclusionClass = "";
		String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		if (!userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}
		if (StringUtils.isNotEmpty(selectedGroups)) {
			ModelMap map = new ModelMap();
			customerType = generateParametersForAgedDetailGrid(customerDetailsList, myCustomerDetailsList,
					accountsBringUpDetailsList, customerBringUpDetailsList, userDetails, selectedGroups, customerType,
					responseMap, map);
			boolean response = validateAgedDetailRequest(userDetails, responseMap);
			if (response) {
				String customerGrpCd = retreiveCustomerGrpCd(userDetails.getCustomerGrpCd(), map);

				if (StringUtils.isNotEmpty(customerGrpCd)) {
					List<CustomerAgedDetails> agedDetail = getCustomerAgedDetails(userDetails.getProfileName(),
							userDetails.getProfileType(), "", "", customerType, selectedGroups, customerGrpCd,
							userDetails.getUserLoginCd().trim(), userDetails.getBillingPeriod().trim(), statusClause,
							userDetails.getExclusions().trim(), exclusionClass, segment, originatingSystem, "", "1",
							"account");
					responseMap.put(ApplicationConstant.AGED_DETAIL, agedDetail);
					commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(),
							ApplicationConstant.AGED_DETAIL, responseMap);
				}
			} else {
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Data Found for the selected input");
			}

		}

		return responseMap;
	}

	private String generateParametersForAgedDetailGrid(List<CustomerDetails> customerDetailsList,
			List<MyCustomerDetails> myCustomerDetailsList, List<AccountsBringUpDetails> accountsBringUpDetailsList,
			List<CustomerBringUpDetails> customerBringUpDetailsList, UserDetails userDetails, String selectedGroups,
			String customerType, Map<Object, Object> responseMap, ModelMap map) {
		if (StringUtils.isEmpty(userDetails.getCustomerGrpCd())) {
			if (CollectionUtils.isEmpty(customerDetailsList)
					&& userDetails.getCustomerType().equals(ApplicationConstant.CUSTOMER_TYPE_ALL_CUSTOMER)) {
				customerDetailsList = getCustomerDetails(userDetails.getBillingPeriod(), selectedGroups,
						userDetails.getEnteredValue());
				customerType = ApplicationConstant.ALL_CUSTOMERS;
				map.put(ApplicationConstant.ALL_CUSTOMERS, customerDetailsList);
			} else if (StringUtils.isNotEmpty(userDetails.getRegion())
					&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
				if (CollectionUtils.isEmpty(myCustomerDetailsList)
						&& userDetails.getCustomerType().equals(ApplicationConstant.CUSTOMER_TYPE_MY_CUSTOMER)) {
					myCustomerDetailsList = getCustomerDetailsPersonal(selectedGroups, userDetails.getRegion(),
							userDetails.getBillingPeriod(), userDetails.getUserLoginCd(),
							userDetails.getEnteredValue());
					customerType = ApplicationConstant.MY_CUSTOMERS;
					map.put(ApplicationConstant.MY_CUSTOMERS, myCustomerDetailsList);
				} else if (CollectionUtils.isEmpty(customerBringUpDetailsList)
						&& userDetails.getCustomerType().equals(ApplicationConstant.CUSTOMER_TYPE_CUSTOMER_BRING_UPS)) {
					customerBringUpDetailsList = getCustomerDetailsBringUp(selectedGroups, userDetails.getRegion(),
							userDetails.getBillingPeriod(), userDetails.getUserLoginCd(), userDetails.getEnteredValue(),
							"C");
					customerType = ApplicationConstant.CUSTOMER_BRING_UPS;
					map.put(ApplicationConstant.CUSTOMER_BRING_UPS, customerBringUpDetailsList);
				} else if (CollectionUtils.isEmpty(accountsBringUpDetailsList)
						&& userDetails.getCustomerType().equals(ApplicationConstant.CUSTOMER_TYPE_ACCOUNT_BRING_UPS)) {
					accountsBringUpDetailsList = getAccountDetailsBringUp(selectedGroups, userDetails.getRegion(),
							userDetails.getBillingPeriod(), userDetails.getUserLoginCd(), userDetails.getEnteredValue(),
							"A");
					customerType = ApplicationConstant.ACCOUNT_BRING_UPS;
					map.put(ApplicationConstant.ACCOUNT_BRING_UPS, accountsBringUpDetailsList);
				}
			}

		}
		responseMap.put(ApplicationConstant.ALL_CUSTOMERS, customerDetailsList);
		responseMap.put(ApplicationConstant.MY_CUSTOMERS, myCustomerDetailsList);
		responseMap.put(ApplicationConstant.CUSTOMER_BRING_UPS, customerBringUpDetailsList);
		responseMap.put(ApplicationConstant.ACCOUNT_BRING_UPS, accountsBringUpDetailsList);
		return customerType;
	}

	private boolean validateAgedDetailRequest(UserDetails userDetails, Map<Object, Object> responseMap) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())
				|| (!responseMap.isEmpty() && ((responseMap.containsKey(ApplicationConstant.ALL_CUSTOMERS)
						&& responseMap.get(ApplicationConstant.ALL_CUSTOMERS) != null)
						|| (responseMap.containsKey(ApplicationConstant.MY_CUSTOMERS)
								&& responseMap.get(ApplicationConstant.MY_CUSTOMERS) != null)
						|| (responseMap.containsKey(ApplicationConstant.CUSTOMER_BRING_UPS)
								&& responseMap.get(ApplicationConstant.CUSTOMER_BRING_UPS) != null)
						|| (responseMap.containsKey(ApplicationConstant.ACCOUNT_BRING_UPS)
								&& responseMap.get(ApplicationConstant.ACCOUNT_BRING_UPS) != null)))) {
			response = true;
		}
		return response;
	}

	private String retreiveCustomerGrpCd(String customerGrpCd, ModelMap map) {

		if (StringUtils.isEmpty(customerGrpCd)) {
			if (map.containsKey(ApplicationConstant.ALL_CUSTOMERS)) {
				customerGrpCd = getAllCustomerGrpCd(map);
			} else if (map.containsKey(ApplicationConstant.MY_CUSTOMERS)) {
				customerGrpCd = getMyCustomerGrpCd(map);
			} else if (map.containsKey(ApplicationConstant.CUSTOMER_BRING_UPS)) {
				customerGrpCd = getCustBringUpCustomerGrpCd(map);

			} else if (map.containsKey(ApplicationConstant.ACCOUNT_BRING_UPS)) {
				customerGrpCd = getAcntBringUpCustomerGrpCd(map);
			}
		}
		return customerGrpCd;
	}

	private String getAllCustomerGrpCd(ModelMap map) {
		List<CustomerDetails> customerDetailsList = (List<CustomerDetails>) map.get(ApplicationConstant.ALL_CUSTOMERS);
		return (!CollectionUtils.isEmpty(customerDetailsList) && customerDetailsList.size() == 1)
				? customerDetailsList.get(0).getCustomerGrpCd().trim()
				: "";
	}

	private String getMyCustomerGrpCd(ModelMap map) {
		List<MyCustomerDetails> myCustomerDetailsList = (List<MyCustomerDetails>) map
				.get(ApplicationConstant.MY_CUSTOMERS);
		return (!CollectionUtils.isEmpty(myCustomerDetailsList) && myCustomerDetailsList.size() == 1)
				? myCustomerDetailsList.get(0).getCustomerGrpCd().trim()
				: "";
	}

	private String getCustBringUpCustomerGrpCd(ModelMap map) {
		List<CustomerBringUpDetails> customerBringUpDetailsList = (List<CustomerBringUpDetails>) map
				.get(ApplicationConstant.CUSTOMER_BRING_UPS);
		return (!CollectionUtils.isEmpty(customerBringUpDetailsList) && customerBringUpDetailsList.size() == 1)
				? customerBringUpDetailsList.get(0).getCustomerGrpCd().trim()
				: "";
	}

	private String getAcntBringUpCustomerGrpCd(ModelMap map) {
		List<AccountsBringUpDetails> accountsBringUpDetailsList = (List<AccountsBringUpDetails>) map
				.get(ApplicationConstant.ACCOUNT_BRING_UPS);
		return (!CollectionUtils.isEmpty(accountsBringUpDetailsList) && accountsBringUpDetailsList.size() == 1)
				? accountsBringUpDetailsList.get(0).getCustomerGrpCd().trim()
				: "";
	}

	@Override
	public List<CustomerAgedDetails> getCustomerAgedDetails(String profileName, String profileType,
			String strStateClause, String strOriginatingCompanyCD, String strQueryType, String strGroup,
			String strCustomerGrpCd, String strUserLoginCode, String strBillingPeriod, String strStatusClause,
			String strAccountStatusClause, String strClassClause, String strSegmentClause,
			String strOriginatingSystemClause, String myacctNbr, String rollupFlag, String acctInvFlag) {
		return customerAgedDetailsRepository.getCustomerAgedDetails(profileName, profileType, strStateClause,
				strOriginatingCompanyCD, strQueryType, strGroup, strCustomerGrpCd, strUserLoginCode, strBillingPeriod,
				strStatusClause, strAccountStatusClause, strClassClause, strSegmentClause, strOriginatingSystemClause,
				myacctNbr, rollupFlag, acctInvFlag);
	}

	@Override
	public Map<Object, Object> populateCustomers(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<CustomerDetails> customerDetailsList = null;
		List<MyCustomerDetails> myCustomerDetailsList = null;
		List<AccountsBringUpDetails> accountsBringUpDetailsList = null;
		List<CustomerBringUpDetails> customerBringUpDetailsList = null;
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());

		if (StringUtils.isNotEmpty(selectedGroups) && StringUtils.isEmpty(userDetails.getCustomerGrpCd())) {
			if (userDetails.getCustomerType().equals(ApplicationConstant.CUSTOMER_TYPE_ALL_CUSTOMER)) {
				customerDetailsList = getCustomerDetails(userDetails.getBillingPeriod(), selectedGroups,
						userDetails.getEnteredValue());
				responseMap.put(ApplicationConstant.ALL_CUSTOMERS, customerDetailsList);
			} else {
				if (StringUtils.isNotEmpty(userDetails.getRegion())
						&& StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
					if (userDetails.getCustomerType().equals(ApplicationConstant.CUSTOMER_TYPE_MY_CUSTOMER)) {
						myCustomerDetailsList = getCustomerDetailsPersonal(selectedGroups, userDetails.getRegion(),
								userDetails.getBillingPeriod(), userDetails.getUserLoginCd(),
								userDetails.getEnteredValue());
						responseMap.put(ApplicationConstant.MY_CUSTOMERS, myCustomerDetailsList);
					} else if (userDetails.getCustomerType()
							.equals(ApplicationConstant.CUSTOMER_TYPE_CUSTOMER_BRING_UPS)) {
						customerBringUpDetailsList = getCustomerDetailsBringUp(selectedGroups, userDetails.getRegion(),
								userDetails.getBillingPeriod(), userDetails.getUserLoginCd(),
								userDetails.getEnteredValue(), "C");
						responseMap.put(ApplicationConstant.CUSTOMER_BRING_UPS, customerBringUpDetailsList);
					} else if (userDetails.getCustomerType()
							.equals(ApplicationConstant.CUSTOMER_TYPE_ACCOUNT_BRING_UPS)) {
						accountsBringUpDetailsList = getAccountDetailsBringUp(selectedGroups, userDetails.getRegion(),
								userDetails.getBillingPeriod(), userDetails.getUserLoginCd(),
								userDetails.getEnteredValue(), "A");
						responseMap.put(ApplicationConstant.ACCOUNT_BRING_UPS, accountsBringUpDetailsList);
					}
				}
			}

		}
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateInvoiceView(UserDetails userDetails, Map<Object, Object> responseMap) {

		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String customerType = getCustomerType(userDetails.getCustomerType());
		String originatingSystem = "";
		String statusClause = "";
		String exclusionClass = "";
		String segment = "";
		String accountInvFanVal = StringUtils.isNotEmpty(userDetails.getAcctInvFan()) ? userDetails.getAcctInvFan()
				: "";
		String accountInvType = StringUtils.isNotEmpty(userDetails.getAcctInvFanType())
				? userDetails.getAcctInvFanType()
				: "account";
		Integer rollUp = userDetails.getRollUp() != null ? userDetails.getRollUp() : 1;
		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		}
		if (!CollectionUtils.isEmpty(userDetails.getStatusClause())) {
			statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		}
		if (!CollectionUtils.isEmpty(userDetails.getExclusionClass())
				&& !userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}
		if (!CollectionUtils.isEmpty(userDetails.getSegment())) {
			segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		}
		if (StringUtils.isNotEmpty(selectedGroups) || StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			List<InvoiceViewDetails> agedDetail = getInvoiceViewDetails(userDetails.getProfileName(),
					userDetails.getProfileType(), "", "", customerType, selectedGroups,
					userDetails.getCustomerGrpCd().trim(), userDetails.getUserLoginCd().trim(),
					userDetails.getBillingPeriod().trim(), statusClause, userDetails.getExclusions().trim(),
					exclusionClass, segment, originatingSystem, accountInvFanVal, rollUp.toString(), accountInvType);
			responseMap.put(ApplicationConstant.INVOICE_VIEW, agedDetail);
			commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(),
					ApplicationConstant.INVOICE_VIEW, responseMap);

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return responseMap;
	}

	@Override
	public Map<Object, Object> getsingleCustomerSummary(UserDetails userDetails, Map<Object, Object> responseMap) {

		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String customerType = getCustomerType(userDetails.getCustomerType());
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		String exclusionClass = "";
		String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		if (!userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}
		if (StringUtils.isNotEmpty(selectedGroups) && StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			List<SummaryDetails> agedDetail = summaryDetailsRepository.getsingleCustomerSummary(
					userDetails.getProfileName(), userDetails.getProfileType(), customerType, "", selectedGroups,
					userDetails.getCustomerGrpCd(), userDetails.getUserLoginCd(), userDetails.getBillingPeriod(),
					statusClause, userDetails.getExclusions(), exclusionClass, segment, originatingSystem);
			responseMap.put(ApplicationConstant.SUMMARY_DETAIL, agedDetail);
			commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(),
					ApplicationConstant.SUMMARY_DETAIL, responseMap);

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return responseMap;
	}

	@Override
	public String getCustomerType(Integer customerCode) {
		String customerType = "";
		switch (customerCode) {
		case 0:
			customerType = ApplicationConstant.ALL_CUSTOMERS;
			break;
		case 1:
			customerType = ApplicationConstant.MY_CUSTOMERS;
			break;
		case 2:
			customerType = ApplicationConstant.CUSTOMER_BRING_UPS;
			break;
		case 3:
			customerType = ApplicationConstant.ACCOUNT_BRING_UPS;
			break;
		default:
			customerType = ApplicationConstant.ALL_CUSTOMERS;
			break;

		}

		return customerType;
	}

	@Override
	public Map<Object, Object> viewInternalContacts(UserDetails userDetails, Map<Object, Object> responseMap) {

		String selectedAccountNumbers = CommonUtils
				.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());
		String originatingSystems = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());

		if (StringUtils.isNotEmpty(selectedAccountNumbers) && StringUtils.isNotEmpty(originatingSystems)) {
			List<ViewInternalContacts> viewInternalContactsList = viewInternalContactsRepository
					.viewInternalContacts(userDetails.getUserLoginCd(), selectedAccountNumbers, originatingSystems);
			responseMap.put(ApplicationConstant.VIEW_INTERNAL_CONTACTS, viewInternalContactsList);

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return responseMap;
	}

	@Override
	public Map<Object, Object> getEmaorView(UserDetails userDetails, Map<Object, Object> responseMap) {

		String selectedAccountNumbers = CommonUtils
				.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());
		String originatingSystems = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());

		if (StringUtils.isNotEmpty(selectedAccountNumbers) && StringUtils.isNotEmpty(originatingSystems)) {
			List<EmaorView> emaorViewList = emaorViewRepository.getEmaorView(selectedAccountNumbers, originatingSystems,
					userDetails.getUserLoginCd());
			responseMap.put(ApplicationConstant.EMAOR_VIEW, emaorViewList);

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return responseMap;
	}

	@Override
	public List<InvoiceViewDetails> getInvoiceViewDetails(String profileName, String profileType, String strStateClause,
			String strOriginatingCompanyCD, String strQueryType, String strGroup, String strCustomerGrpCd,
			String strUserLoginCode, String strBillingPeriod, String strStatusClause, String strAccountStatusClause,
			String strClassClause, String strSegmentClause, String strOriginatingSystemClause, String myacctNbr,
			String rollupFlag, String acctInvFlag) {
		return invoiceViewRepository.getInvoiceViewDetails(profileName, profileType, strStateClause,
				strOriginatingCompanyCD, strQueryType, strGroup, strCustomerGrpCd, strUserLoginCode, strBillingPeriod,
				strStatusClause, strAccountStatusClause, strClassClause, strSegmentClause, strOriginatingSystemClause,
				myacctNbr, rollupFlag, acctInvFlag);
	}

	@Override
	public Map<Object, Object> accountPastDue(String accountNumber, String acntNoteOrgSys,
			Map<Object, Object> responseMap) {
		List<AccountPastDueDetails> pastDueDetails = accountPastDueDetailsRepository
				.getAccountPastDueDetails(accountNumber, acntNoteOrgSys);
		responseMap.put(ApplicationConstant.PAST_DUE_DETAILS, pastDueDetails);
		List<AccountPastDueAmount> pastDueAmountDetails = accountPastDueAmountRepository
				.getAccountPastDueAmountDetails(accountNumber, acntNoteOrgSys);
		responseMap.put(ApplicationConstant.PAST_DUE_AMOUNT_DETAILS, pastDueAmountDetails);
		return responseMap;
	}

	@Override
	public Map<Object, Object> cashDataDetails(String accountNumber, Integer byPayment, Integer byAdjustment,
			String acntNoteOrgSys, Map<Object, Object> responseMap) {
		List<CashDataDetails> cashDataDetails = cashDataDetailsRepository.getCashDataDetails(accountNumber, byPayment,
				byAdjustment, acntNoteOrgSys);
		responseMap.put(ApplicationConstant.CASH_DATA_DETAILS, cashDataDetails);
		return responseMap;
	}

	@Override
	public Map<Object, Object> breakdownDetails(String accountNumber, String acntNoteOrgSys,
			Map<Object, Object> responseMap) {
		List<BreakdownDetails> breakdownDetails = breakdownDetailsRepository.getBreakDownDetails(accountNumber,
				acntNoteOrgSys);
		responseMap.put(ApplicationConstant.BREAKDOWN_DETAILS, breakdownDetails);
		return responseMap;
	}

	@Override
	public Map<Object, Object> taxiClaimDetails(String accountNumber, String acntNoteOrgSys,
			Map<Object, Object> responseMap) {
		List<TaxiClaimDetails> taxiClaimDetails = taxiClaimDetailsRepository.getTaxiClaimDetails(accountNumber,
				acntNoteOrgSys);
		responseMap.put(ApplicationConstant.TAXI_CLAIM_DETAILS, taxiClaimDetails);
		return responseMap;
	}

	@Override
	public Map<Object, Object> getCustAPSubGrp(UserDetails userDetails, Map<Object, Object> responseMap) {

		if (StringUtils.isEmpty(userDetails.getCustomerGrpCd())) {
			List<TableMaintenanceAcnaComboBox> custDDList = tableMaintenanceAcnaRepository
					.getCustomerLb(userDetails.getUserBusGrp());
			responseMap.put(ApplicationConstant.AP_SUB_GROUP_CUSTOMER_DETAILS, custDDList);

		} else {
			List<CustomerApSubGroup> apSubGrp = customerSubGroupRepository.getCustAPSubGrp(
					userDetails.getCustomerGrpCd(), userDetails.getStrSort(), userDetails.getStrFilter());
			responseMap.put(ApplicationConstant.CUSTOMER_SUB_GRP, apSubGrp);
		}

		return responseMap;
	}

	@Override
	public Map<Object, Object> apSubGroupUpdate(UserDetails userDetails, Map<Object, Object> responseMap) {

		customerSubGroupRepository.apSubGroupUpdate(userDetails.getCustomerGrpCd(), userDetails.getApSubGroupName(),
				userDetails.getGroupDesc(), userDetails.getInsertLoginCd(), userDetails.getUpdateLoginCd(),
				userDetails.getFunction());
		responseMap.put("MESSAGE", ApplicationConstant.SUCCESS);
		return responseMap;
	}
}

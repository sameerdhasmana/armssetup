package com.att.arms.entity;

import java.util.List;

import lombok.Data;
@Data
public class ProfileModel {
	private String userLoginCd;
	private String profileType;
	private String profileName;
	private String profileOwner;
	private String queryType;
	private String customerGrpCd;
	private String queryAcna;
	private String queryAecn;
	private String queryOcn;
	private String queryCtc;
	private String queryBillName;
	private String exclusions;
	private String businessGroup;
	private String billingPeriod;
	private List<String> exclusionClass;
	private List<String> originatingSystem;
	private List<String> groupSelected;
	private List<String> statusClause;
	private List<String> segment;
	private String rollUptoParent;
	private String bringUpDateRef;
	private String bringUpType;
	private List<String> flagActivity;
	private List<String> flagActivityDesc;
	private String flagDateRef;
	private String amountType;
	private String amountOperator;
	private Double amountValue;
	private String disputedAmountRef;
	private String contestedAmountRef;
	private String unappliedAmtOperator;
	private Double unappliedAmtValue;
	private String userAssignmentInd;
	private String sort1Field;
	private String sort2Field;
	private String sort3Field;
	private String sort4Field;
	private String sort5Field;
	private String sort1Order;
	private String sort2Order;
	private String sort3Order;
	private String sort4Order;
	private String sort5Order;
	private List<String> h1Logins;
}

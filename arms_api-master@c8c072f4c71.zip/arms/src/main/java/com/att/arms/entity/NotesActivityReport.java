package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.Data;

@Entity
@IdClass(NotesActivityReport.NotesActivityReportId.class)
@Data
public class NotesActivityReport {

	@Column(name = "Customer")
	private String customer;
	@Column(name = "UserName")
	private String userName;
	@Column(name = "MgrUID")
	private String mgrUid;
	@Id
	@Column(name = "InsertDate")
	private String insertDate;
	@Column(name = "Month")
	private String month;
	@Column(name = "NoteType")
	private String noteType;
	@Id
	@Column(name = "Acct_nbr")
	private String acctNbr;
	@Column(name = "Activity")
	private String activity;
	@Column(name = "SubActivity")
	private String subActivity;
	@Column(name = "BUDate")
	private String buDate;
	@Column(name = "Commitment_Amt")
	private Double commitmentAmt;
	@Id
	@Column(name = "NoteText")
	private String noteText;
	@Id
	@Column(name = "originating_system")
	private String originatingSystem;

	@SuppressWarnings("serial")
	@Data
	public static class NotesActivityReportId implements Serializable {

		private String acctNbr;
		private String originatingSystem;
		private String noteText;
		private String insertDate;
		
		
	}

}

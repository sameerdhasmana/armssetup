package com.att.arms.reports.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.reports.entity.TemplateCriteriaDetails;
import com.att.arms.reports.entity.TemplateDetailsModel;
import com.att.arms.reports.entity.UserTemplateDetails;
import com.att.arms.reports.repo.TemplateFileDetailsRepository;
import com.att.arms.reports.repo.TemplateFilesDetailsRepository;
import com.att.arms.reports.repo.TemplateReportSaveDetailsRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class TemplateReportsServiceImpl implements TemplateReportsService {

	@Autowired
	TemplateReportSaveDetailsRepository templateReportSaveDetailsRepository;

	@Autowired
	TemplateFileDetailsRepository templateFileDetailsRepository;

	@Autowired
	TemplateFilesDetailsRepository templateFilesDetailsRepository;
	
	@Override
	public Map<Object, Object> saveOrUpdateTemplateFile(TemplateDetailsModel templateDetailsModel,
			Map<Object, Object> responseMap) {
		String exclusionClass = CommonUtils.getListToCommaSeparatedString(templateDetailsModel.getExclusionClass());
		String originatingSystem = CommonUtils
				.getListToCommaSeparatedString(templateDetailsModel.getOriginatingSystem());
		String region = CommonUtils.getListToCommaSeparatedString(templateDetailsModel.getOriginatingCompanyCdClause());
		String group = CommonUtils.getListToCommaSeparatedString(templateDetailsModel.getGroupSelected());
		String status = CommonUtils.getListToCommaSeparatedString(templateDetailsModel.getStatusClause());
		String segment = CommonUtils.getListToCommaSeparatedString(templateDetailsModel.getSegment());
		String customerList = CommonUtils.getListToCommaSeparatedString(templateDetailsModel.getCustomerGrpCd());
		String templatedSelectedFields = CommonUtils
				.getListToCommaSeparatedString(templateDetailsModel.getTemplateSelectedFields());
		String groupByFields = CommonUtils.getListToCommaSeparatedString(templateDetailsModel.getGroupByFields());
		String sortByFields = CommonUtils.getListToCommaSeparatedString(templateDetailsModel.getSortByFields());
		String criteriaClause = CommonUtils.getListToCommaSeparatedString(templateDetailsModel.getCriteriaClause());
		int response = 0;
			List<UserTemplateDetails> templateDetailsList = templateFilesDetailsRepository.getTemplateFilesDetails(templateDetailsModel.getUserLoginCd(),
				templateDetailsModel.getReportType());
		
		for(UserTemplateDetails userTemplateDetails:templateDetailsList) {
			if(userTemplateDetails.getReportDisplayName().equals(templateDetailsModel.getReportName())){
				responseMap.put("msg", ReportsConstant.DUPLICATE_NAME);
				return responseMap;
			}
		}
		
		if (templateDetailsModel.getUpdatedType().equalsIgnoreCase("I")) {
			response = templateReportSaveDetailsRepository.saveTemplateCriteriaDetails(
					templateDetailsModel.getUserLoginCd(), templateDetailsModel.getUpdatedType(),
					templateDetailsModel.getReportType(), templateDetailsModel.getReportName(), status, group, region,
					templateDetailsModel.getCustomerChildFlag(), customerList, segment,
					templateDetailsModel.getExclusions(), exclusionClass, originatingSystem, templatedSelectedFields,
					groupByFields, sortByFields, templateDetailsModel.getSortOrder(), criteriaClause);
			if (response != 0) {
				responseMap.put("msg", ReportsConstant.SUCCESSFULLY_INSERTED);
			} else {
				responseMap.put("msg", ApplicationConstant.ERROR_MESSSAGE);
			}

		} else if (templateDetailsModel.getUpdatedType().equalsIgnoreCase("U")) {
			response = templateReportSaveDetailsRepository.updateTemplateCriteriaDetails(

					templateDetailsModel.getUserLoginCd(), templateDetailsModel.getUpdatedType(),
					templateDetailsModel.getReportType(), templateDetailsModel.getReportName(), status, group, region,
					templateDetailsModel.getCustomerChildFlag(), customerList, segment,
					templateDetailsModel.getExclusions(), exclusionClass, originatingSystem, templatedSelectedFields,
					groupByFields, sortByFields, templateDetailsModel.getSortOrder(), criteriaClause);
			if (response != 0) {
				responseMap.put("msg", ReportsConstant.SUCCESSFULLY_UPDATED);
			} else {
				responseMap.put("msg", ApplicationConstant.ERROR_MESSSAGE);
			}
		}

		return responseMap;
	}

	@Override
	public void deleteTemplateFile(String userLoginCd, String updatedType, String reportType, String reportName) {
		templateReportSaveDetailsRepository.deleteTemplateFile(userLoginCd, updatedType, reportType, reportName);
	}

	@Override
	public Map<Object, Object> loadSelectedTemplateFile(String userLoginCd, String reportType, String reportName,
			Map<Object, Object> responseMap) {
		TemplateCriteriaDetails templateDetails = templateFileDetailsRepository.getTemplateFileDetails(userLoginCd,
				reportType, reportName);
		if (templateDetails != null) {
			List<String> exclusionClass = CommonUtils
					.getCommaSeparatedStringToList(templateDetails.getReportExclusionClass());
			templateDetails.setExclusionClass(exclusionClass);
			List<String> originatingSystem = CommonUtils
					.getCommaSeparatedStringToList(templateDetails.getReportOriginatingSystem());
			templateDetails.setOriginatingSystem(originatingSystem);
			List<String> businessGroup = CommonUtils
					.getCommaSeparatedStringToList(templateDetails.getReportBusinessGroup());
			templateDetails.setBusinessGroup(businessGroup);
			List<String> statusClause = CommonUtils
					.getCommaSeparatedStringToList(templateDetails.getReportStatusClause());
			templateDetails.setStatusClause(statusClause);
			List<String> segment = CommonUtils.getCommaSeparatedStringToList(templateDetails.getReportSegment());
			templateDetails.setSegment(segment);

			List<String> customerGrpCd = CommonUtils
					.getCommaSeparatedStringToList(templateDetails.getReportCustomerGrpCd());
			templateDetails.setCustomerGrpCd(customerGrpCd);

			List<String> templateSelectedFields = CommonUtils
					.getCommaSeparatedStringToList(templateDetails.getReportTemplateFields());
			templateDetails.setTemplateSelectedFields(templateSelectedFields);

			List<String> groupByFields = CommonUtils
					.getCommaSeparatedStringToList(templateDetails.getReportGroupByFields());
			templateDetails.setGroupByFields(groupByFields);

			List<String> sortByFields = CommonUtils
					.getCommaSeparatedStringToList(templateDetails.getReportSortByFields());
			templateDetails.setSortByFields(sortByFields);

			List<String> criteriaClause = CommonUtils
					.getCommaSeparatedStringToList(templateDetails.getReportCriteriaClause());
			templateDetails.setCriteriaClause(criteriaClause);

			responseMap.put(ReportsConstant.TEMPLATE_DETAILS, templateDetails);
		}
		return responseMap;
	}

}

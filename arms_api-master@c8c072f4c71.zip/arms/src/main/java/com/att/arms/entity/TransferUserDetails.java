package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(TransferUserDetails.TransferUserDetailsId.class)

@Data
public class TransferUserDetails {

	@Id
	@JsonProperty("user_login_cd")
	@Column(name = "user_login_cd")
	private String userLoginCd;
	@JsonProperty("UserLogin")
	@Column(name = "UserLogin")
	private String userLogin;

	@Data
	public static class TransferUserDetailsId implements Serializable {

		private static final long serialVersionUID = 1L;		
		private String userLogin;		
		private String userLoginCd;
	}

}

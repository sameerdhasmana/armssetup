package com.att.arms.jwt;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class JwtInMemoryUserDetailsService implements UserDetailsService {

	@Value("${jwt.http.request.userName}")
	private String jwtUserName;

	@Value("${jwt.http.request.pass}")
	private String jwtPass;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		if (jwtUserName.equals(username)) {
			return new User(jwtUserName, jwtPass, new ArrayList<>());
		} else {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
	}
}

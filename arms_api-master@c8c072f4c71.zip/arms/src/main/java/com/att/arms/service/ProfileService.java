package com.att.arms.service;

import java.util.Map;

import com.att.arms.entity.ProfileModel;
import com.att.arms.entity.RequestModel;

public interface ProfileService {

	Map<Object, Object> renderManageProfile(String userLoginCd, String businessGroup, Map<Object, Object> responseMap);

	Map<Object, Object> populateProfileDetails(String userLoginCd, Map<Object, Object> responseMap);

	Map<Object, Object> populateProfileCustomers(RequestModel requestModel, Map<Object, Object> responseMap);

	boolean validatePopulateCustomerQuery(RequestModel requestModel);

	Map<Object, Object> saveManageProfile(ProfileModel profileModel, Map<Object, Object> responseMap);

	boolean validateSaveManageProfileQuery(ProfileModel profileModel);

	boolean validateDefaultProfileQuery(ProfileModel profileModel);

	Map<Object, Object> setDefaultProfile(String userLoginCd, String profileName, String profileType,
			Map<Object, Object> responseMap);

	Map<Object, Object> deleteProfile(String userLoginCd, String profileName, String profileType,
			Map<Object, Object> responseMap);

	Map<Object, Object> loadProfile(String userLoginCd, String profileName, String profileType,
			Map<Object, Object> responseMap);

	Map<Object, Object> executeProfile(ProfileModel profileModel, Map<Object, Object> responseMap);

}

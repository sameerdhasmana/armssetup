package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(PaymentTerm.PaymentTermsId.class)
@Data
public class PaymentTerm {

	@Id
	@JsonProperty("account_number")
	@Column(name="acct_nbr")
	private String accountNumber;
	@Id
	@JsonProperty("originating_system")
	@Column(name="originating_system")
	private String originatingSystem;
	@JsonProperty("payment_terms")
	@Column(name="payment_terms")
	private String paymentTerms;

	@SuppressWarnings("serial")
	@Data
	public static class PaymentTermsId implements Serializable {

		private String accountNumber;
		private String originatingSystem;
		
	}
}

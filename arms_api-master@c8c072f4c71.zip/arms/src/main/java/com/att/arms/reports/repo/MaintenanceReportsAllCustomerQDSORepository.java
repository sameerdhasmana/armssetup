package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.reports.entity.MaintainanceReportAllCustomerQDSODetails;


@Transactional
public interface MaintenanceReportsAllCustomerQDSORepository extends JpaRepository<MaintainanceReportAllCustomerQDSODetails, String>{
	
	@Query(value = "exec arms_rpt_allcustomer_QDSO_by_grp_region_LFW :billingPeriod,:originatingSystem,:reportStatus", nativeQuery = true)
	public List<MaintainanceReportAllCustomerQDSODetails> findMaintainanceReportAllCustomerQDSODetailsList(@Param("billingPeriod") String billingPeriod,@Param("originatingSystem") String originatingSystem, @Param("reportStatus") String reportStatus);
	
	
}

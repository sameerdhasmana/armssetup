package com.att.arms.reports.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.reports.entity.TemplateCriteriaDetails;

@Transactional
public interface TemplateFileDetailsRepository extends JpaRepository<TemplateCriteriaDetails, String> {

	@Query(value = "Exec arms_rpt_user_rpt_view_v22 :userLoginCd,:reportType,:reportName", nativeQuery = true)
	public TemplateCriteriaDetails getTemplateFileDetails(@Param("userLoginCd") String userLoginCd,
			@Param("reportType") String reportType, @Param("reportName") String reportName);
}

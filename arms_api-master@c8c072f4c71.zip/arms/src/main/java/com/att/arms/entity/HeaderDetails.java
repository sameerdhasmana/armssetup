package com.att.arms.entity;

import lombok.Data;

@Data
public class HeaderDetails {

	private String userLoginCd;
	private String moduleName;
	private String headerParams;

}

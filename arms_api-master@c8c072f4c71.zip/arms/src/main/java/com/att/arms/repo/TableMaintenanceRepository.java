package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.TableMaintenanceAcna;

@Transactional
public interface TableMaintenanceRepository extends JpaRepository<TableMaintenanceAcna, String> {

	@Query(value = "Exec arms_tablemaint_acna_all_records_ex :strFilter,:strSort", nativeQuery = true)
	public List<TableMaintenanceAcna> getAcnaMaintRecords(@Param("strFilter") String strFilter,
			@Param("strSort") String strSort);

	@Modifying
	@Query(value = "Exec arms_tblmaint_segment_updt_v22 :segment_cd,:description,:group,:bus_unit,:webtaxi_xcld,:function,:user_login_cd", nativeQuery = true)
	public void segmentUpdate(@Param("segment_cd") String segmentCd, @Param("description") String description,
			@Param("group") String group, @Param("bus_unit") String busUnit, @Param("webtaxi_xcld") String webtaxiXcld,
			@Param("function") String function, @Param("user_login_cd") String userLoginCd);

}

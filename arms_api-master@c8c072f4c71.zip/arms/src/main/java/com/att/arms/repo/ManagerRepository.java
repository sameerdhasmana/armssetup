package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.Manager;

@Transactional
public interface ManagerRepository extends JpaRepository<Manager, String> {

	@Query(value = "select distinct h2uid from arms_rpt_hierarchy with (nolock) where h2uid is not null order by h2uid", nativeQuery = true)
	public List<Manager> getAllManagers();

}

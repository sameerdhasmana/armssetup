package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.TableMaintenanceModel;
import com.att.arms.service.TableMaintenanceService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class TableMaintenanceController {

	@Autowired
	TableMaintenanceService tableMaintenanceService;

	@PostMapping("acnaMaintenance")
	public ResponseEntity<Object> getAcnaMaintRecords(@RequestBody TableMaintenanceModel tableMaintModel) {
		boolean response = this.tableMaintenanceService.validateQueryRequest(tableMaintModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.tableMaintenanceService.getAcnaMaintRecords(tableMaintModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	@PostMapping("aecnMaintenance")
	public ResponseEntity<Object> getAecnMaintRecords(@RequestBody TableMaintenanceModel tableMaintModel) {
		boolean response = this.tableMaintenanceService.validateQueryRequest(tableMaintModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.tableMaintenanceService.getAecnMaintRecords(tableMaintModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("customerInfo")
	public ResponseEntity<Object> getCustomerInfo() {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = this.tableMaintenanceService.getCustomerInfo(responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("fetchCustomerUsage")
	public ResponseEntity<Object> getCustomerUsage(@RequestBody TableMaintenanceModel tableMaintModel) {
		boolean response = this.tableMaintenanceService.validateQueryRequest(tableMaintModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.tableMaintenanceService.getCustomerUsage(tableMaintModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("fetchMessage")
	public ResponseEntity<Object> fetchMessage() {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = this.tableMaintenanceService.fetchMessage(responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("modifyMenuMsg")
	public ResponseEntity<Object> modifyMenuMsg(@RequestBody TableMaintenanceModel tableMaintModel) {
		boolean response = this.tableMaintenanceService.validateQueryRequest(tableMaintModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.tableMaintenanceService.modifyMenuMsg(tableMaintModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("fetchCustMaintenance")
	public ResponseEntity<Object> fetchCustMaintenance(@RequestBody TableMaintenanceModel tableMaintModel) {
		boolean response = this.tableMaintenanceService.validateQueryRequest(tableMaintModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.tableMaintenanceService.fetchCustMaintenance(tableMaintModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("fetchSegmentMaintenance")
	public ResponseEntity<Object> fetchSegmentMaintenance(@RequestBody TableMaintenanceModel tableMaintModel) {
		boolean response = this.tableMaintenanceService.validateQueryRequest(tableMaintModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.tableMaintenanceService.fetchSegmentMaintenance(tableMaintModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("segmentUpdate")
	public ResponseEntity<Object> segmentUpdate(@RequestBody TableMaintenanceModel segmentUpdateModel) {
		boolean response = this.tableMaintenanceService.validateSegmentUpdateQueryRequest(segmentUpdateModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.tableMaintenanceService.segmentUpdate(segmentUpdateModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

}
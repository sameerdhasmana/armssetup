package com.att.arms.config;


public class ReportsConstant {

	// CannedReports-Maintenance Reports
	public static final String GROUP = "Group";
	public static final String REGION = "Region";
	public static final String SEGMENT = "Segment";
	public static final String STATUS = "Status";
	public static final String CURRENT_BILLING = "Current Billing";
	public static final String PAST_DUE_0_DAYS = "0 Days past Due";
	public static final String PAST_DUE_30_DAYS = "30 Days past Due";
	public static final String PAST_DUE_60_DAYS = "60 Days past Due";
	public static final String PAST_DUE_90_DAYS = "90 Days past Due";
	public static final String PAST_DUE_120_DAYS = "120 Days past Due";
	public static final String TOTAL_PAST_DUE = "Total Past Due";
	public static final String TOTAL_DUE = "Total Due";
	public static final String DISPUTE = "Dispute";
	public static final String QDSO = "Q-DSO";

	public static final String CUSTOMER = "Customer";
	public static final String CURRENT_BALANCE = "Current Balance";
	public static final String DSO = "DSO";
	public static final String BILLING_PERIOD = "Billing Period";
	public static final String CUSTOMER_GRP_CD = "Customer_Grp_Cd";
	public static final String STATE = "State";
	 
	public static final String CUSTOMER_GRP_ID = "customer_grp_cd";
	public static final String ACCOUNT_NUMBER = "Account Number";
	public static final String ACNA = "ACNA";
	public static final String AECN = "AECN";
	public static final String OCN = "OCN";
	public static final String BILL_DATE = "Bill Date";
	public static final String BILL_NAME = "Bill Name";
	public static final String CURRNET_BILLING_AMOUNT = "Current Billing Amount";
	public static final String PAST_DUE_ZERO_AMOUNT = "Past Due 0 Amount";
	public static final String TOTAL_AMOUNT = "Total Amount";
	public static final String DENIED_DISP_AMOUT = "Denied Disp Amt";
	public static final String DISPUTE_INTERVAL = "Dispute Interval";
	public static final String ACCT_NBR = "Acct Nbr";
	public static final String SEG = "Seg";

	//Template Reports Constants
		public static final String TEMPLATE_DETAILS = "templateDetails";
		public static final String USER_TEMPLATE_DETAILS="userTemplateDetails";
		public static final String SUCCESSFULLY_INSERTED="Successfully Inserted";
		public static final String SUCCESSFULLY_UPDATED="Successfully Updated";
		public static final String SUCCESSFULLY_DELETED="Successfully Deleted";
		public static final String DUPLICATE_NAME="Duplicate Name. Try with New One.";

}

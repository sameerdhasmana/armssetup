package com.att.arms.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.CustomerNotes;
import com.att.arms.entity.CustomerNotesNextAction;
import com.att.arms.entity.CustomerNotesRootCause;
import com.att.arms.entity.CustomerPermNotes;
import com.att.arms.entity.SubActivity;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.CustomerNotesNextActionRepository;
import com.att.arms.repo.CustomerNotesRepository;
import com.att.arms.repo.CustomerNotesRootCauseRepository;
import com.att.arms.repo.CustomerPermNotesRepository;
import com.att.arms.repo.SubActivityRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class CustomerNotesServiceImpl implements CustomerNotesService {

	@Autowired
	CustomerNotesRepository customerNotesRepository;
	@Autowired
	CustomerNotesNextActionRepository customerNotesNextActionRepository;
	@Autowired
	CustomerNotesRootCauseRepository customerNotesRootCauseRepository;
	@Autowired
	SubActivityRepository subActivityRepository;
	@Autowired
	CommonService commonService;
	@Autowired
	CustomerPermNotesRepository customerPermNotesRepository;

	@Override
	public Map<Object, Object> populateCustomerNotes(String userLoginCd,String customerGrpCd, Map<Object, Object> responseMap) {

		List<CustomerNotes> customerNotes = customerNotesRepository.getCustomerNotes(customerGrpCd);
		commonService.populateHeaderParameters(userLoginCd, ApplicationConstant.CUSTOMER_NOTES, responseMap);
		responseMap.put(ApplicationConstant.CUSTOMER_NOTES, customerNotes);
		return responseMap;
	}

	@Override
	public Map<Object, Object> populateCustomerNotesContactInfo(String customerGrpCd, Map<Object, Object> responseMap) {
		List<Object[]> customerNotesInfo = new ArrayList<>();
		List<Object[]> customerNotes = customerNotesRepository.getCustomerNotesContactInfo(customerGrpCd);
		if (!CollectionUtils.isEmpty(customerNotes)) {
			customerNotes.stream().forEach(ele -> {
				StringJoiner joiner = new StringJoiner(",");
				Object[] objArr= new Object[1];
				for (Object obj : ele) {
					joiner.add((String) obj);
				}
				if (StringUtils.isNotEmpty(joiner.toString())) {
					objArr[0]=joiner.toString();
					customerNotesInfo.add(objArr);
				}
			});
		}
		responseMap.put(ApplicationConstant.CUSTOMER_NOTES_CONTACT_INFO, customerNotesInfo);
		return responseMap;
	}

	@Override
	public Map<Object, Object> addCustomerNote(String userLoginCd,String customerGrpCd, Map<Object, Object> responseMap) {
		responseMap=populateCustomerNotesContactInfo(customerGrpCd, responseMap);
		List<String> groupList = customerNotesRepository.getBusinessGroupList(userLoginCd, 1);
		responseMap.put(ApplicationConstant.BUSINESS_GROUP, groupList);
		List<CustomerNotesNextAction> nextActionList = customerNotesNextActionRepository.getCustomerNotesNextAction(userLoginCd);
		responseMap.put(ApplicationConstant.NEXT_ACTION,nextActionList);
		List<CustomerNotesRootCause> rootCauseList = customerNotesRootCauseRepository.getCustomerNotesRootCause(userLoginCd);
		responseMap.put(ApplicationConstant.ROOT_CAUSE,rootCauseList);
		List<SubActivity> subActivityList = subActivityRepository.getSubActivityList("C");
		responseMap.put(ApplicationConstant.SUB_ACTIVITY,subActivityList);
		return responseMap;
	}
	
	@Override
	public Map<Object, Object> saveCustomerNote(UserDetails userDetails, Map<Object, Object> responseMap) {
		String selectedGrp=CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		if(StringUtils.isNotEmpty(selectedGrp)) {
		customerNotesRepository.saveCustomerNote(userDetails.getModeType(), userDetails.getNoteId(), userDetails.getBillingPeriod(), "", 
				selectedGrp, userDetails.getCustomerGrpCd(), userDetails.getResolved(), userDetails.getActivityCode(), userDetails.getCommitmentAmt()
				, userDetails.getBringupDate(), userDetails.getSubActivity(), userDetails.getTalkedTo()
				, userDetails.getUserLoginCd(), userDetails.getNotes(), userDetails.getContestedAmt(), userDetails.getRcCode()
				, userDetails.getNxtactCode(), userDetails.getCommitmentDate());
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		}else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "Unable to save the note due to insufficient input");	
		}
		return responseMap;
	}
	
	@Override 
	public boolean validateNotesQuery(UserDetails userDetails) {
		boolean response=false;
		if (StringUtils.isNotEmpty(userDetails.getNotes()) && userDetails.getNoteId()!=null && StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
			response= true;
		}
		return response;
	}
	
	@Override 
	public boolean validateSaveNotesQuery(UserDetails userDetails) {
		boolean response=false;
		if (StringUtils.isNotEmpty(userDetails.getBillingPeriod()) && StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& !CollectionUtils.isEmpty(userDetails.getGroupSelected()) &&
				StringUtils.isNotEmpty(userDetails.getCustomerGrpCd()) && StringUtils.isNotEmpty(userDetails.getActivityCode())) {
			response= true;
		}
		return response;
	}
	
	@Override
	public Map<Object,Object> resolveCustomerNotes(String userLoginCd,String notes,Integer noteId,Map<Object,Object> responseMap){
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDate localDate = LocalDate.now();
		String date = dtf.format(localDate); 
		notes=notes+" resolved by "+userLoginCd+" on "+date;
		customerNotesRepository.resolveCustomerNotes(noteId, 1, notes);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}
	
	@Override
	public Map<Object,Object> deleteCustomerNotes(List<String> noteIdList,Map<Object,Object> responseMap){
		String noteList = CommonUtils.getListToCommaSeparatedString(noteIdList);
		customerNotesRepository.deleteCustomerNotes(noteList);
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
		
	}

	@Override
	public Map<Object, Object> customerPermNotes(String customerGrpCd, Map<Object, Object> responseMap) {
		List<CustomerPermNotes> permNotes=customerPermNotesRepository.getCustomerPermNotes(customerGrpCd);
		responseMap.put(ApplicationConstant.PERM_NOTES, permNotes);
		return responseMap;
	}
	
	@Override
	public Map<Object, Object> customerNotesHistory(String customerGrpCd, Map<Object, Object> responseMap) {
		List<CustomerPermNotes> customerHistoryNotes=customerPermNotesRepository.getCustomerHistoryNotes(customerGrpCd);
		responseMap.put(ApplicationConstant.CUSTOMER_NOTES_HISTORY, customerHistoryNotes);
		return responseMap;
	}

}

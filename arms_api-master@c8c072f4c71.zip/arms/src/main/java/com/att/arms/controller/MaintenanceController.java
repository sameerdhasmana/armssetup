package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.RequestModel;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.AccountsNoteService;
import com.att.arms.service.MaintenanceService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class MaintenanceController {

	@Autowired
	MaintenanceService maintenanceService;
	@Autowired
	AccountsNoteService accountsNoteService;

	@PostMapping("allContacts")
	public ResponseEntity<Object> getContacts() {
		Map<Object, Object> responseMap = new HashMap<>();
		responseMap = this.maintenanceService.getAllContacts(responseMap);
		if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("populateContacts")
	public ResponseEntity<Object> populateContacts(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			responseMap = this.maintenanceService.populateContacts(userDetails.getCustomerGrpCd(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("deleteContacts")
	public ResponseEntity<Object> deleteContacts(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = maintenanceService.validateDeleteQueryRequest(userDetails);
		if (response) {
			responseMap = this.maintenanceService.deleteContacts(userDetails.getCustomerGrpCd(),
					userDetails.getUserLoginCd(), userDetails.getSequence(), responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("saveContacts")
	public ResponseEntity<Object> saveContacts(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = maintenanceService.validateSaveQueryRequest(userDetails);
		if (response) {
			responseMap = this.maintenanceService.saveContacts(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("renderApSubGroup")
	public ResponseEntity<Object> renderApSubGroup(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = maintenanceService.validateSubGroupQueryRequest(userDetails);
		if (response) {
			responseMap = this.maintenanceService.renderApSubGroup(userDetails.getGroup(), userDetails.getRegion(),
					responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("renderApSubGroupGrid")
	public ResponseEntity<Object> renderApSubGroupGrid(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = maintenanceService.validateSubGroupGridQueryRequest(userDetails);
		if (response) {
			responseMap = this.maintenanceService.renderApSubGroupGrid(userDetails.getCustomerGrpCd(),userDetails.getBillingPeriod()
					,userDetails.getUserLoginCd(),userDetails.getGroup(), userDetails.getRegion(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("saveApSubGroupGrid")
	public ResponseEntity<Object> saveApSubGroupGrid(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = maintenanceService.validateSaveSubGroupGridQueryRequest(userDetails);
		if (response) {
			responseMap = this.maintenanceService.saveApSubGroupGrid(userDetails.getAccountNumber(),userDetails.getApSubGroupName()
					,userDetails.getUserLoginCd(),userDetails.getAcntNoteOrgSys(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("manageTemplateNotes")
	public ResponseEntity<Object> manageTemplateNotes(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(userDetails.getUserLoginCd())) {
			responseMap = this.maintenanceService.manageTemplateNotes(userDetails.getUserLoginCd(),
					responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("viewTemplate")
	public ResponseEntity<Object> viewTemplate(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validateGetNotesTextQuery(userDetails);
		if (response) {
			responseMap = this.maintenanceService.getTemplateDetails(userDetails.getUserLoginCd(),
					userDetails.getTemplateName(),userDetails.getTemplateType(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("deleteTemplate")
	public ResponseEntity<Object> deleteTemplate(@RequestBody UserDetails userDetails) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.accountsNoteService.validateGetNotesTextQuery(userDetails);
		if (response) {
			responseMap = this.maintenanceService.deleteTemplate(userDetails.getUserLoginCd(),
					userDetails.getTemplateName(),userDetails.getTemplateType(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("saveTemplate")
	public ResponseEntity<Object> saveTemplate(@RequestBody RequestModel requestModel) {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean response = this.maintenanceService.validateSaveTemplateQuery(requestModel);
		if (response) {
			responseMap = this.maintenanceService.saveTemplate(requestModel.getUserLoginCd(),
					requestModel.getTemplateName(),requestModel.getTemplateType()
					,requestModel.getTemplateOwner(),requestModel.getTemplateNote()
					,requestModel.getTemplateH1Logins(),responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
}
package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CPPODetails;

@Transactional
public interface CPPORepository extends JpaRepository<CPPODetails, String> {

	@Query(value = "Exec arms_custqry_rpt_apply_dollars_for_cppo_TOP_v22 :strCustomerGrpCd, :strGroup,"
			+ " :strBillingPeriod, :strStatusClause, :exclusiveAccess,:accountStatus, :strClassClause,"
			+ ":strBillName,:strStateFilter, :strSegmentClause, :acnaCriteriaType,:acnaSubType,:acnaValue,:ctcValue"
			+ " , :rollup_flag", nativeQuery = true)
	public List<CPPODetails> getCPPODetails(@Param("strCustomerGrpCd") String strCustomerGrpCd,
			@Param("strGroup") String strGroup, @Param("strBillingPeriod") String strBillingPeriod,
			@Param("strStatusClause") String strStatusClause, @Param("exclusiveAccess") Integer exclusiveAccess,
			@Param("accountStatus") Integer accountStatus, @Param("strClassClause") String strClassClause,
			 @Param("strBillName") String strBillName, @Param("strStateFilter") String strStateFilter,
			 @Param("strSegmentClause") String strSegmentClause,
			@Param("acnaCriteriaType") String acnaCriteriaType,
			@Param("acnaSubType") String acnaSubType, @Param("acnaValue") String acnaValue,
			@Param("ctcValue") String ctcValue,@Param("rollup_flag") Integer rollupFlag);

}

package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerGroupList;

@Transactional
public interface GroupFetchingRepository extends JpaRepository<CustomerGroupList, String> {

	@Query(value = "Exec arms_custqry_group_list_v20 :group", nativeQuery = true)
	public List<CustomerGroupList> findcustomerGroupList(@Param("group") String group);

}

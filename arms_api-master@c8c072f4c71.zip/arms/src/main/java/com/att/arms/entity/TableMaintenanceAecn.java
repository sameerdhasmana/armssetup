package com.att.arms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class TableMaintenanceAecn {

	@Id
	private String aecn;
	private String segmentCode;
	private String notes;
	private String autoAssign;
	private String customerGroupCode;

}

package com.att.arms.reports.service;

import com.att.arms.config.ReportsConstant;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;

public class CustomerReportRegionSegmentStatusHeaderEvent extends PdfPageEventHelper {

	private PdfTemplate template;
	private Image total;
	int totalPages = 0;
	private static final Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

	@Override
	public void onOpenDocument(PdfWriter writer, Document document) {
		template = writer.getDirectContent().createTemplate(50, 16);
		try {
			total = Image.getInstance(template);
		} catch (BadElementException e) {
			e.printStackTrace();
		}
		total.setRole(PdfName.ARTIFACT);

	}

	@Override
	public void onCloseDocument(PdfWriter writer, Document document) {

		ColumnText.showTextAligned(template, Element.ALIGN_JUSTIFIED_ALL,
				new Phrase(String.valueOf(writer.getPageNumber())), 0, 2, 0);
	}

	@Override
	public void onEndPage(PdfWriter writer, Document document) {
		if (writer.getPageNumber() > 1) {
			addHeader(writer, document);
		}
		addFooter(writer, document);
	}

	private void addFooter(PdfWriter writer, Document document) {
		PdfPTable footerTable = new PdfPTable(4);
		try {
			footerTable.setWidths(new int[] { 18, 24, 60, 7 });
			footerTable.setTotalWidth(1250);
			footerTable.setLockedWidth(true);
			footerTable.getDefaultCell().setFixedHeight(20);
			footerTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			PdfPCell pCell = new PdfPCell(new Paragraph(new Chunk(" ")));
			pCell.setColspan(2);
			pCell.setBorder(Rectangle.NO_BORDER);
			footerTable.addCell(pCell);

			footerTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			footerTable.addCell(String.format("Page %d of", writer.getPageNumber()));

			PdfPCell totalPageCount = new PdfPCell(total);
			totalPageCount.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
			totalPageCount.setBorder(Rectangle.NO_BORDER);
			footerTable.addCell(totalPageCount);

			footerTable.writeSelectedRows(0, -1, 34, 50, writer.getDirectContent());

		} catch (DocumentException de) {
			throw new ExceptionConverter(de);
		}

	}

	private void addHeader(PdfWriter writer, Document document) {
		try {
			PdfPTable table = new PdfPTable(11);

			float[] columnWidths = { 240, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 100f, 60f };

			table.setWidths(columnWidths);
			table.setTotalWidth(1200);
			table.setLockedWidth(true);
			table.getDefaultCell().setFixedHeight(100);

			PdfPCell cell1 = new PdfPCell(new Paragraph(ReportsConstant.STATUS, boldFont));
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);

			PdfPCell cell2 = new PdfPCell(new Paragraph(ReportsConstant.CURRENT_BILLING, boldFont));
			cell2.setBorder(Rectangle.NO_BORDER);
			cell2.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell3 = new PdfPCell(new Paragraph(ReportsConstant.CURRENT_BALANCE, boldFont));
			cell3.setBorder(Rectangle.NO_BORDER);
			cell3.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell4 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_30_DAYS, boldFont));
			cell4.setBorder(Rectangle.NO_BORDER);
			cell4.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell5 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_60_DAYS, boldFont));
			cell5.setBorder(Rectangle.NO_BORDER);
			cell5.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell6 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_90_DAYS, boldFont));
			cell6.setBorder(Rectangle.NO_BORDER);
			cell6.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell7 = new PdfPCell(new Paragraph(ReportsConstant.PAST_DUE_120_DAYS, boldFont));
			cell7.setBorder(Rectangle.NO_BORDER);
			cell7.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell8 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_PAST_DUE, boldFont));
			cell8.setBorder(Rectangle.NO_BORDER);
			cell8.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell9 = new PdfPCell(new Paragraph(ReportsConstant.TOTAL_DUE, boldFont));
			cell9.setBorder(Rectangle.NO_BORDER);
			cell9.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell10 = new PdfPCell(new Paragraph(ReportsConstant.DISPUTE, boldFont));
			cell10.setBorder(Rectangle.NO_BORDER);
			cell10.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			PdfPCell cell11 = new PdfPCell(new Paragraph(ReportsConstant.DSO, boldFont));
			cell11.setBorder(Rectangle.NO_BORDER);
			cell11.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);

			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);
			table.addCell(cell8);
			table.addCell(cell9);
			table.addCell(cell10);
			table.addCell(cell11);

			LineSeparator thickLine = new LineSeparator();
			thickLine.setLineWidth(2);
			thickLine.setOffset(10);
			PdfPCell pCell = new PdfPCell(new Paragraph(new Chunk(thickLine)));
			pCell.setColspan(15);
			pCell.setBorder(Rectangle.NO_BORDER);

			table.addCell(pCell);

			PdfContentByte overThePage = writer.getDirectContent();
			overThePage.beginMarkedContentSequence(PdfName.ARTIFACT);
			table.writeSelectedRows(0, -1, 55, 1712, overThePage);
			overThePage.endMarkedContentSequence();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}

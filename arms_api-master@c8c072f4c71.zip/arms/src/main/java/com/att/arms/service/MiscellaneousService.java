package com.att.arms.service;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;

import com.att.arms.entity.CPPODetails;
import com.att.arms.entity.RepCopy;
import com.att.arms.entity.UserDetails;

public interface MiscellaneousService {

	List<CPPODetails> getCPPOReport(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateCPPOReportQueryRequest(UserDetails userDetails);

	ByteArrayInputStream generateCPPOReport(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateAccountPermNoteRequest(UserDetails userDetails);

	ByteArrayInputStream generateAccountPermNoteReport(UserDetails userDetails, Map<Object, Object> responseMap);

	ByteArrayInputStream generatePermNoteReport(String customerGrpCd, String userLoginCd,
			Map<Object, Object> responseMap);

	ByteArrayInputStream generateRepCopyReport(UserDetails userDetails, Map<Object, Object> responseMap);

	List<RepCopy> getRepCopyReport(UserDetails userDetails, Map<Object, Object> responseMap);

	ByteArrayInputStream generateCustCopyReport(UserDetails userDetails, Map<Object, Object> responseMap);

	boolean validateCustCopyReportRequest(UserDetails userDetails);

	boolean validateMyCustomerReportRequest(UserDetails userDetails);

	ByteArrayInputStream generateMyCustomerReport(UserDetails userDetails, Map<Object, Object> responseMap);

	ByteArrayInputStream generateCustomerBringupReport(UserDetails userDetails, Map<Object, Object> responseMap);

	ByteArrayInputStream generateAccountBringupReport(UserDetails userDetails, Map<Object, Object> responseMap);

}

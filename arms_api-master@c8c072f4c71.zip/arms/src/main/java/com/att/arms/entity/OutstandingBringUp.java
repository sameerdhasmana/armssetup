package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(OutstandingBringUp.OutstandingBringUpId.class)
@Data
public class OutstandingBringUp {

	@Id
	@JsonProperty("account_number")
	@Column(name="ACCTNBR")
	private String accountNumber;
	@JsonProperty("past_due_amt")
	@Column(name="past_due_amt")
	private Double pastDueAmt;
	@JsonProperty("state")
	@Column(name="state_cd")
	private String stateCd;
	@JsonProperty("status")
	@Column(name="status_cd")
	private String status;
	@JsonProperty("Customer")
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	@Id
	@JsonProperty("system")
	@Column(name="originating_system")
	private String originatingSystem;
	@JsonProperty("Assigned_CAS")
	@Column(name="collections_userid")
	private String collectionsUserid;
	@JsonProperty("Bill_Name")
	@Column(name="customer_nm")
	private String customerName;
	@JsonProperty("Bring_Up_Date")
	@Column(name="next_call_back_dt")
	private String nextCallBackDt;
	
	@SuppressWarnings("serial")
	@Data
	public static class OutstandingBringUpId implements Serializable {

		private String accountNumber;
		private String originatingSystem;
		
	}
}

package com.att.arms.repo;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.att.arms.entity.FetchContact;

@Transactional
public interface FetchContactRepository extends JpaRepository<FetchContact, String> {

	@Query(value = "Exec arms_vc_contact_fetch_v19 :strUserLoginCd, :cntctid, :columnid, :acct_nbr, :fan,"
			+ " :svid, :custgrpcd, :origsys", nativeQuery = true)
	public List<FetchContact> getFetchContact(@Param("strUserLoginCd") String strUserLoginCd,
			@Param("cntctid") String cntctid, @Param("columnid") String columnid, @Param("acct_nbr") String acctNbr,
			@Param("fan") String fan, @Param("svid") String svid, @Param("custgrpcd") String custgrpcd,
			@Param("origsys") String origsys);

	//@Modifying
	@Query(value = "Exec arms_vc_contact_add_modify_v19 :strUserLoginCd, :last_nm, :addr, :city, :state, :zip, :title,:phone_nbr,:extension, :phone2, :ext2, :fax_nbr,"
			+ " :email_addr, :email_addr2,:notes, :contacts_id, "
			+ ":hdqtrs_ind, :userlogincd, :EMAOR, :EMAOR_PRIMARY, :EMAOR_EFF_dt, :columnid, :acct_nbr, :fan, :svid, "
			+ ":custgrplist, :origsys", nativeQuery = true)
	public void getEditContact(@Param("strUserLoginCd") String strUserLoginCd,
			@Param("last_nm") String lastNm, @Param("addr") String addr, @Param("city") String city,
			@Param("state") String state, @Param("zip") String zip, @Param("title") String title,
			@Param("phone_nbr") String phoneNbr, @Param("extension") String extension, @Param("phone2") String phone2,
			@Param("ext2") String ext2, @Param("fax_nbr") String faxNbr, @Param("email_addr") String emailAddr,
			@Param("email_addr2") String emailAddr2, @Param("notes") String notes,
			@Param("contacts_id") String contactsId, @Param("hdqtrs_ind") String hdqtrsInd,
			@Param("userlogincd") String userlogincd, @Param("EMAOR") String eMAOR,
			@Param("EMAOR_PRIMARY") String emaorPrimary, @Param("EMAOR_EFF_dt") String emaorEffDt,
			@Param("columnid") String columnid, @Param("acct_nbr") String acctNbr, @Param("fan") String fan,
			@Param("svid") String svid, @Param("custgrplist") String custgrplist, @Param("origsys") String origsys);

	@Modifying
	@Query(value = "Exec arms_vc_contact_delete_v19 :strUserLoginCd, :cntctid", nativeQuery = true)
	public void getDeleteContact(@Param("strUserLoginCd") String strUserLoginCd, @Param("cntctid") String cntctid);

}

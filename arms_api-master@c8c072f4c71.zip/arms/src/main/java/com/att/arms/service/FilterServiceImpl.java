package com.att.arms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.AccountClassification;
import com.att.arms.entity.CustomerBillingPeriod;
import com.att.arms.entity.CustomerGroupList;
import com.att.arms.entity.CustomerSegment;
import com.att.arms.entity.FilterResponse;
import com.att.arms.entity.GlobalLogonUsers;
import com.att.arms.entity.HeaderDetails;
import com.att.arms.entity.OriginatingSystem;
import com.att.arms.entity.UserDetails;
import com.att.arms.entity.UserRole;
import com.att.arms.repo.AccountsClassificationRepository;
import com.att.arms.repo.CustomerBillingPeriodRepository;
import com.att.arms.repo.CustomerSegmentRepository;
import com.att.arms.repo.FilterRepository;
import com.att.arms.repo.MessageRepository;
import com.att.arms.repo.OriginatingSystemRepository;
import com.att.arms.repo.UserRoleRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class FilterServiceImpl implements FilterService {
	@Value("${arms.help.url}")
	private String helpUrl;
	@Autowired
	FilterRepository filterRepository;
	@Autowired
	CustomerSegmentRepository customerSegmentRepository;
	@Autowired
	AccountsClassificationRepository accountsClassificationRepository;
	@Autowired
	OriginatingSystemRepository originatingSystemRepository;
	@Autowired
	UserService userService;
	@Autowired
	MessageRepository messageRepository;
	@Autowired
	CustomerBillingPeriodRepository customerBillingPeriodRepository;
	@Autowired
	UserRoleRepository userRoleRepository;

	@Override
	public List<CustomerGroupList> findcustomerGroupList(String group) {
		return this.filterRepository.findcustomerGroupList(group);
	}

	@Override
	public List<CustomerBillingPeriod> findCustomerBillingPeriod(List<String> groupList) {
		return this.customerBillingPeriodRepository.findCustomerBillingPeriod(groupList);
	}

	@Override
	public List<CustomerSegment> findCustomerSegmentList(List<String> groupList) {
		return this.customerSegmentRepository.findCustomerSegmentList(groupList);
	}

	@Override
	public List<AccountClassification> findAccountsClassificationList() {
		return this.accountsClassificationRepository.findAccountsClassificationList();
	}

	@Override
	public List<OriginatingSystem> findOriginatingSystemList() {
		return this.originatingSystemRepository.findOriginatingSystemList();
	}

	@Override
	public FilterResponse populateFilter(FilterResponse filter, UserDetails userDetails) {
		GlobalLogonUsers glUser = null;

		glUser = this.userService.findUserDetails(userDetails.getUserLoginCd(), userDetails.getAppName(),
				userDetails.getEnvironment(), userDetails.getUserPcName(), userDetails.getUserPcLoginId(),
				userDetails.getUserPcIp(), 0);
		if (glUser != null) {
			List<CustomerGroupList> groupList = findcustomerGroupList(glUser.getGroup());
			List<String> selectedGrpList = new ArrayList<>();
			selectedGrpList.add(glUser.getGroup());
			List<CustomerBillingPeriod> billingPeriodList = findCustomerBillingPeriod(selectedGrpList);
			List<CustomerSegment> segmentList = findCustomerSegmentList(selectedGrpList);
			List<AccountClassification> accountsClassificationList = findAccountsClassificationList();
			List<OriginatingSystem> originatingSystemList = findOriginatingSystemList();
			List<UserRole> userRole = userRoleRepository.getUserRole(userDetails.getUserLoginCd());
			List<String> taskList = CommonUtils.getCommaSeparatedStringToList(userRole.get(0).getTasklist());
			filter.setTaskList(taskList);
			filter.setCustomerGroupList(groupList);
			filter.setGlobalLogonUsers(glUser);
			filter.setCustomerBillingPeriod(billingPeriodList);
			filter.setSegmentList(segmentList);
			filter.setAccountsClassificationList(accountsClassificationList);
			filter.setOriginatingSystemList(originatingSystemList);
			filter.setHelpUrl(helpUrl);
			
		} else {
			filter.setErrorMsg("Invalid User");
		}
		return filter;
	}

	@Override
	public FilterResponse rePopulateFilter(FilterResponse filter, UserDetails userDetails) {
		List<CustomerBillingPeriod> billingPeriodList = findCustomerBillingPeriod(userDetails.getGroupSelected());
		List<CustomerSegment> segmentList = findCustomerSegmentList(userDetails.getGroupSelected());
		filter.setSegmentList(segmentList);
		filter.setCustomerBillingPeriod(billingPeriodList);
		return filter;
	}

	@Override
	public boolean validateHeaderRequest(HeaderDetails headerDetails) {
		boolean response = false;
		if (headerDetails != null && StringUtils.isNotEmpty(headerDetails.getUserLoginCd())
				&& StringUtils.isNotEmpty(headerDetails.getModuleName())
				&& StringUtils.isNotEmpty(headerDetails.getHeaderParams())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> saveHeaderParameters(Map<Object, Object> responseMap, HeaderDetails headerDetails) {
		filterRepository.saveHeaderParams(headerDetails.getUserLoginCd().trim(), headerDetails.getModuleName().trim(),
				headerDetails.getHeaderParams().trim());
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public boolean validateResetColumnOrderRequest(HeaderDetails headerDetails) {
		boolean response = false;
		if (headerDetails != null && StringUtils.isNotEmpty(headerDetails.getUserLoginCd())
				&& StringUtils.isNotEmpty(headerDetails.getModuleName())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> resetColumnOrder(Map<Object, Object> responseMap, HeaderDetails headerDetails) {
		filterRepository.deleteHeaderParams(headerDetails.getUserLoginCd().trim(),
				headerDetails.getModuleName().trim());
		responseMap.put("msg", ApplicationConstant.SUCCESS);
		return responseMap;
	}

}

package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class LetterProfileList {
	@Id
	@JsonProperty("letter_profile_id")
	@Column(name = "letter_profile_id")
	private Integer letterProfileId;
	@JsonProperty("letter_profiles_name")
	@Column(name = "letter_profiles_name")
	private String letterProfilesName;
	@JsonProperty("letter_profiles_desc")
	@Column(name = "letter_profiles_desc")
	private String letterProfileDesc;

}

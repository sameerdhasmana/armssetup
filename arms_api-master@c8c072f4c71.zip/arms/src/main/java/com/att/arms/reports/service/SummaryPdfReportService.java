package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface SummaryPdfReportService {

	ByteArrayInputStream searchByCustomer(UserDetails requestModel, Map<Object, Object> responseMap);
	
	ByteArrayInputStream searchByCustomerStatus(UserDetails requestModel, Map<Object, Object> responseMap);
	
    ByteArrayInputStream searchBySegment(UserDetails requestModel,  Map<Object, Object> responseMap);
	
	ByteArrayInputStream searchByState(UserDetails requestModel,  Map<Object, Object> responseMap);
	
}

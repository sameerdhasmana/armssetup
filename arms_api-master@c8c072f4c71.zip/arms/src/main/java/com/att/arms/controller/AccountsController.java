package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.AccountsService;
import com.att.arms.service.CustomerDetailsService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class AccountsController {

	@Autowired
	AccountsService accountsService;
	@Autowired
	CustomerDetailsService customerDetailsService;

	

	@PostMapping("getAIFCustomerInfo")
	public ResponseEntity<Object> getAIFCustomerInfo(@RequestBody UserDetails userDetails) {

		boolean response = this.accountsService.validateAIFCustomerInfo(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {

			responseMap = this.accountsService.getAIFCustomerDetails(responseMap, userDetails);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("viewCommitmentHistory")
	public ResponseEntity<Object> viewCommitmentHistory(@RequestBody UserDetails userDetails) {
		boolean response = this.customerDetailsService.validateViewQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.accountsService.getCommitmentHistory(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
	
	@PostMapping("closeCommitmentHistory")
	public ResponseEntity<Object> closeCommitmentHistory(@RequestBody UserDetails userDetails) {
		boolean response = this.accountsService.validateCloseQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.accountsService.closeCommitmentHistory(userDetails, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);

	}
}

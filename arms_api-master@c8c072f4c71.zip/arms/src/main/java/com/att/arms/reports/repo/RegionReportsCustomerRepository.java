package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.reports.entity.RegionReportByCustomerDetails;

@Transactional
public interface RegionReportsCustomerRepository extends JpaRepository<RegionReportByCustomerDetails, String> {

	//@Query(value = "EXEC arms_rpt_mgr_region_by_customer '202109', '''LSC'', ''TWH''', ' (''CABS'',''CRIS'' )', '''AIT''', '''LIVE'',''FINAL''', '''CPO'', ''CTX''', '''N174383'',''D000037'',''U111216'',''A002211'',''D011257''', 'Included & Excluded', 'AND (cx.class_cd IN (80))',0", nativeQuery = true)
	@Query(value = "EXEC arms_rpt_mgr_region_by_customer :billingPeriod,:groupSelected,:originatingSystem,:originatingCompanyCdClause,:statusClause,:segment,:customerClause, :exclusions,:exclusionClass,:customerChidFlag", nativeQuery = true)	
	public List<RegionReportByCustomerDetails> byCustomer(			
			@Param("billingPeriod") String billingPeriod,	  
			@Param("groupSelected") String groupSelected,	
			@Param("originatingSystem") String originatingSystem,	  
			@Param("originatingCompanyCdClause") String originatingCompanyCdClause,	  
			@Param("statusClause") String statusClause,	  
			@Param("segment") String segment,	  
			@Param("customerClause") String customerClause,	  
			@Param("exclusions") String exclusions,	  
			@Param("exclusionClass") String exclusionClass,	  
			@Param("customerChidFlag") String customerChidFlag 
			);

}

package com.att.arms.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.LetterModel;
import com.att.arms.service.LetterMaintenanceService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class LetterMaintenanceController {

	@Autowired
	LetterMaintenanceService letterMaintenanceService;

	@PostMapping("letterDetailList")
	public ResponseEntity<Object> getLetterTypes(@RequestBody LetterModel letterModel) {
		boolean response = this.letterMaintenanceService.validateQueryRequest(letterModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.letterMaintenanceService.getLetterTypes(letterModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("letterProfileFieldList")
	public ResponseEntity<Object> getProfileList(@RequestBody LetterModel letterModel) {
		boolean response = this.letterMaintenanceService.validateQueryRequest(letterModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.letterMaintenanceService.getLetterProfileField(letterModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("letterSegment")
	public ResponseEntity<Object> getSegment(@RequestBody LetterModel letterModel) {
		boolean response = this.letterMaintenanceService.validateSegment(letterModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.letterMaintenanceService.getSegment(letterModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("createLetterProfile")
	public ResponseEntity<Object> saveLetterProfile(@RequestBody LetterModel letterModel) {
		boolean response = this.letterMaintenanceService.validateQueryRequest(letterModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.letterMaintenanceService.saveLetterProfile(letterModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("letterProfileList") 
	public ResponseEntity<Object> getLetterProfileList(@RequestBody LetterModel letterModel) {
		boolean response = this.letterMaintenanceService.validateQueryRequest(letterModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.letterMaintenanceService.getLetterProfileList(letterModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("saveModifyLetterProfile")
	public ResponseEntity<Object> saveModifyLetter(@RequestBody LetterModel letterModel) {
		boolean response = this.letterMaintenanceService.validateQueryRequest(letterModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.letterMaintenanceService.saveModifyLetter(letterModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("fetchModifyLetterDetails")
	public ResponseEntity<Object> fetchModifyLetterDetails(@RequestBody LetterModel letterModel) {
		boolean response = this.letterMaintenanceService.modifyLetter(letterModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.letterMaintenanceService.fetchLetterProfileFieldList(letterModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("deleteLetterProfile")
	public ResponseEntity<Object> deleteLetterProfile(@RequestBody LetterModel letterModel) {
		boolean response = this.letterMaintenanceService.validateDelete(letterModel);
		Map<Object, Object> responseMap = new HashMap<>();
		if (response) {
			responseMap = this.letterMaintenanceService.deleteLetterProfile(letterModel, responseMap);
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

}
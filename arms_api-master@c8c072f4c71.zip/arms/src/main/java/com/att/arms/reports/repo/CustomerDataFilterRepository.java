package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.CustomerInfo;

@Transactional
public interface CustomerDataFilterRepository extends JpaRepository<CustomerInfo, String> {

	@Query(value = "Exec arms_reputil_allcustomers", nativeQuery = true)
	public List<CustomerInfo> getAllCustomerInfo();

}

package com.att.arms.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class UserRole {
	@Id
	@JsonProperty("userRoleId")
	@Column(name = "user_role")
	private String userRoleId;
	@JsonProperty("userLoginCd")
	@Column(name = "user_login_cd")
	private String userLoginCd;
	@Transient
	@JsonProperty("tasklistDetails")
	private List<String> tasklistDetails;
	@JsonIgnore
	@Column(name = "tasklist")
	private String tasklist;

}

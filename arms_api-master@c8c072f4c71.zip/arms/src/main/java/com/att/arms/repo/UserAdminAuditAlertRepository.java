package com.att.arms.repo;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.att.arms.entity.AuditAlertGui;

@Transactional
public interface UserAdminAuditAlertRepository extends JpaRepository<AuditAlertGui, String> {
	@Query(value = "EXEC arms_useradmin_rpt_security_audit_alert_gui ", nativeQuery = true)
	public List<AuditAlertGui> getSecurityAuditAlertGui();
}
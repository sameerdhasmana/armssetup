package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class ContestedAmtView {

	@Id
	@JsonIgnore
	private String acct;
	@JsonIgnore
	private String origsys;
	@JsonProperty("contested_amt")
	@Column(name="contested_amt")
	private String contestedAmt;

	
}

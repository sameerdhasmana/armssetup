package com.att.arms.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(CustomerCopy.CustomerCopyId.class)
@Data
public class CustomerCopy {

	@Id
	@JsonProperty("account_number")
	@Column(name = "acct_nbr")
	private String accountNbr;
	@Id
	@JsonProperty("originating_system")
	@Column(name = "originating_system")
	private String originatingSystem;
	@JsonProperty("promo_cr")
	@Column(name = "PROMO_CR")
	private Double promoCr;
	@JsonProperty("segment_cd")
	@Column(name = "segment_cd")
	private String segmentCd;
	@JsonProperty("state_cd")
	@Column(name = "state_cd")
	private String stateCd;
	@JsonProperty("customer_grp_cd")
	@Column(name = "customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("customer_legal_nm")
	@Column(name = "customer_legal_nm")
	private String customerLegalNm;
	@Id
	@JsonProperty("billing_period")
	@Column(name = "billing_period")
	private String billingPeriod;
	@JsonProperty("accountNumberCode")
	@Column(name = "acct_nbr_cd")
	private String accountNumberCode;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("lastBillingDate")
	@Column(name = "last_Billing_dt")
	private Date lastBillingDate;
	@JsonProperty("acna_cd")
	@Column(name = "acna_cd")
	private String acnaCd;
	@Column(name = "Current Billing Amt")
	private Double currentBillingAmt;
	@JsonProperty("pastDue0Amt")
	@Column(name = "Past_Due_0_Amt")
	private Double pastDue0Amt;
	@JsonProperty("pastDue30Amt")
	@Column(name = "Past_Due_30_Amt")
	private Double pastDue30Amt;
	@JsonProperty("pastDue60Amt")
	@Column(name = "Past_Due_60_Amt")
	private Double pastDue60Amt;
	@JsonProperty("pastDue90Amt")
	@Column(name = "Past_Due_90_Amt")
	private Double pastDue90Amt;
	@JsonProperty("pastDue120Amt")
	@Column(name = "Past_Due_120_Amt")
	private Double pastDue120Amt;
	@Column(name = "Total Amt")
	private Double totalAmt;
	@Column(name = "Past_Due_Amt")
	private Double pastDueAmt;
	@Column(name = "Dispute Amt")
	private Double disputeAmt;
	@JsonProperty("apSubGrpNm")
	@Column(name = "ap_sub_grp_nm")
	private String apSubGrpNm;
	
	@SuppressWarnings("serial")
	@Data
	public static class CustomerCopyId implements Serializable {

		private String accountNbr;
		private String originatingSystem;
		private String billingPeriod;
		
		
	}

}

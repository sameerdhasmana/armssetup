package com.att.arms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.BillNameDetails;
import com.att.arms.entity.CustomerAgedDetails;
import com.att.arms.entity.InvoiceViewDetails;
import com.att.arms.entity.SummaryDetails;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.BillNameDetailsRepository;
import com.att.arms.repo.CustomerAgedDetailsRepository;
import com.att.arms.repo.InvoiceViewRepository;
import com.att.arms.repo.SummaryDetailsRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class BillNameDetailsServiceImpl implements BillNameDetailsService {

	@Autowired
	CustomerAgedDetailsRepository customerAgedDetailsRepository;
	@Autowired
	BillNameDetailsRepository billNameDetailsRepository;
	@Autowired
	InvoiceViewRepository invoiceViewRepository;
	@Autowired
	SummaryDetailsRepository summaryDetailsRepository;
	@Autowired
	CommonService commonService;

	@Override
	public List<BillNameDetails> getBillNameDetails(String group, String strVal) {
		return billNameDetailsRepository.getBillNameDetails(group, strVal);
	}

	@Override
	public boolean validateQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& StringUtils.isNotEmpty(userDetails.getBillingPeriod())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateSummaryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getBillName())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateBillNameInvoiceQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && !CollectionUtils.isEmpty(userDetails.getGroupSelected())
				&& StringUtils.isNotEmpty(userDetails.getBillingPeriod())
				&& StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())
				&& StringUtils.isNotEmpty(userDetails.getBillName())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> getQueryResponse(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<BillNameDetails> billNameDetailsList = new ArrayList<>();
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		String statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		String exclusionClass = "";
		String segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		String billName = StringUtils.isNotEmpty(userDetails.getBillName()) ? userDetails.getBillName() : "";

		if (!userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}

		if (StringUtils.isNotEmpty(selectedGroups) && StringUtils.isEmpty(userDetails.getCustomerGrpCd())
				|| StringUtils.isEmpty(billName)) {
			billNameDetailsList = getBillNameDetails(selectedGroups, userDetails.getEnteredValue());
		}

		String customerGrpCd = "";
		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			customerGrpCd = userDetails.getCustomerGrpCd().trim();
		} else if (!CollectionUtils.isEmpty(billNameDetailsList)) {
			customerGrpCd = billNameDetailsList.size()==1?billNameDetailsList.get(0).getCustomerGrpCd().trim():"";
			billName = (StringUtils.isEmpty(billName) && billNameDetailsList.size()==1 )? billNameDetailsList.get(0).getCustomerNm().trim() : billName;
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No Data Found for the selected input");
		}

		if (StringUtils.isNotEmpty(customerGrpCd)) {
			List<CustomerAgedDetails> agedDetail = customerAgedDetailsRepository.getBillNameAgedDetails(userDetails.getProfileName(), userDetails.getProfileType(), "", "",
					selectedGroups, customerGrpCd, userDetails.getUserLoginCd().trim(),
					userDetails.getBillingPeriod().trim(), statusClause, userDetails.getExclusions().trim(),
					exclusionClass, segment, originatingSystem, billName);
			responseMap.put(ApplicationConstant.AGED_DETAIL, agedDetail);
			commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(), ApplicationConstant.AGED_DETAIL, responseMap);
		}

		responseMap.put(ApplicationConstant.BILL_NAME, billNameDetailsList);

		return responseMap;
	}

	@Override
	public Map<Object, Object> populateBillName(UserDetails userDetails, Map<Object, Object> responseMap) {

		List<BillNameDetails> billNameDetailsList = null;
		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());

		if (StringUtils.isNotEmpty(selectedGroups) && StringUtils.isEmpty(userDetails.getCustomerGrpCd())) {
			billNameDetailsList = getBillNameDetails(selectedGroups, userDetails.getEnteredValue());
			responseMap.put(ApplicationConstant.BILL_NAME, billNameDetailsList);
		}

		return responseMap;
	}

	@Override
	public Map<Object, Object> populateBillNameInvoiceView(UserDetails userDetails, Map<Object, Object> responseMap) {

		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String originatingSystem = "";
		String statusClause = "";
		String exclusionClass = "";
		String segment = "";
		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		}
		if (!CollectionUtils.isEmpty(userDetails.getStatusClause())) {
			statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		}
		if (!CollectionUtils.isEmpty(userDetails.getExclusionClass())
				&& !userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}
		if (!CollectionUtils.isEmpty(userDetails.getSegment())) {
			segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		}
		if (StringUtils.isNotEmpty(selectedGroups) || StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			List<InvoiceViewDetails> agedDetail = invoiceViewRepository.getBillNameInvoiceViewDetails(userDetails.getProfileName(), userDetails.getProfileType(), "", "",
					selectedGroups, userDetails.getCustomerGrpCd().trim(), userDetails.getUserLoginCd().trim(),
					userDetails.getBillingPeriod().trim(), statusClause, userDetails.getExclusions().trim(),
					exclusionClass, segment, originatingSystem, userDetails.getBillName().trim());

			responseMap.put(ApplicationConstant.INVOICE_VIEW, agedDetail);
			commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(), ApplicationConstant.INVOICE_VIEW, responseMap);

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return responseMap;
	}

	@Override
	public Map<Object, Object> getBillNameSummaryDetails(UserDetails userDetails, Map<Object, Object> responseMap) {

		String selectedGroups = CommonUtils.getListToCommaSeparatedString(userDetails.getGroupSelected());
		String originatingSystem = "";
		String statusClause = "";
		String exclusionClass = "";
		String segment = "";
		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		}
		if (!CollectionUtils.isEmpty(userDetails.getStatusClause())) {
			statusClause = CommonUtils.getListToCommaSeparatedString(userDetails.getStatusClause());
		}
		if (!CollectionUtils.isEmpty(userDetails.getExclusionClass())
				&& !userDetails.getExclusions().equalsIgnoreCase(ApplicationConstant.INCLUDED_ACCOUNTS)) {
			exclusionClass = CommonUtils.getListToCommaSeparatedString(userDetails.getExclusionClass());
		}
		if (!CollectionUtils.isEmpty(userDetails.getSegment())) {
			segment = CommonUtils.getListToCommaSeparatedString(userDetails.getSegment());
		}
		if (StringUtils.isNotEmpty(selectedGroups) && StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			List<SummaryDetails> agedDetail = summaryDetailsRepository.getBillNameSummaryDetails("", selectedGroups,
					userDetails.getCustomerGrpCd(), userDetails.getUserLoginCd(), userDetails.getBillingPeriod(),
					statusClause, userDetails.getExclusions(), exclusionClass, segment, originatingSystem,
					userDetails.getBillName());
			responseMap.put(ApplicationConstant.SUMMARY_DETAIL, agedDetail);
			commonService.populateHeaderParameters(userDetails.getUserLoginCd().trim(), ApplicationConstant.SUMMARY_DETAIL, responseMap);

		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}

		return responseMap;
	}

}

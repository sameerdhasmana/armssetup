package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.att.arms.entity.ContactsDisplay;

@Transactional
public interface ContactsDisplayRepository extends JpaRepository<ContactsDisplay, String> {

	@Query(value = "Exec arms_vc_contacts_display_v19 :acct_nbr, :fan, :svid, :custgrpcd, :origsys, :strlogincd, :strAcctLvl,"
			+ " :strEMAORind", nativeQuery = true)
	public List<ContactsDisplay> getDisplayContacts(@Param("acct_nbr") String acctNbr, @Param("fan") String fan,
			@Param("svid") String svid, @Param("custgrpcd") String custgrpcd, @Param("origsys") String origsys,
			@Param("strlogincd") String strlogincd, @Param("strAcctLvl") String strAcctLvl,
			@Param("strEMAORind") String strEMAORind);
}

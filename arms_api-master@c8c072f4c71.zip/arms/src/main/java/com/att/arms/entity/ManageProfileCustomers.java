package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(ManageProfileCustomers.ManageProfileCustomersId.class)
@Data
public class ManageProfileCustomers {

	@Id
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("customer_legal_nm")
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	private String excludedAccountsExists;
	@Id
	@JsonProperty("acna_cd")
	@Column(name="acna_cd")
	private String acnaCd;
	@Id
	@JsonProperty("customer_grp_child_cd")
	@Column(name="customer_grp_child_cd")
	private String customerGrpChildCd;
	@Id
	@JsonProperty("ocn_cd")
	@Column(name="ocn_cd")
	private String ocnCd;
	@Id
	@JsonProperty("aecn_cd")
	@Column(name="aecn_cd")
	private String aecnCd;

	@SuppressWarnings("serial")
	@Data
	public static class ManageProfileCustomersId implements Serializable {

		private String customerGrpCd;
		private String acnaCd;
		private String customerGrpChildCd;
		private String ocnCd;
		private String aecnCd;
	}
}

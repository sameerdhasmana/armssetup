package com.att.arms.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class FetchContact {

	@Id
	@JsonProperty("contacts_id")
	@Column(name="contacts_id")
	private String contactsId;
	private Integer sequence;
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	private String firstName;
	private String lastName;
	private String title;
	private String phone;
	private String extension;
	@JsonProperty("Phone2")
	@Column(name="Phone2")
	private String phone2;
	@JsonProperty("Extension2")
	@Column(name="Extension2")
	private String extension2;
	@JsonProperty("FaxNumber")
	@Column(name="FaxNumber")
	private String faxNumber;
	private String email;
	private String email2;
	@JsonProperty("Address")
	@Column(name="Address")
	private String address;
	private String city;
	private String state;
	private String zip;
	private String notes;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("InsertDate")
	@Column(name="InsertDate")
	private Date insertDate;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@JsonProperty("UpdateDate")
	@Column(name="UpdateDate")
	private Date updateDate;
	private String headQtrs;

}

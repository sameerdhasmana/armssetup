package com.att.arms.entity;

import javax.persistence.Id;

import lombok.Data;

@Data
public class Users {

	@Id
	private String userLoginCd;
	private String fname;
	private String lname;
}

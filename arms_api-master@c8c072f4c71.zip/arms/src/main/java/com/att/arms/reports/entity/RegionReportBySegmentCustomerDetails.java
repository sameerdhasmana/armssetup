package com.att.arms.reports.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(RegionReportBySegmentCustomerDetails.RegionReportBySegmentCustomerDetailsId.class)
@Data
public class RegionReportBySegmentCustomerDetails {

	@Id
	@JsonProperty("Billing Period")
	@Column(name="Billing Period")
	private String billingPeriod;
	
	@JsonProperty("region")
	@Column(name="region")
	private String region;
	
	@JsonProperty("segment")
	@Column(name="segment")
	private String segment;
	
	@JsonProperty("customer")
	@Column(name="customer")
	private String customer;
	
	@Id
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGroupCd;
	
	@Id
	@JsonProperty("Current Billing Amount")
	@Column(name="Current Billing Amount")
	private BigDecimal currentBillingAmount;
	
	@Id
	@JsonProperty("Past Due 0 Amount")
	@Column(name="Past Due 0 Amount")
	private BigDecimal pastDue0Amount;
	
	@Id
	@JsonProperty("Past Due 30 Amount")
	@Column(name="Past Due 30 Amount")
	private BigDecimal pastDue30Amount;
	
	@Id
	@JsonProperty("Past Due 60 Amount")
	@Column(name="Past Due 60 Amount")
	private BigDecimal pastDue60Amount;
	
	@Id
	@JsonProperty("Past Due 90 Amount")
	@Column(name="Past Due 90 Amount")
	private BigDecimal pastDue90Amount;
	
	@Id
	@JsonProperty("Past Due 120 Amount")
	@Column(name="Past Due 120 Amount")
	private BigDecimal pastDue120Amount;
	
	@Id
	@JsonProperty("Total Past Due")
	@Column(name="Total Past Due")
	private BigDecimal totalPastDueAmount;
	
	@Id
	@JsonProperty("Total Amount")
	@Column(name="Total Amount")
	private BigDecimal totalAmount;
	
	@JsonProperty("Dispute")
	@Column(name="Dispute")
	private BigDecimal dispute;

	@JsonProperty("DSO")
	@Column(name="DSO")
	private BigDecimal dso;	
	
	@SuppressWarnings("serial")
	@Data
	public static class RegionReportBySegmentCustomerDetailsId implements Serializable {

		private String billingPeriod;
		private String customerGroupCd;
		private BigDecimal totalAmount;
		private BigDecimal totalPastDueAmount;
		private BigDecimal pastDue120Amount;
		private BigDecimal pastDue90Amount;
		private BigDecimal pastDue60Amount;
		private BigDecimal pastDue30Amount;
		private BigDecimal pastDue0Amount;
		
	}
}

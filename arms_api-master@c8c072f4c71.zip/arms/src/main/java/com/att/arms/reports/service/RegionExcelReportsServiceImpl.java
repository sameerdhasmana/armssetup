package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.reports.entity.RegionReportByCustomerDetails;
import com.att.arms.reports.entity.RegionReportBySegmentCustomerDetails;
import com.att.arms.reports.entity.RegionReportBySegmentDetails;
import com.att.arms.reports.entity.RegionReportByStateCustomerDetails;
import com.att.arms.reports.entity.RegionReportByStateDetails;
import com.att.arms.reports.entity.RegionReportByStateSegmentDetails;
import com.att.arms.reports.repo.RegionReportsCustomerRepository;
import com.att.arms.reports.repo.RegionReportsRepository;
import com.att.arms.reports.repo.RegionReportsSegmentCustomerRepository;
import com.att.arms.reports.repo.RegionReportsStateCustomerRepository;
import com.att.arms.reports.repo.RegionReportsStateRepository;
import com.att.arms.reports.repo.RegionReportsStateSegmentRepository;
import com.att.arms.utils.CommonReportsUtils;

@Service
public class RegionExcelReportsServiceImpl implements RegionExcelReportsService {

	private static final String AND_CX_CLASS_CD_IN = "AND (cx.class_cd IN (";

	@Autowired
	RegionReportsRepository regionReportsBySegmentsRepository;

	@Autowired
	RegionReportsCustomerRepository regionReportsByCustomerRepository;
	
	@Autowired
	RegionReportsStateRepository regionReportsByStateRepository;
	
	@Autowired
	RegionReportsSegmentCustomerRepository regionReportsBySegmentCustomerRepository;
	
	@Autowired
	RegionReportsStateCustomerRepository regionReportsByStateCustomerRepository;
	
	@Autowired
	RegionReportsStateSegmentRepository regionReportsByStateSegmentRepository;

	@Override
	public ByteArrayInputStream createExcelForRegionSegment(UserDetails userDetails, Map<Object, Object> responseMap) {
		List<RegionReportBySegmentDetails> response = regionReportsBySegmentsRepository.bySegment(
				userDetails.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
				userDetails.getExclusions(), 
				AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
				userDetails.getCustomerChidFlag());

		try (Workbook regionReportBySegmentSheetWorkbook = new XSSFWorkbook()) {
			Sheet segmentReportBySegmentDetailsSheet = regionReportBySegmentSheetWorkbook
					.createSheet("Region Report By Segment");

			if (response != null) {

				addHeaderContent(segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook, ReportsConstant.SEGMENT);
				addActualContentForSegment(response, segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			regionReportBySegmentSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void addActualContentForSegment(List<RegionReportBySegmentDetails> responseList,
			Sheet regionBySegmentSheet, Workbook regionBySegmentWorkBook) {

		CellStyle dataCellStyleBlack = regionBySegmentWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = regionBySegmentWorkBook.createCellStyle();
		Font blackColorFont = regionBySegmentWorkBook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = regionBySegmentWorkBook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow ;

		BigDecimal currentBilling;
		BigDecimal pastDue0Amt;
		BigDecimal pastDue30Amt;
		BigDecimal pastDue60Amt;
		BigDecimal pastDue90Amt;
		BigDecimal pastDue120Amt;
		BigDecimal pastDueAmt;
		BigDecimal totalDueAmt;
		BigDecimal dispute;
		BigDecimal dso;

		for (int i = 0; i < responseList.size(); i++) {
			dataRow = regionBySegmentSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = regionBySegmentWorkBook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(responseList.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);
			
			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(responseList.get(i).getRegion());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(responseList.get(i).getSegment());
			cell3.setCellStyle(dataCellStyleBlack);

			currentBilling=responseList.get(i).getCurrentBillingAmount();
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell4.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);

			pastDue0Amt=responseList.get(i).getPastDue0Amount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);

			pastDue30Amt=responseList.get(i).getPastDue30Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);

			pastDue60Amt=responseList.get(i).getPastDue60Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);

			pastDue90Amt=responseList.get(i).getPastDue90Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);

			pastDue120Amt=responseList.get(i).getPastDue120Amount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);

			pastDueAmt=responseList.get(i).getTotalPastDueAmount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(pastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(pastDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);

			totalDueAmt=responseList.get(i).getTotalAmount();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);

			dispute=responseList.get(i).getDispute();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(dispute.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);

			dso=responseList.get(i).getDso();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(dso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell13.setCellStyle(dso.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);

			regionBySegmentSheet.setColumnWidth(i, regionBySegmentSheet.getColumnWidth(i)*23/10);
		}
	}

	@Override
	public ByteArrayInputStream createExcelForRegionCustomer(UserDetails userDetails, Map<Object, Object> responseMap) {
		List<RegionReportByCustomerDetails> response = regionReportsByCustomerRepository.byCustomer(
				userDetails.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
				userDetails.getExclusions(), 
				AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
				userDetails.getCustomerChidFlag());

		try (Workbook regionReportByCustomerSheetWorkbook = new XSSFWorkbook()) {
			Sheet segmentReportByCustomerDetailsSheet = regionReportByCustomerSheetWorkbook
					.createSheet("Region Report By Customer");

			if (response != null) {

				addHeaderContent(segmentReportByCustomerDetailsSheet, regionReportByCustomerSheetWorkbook, ReportsConstant.CUSTOMER);
				addActualContent(response, segmentReportByCustomerDetailsSheet, regionReportByCustomerSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			regionReportByCustomerSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void addActualContent(List<RegionReportByCustomerDetails> responseList,
			Sheet regionByCustomerSheet, Workbook regionByCustomerWorkBook) {

		CellStyle dataCellStyleBlack = regionByCustomerWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = regionByCustomerWorkBook.createCellStyle();
		Font blackColorFont = regionByCustomerWorkBook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = regionByCustomerWorkBook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow ;

		BigDecimal currentBilling;
		BigDecimal pastDue0Amt;
		BigDecimal pastDue30Amt;
		BigDecimal pastDue60Amt;
		BigDecimal pastDue90Amt;
		BigDecimal pastDue120Amt;
		BigDecimal pastDueAmt;
		BigDecimal totalDueAmt;
		BigDecimal dispute;
		BigDecimal dso;

		for (int i = 0; i < responseList.size(); i++) {
			dataRow = regionByCustomerSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = regionByCustomerWorkBook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(responseList.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);
			
			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(responseList.get(i).getRegion());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(responseList.get(i).getCustomer());
			cell3.setCellStyle(dataCellStyleBlack);

			currentBilling=responseList.get(i).getCurrentBillingAmount();
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell4.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);

			pastDue0Amt=responseList.get(i).getPastDue0Amount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);

			pastDue30Amt=responseList.get(i).getPastDue30Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);

			pastDue60Amt=responseList.get(i).getPastDue60Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);

			pastDue90Amt=responseList.get(i).getPastDue90Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);

			pastDue120Amt=responseList.get(i).getPastDue120Amount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);

			pastDueAmt=responseList.get(i).getTotalPastDueAmount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(pastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(pastDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);

			totalDueAmt=responseList.get(i).getTotalAmount();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);

			dispute=responseList.get(i).getDispute();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(dispute.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);

			dso=responseList.get(i).getDso();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(dso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell13.setCellStyle(dso.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);

			regionByCustomerSheet.setColumnWidth(i, regionByCustomerSheet.getColumnWidth(i)*23/10);
		}
	}

	@Override
	public ByteArrayInputStream createExcelForRegionState(UserDetails userDetails, Map<Object, Object> responseMap) {
		List<RegionReportByStateDetails> response = regionReportsByStateRepository.byState(
				userDetails.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
				userDetails.getExclusions(), 
				AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
				userDetails.getCustomerChidFlag());

		try (Workbook regionReportBySegmentSheetWorkbook = new XSSFWorkbook()) {
			Sheet segmentReportBySegmentDetailsSheet = regionReportBySegmentSheetWorkbook
					.createSheet("Region Report By State");

			if (response != null) {

				addHeaderContent(segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook, ReportsConstant.STATE);
				addActualContentForState(response, segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			regionReportBySegmentSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void addActualContentForState(List<RegionReportByStateDetails> responseList,
			Sheet regionBySegmentSheet, Workbook regionBySegmentWorkBook) {

		CellStyle dataCellStyleBlack = regionBySegmentWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = regionBySegmentWorkBook.createCellStyle();
		Font blackColorFont = regionBySegmentWorkBook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = regionBySegmentWorkBook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow ;

		BigDecimal currentBilling;
		BigDecimal pastDue0Amt;
		BigDecimal pastDue30Amt;
		BigDecimal pastDue60Amt;
		BigDecimal pastDue90Amt;
		BigDecimal pastDue120Amt;
		BigDecimal pastDueAmt;
		BigDecimal totalDueAmt;
		BigDecimal dispute;
		BigDecimal dso;

		for (int i = 0; i < responseList.size(); i++) {
			dataRow = regionBySegmentSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = regionBySegmentWorkBook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(responseList.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);
			
			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(responseList.get(i).getRegion());
			cell2.setCellStyle(dataCellStyleBlack);

			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(responseList.get(i).getState());
			cell3.setCellStyle(dataCellStyleBlack);

			currentBilling=responseList.get(i).getCurrentBillingAmount();
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell4.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);

			pastDue0Amt=responseList.get(i).getPastDue0Amount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);

			pastDue30Amt=responseList.get(i).getPastDue30Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);

			pastDue60Amt=responseList.get(i).getPastDue60Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);

			pastDue90Amt=responseList.get(i).getPastDue90Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);

			pastDue120Amt=responseList.get(i).getPastDue120Amount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);

			pastDueAmt=responseList.get(i).getTotalPastDueAmount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(pastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(pastDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);

			totalDueAmt=responseList.get(i).getTotalAmount();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);

			dispute=responseList.get(i).getDispute();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(dispute.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);

			dso=responseList.get(i).getDso();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(dso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell13.setCellStyle(dso.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);

			regionBySegmentSheet.setColumnWidth(i, regionBySegmentSheet.getColumnWidth(i)*23/10);
		}
	}

	@Override
	public ByteArrayInputStream createExcelForRegionSegmentCustomer(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		List<RegionReportBySegmentCustomerDetails> response = regionReportsBySegmentCustomerRepository.bySegmentCustomer(
				userDetails.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
				userDetails.getExclusions(), 
				AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
				userDetails.getCustomerChidFlag());

		try (Workbook regionReportBySegmentSheetWorkbook = new XSSFWorkbook()) {
			Sheet segmentReportBySegmentDetailsSheet = regionReportBySegmentSheetWorkbook
					.createSheet("Region Report By Segment Customer");

			if (response != null) {

				addHeaderContent(segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook, ReportsConstant.SEGMENT, ReportsConstant.CUSTOMER);
				addActualContentForSegmentCustomer(response, segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			regionReportBySegmentSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void addActualContentForSegmentCustomer(List<RegionReportBySegmentCustomerDetails> responseList,
			Sheet regionBySegmentSheet, Workbook regionBySegmentWorkBook) {

		CellStyle dataCellStyleBlack = regionBySegmentWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = regionBySegmentWorkBook.createCellStyle();
		Font blackColorFont = regionBySegmentWorkBook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = regionBySegmentWorkBook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow ;

		BigDecimal currentBilling;
		BigDecimal pastDue0Amt;
		BigDecimal pastDue30Amt;
		BigDecimal pastDue60Amt;
		BigDecimal pastDue90Amt;
		BigDecimal pastDue120Amt;
		BigDecimal pastDueAmt;
		BigDecimal totalDueAmt;
		BigDecimal dispute;
		BigDecimal qdso;
		
		for (int i = 0; i < responseList.size(); i++) {
			dataRow = regionBySegmentSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = regionBySegmentWorkBook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(responseList.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);
			
			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(responseList.get(i).getRegion());
			cell2.setCellStyle(dataCellStyleBlack);
			
			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(responseList.get(i).getSegment());
			cell3.setCellStyle(dataCellStyleBlack);
			
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(responseList.get(i).getCustomer());
			cell4.setCellStyle(dataCellStyleBlack);

			currentBilling=responseList.get(i).getCurrentBillingAmount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);

			pastDue0Amt=responseList.get(i).getPastDue0Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);

			pastDue30Amt=responseList.get(i).getPastDue30Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);

			pastDue60Amt=responseList.get(i).getPastDue60Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);

			pastDue90Amt=responseList.get(i).getPastDue90Amount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);

			pastDue120Amt=responseList.get(i).getPastDue120Amount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);

			pastDueAmt=responseList.get(i).getTotalPastDueAmount();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(pastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(pastDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);

			totalDueAmt=responseList.get(i).getTotalAmount();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);

			dispute=responseList.get(i).getDispute();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell13.setCellStyle(dispute.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);

			qdso=responseList.get(i).getDso();
			Cell cell14 = dataRow.createCell(13);
			cell14.setCellValue(qdso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell14.setCellStyle(qdso.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell14.setCellStyle(styleCurrencyFormat);

			regionBySegmentSheet.setColumnWidth(i, regionBySegmentSheet.getColumnWidth(i)*23/10);
		}
	}

	@Override
	public ByteArrayInputStream createExcelForRegionStateCustomer(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		List<RegionReportByStateCustomerDetails> response = regionReportsByStateCustomerRepository.byStateCustomer(
				userDetails.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
				userDetails.getExclusions(), 
				AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
				userDetails.getCustomerChidFlag());

		try (Workbook regionReportBySegmentSheetWorkbook = new XSSFWorkbook()) {
			Sheet segmentReportBySegmentDetailsSheet = regionReportBySegmentSheetWorkbook
					.createSheet("Region Report By State Customer");

			if (response != null) {

				addHeaderContent(segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook, ReportsConstant.STATE, ReportsConstant.CUSTOMER);
				addActualContentForStateCustomer(response, segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			regionReportBySegmentSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void addActualContentForStateCustomer(List<RegionReportByStateCustomerDetails> responseList,
			Sheet regionBySegmentSheet, Workbook regionBySegmentWorkBook) {

		CellStyle dataCellStyleBlack = regionBySegmentWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = regionBySegmentWorkBook.createCellStyle();
		Font blackColorFont = regionBySegmentWorkBook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = regionBySegmentWorkBook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow ;

		BigDecimal currentBilling;
		BigDecimal pastDue0Amt;
		BigDecimal pastDue30Amt;
		BigDecimal pastDue60Amt;
		BigDecimal pastDue90Amt;
		BigDecimal pastDue120Amt;
		BigDecimal pastDueAmt;
		BigDecimal totalDueAmt;
		BigDecimal dispute;
		BigDecimal qdso;
		
		for (int i = 0; i < responseList.size(); i++) {
			dataRow = regionBySegmentSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = regionBySegmentWorkBook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(responseList.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);
			
			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(responseList.get(i).getRegion());
			cell2.setCellStyle(dataCellStyleBlack);
			
			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(responseList.get(i).getState());
			cell3.setCellStyle(dataCellStyleBlack);
			
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(responseList.get(i).getCustomer());
			cell4.setCellStyle(dataCellStyleBlack);

			currentBilling=responseList.get(i).getCurrentBillingAmount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);

			pastDue0Amt=responseList.get(i).getPastDue0Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);

			pastDue30Amt=responseList.get(i).getPastDue30Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);

			pastDue60Amt=responseList.get(i).getPastDue60Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);

			pastDue90Amt=responseList.get(i).getPastDue90Amount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);

			pastDue120Amt=responseList.get(i).getPastDue120Amount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);

			pastDueAmt=responseList.get(i).getTotalPastDueAmount();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(pastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(pastDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);

			totalDueAmt=responseList.get(i).getTotalAmount();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);

			dispute=responseList.get(i).getDispute();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell13.setCellStyle(dispute.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);

			qdso=responseList.get(i).getDso();
			Cell cell14 = dataRow.createCell(13);
			cell14.setCellValue(qdso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell14.setCellStyle(qdso.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell14.setCellStyle(styleCurrencyFormat);

			regionBySegmentSheet.setColumnWidth(i, regionBySegmentSheet.getColumnWidth(i)*23/10);
		}
	}

	@Override
	public ByteArrayInputStream createExcelForRegionStateSegment(UserDetails userDetails,
			Map<Object, Object> responseMap) {
		List<RegionReportByStateSegmentDetails> response = regionReportsByStateSegmentRepository.byStateSegment(
				userDetails.getBillingPeriod(),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getGroupSelected()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedAddBracketsString(userDetails.getOriginatingSystem()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getOriginatingCompanyCdClause()), 
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getStatusClause()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getSegment()),
				CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getCustomerClause()),
				userDetails.getExclusions(), 
				AND_CX_CLASS_CD_IN+CommonReportsUtils.getListToCommaQuotesSeparatedString(userDetails.getExclusionClass())+"))",
				userDetails.getCustomerChidFlag());

		try (Workbook regionReportBySegmentSheetWorkbook = new XSSFWorkbook()) {
			Sheet segmentReportBySegmentDetailsSheet = regionReportBySegmentSheetWorkbook
					.createSheet("Region Report By State Segment");

			if (response != null) {

				addHeaderContent(segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook, ReportsConstant.STATE, ReportsConstant.SEGMENT);
				addActualContentForStateSegment(response, segmentReportBySegmentDetailsSheet, regionReportBySegmentSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			regionReportBySegmentSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void addActualContentForStateSegment(List<RegionReportByStateSegmentDetails> responseList,
			Sheet regionBySegmentSheet, Workbook regionBySegmentWorkBook) {

		CellStyle dataCellStyleBlack = regionBySegmentWorkBook.createCellStyle();
		CellStyle dataCellStyleRed = regionBySegmentWorkBook.createCellStyle();
		Font blackColorFont = regionBySegmentWorkBook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		dataCellStyleBlack.setFont(blackColorFont);

		Font redColorFont = regionBySegmentWorkBook.createFont();
		redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);

		Row dataRow ;

		BigDecimal currentBilling;
		BigDecimal pastDue0Amt;
		BigDecimal pastDue30Amt;
		BigDecimal pastDue60Amt;
		BigDecimal pastDue90Amt;
		BigDecimal pastDue120Amt;
		BigDecimal pastDueAmt;
		BigDecimal totalDueAmt;
		BigDecimal dispute;
		BigDecimal qdso;
		
		for (int i = 0; i < responseList.size(); i++) {
			dataRow = regionBySegmentSheet.createRow(i + 1);
			CellStyle styleCurrencyFormat = regionBySegmentWorkBook.createCellStyle();
			styleCurrencyFormat.setDataFormat((short)8);

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(responseList.get(i).getBillingPeriod());
			cell1.setCellStyle(dataCellStyleBlack);
			
			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(responseList.get(i).getRegion());
			cell2.setCellStyle(dataCellStyleBlack);
			
			Cell cell3 = dataRow.createCell(2);
			cell3.setCellValue(responseList.get(i).getState());
			cell3.setCellStyle(dataCellStyleBlack);
			
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(responseList.get(i).getSegment());
			cell4.setCellStyle(dataCellStyleBlack);

			currentBilling=responseList.get(i).getCurrentBillingAmount();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(currentBilling.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell5.setCellStyle(currentBilling.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);

			pastDue0Amt=responseList.get(i).getPastDue0Amount();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue0Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell6.setCellStyle(pastDue0Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);

			pastDue30Amt=responseList.get(i).getPastDue30Amount();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(pastDue30Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell7.setCellStyle(pastDue30Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);

			pastDue60Amt=responseList.get(i).getPastDue60Amount();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(pastDue60Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell8.setCellStyle(pastDue60Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);

			pastDue90Amt=responseList.get(i).getPastDue90Amount();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(pastDue90Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell9.setCellStyle(pastDue90Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);

			pastDue120Amt=responseList.get(i).getPastDue120Amount();
			Cell cell10 = dataRow.createCell(9);
			cell10.setCellValue(pastDue120Amt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell10.setCellStyle(pastDue120Amt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell10.setCellStyle(styleCurrencyFormat);

			pastDueAmt=responseList.get(i).getTotalPastDueAmount();
			Cell cell11 = dataRow.createCell(10);
			cell11.setCellValue(pastDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell11.setCellStyle(pastDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell11.setCellStyle(styleCurrencyFormat);

			totalDueAmt=responseList.get(i).getTotalAmount();
			Cell cell12 = dataRow.createCell(11);
			cell12.setCellValue(totalDueAmt.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell12.setCellStyle(totalDueAmt.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell12.setCellStyle(styleCurrencyFormat);

			dispute=responseList.get(i).getDispute();
			Cell cell13 = dataRow.createCell(12);
			cell13.setCellValue(dispute.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell13.setCellStyle(dispute.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell13.setCellStyle(styleCurrencyFormat);

			qdso=responseList.get(i).getDso();
			Cell cell14 = dataRow.createCell(13);
			cell14.setCellValue(qdso.setScale(2, RoundingMode.HALF_UP).doubleValue());
			cell14.setCellStyle(qdso.compareTo(BigDecimal.ZERO) > 0 ?dataCellStyleBlack:dataCellStyleRed);
			cell14.setCellStyle(styleCurrencyFormat);

			regionBySegmentSheet.setColumnWidth(i, regionBySegmentSheet.getColumnWidth(i)*23/10);
		}
	}
	
	private void addHeaderContent(Sheet regionByCustomerSheet, Workbook regionByCustomerWorkBook, String cell3Value, String cell4Value) {
		Row row = regionByCustomerSheet.createRow(0);
		CellStyle headerCellStyle = regionByCustomerWorkBook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = null;
		cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.REGION);
		cell2.setCellStyle(headerCellStyle);
		
		Cell cell3 = row.createCell(2);
		cell3.setCellValue(cell3Value);
		cell3.setCellStyle(headerCellStyle);
		
		Cell cell4 = row.createCell(3);
		cell4.setCellValue(cell4Value);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.CURRENT_BALANCE);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.TOTAL_DUE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.DISPUTE);
		cell13.setCellStyle(headerCellStyle);

		Cell cell14 = row.createCell(13);
		cell14.setCellValue(ReportsConstant.DSO);
		cell14.setCellStyle(headerCellStyle);

		regionByCustomerSheet.createFreezePane(1, 1);
	}
	
	private void addHeaderContent(Sheet regionByCustomerSheet, Workbook regionByCustomerWorkBook, String reportBy) {
		Row row = regionByCustomerSheet.createRow(0);
		CellStyle headerCellStyle = regionByCustomerWorkBook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.BILLING_PERIOD);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.REGION);
		cell2.setCellStyle(headerCellStyle);
		
		Cell cell3 = row.createCell(2);
		cell3.setCellValue(reportBy);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.CURRENT_BALANCE);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.TOTAL_DUE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.DISPUTE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.DSO);
		cell13.setCellStyle(headerCellStyle);

		regionByCustomerSheet.createFreezePane(1, 1);
	}
}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.TaxiClaimDetails;

@Transactional
public interface TaxiClaimDetailsRepository extends JpaRepository<TaxiClaimDetails, String> {

	@Query(value = "exec arms_taxi_claim_list_v22 :accountNumber,:originatingSystem", nativeQuery = true)
	public List<TaxiClaimDetails> getTaxiClaimDetails(@Param("accountNumber") String accountNumber,
			@Param("originatingSystem") String originatingSystem);

}

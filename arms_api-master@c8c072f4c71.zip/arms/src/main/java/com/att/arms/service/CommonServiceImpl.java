package com.att.arms.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.GridHeaders;
import com.att.arms.repo.CommonRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CommonServiceImpl implements CommonService {

	@Autowired
	CommonRepository commonRepository;

	@Override
	public Map<Object, Object> populateHeaderParameters(String userLoginCd, String moduleName,Map<Object, Object> responseMap) {
		String headerParams=commonRepository.getHeaderparameters(userLoginCd, moduleName);
		List<GridHeaders> headersList =null;
		if(StringUtils.isEmpty(headerParams)) {
			headerParams=getDefaultHeaderParams(moduleName);
		}
		final ObjectMapper objectMapper = new ObjectMapper();
		try {
			GridHeaders[] headers = objectMapper.readValue(headerParams, GridHeaders[].class);
			headersList = new ArrayList<>(Arrays.asList(headers));
			
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		responseMap.put("GridHeaders", headersList);
		return responseMap;
	}
	

	private String getDefaultHeaderParams(String moduleName) {
		String headerParam = "";
		switch (moduleName) {
		case ApplicationConstant.AGED_DETAIL:
			headerParam = ApplicationConstant.AGED_DETAIL_DEFAULT_HEADER;
			break;
		case ApplicationConstant.ACCOUNT_NOTES:
			headerParam = ApplicationConstant.ACCOUNT_NOTES_DEFAULT_HEADER;
			break;
		case ApplicationConstant.CUSTOMER_NOTES:
			headerParam = ApplicationConstant.CUSTOMER_NOTES_DEFAULT_HEADER;
			break;
		case ApplicationConstant.SUMMARY_DETAIL:
			headerParam = ApplicationConstant.SUMMARY_DETAILS_DEFAULT_HEADER;
			break;
		case ApplicationConstant.INVOICE_VIEW:
			headerParam = ApplicationConstant.INVOICE_VIEW_DEFAULT_HEADER;
			break;
		default:
			headerParam = ApplicationConstant.AGED_DETAIL_DEFAULT_HEADER;
			break;

		}

		return headerParam;
	}
}

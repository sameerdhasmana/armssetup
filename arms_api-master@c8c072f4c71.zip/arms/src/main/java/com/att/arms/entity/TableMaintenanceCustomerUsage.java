package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class TableMaintenanceCustomerUsage {

	@Id
	@JsonProperty("tableName")
	@Column(name="table_nm")
	private String tableName;
	@JsonProperty("tableDesc")
	@Column(name="table_desc")
	private String tableDesc;
	@JsonProperty("countOfCustomer")
	@Column(name="count_of_customer")
	private String countOfCustomer;
}

package com.att.arms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.repo.EmailRepository;
import com.att.arms.utils.CommonUtils;

@Service
public class EmailServiceImpl implements EmailService {

	@Autowired
	EmailRepository emailRepositry;

	@Override
	public boolean validateQueryRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getStrTmpltName())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateMailRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean mailEligibleUpdate(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())
				&& userDetails.getMailMergeEligible() != null 
				&& !CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			response = true;
		}
		return response;
	}

	@Override
	public boolean validateMailUpdateRequest(UserDetails userDetails) {
		boolean response = false;
		if (userDetails != null && StringUtils.isNotEmpty(userDetails.getUserLoginCd())
				&& userDetails.getEmail() != null && !CollectionUtils.isEmpty(userDetails.getSelectedAccountNumbers())
				&& !CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			response = true;
		}
		return response;
	}

	@Override
	public Map<Object, Object> emailTmpltList(Map<Object, Object> responseMap) {

		List<String> populateEmilTmpltList = new ArrayList<>();

		List<Object[]> emilInfoList = emailRepositry.emailTmpltList();
		if (!CollectionUtils.isEmpty(emilInfoList)) {
			emilInfoList.stream().forEach(ele -> {
				StringJoiner joiner = new StringJoiner(",");
				for (Object obj : ele) {
					joiner.add((String) obj);
				}
				if (StringUtils.isNotEmpty(joiner.toString())) {
					populateEmilTmpltList.add(joiner.toString());
				}
			});
		}
		responseMap.put(ApplicationConstant.EMAIL_TEMPLT, populateEmilTmpltList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> emailTmpltName(UserDetails userDetails, Map<Object, Object> responseMap) {
		List<String> emailTmpltName = new ArrayList<>();
		List<Object[]> emailTmpltNameList = emailRepositry.getTmpltName(userDetails.getStrTmpltName());
		if (!CollectionUtils.isEmpty(emailTmpltNameList)) {
			emailTmpltNameList.stream().forEach(ele -> {
				StringJoiner joiner = new StringJoiner(",");
				for (Object obj : ele) {
					joiner.add((String) obj);
				}
				if (StringUtils.isNotEmpty(joiner.toString())) {
					emailTmpltName.add(joiner.toString());
				}
			});
		}
		responseMap.put(ApplicationConstant.EMAIL_TEMPLT_NAME, emailTmpltName);
		return responseMap;
	}

	@Override
	public Map<Object, Object> sendEmail(UserDetails userDetails, Map<Object, Object> responseMap) {
		String originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		String amountList = CommonUtils.getListToCommaSeparatedString(userDetails.getAmountlist());
		String dateList = CommonUtils.getListToCommaSeparatedString(userDetails.getDatelist());
		String acountNumList = CommonUtils.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());

		String emailTmpltNameList = emailRepositry.armsEmailCreate(acountNumList, originatingSystem,
				userDetails.getUserLoginCd(), userDetails.getTmpltdesc(), userDetails.getDuedate(),
				userDetails.getPadeadline(), userDetails.getPastDue(), userDetails.getTotalAmt(),
				userDetails.getPayArrangeDate(), userDetails.getConfirmByDate(), userDetails.getAmountPaid(),
				userDetails.getDatePaid(), userDetails.getConfirmNum(), userDetails.getPcfAmount(),
				userDetails.getPayAddrInd(), amountList, dateList);

		responseMap.put(ApplicationConstant.EMAIL_TEMPLT_NAME, emailTmpltNameList);
		return responseMap;
	}

	@Override
	public Map<Object, Object> accountEmailupdate(UserDetails userDetails, Map<Object, Object> responseMap) {
		String originatingSystem = "";
		String accountnumbers = CommonUtils.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());
		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		}
		emailRepositry.accountEmailupdate(userDetails.getUserLoginCd(), accountnumbers, userDetails.getEmail(),
				originatingSystem);
		responseMap.put("MESSAGE", ApplicationConstant.SUCCESS);
		return responseMap;
	}

	@Override
	public Map<Object, Object> mailEligibleUpdate(UserDetails userDetails, Map<Object, Object> responseMap) {
		String originatingSystem = "";
		String accountnumbers = CommonUtils.getListToCommaSeparatedString(userDetails.getSelectedAccountNumbers());
		if (!CollectionUtils.isEmpty(userDetails.getOriginatingSystem())) {
			originatingSystem = CommonUtils.getListToCommaSeparatedString(userDetails.getOriginatingSystem());
		}
		emailRepositry.mailEligibleUpdate(userDetails.getUserLoginCd(), accountnumbers,
				userDetails.getMailMergeEligible(), originatingSystem);
		responseMap.put("MESSAGE", ApplicationConstant.SUCCESS);
		return responseMap;
	}
}

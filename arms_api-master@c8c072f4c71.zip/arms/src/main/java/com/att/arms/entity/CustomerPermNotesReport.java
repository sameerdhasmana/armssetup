package com.att.arms.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.Data;

@Entity
@IdClass(CustomerPermNotesReport.CustomerPermNotesReportId.class)
@Data
public class CustomerPermNotesReport {

	@Id
	@Column(name="billing_period")
	private String billingPeriod;
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	@Column(name="insert_dt")
	private Date insertDate;
	@Id
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	private Integer resolved;
	@Id
	private String notes;
	@Column(name="sub_activity_cd")
	private String subActivityCode;
	@Column(name="activity_cd")
	private String activityCode;
	@Id
	private String rep;
	
	
	@SuppressWarnings("serial")
	@Data
	public static class CustomerPermNotesReportId implements Serializable {

		private String billingPeriod;
		private String customerGrpCd;
		private String rep;
		private String notes;

	}
}

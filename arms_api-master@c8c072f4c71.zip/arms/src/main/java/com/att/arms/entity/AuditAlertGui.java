package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(AuditAlertGui.AuditAlertGuiId.class)
@Data
public class AuditAlertGui {

	@Id
	@JsonProperty("login_id")
	@Column(name="login_id")
	private String loginId;
	@Id
	@JsonProperty("first_name")
	@Column(name="first_name")
	private String firstName;
	@Id
	@JsonProperty("last_name")
	@Column(name="last_name")
	private String lastName;
	@Id
	@JsonProperty("userid_status")
	@Column(name="userid_status")
	private String useridStatus;
	private String accessed;
	private String violation;
	@Id
	@JsonProperty("appl_name")
	@Column(name="appl_name")
	private String applName;
	@Id
	private String environment;
	@Id
	@JsonProperty("login_dt")
	@Column(name="login_dt")
	private String loginDt;
	@JsonProperty("pc_ip")
	@Column(name="pc_ip")
	private String pcIp;
	@JsonProperty("pc_id")
	@Column(name="pc_id")
	private String pcId;
	@JsonProperty("pc_name")
	@Column(name="pc_name")
	private String pcName;
	@JsonProperty("last_reviewed_by")
	@Column(name="last_reviewed_by")
	private String lastReviewedBy;
	@JsonProperty("last_reviewed_dt")
	@Column(name="last_reviewed_dt")
	private String lastReviewedDt;
	@JsonProperty("role_Desc")
	@Column(name="role_Desc")
	private String roleDesc;
	@JsonProperty("userid_create_dt")
	@Column(name="userid_create_dt")
	private String useridCreateDt;
	@JsonProperty("llobal_Resp_CD")
	@Column(name="llobal_Resp_CD")
	private String llobalRespCD;
	@JsonProperty("userid_status_chng_dt")
	@Column(name="userid_status_chng_dt")
	private String useridStatusChngDt;
	@Id
	@JsonProperty("times_logged_in")
	@Column(name="times_logged_in")
	private String timesLoggedIn;
	
	@SuppressWarnings("serial")
	@Data
	public static class AuditAlertGuiId implements Serializable {

		private String loginId;
		private String firstName;
		private String lastName;
		private String useridStatus;
		private String applName;
		private String environment;
		private String loginDt;
		private String timesLoggedIn;
		
		
	}
}

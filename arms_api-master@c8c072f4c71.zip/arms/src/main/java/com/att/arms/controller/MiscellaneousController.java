package com.att.arms.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.entity.UserDetails;
import com.att.arms.service.MiscellaneousService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/api/")
public class MiscellaneousController {

	private static final String APPLICATION_OCTET_STREAM = "application/octet-stream";
	private static final String CONTENT_DISPOSITION = "Content-Disposition";
	
	@Autowired
	MiscellaneousService miscellaneousService;

	@PostMapping("generateCPPOReport")
	public ResponseEntity<Object> generateCPPOReport(@RequestBody UserDetails userDetails, HttpServletResponse response)
			throws IOException {
		boolean valid = this.miscellaneousService.validateCPPOReportQueryRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (valid) {
			response.setContentType(APPLICATION_OCTET_STREAM);
			response.setHeader(CONTENT_DISPOSITION, "attachment; filename=CPPOReports.pdf");
			ByteArrayInputStream stream = miscellaneousService.generateCPPOReport(userDetails, responseMap);
			IOUtils.copy(stream, response.getOutputStream());
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("generatePermNoteReport")
	public ResponseEntity<Object> generatePermNoteReport(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			response.setContentType(APPLICATION_OCTET_STREAM);
			response.setHeader(CONTENT_DISPOSITION, "attachment; filename=PermNoteReport.pdf");
			ByteArrayInputStream stream = miscellaneousService.generatePermNoteReport(userDetails.getCustomerGrpCd(),
					userDetails.getUserLoginCd(), responseMap);
			IOUtils.copy(stream, response.getOutputStream());
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

	@PostMapping("generateAccountPermNoteReport")
	public ResponseEntity<Object> generateAccountPermNoteReport(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws IOException {
		boolean valid = this.miscellaneousService.validateAccountPermNoteRequest(userDetails);
		Map<Object, Object> responseMap = new HashMap<>();
		if (valid) {
			response.setContentType(APPLICATION_OCTET_STREAM);
			response.setHeader(CONTENT_DISPOSITION, "attachment; filename=AccountPermNoteReport.pdf");
			ByteArrayInputStream stream = miscellaneousService.generateAccountPermNoteReport(userDetails, responseMap);
			IOUtils.copy(stream, response.getOutputStream());
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	@PostMapping("generateRepCopyReport")
	public ResponseEntity<Object> generateRepCopyReport(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		if (StringUtils.isNotEmpty(userDetails.getCustomerGrpCd())) {
			response.setContentType(APPLICATION_OCTET_STREAM);
			response.setHeader(CONTENT_DISPOSITION, "attachment; filename=RepCopyReport.pdf");
			ByteArrayInputStream stream = miscellaneousService.generateRepCopyReport(userDetails, responseMap);
			IOUtils.copy(stream, response.getOutputStream());
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("generateCustCopyReport")
	public ResponseEntity<Object> generateCustCopyReport(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean valid = this.miscellaneousService.validateCustCopyReportRequest(userDetails);
		if (valid) {
			response.setContentType(APPLICATION_OCTET_STREAM);
			response.setHeader(CONTENT_DISPOSITION, "attachment; filename=CustomerCopyReport.pdf");
			ByteArrayInputStream stream = miscellaneousService.generateCustCopyReport(userDetails, responseMap);
			IOUtils.copy(stream, response.getOutputStream());
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("printCustomerReport")
	public ResponseEntity<Object> printCustomerReport(@RequestBody UserDetails userDetails,
			HttpServletResponse response) throws IOException {
		Map<Object, Object> responseMap = new HashMap<>();
		boolean valid = this.miscellaneousService.validateMyCustomerReportRequest(userDetails);
		if (valid) {
			response.setContentType(APPLICATION_OCTET_STREAM);
			ByteArrayInputStream stream =null;
			if(userDetails.getCustomerType().equals(ApplicationConstant.CUSTOMER_TYPE_MY_CUSTOMER)) {
				response.setHeader(CONTENT_DISPOSITION, "attachment; filename=MyCustomerReport.pdf");
				stream = miscellaneousService.generateMyCustomerReport(userDetails, responseMap);
			}else if(userDetails.getCustomerType().equals(ApplicationConstant.CUSTOMER_TYPE_CUSTOMER_BRING_UPS)) {
				response.setHeader(CONTENT_DISPOSITION, "attachment; filename=CustomerBringupReport.pdf");
				stream = miscellaneousService.generateCustomerBringupReport(userDetails, responseMap);
			}else if(userDetails.getCustomerType().equals(ApplicationConstant.CUSTOMER_TYPE_ACCOUNT_BRING_UPS)) {
				response.setHeader(CONTENT_DISPOSITION, "attachment; filename=AccountBringupReport.pdf");
				stream = miscellaneousService.generateAccountBringupReport(userDetails, responseMap);
			}
			
			IOUtils.copy(stream, response.getOutputStream());
			if (!(responseMap.containsKey(ApplicationConstant.ERROR_MESSSAGE))) {
				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			}
		} else {
			responseMap.put(ApplicationConstant.ERROR_MESSSAGE, ApplicationConstant.INVALID_PARAMETER_MSG);
		}
		return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
	}

}

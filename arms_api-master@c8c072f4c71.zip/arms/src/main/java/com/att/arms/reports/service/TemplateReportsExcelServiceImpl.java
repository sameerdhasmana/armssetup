package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.arms.config.ApplicationConstant;
import com.att.arms.config.ReportsConstant;
import com.att.arms.reports.entity.TemplateReportsEntity;
import com.att.arms.reports.repo.TemplateReportsRepository;
import com.itextpdf.text.DocumentException;

@Service
public class TemplateReportsExcelServiceImpl implements TemplateReportsExcelService {
	
	@Autowired
	TemplateReportsRepository templateReportsRepository;
	
	
	@SuppressWarnings("unused")
	@Override
	public ByteArrayInputStream createExcelWithDbData(String billingPeriod, String originatingSystem,
			String reportStatus, Map<Object, Object> responseMap) throws DocumentException, FileNotFoundException {

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		List<TemplateReportsEntity> allTemplateDetailsList = null;
			
		allTemplateDetailsList = templateReportsRepository.findTemplateReportsList(billingPeriod);

 		try (Workbook allTemplateDetailsSheetWorkbook = new XSSFWorkbook()) {
			Sheet allTemplateDetailsSheet = allTemplateDetailsSheetWorkbook.createSheet("AllTemplateDetails");

			if (allTemplateDetailsList != null) {

				addHeaderContent(allTemplateDetailsSheet, allTemplateDetailsSheetWorkbook);
				addActualContent(allTemplateDetailsList, allTemplateDetailsSheet, allTemplateDetailsSheetWorkbook);
				responseMap.put("msg", ApplicationConstant.SUCCESS);

			} else {
				responseMap.remove("msg");
				responseMap.put(ApplicationConstant.ERROR_MESSSAGE, "No records Found..");
			}
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			allTemplateDetailsSheetWorkbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void addActualContent(List<TemplateReportsEntity> allTemplateDetailsList,
			Sheet allCustomerDetailsSheet, Workbook allCustomerDetailsSheetWorkbook) {

		CellStyle dataCellStyleBlack = allCustomerDetailsSheetWorkbook.createCellStyle();
		CellStyle dataCellStyleRed = allCustomerDetailsSheetWorkbook.createCellStyle();
		Font blackColorFont = allCustomerDetailsSheetWorkbook.createFont();
		blackColorFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        dataCellStyleBlack.setFont(blackColorFont);
        
        Font redColorFont = allCustomerDetailsSheetWorkbook.createFont();
        redColorFont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
		dataCellStyleRed.setFont(redColorFont);
        
		Row dataRow ;

		double pastDue = 0;
		double totalDue = 0;
		double pastDue30Amt = 0;
		double pastDue60Amt = 0;
		double collectablePd = 0;
		double collectableTotal = 0;
		double disputeAmt = 0;

		for (int i = 0; i < allTemplateDetailsList.size(); i++) {
			dataRow = allCustomerDetailsSheet.createRow(i + 1);
		CellStyle styleCurrencyFormat = allCustomerDetailsSheetWorkbook.createCellStyle();
		styleCurrencyFormat.setDataFormat((short)8);
			
			

			Cell cell1 = dataRow.createCell(0);
			cell1.setCellValue(allTemplateDetailsList.get(i).getAccountNumber());
			cell1.setCellStyle(dataCellStyleBlack);

			Cell cell2 = dataRow.createCell(1);
			cell2.setCellValue(allTemplateDetailsList.get(i).getOriginatingSystem());
			cell2.setCellStyle(dataCellStyleBlack);

			pastDue=allTemplateDetailsList.get(i).getPastDue();
			Cell cell3 = dataRow.createCell(2);
			cell3.setCellStyle(pastDue>0?dataCellStyleBlack:dataCellStyleRed);
			cell3.setCellStyle(styleCurrencyFormat);


			totalDue=allTemplateDetailsList.get(i).getTotalDue();
			Cell cell4 = dataRow.createCell(3);
			cell4.setCellValue(totalDue);
			cell4.setCellStyle(totalDue>0?dataCellStyleBlack:dataCellStyleRed);
			cell4.setCellStyle(styleCurrencyFormat);


			pastDue30Amt=allTemplateDetailsList.get(i).getThirtyPlusAmt();
			Cell cell5 = dataRow.createCell(4);
			cell5.setCellValue(pastDue30Amt);
			cell5.setCellStyle(pastDue30Amt>0?dataCellStyleBlack:dataCellStyleRed);
			cell5.setCellStyle(styleCurrencyFormat);


			pastDue60Amt=allTemplateDetailsList.get(i).getSixtyPlusAmt();
			Cell cell6 = dataRow.createCell(5);
			cell6.setCellValue(pastDue60Amt);
			cell6.setCellStyle(pastDue60Amt>0?dataCellStyleBlack:dataCellStyleRed);
			cell6.setCellStyle(styleCurrencyFormat);


			collectablePd=allTemplateDetailsList.get(i).getCollectablePd();
			Cell cell7 = dataRow.createCell(6);
			cell7.setCellValue(collectablePd);
			cell7.setCellStyle(collectablePd>0?dataCellStyleBlack:dataCellStyleRed);
			cell7.setCellStyle(styleCurrencyFormat);


			collectableTotal=allTemplateDetailsList.get(i).getCollectableTotal();
			Cell cell8 = dataRow.createCell(7);
			cell8.setCellValue(collectableTotal);
			cell8.setCellStyle(collectableTotal>0?dataCellStyleBlack:dataCellStyleRed);
			cell8.setCellStyle(styleCurrencyFormat);


			disputeAmt=allTemplateDetailsList.get(i).getDisputeAmt();
			Cell cell9 = dataRow.createCell(8);
			cell9.setCellValue(disputeAmt);
			cell9.setCellStyle(disputeAmt>0?dataCellStyleBlack:dataCellStyleRed);
			cell9.setCellStyle(styleCurrencyFormat);


			allCustomerDetailsSheet.setColumnWidth(i,allCustomerDetailsSheet.getColumnWidth(i)*23/10);
	        
			
		}
	}

	private void addHeaderContent(Sheet allCustomerDetailsSheet, Workbook allCustomerDetailsSheetWorkbook) {
		Row row = allCustomerDetailsSheet.createRow(0);
		CellStyle headerCellStyle = allCustomerDetailsSheetWorkbook.createCellStyle();
		headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		Cell cell1 = row.createCell(0);
		cell1.setCellValue(ReportsConstant.GROUP);
		cell1.setCellStyle(headerCellStyle);

		Cell cell2 = row.createCell(1);
		cell2.setCellValue(ReportsConstant.REGION);
		cell2.setCellStyle(headerCellStyle);

		Cell cell3 = row.createCell(2);
		cell3.setCellValue(ReportsConstant.SEGMENT);
		cell3.setCellStyle(headerCellStyle);

		Cell cell4 = row.createCell(3);
		cell4.setCellValue(ReportsConstant.CURRENT_BILLING);
		cell4.setCellStyle(headerCellStyle);

		Cell cell5 = row.createCell(4);
		cell5.setCellValue(ReportsConstant.PAST_DUE_0_DAYS);
		cell5.setCellStyle(headerCellStyle);

		Cell cell6 = row.createCell(5);
		cell6.setCellValue(ReportsConstant.PAST_DUE_30_DAYS);
		cell6.setCellStyle(headerCellStyle);

		Cell cell7 = row.createCell(6);
		cell7.setCellValue(ReportsConstant.PAST_DUE_60_DAYS);
		cell7.setCellStyle(headerCellStyle);

		Cell cell8 = row.createCell(7);
		cell8.setCellValue(ReportsConstant.PAST_DUE_90_DAYS);
		cell8.setCellStyle(headerCellStyle);

		Cell cell9 = row.createCell(8);
		cell9.setCellValue(ReportsConstant.PAST_DUE_120_DAYS);
		cell9.setCellStyle(headerCellStyle);

		Cell cell10 = row.createCell(9);
		cell10.setCellValue(ReportsConstant.TOTAL_PAST_DUE);
		cell10.setCellStyle(headerCellStyle);

		Cell cell11 = row.createCell(10);
		cell11.setCellValue(ReportsConstant.TOTAL_DUE);
		cell11.setCellStyle(headerCellStyle);

		Cell cell12 = row.createCell(11);
		cell12.setCellValue(ReportsConstant.DISPUTE);
		cell12.setCellStyle(headerCellStyle);

		Cell cell13 = row.createCell(12);
		cell13.setCellValue(ReportsConstant.QDSO);
		cell13.setCellStyle(headerCellStyle);
		
		 allCustomerDetailsSheet.createFreezePane(1, 1);
	}

	
}

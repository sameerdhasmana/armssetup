package com.att.arms.repo;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.att.arms.entity.UserAdministrationMaintenance;

@Transactional
public interface UserAdministrationRepository extends JpaRepository<UserAdministrationMaintenance, String> {

	@Query(value = "EXEC arms_usermaintenance_getUsers_ex22 :strSort ,:strFilter", nativeQuery = true)
	public List<UserAdministrationMaintenance> getMaintenanceUsers(@Param("strSort") String strSort,
			@Param("strFilter") String strFilter);

}
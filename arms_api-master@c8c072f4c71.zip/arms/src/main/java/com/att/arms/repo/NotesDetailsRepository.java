package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.NotesDetails;

@Transactional
public interface NotesDetailsRepository extends JpaRepository<NotesDetails, String> {

	@Query(value = "exec arms_ntstmplt_get_v20 :userLoginCd,:templateName,:templateType", nativeQuery = true)
	public List<NotesDetails> getNotesDetails(@Param("userLoginCd") String userLoginCd,@Param("templateName") String templateName,
			@Param("templateType") String templateType);
	
}

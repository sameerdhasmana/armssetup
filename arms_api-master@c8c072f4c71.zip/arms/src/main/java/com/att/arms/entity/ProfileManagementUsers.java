package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Entity

public class ProfileManagementUsers {

	@Id
	@JsonProperty("user_id")
	@Column(name = "user_id")
	private String userId;
	@JsonProperty("last_name")
	@Column(name = "last_name")
	private String lastName;
	@JsonProperty("first_name")
	@Column(name = "first_name")
	private String firstName;
	@JsonProperty("s1_l_name")
	@Column(name = "s1_l_name")
	private String s1LName;
	@JsonProperty("s1_f_name")
	@Column(name = "s1_f_name")
	private String s1FName;
	@JsonProperty("s2_l_name")
	@Column(name = "s2_l_name")
	private String s2LName;
	@JsonProperty("s2_f_name")
	@Column(name = "s2_f_name")
	private String s2FName;

}

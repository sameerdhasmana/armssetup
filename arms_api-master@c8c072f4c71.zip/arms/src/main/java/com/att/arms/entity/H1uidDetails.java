package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(H1uidDetails.H1uidDetailsId.class)
@Data
public class H1uidDetails {

	@Id
	@JsonProperty("h1uid")
	private String h1uid;
	@Id
	@JsonProperty("userid")
	private String userid;

	@SuppressWarnings("serial")
	@Data
	public static class H1uidDetailsId implements Serializable {

		private String h1uid;
		private String userid;

	}
}

package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.AccountClassification;

@Transactional
public interface CustomerAccountClassificationRepository extends JpaRepository<AccountClassification, String> {

	@Query(value = "EXEC arms_custqry_account_classification_for_lb", nativeQuery = true)
	public List<AccountClassification> findAccountsClassificationList();
}

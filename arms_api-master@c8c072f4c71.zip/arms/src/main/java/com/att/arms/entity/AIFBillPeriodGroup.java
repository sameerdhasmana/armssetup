package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Entity
@IdClass(AIFBillPeriodGroup.AIFBillPeriodGroupId.class)
@Data
public class AIFBillPeriodGroup {
	@Id
	@JsonProperty("billing_period")
	@Column(name="billing_period")
	private String billingPeriod;
	private String group;	
	@Id
	@JsonProperty("originating_system")
	@Column(name="originating_system")
	private String originatingSystem;
	
	@SuppressWarnings("serial")
	@Data
	public static class AIFBillPeriodGroupId implements Serializable {

		private String billingPeriod;
		private String originatingSystem;
	}
	}


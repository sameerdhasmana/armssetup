package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface RegionExcelReportsService {
	
	public ByteArrayInputStream createExcelForRegionSegment(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createExcelForRegionCustomer(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createExcelForRegionState(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createExcelForRegionSegmentCustomer(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createExcelForRegionStateCustomer(UserDetails userDetails, Map<Object, Object> responseMap);
	public ByteArrayInputStream createExcelForRegionStateSegment(UserDetails userDetails, Map<Object, Object> responseMap);

}

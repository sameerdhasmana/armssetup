package com.att.arms.reports.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.reports.entity.CustomerReportByAccount;

@Transactional
public interface CustomerReportRepositoryForAccNumber extends JpaRepository<CustomerReportByAccount, String> {

	@Query(value = "exec arms_rpt_mgr_customer_by_account_v20 :billingPeriod,:groupSelected,:originatingSystem,:originatingCompanyCdClause,:statusClause,:segment,:customerClause,:accountStatusClause, :classClause,:customerChidFlag,:disputeInterval", nativeQuery = true)
	 public List<CustomerReportByAccount> findCustomerReportData(
			@Param("billingPeriod") String billingPeriod,
			@Param("groupSelected") String groupSelected,
			@Param("originatingSystem") String originatingSystem,
			@Param("originatingCompanyCdClause") String originatingCompanyCdClause,
			@Param("statusClause") String statusClause, 
			@Param("segment") String segment,
			@Param("customerClause") String customerClause,
			@Param("accountStatusClause")  String accountStatusClause,
			@Param("classClause") String classClause,
			@Param("customerChidFlag") String customerChidFlag,
			@Param("disputeInterval") String disputeInterval);
	
	
	
	
	
	

}

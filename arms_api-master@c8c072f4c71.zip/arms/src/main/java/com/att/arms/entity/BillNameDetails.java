package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@IdClass(BillNameDetails.BillNameDetailsId.class)
@Data
public class BillNameDetails {
	@Id
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("customer_legal_nm")
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	@Id
	@JsonProperty("customer_nm")
	@Column(name="customer_nm")
	private String customerNm;
	@Id
	private Integer ctc;
	
	@SuppressWarnings("serial")
	@Data
	public static class BillNameDetailsId implements Serializable {

		private String customerGrpCd;
		private String customerNm;
		private Integer ctc;
		
		
	}
}

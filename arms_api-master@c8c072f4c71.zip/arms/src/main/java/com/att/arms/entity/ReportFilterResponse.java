package com.att.arms.entity;

import java.util.List;

import lombok.Data;
@Data
public class ReportFilterResponse {

	private GlobalLogonUsers globalLogonUsers;
	private List<CustomerGroupList> customerGroupList;
	private List<CustomerBillingPeriod> customerBillingPeriod;
	private List<CustomerSegment> segmentList;
	private List<AccountClassification> accountsClassificationList;
	private List<OriginatingSystem> originatingSystemList;
	private List<RegionDetails> regionDetailsList;
	private List<DispIntervalDetails> dispIntervalDetails;
	private List<ChildTieCodeDetails> childTieCodeDetails;
	private List<TemplateFieldsDetails> templateFieldsDetails;

	private String errorMsg;

	public GlobalLogonUsers getGlobalLogonUsers() {
		return globalLogonUsers;
	}

	public void setGlobalLogonUsers(GlobalLogonUsers globalLogonUsers) {
		this.globalLogonUsers = globalLogonUsers;
	}

	public List<CustomerGroupList> getCustomerGroupList() {
		return customerGroupList;
	}

	public void setCustomerGroupList(List<CustomerGroupList> customerGroupList) {
		this.customerGroupList = customerGroupList;
	}

	public List<CustomerBillingPeriod> getCustomerBillingPeriod() {
		return customerBillingPeriod;
	}

	public void setCustomerBillingPeriod(List<CustomerBillingPeriod> customerBillingPeriod) {
		this.customerBillingPeriod = customerBillingPeriod;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<CustomerSegment> getSegmentList() {
		return segmentList;
	}

	public void setSegmentList(List<CustomerSegment> segmentList) {
		this.segmentList = segmentList;
	}

	public List<AccountClassification> getAccountsClassificationList() {
		return accountsClassificationList;
	}

	public void setAccountsClassificationList(List<AccountClassification> accountsClassificationList) {
		this.accountsClassificationList = accountsClassificationList;
	}

	public List<OriginatingSystem> getOriginatingSystemList() {
		return originatingSystemList;
	}

	public void setOriginatingSystemList(List<OriginatingSystem> originatingSystemList) {
		this.originatingSystemList = originatingSystemList;
	}
	public List<RegionDetails> getRegionDetailsList() {
		return regionDetailsList;
	}

	public void setRegionDetailsList(List<RegionDetails> regionDetailsList) {
		this.regionDetailsList = regionDetailsList;
	}
	
	public List<DispIntervalDetails> getDispIntervalDetails() {
		return dispIntervalDetails;
	}

	public void setDispIntervalDetails(List<DispIntervalDetails> dispIntervalDetails) {
		this.dispIntervalDetails = dispIntervalDetails;
	}

	public List<ChildTieCodeDetails> getChildTieCodeDetails() {
		return childTieCodeDetails;
	}

	public void setChildTieCodeDetails(List<ChildTieCodeDetails> childTieCodeDetails) {
		this.childTieCodeDetails = childTieCodeDetails;
	}


}

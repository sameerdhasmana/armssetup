package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.Segment;

@Transactional
public interface SegmentRepository extends JpaRepository<Segment, String> {

	@Query(value = "EXEC arms_reputil_getSegment_v22 :group", nativeQuery = true)
	public List<Segment> findCustomerSegmentList(@Param("group") String group);

	@Query(value = "EXEC arms_tablemaint_Select_Segment_cd ", nativeQuery = true)
	public List<Segment> getSegmentList();

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerGroupList;

@Transactional
public interface FilterRepository extends JpaRepository<CustomerGroupList, String> {

	@Query(value = "Exec arms_custqry_group_list :group", nativeQuery = true)
	public List<CustomerGroupList> findcustomerGroupList(@Param("group") String group);
	
	@Modifying
	@Query(value = "Exec arms_usrpref_updt_v22 :userLoginCd,:moduleName,:headerParams", nativeQuery = true)
	public void saveHeaderParams(@Param("userLoginCd") String userLoginCd,@Param("moduleName") String moduleName
			,@Param("headerParams") String headerParams);
	
	@Modifying
	@Query(value = "Exec arms_usrpref_delete_v22 :userLoginCd,:moduleName", nativeQuery = true)
	public void deleteHeaderParams(@Param("userLoginCd") String userLoginCd,@Param("moduleName") String moduleName);

}

package com.att.arms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class TableMaintenanceAcna {

	@Id
	private String acna;
	private String segmentCode;
	private String acnaMaster;
	private String parentName;
	private String notes;
	private String autoAssign;
	private String customerGroupCode;

}

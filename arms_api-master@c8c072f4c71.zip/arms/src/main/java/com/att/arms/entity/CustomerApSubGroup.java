package com.att.arms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class CustomerApSubGroup {

	@Id
	@JsonProperty("apSubGrpName")
	@Column(name = "ApSubGrpName")
	private String apSubGrpName;
	@JsonProperty("customerGrpCd")
	@Column(name = "customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("apSubGrpDesc")
	@Column(name = "ApSubGrpDesc")
	private String apSubGrpDesc;
	@JsonProperty("insertDt")
	@Column(name = "insert_dt")
	private Date insertDt;
	@JsonProperty("updateDt")
	@Column(name = "update_dt")
	private Date updateDt;
	@JsonProperty("insertUserLoginCd")
	@Column(name = "insert_user_login_cd")
	private String insertUserLoginCd;
	@JsonProperty("updateUserLoginCd")
	@Column(name = "update_user_login_cd")
	private String updateUserLoginCd;

}

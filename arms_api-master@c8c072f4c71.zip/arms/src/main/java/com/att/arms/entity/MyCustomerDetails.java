package com.att.arms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class MyCustomerDetails {

	@Id
	@JsonProperty("customer_grp_cd")
	@Column(name="customer_grp_cd")
	private String customerGrpCd;
	@JsonProperty("customer_legal_nm")
	@Column(name="customer_legal_nm")
	private String customerLegalNm;
	@JsonProperty("ExcludedAccountsExists")
	@Column(name="ExcludedAccountsExists")
	private String excludedAccountsExists;
	private Integer priority;
	@JsonProperty("current_billing_amt")
	@Column(name="current_billing_amt")
	private Double currentBillingAmt;
	@JsonProperty("amt_30")
	@Column(name="amt_30")
	private Double amt30;
	@JsonProperty("disputed_amt")
	@Column(name="disputed_amt")
	private Double disputedAmt;
	@JsonProperty("total_amt")
	@Column(name="total_amt")
	private Double totalAmt;
	private Double collectable;
	


}

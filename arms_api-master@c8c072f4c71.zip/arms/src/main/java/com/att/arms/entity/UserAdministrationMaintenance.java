package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.Data;

@Entity
@IdClass(UserAdministrationMaintenance.UserAdministrationMaintenanceId.class)

@Data
public class UserAdministrationMaintenance {

	@Id
	private String regionalId;
	private String lastName;
	private String phone;
	private String group;
	private String region;
	private String location;
	private String role;
	private Integer org;
	private String email;
	@Id
	private String userStatus;
	private String userStatusDesc;
	private String reviewerManagerID;
	private String reviewedOn;

	@Data
	public static class UserAdministrationMaintenanceId implements Serializable {
		
		private static final long serialVersionUID = 1L;
		private String userStatus;
		private String regionalId;
	}
}

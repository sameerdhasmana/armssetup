package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.TableMaintenanceCustomerUsage;

@Transactional
public interface TableMaintenanceCustUsageRepository extends JpaRepository<TableMaintenanceCustomerUsage, String> {

	@Query(value = "Exec arms_maintainance_fetch_customer_usage_ex :CUSTOMER_GRP_CD,:strSort", nativeQuery = true)
	public List<TableMaintenanceCustomerUsage> getCustomerUsage(
			@Param("CUSTOMER_GRP_CD") String custGrpCd, @Param("strSort") String strSort);

}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.UserAdminReports;

@Transactional
public interface UserAdminReportsRepository extends JpaRepository<UserAdminReports, String> {

	@Query(value = "EXEC arms_rpt_expired_users ", nativeQuery = true)
	public List<UserAdminReports> getUserExpiredReports();
	@Query(value = "EXEC arms_useradmin_rpt_expired_users_to_disable ", nativeQuery = true)
	public List<UserAdminReports> getExpiredUsersToDisable();
	@Query(value = "EXEC arms_useradmin_rpt_users_to_delete_status ", nativeQuery = true)
	public List<UserAdminReports> getUserToDeleteStatus();
	@Query(value = "EXEC arms_useradmin_rpt_users_deleted_status_remove ", nativeQuery = true)
	public List<UserAdminReports> getUsersDeletedStatusRemove();	
	@Query(value = "EXEC arms_useradmin_rpt_users_deleted_status_all ", nativeQuery = true)
	public List<UserAdminReports> getAlldeletedReports();
	@Query(value = "EXEC arms_useradmin_rpt_users_active_status_90 ", nativeQuery = true)
	public List<UserAdminReports> getActiveInNinty();
	@Query(value = "EXEC arms_useradmin_rpt_users_active_status_120 ", nativeQuery = true)
	public List<UserAdminReports> getActiveInOneTwenty();
	@Query(value = "EXEC arms_useradmin_rpt_users_non_active_status_all ", nativeQuery = true)
	public List<UserAdminReports> getNonActiverStatusAll();	
	@Query(value = "EXEC arms_useradmin_rpt_users_suits_match ", nativeQuery = true)
	public List<UserAdminReports> getUserSuits();



}
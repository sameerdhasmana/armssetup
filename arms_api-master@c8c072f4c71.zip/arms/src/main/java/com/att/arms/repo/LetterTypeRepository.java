package com.att.arms.repo;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.att.arms.entity.LetterTypes;

@Transactional
public interface LetterTypeRepository extends JpaRepository<LetterTypes, Integer> {

	@Query(value = "Exec arms_letter_types_list :user_login_id,:blank", nativeQuery = true)
	public List<LetterTypes> getLetterTypes(@Param("user_login_id") String userLoginId,
			@Param("blank") Integer blank);

}

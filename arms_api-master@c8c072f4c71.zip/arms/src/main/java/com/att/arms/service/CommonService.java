package com.att.arms.service;

import java.util.Map;

public interface CommonService {

	Map<Object, Object> populateHeaderParameters(String userLoginCd,String moduleName,Map<Object, Object> responseMap);


}

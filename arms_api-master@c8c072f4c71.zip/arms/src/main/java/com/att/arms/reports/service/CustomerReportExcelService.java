package com.att.arms.reports.service;

import java.io.ByteArrayInputStream;
import java.util.Map;

import com.att.arms.entity.UserDetails;

public interface CustomerReportExcelService {

	public ByteArrayInputStream getCustRepDetailsByAccNumExcel(UserDetails userDetails, Map<Object, Object> responseMap);

	public ByteArrayInputStream getCustRepDetailsByBillNameExcel(UserDetails userDetails,Map<Object, Object> responseMap);

	public ByteArrayInputStream getCustRepDetailsByRegSegExcel(UserDetails userDetails,Map<Object, Object> responseMap);

	public ByteArrayInputStream getCustRepDetailsByRegSegStatusExcel(UserDetails userDetails,Map<Object, Object> responseMap);
	
	public ByteArrayInputStream getCustRepDetailsByRegStateExcel(UserDetails userDetails,Map<Object, Object> responseMap);
	
	public ByteArrayInputStream getCustRepDetailsByRegStateSegExcel(UserDetails userDetails,Map<Object, Object> responseMap);

}

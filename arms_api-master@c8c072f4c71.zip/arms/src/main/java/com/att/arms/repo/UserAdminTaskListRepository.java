package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.UserAdminTaskList;

@Transactional
public interface UserAdminTaskListRepository extends JpaRepository<UserAdminTaskList, Integer> {

	@Query(value = "EXEC arms_user_admin_tasks_list ", nativeQuery = true)
	public List<UserAdminTaskList> getAdminTaskList();
}
package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.CustomerCopy;

@Transactional
public interface CustomerCopyRepository extends JpaRepository<CustomerCopy, String> {

	@Query(value = "Exec arms_rpt_customer_customer_copy_TOP_v22 :strCustomerGrpCd, :strBusUnitCd,"
			+ " :strBillingPeriod, :strStatusClause, :bExclusiveAccess,:naccountStatus, :strClassClause,"
			+ ":strBillName,:strStateFilter, :strSegmentClause, :strACNACriteriaType,:strACNASubType,:strACNAValue,:strChildTieCd"
			+ " , :nRollUp", nativeQuery = true)
	public List<CustomerCopy> getCustCopyReport(@Param("strCustomerGrpCd") String strCustomerGrpCd,
			@Param("strBusUnitCd") String strBusUnitCd, @Param("strBillingPeriod") String strBillingPeriod,
			@Param("strStatusClause") String strStatusClause, @Param("bExclusiveAccess") Integer bExclusiveAccess,
			@Param("naccountStatus") Integer naccountStatus, @Param("strClassClause") String strClassClause,
			@Param("strBillName") String strBillName, @Param("strStateFilter") String strStateFilter,
			@Param("strSegmentClause") String strSegmentClause,
			@Param("strACNACriteriaType") String strACNACriteriaType, @Param("strACNASubType") String strACNASubType,
			@Param("strACNAValue") String strACNAValue, @Param("strChildTieCd") String strChildTieCd,
			@Param("nRollUp") Integer rollupFlag);
	

}

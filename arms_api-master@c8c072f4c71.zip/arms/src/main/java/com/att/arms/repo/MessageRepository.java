package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.Message;

@Transactional
public interface MessageRepository extends JpaRepository<Message, String> {

	@Query(value = "Exec arms_main_menu_message ", nativeQuery = true)
	public List<Message> fetchMessage();

	@Modifying
	@Query(value = "Exec arms_maintainance_modify_main_menu_message :the_msg", nativeQuery = true)
	public void modifyMenuMsg(@Param("the_msg") String msg);
	
}

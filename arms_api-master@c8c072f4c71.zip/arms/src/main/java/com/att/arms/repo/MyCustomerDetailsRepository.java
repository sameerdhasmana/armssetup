package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.MyCustomerDetails;
@Transactional
public interface MyCustomerDetailsRepository extends JpaRepository<MyCustomerDetails, String> {


	@Query(value = "EXEC arms_custqry_customer_query_for_lb_excl_personal_v22 :group ,:region, :billingPeriod, :userLoginCode, :strVal", nativeQuery = true)
	public List<MyCustomerDetails> getCustomerDetailsPersonal(@Param("group") String group,
			@Param("region") String region, @Param("billingPeriod") String billingPeriod,
			@Param("userLoginCode") String userLoginCode, @Param("strVal") String strVal);

}

package com.att.arms.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.Data;

@Entity
@IdClass(AccountPastDueDetails.AccountPastDueDetailsId.class)
@Data
public class AccountPastDueDetails {

	@Id
	private String system;
	@Id
	private String accountNumber;
	private Integer ctc;
	private String billAddr2;
	private String billAddr3;
	private String billAddr4;
	private String billState;
	private String billCity;
	private String billZip;
	private String zbu;
	private String macna;
	private String billName;
	private String mp1;
	private String mp2;
	private String typeOfService;
	

	@SuppressWarnings("serial")
	@Data
	public static class AccountPastDueDetailsId implements Serializable {

		private String accountNumber;
		private String system;
		
	}
}

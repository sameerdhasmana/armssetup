package com.att.arms.service;

import java.util.List;
import java.util.Map;

import com.att.arms.entity.BillNameDetails;
import com.att.arms.entity.UserDetails;

public interface BillNameDetailsService {

	public List<BillNameDetails> getBillNameDetails(String group, String strVal);
	boolean validateQueryRequest(UserDetails userDetails);
	Map<Object, Object> getQueryResponse(UserDetails userDetails, Map<Object, Object> responseMap);
	Map<Object, Object> populateBillName(UserDetails userDetails, Map<Object, Object> responseMap);
	boolean validateBillNameInvoiceQueryRequest(UserDetails userDetails);
	Map<Object, Object> populateBillNameInvoiceView(UserDetails userDetails, Map<Object, Object> responseMap);
	Map<Object, Object> getBillNameSummaryDetails(UserDetails userDetails, Map<Object, Object> responseMap);
	boolean validateSummaryRequest(UserDetails userDetails);

}

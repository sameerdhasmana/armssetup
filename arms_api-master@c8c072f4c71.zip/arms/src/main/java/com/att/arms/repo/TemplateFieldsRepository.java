package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.arms.entity.TemplateFieldsDetails;

@Transactional
public interface TemplateFieldsRepository extends JpaRepository<TemplateFieldsDetails, String> {

	@Query(value = "exec arms_rpt_templatefields_v20", nativeQuery = true)
	public List<TemplateFieldsDetails> findTemplateFieldsList();
}

package com.att.arms.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.arms.entity.AccountContactDetails;

@Transactional
public interface AccountContactDetailsRepository extends JpaRepository<AccountContactDetails, String> {

	@Query(value = "exec arms_acct_contact_fetch_v22 :userloginCd,:accountNumber,:originatingSystem", nativeQuery = true)
	public List<AccountContactDetails> getAccountContactDetailsList(@Param("userloginCd") String userloginCd,
			@Param("accountNumber") String accountNumber, @Param("originatingSystem") String originatingSystem);

}

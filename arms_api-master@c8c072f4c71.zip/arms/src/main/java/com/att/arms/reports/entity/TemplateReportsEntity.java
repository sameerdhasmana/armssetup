package com.att.arms.reports.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Data
public class TemplateReportsEntity {
	@Id
	@JsonProperty("Account Number")
	@Column(name="v_bias_cabs_combo_v20.acct_nbr")
	private String accountNumber;
	@JsonProperty("Originating System")
	@Column(name="v_bias_cabs_combo_v20.originating_system")
	private String originatingSystem;
	@JsonProperty("Past Due")
	@Column(name="v_bias_cabs_combo_v20.past_due_pmt_trm")
	private Double pastDue;
	@JsonProperty("Total Due")
	@Column(name="v_bias_cabs_combo_v20.total_amt")
	private Double totalDue;
	@JsonProperty("30+ Amount")
	@Column(name="v_bias_cabs_combo_v20.past_due_amt")
	private Double thirtyPlusAmt;
	@JsonProperty("60+ Amount")
	@Column(name="v_bias_cabs_combo_v20.plus_60_amt")
	private Double sixtyPlusAmt;
	@JsonProperty("Collectable PD")
	@Column(name="v_bias_cabs_combo_v20.collectable_pd")
	private Double collectablePd;
	@JsonProperty("Collectable Total")
	@Column(name="v_bias_cabs_combo_v20.collectable")
	private Double collectableTotal;
	@JsonProperty("Dispute Amount")
	@Column(name="TXT131_CLAIM_ACCT_SUM.CLAIMED_AMT")
	private Double disputeAmt;
	
}

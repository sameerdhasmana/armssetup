package com.att.arms.arms;

/*import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;*/

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.arms.entity.CustomerAgedDetails;
import com.att.arms.repo.CustomerAgedDetailsRepository;
import com.att.arms.service.AgedDetailsServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
class ArmsApplicationTests {

	/*
	 * @Test void contextLoads() { }
	 */
	@MockBean
	private CustomerAgedDetailsRepository customerAgedDetailsRepository;

	@Autowired
	private AgedDetailsServiceImpl agedDetailsService;

	@Test
	void getCustomerAgedDetails_success() {
		CustomerAgedDetails customerAgedDetails = new CustomerAgedDetails();
		List<CustomerAgedDetails> customerAgedDetailsList = new ArrayList<>();

		customerAgedDetails.setAccountNumber("");
		customerAgedDetails.setSeg("");
		customerAgedDetails.setCheckDigit("");
		customerAgedDetails.setAcna("");
		customerAgedDetails.setAecn("");
		customerAgedDetails.setOcn("");
		customerAgedDetails.setStatus("");
		customerAgedDetails.setCurrentBillingAmt(0.0);
		customerAgedDetails.setCurrentBalanceAmt(0.0);
		customerAgedDetails.setPastDueAmt(0.0);
		customerAgedDetails.setDisputeAmt(0.0);
		customerAgedDetails.setCollectable(0.0);
		customerAgedDetails.setBillDate(new Date());
		customerAgedDetails.setFinalBillDate(new Date());
		customerAgedDetails.setWriteOffDate(new Date());
		customerAgedDetails.setLastPaymentDate(new Date());
		customerAgedDetails.setLastPaymentAmt(0.0);
		customerAgedDetails.setPaymentAppliedAmt(0.0);
		customerAgedDetails.setLastAdjustmentDate(new Date());
		customerAgedDetails.setLastAdjustmentAmt(0.0);
		customerAgedDetails.setAdjustmentAppliedAmt(0.0);
		customerAgedDetails.setTotalNdAmt(0.0);
		customerAgedDetails.setPastDue30Amt(0.0);
		customerAgedDetails.setPastDue60Amt(0.0);
		customerAgedDetails.setPastDue90Amt(0.0);
		customerAgedDetails.setPastDue120Amt(0.0);
		customerAgedDetails.setApSubGrpNm("");
		customerAgedDetails.setCustomerGrpCd("");
		customerAgedDetails.setStateCd("");
		customerAgedDetails.setTotalAmt(0.0);
		customerAgedDetails.setClassCd(0);
		customerAgedDetails.setBillingPeriodStopCopyForward("");
		customerAgedDetails.setClassDesc("");
		customerAgedDetails.setExcluded(0);
		customerAgedDetails.setNotesExists(0);
		customerAgedDetails.setBillingPeriod("");
		customerAgedDetails.setCustomerLegalNm("");
		customerAgedDetails.setOriginatingSystem("");
		customerAgedDetails.setBillName("");
		customerAgedDetails.setRegion("");
		customerAgedDetails.setMacnaCd("");
		customerAgedDetails.setZbu("");
		customerAgedDetails.setPromoCr(0.0);
		customerAgedDetails.setLastDtWorked(new Date());
		customerAgedDetails.setCollectionsUserid("");
		customerAgedDetails.setPaymentTerms("");
		customerAgedDetails.setEmailOrMail("");
		customerAgedDetails.setMailMergeEligible("");
		customerAgedDetails.setInvoiceBilled("");
		customerAgedDetails.setAge030(0);
		customerAgedDetails.setAge3160(0);
		customerAgedDetails.setAge6190(0);
		customerAgedDetails.setAge91120(0);
		customerAgedDetails.setSubActivityCd("");
		customerAgedDetails.setNextcall(new Date());
		customerAgedDetails.setFlagAge(0);
		customerAgedDetails.setFlagActivity("");
		customerAgedDetails.setFlagActivityDate(new Date());
		customerAgedDetails.setCustomerName("");
		customerAgedDetails.setBillNameCx("");
		customerAgedDetails.setBillAddress2("");
		customerAgedDetails.setBillAddress3("");
		customerAgedDetails.setBillAddress4("");
		customerAgedDetails.setBillCity("");
		customerAgedDetails.setBillState("");
		customerAgedDetails.setBillZip("");
		customerAgedDetails.setContactName("");
		customerAgedDetails.setContactTn("");
		customerAgedDetails.setContactEmail("");
		customerAgedDetails.setAmt60(0.0);
		customerAgedDetails.setAmt90(0.0);
		customerAgedDetails.setUnappliedAmt(0.0);
		customerAgedDetails.setCtc("");
		customerAgedDetails.setSvid("");
		customerAgedDetails.setSvidName("");
		customerAgedDetails.setNextAction("");
		customerAgedDetails.setEmaor("");
		customerAgedDetails.setEmaorEffDt(new Date());
		customerAgedDetails.setEmaorCnt(0);
		customerAgedDetails.setBillerStatus("");
		customerAgedDetails.setHotNote("");
		customerAgedDetails.setAvgAge(0);
		customerAgedDetails.setCommitmentAmt(0.0);
		customerAgedDetails.setContestedCharges(0.0);
		customerAgedDetails.setRootCause("");
		customerAgedDetails.setCollectablePd(0.0);
		customerAgedDetails.setPastDue(0.0);

		customerAgedDetailsList.add(customerAgedDetails);

		when(customerAgedDetailsRepository.getCustomerAgedDetails("", "", "", "", "", "", "", "", "", "", "", "", "",
				"", "", "", "")).thenReturn(customerAgedDetailsList);

		List<CustomerAgedDetails> fetchCustomerAgedDetails = agedDetailsService.getCustomerAgedDetails("", "", "", "",
				"", "", "", "", "", "", "", "", "", "", "", "", "");
		assertEquals(1, fetchCustomerAgedDetails.size());
		verify(customerAgedDetailsRepository, times(1)).getCustomerAgedDetails("", "", "", "", "", "", "", "", "", "",
				"", "", "", "", "", "", "");
	}

}

export class PastDueDetails {

  system: any;
  accountNumber: any;
  ctc: any;
  billAddr2: any;
  billAddr3: any;
  billAddr4: any;
  billState: any;
  billCity: any;
  billZip: any;
  zbu: any;
  macna: any;
  billName: any;
  mp1: any;
  mp2: any;
  typeOfService:  any;
}

export class FilterSelection {

  billingPeriod : any;
  businessGroups : any;
  originatingSystems : any;
  segmentList :any;
  exclusions :any;
  exclusionsClass :any;




}

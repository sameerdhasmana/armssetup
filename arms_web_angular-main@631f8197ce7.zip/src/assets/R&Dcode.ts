filterExcluding4(params:any) {
  console.log(params);
  let column = params.column.colDef.field;
  let filterKey = params.value;

  let currentFilterValues = this.gridApi
  .getFilterInstance(column)
  .getValues();
  console.log(currentFilterValues);

  let newFilterValues = currentFilterValues.filter(
    (column:any) => column !== filterKey
  );
  console.log(newFilterValues);


  let hardcodedFilter:any={};
  hardcodedFilter[column]={
    type: 'set',
    values: newFilterValues,
  }
  console.log(hardcodedFilter);

  this.gridApi.setFilterModel(hardcodedFilter);
}


filterExcluding3(params:any) {
  console.log(params);
  let column = params.column.colDef.field;
  let filterKey = params.value;
  let hardcodedFilter:any={};
  hardcodedFilter[column]={
    type: 'set',
    values: [filterKey],
  }
  this.gridApi.setFilterModel(hardcodedFilter);
}

filterExcluding2(params:any){
  console.log(params);
  let column = params.column.colDef.field;
  let filterKey = params.value;
  debugger
  let currentFilterValues = this.gridApi
    .getFilterInstance(column)
    .getValues();
    console.log(currentFilterValues);

    let newFilterValues = currentFilterValues.filter(
      (column:any) => column !== filterKey
    );
    console.log(newFilterValues);
    this.gridApi.setFilterModel({
      column: { filter: 'set', values: newFilterValues },
    });

  //this.gridApi.onFilterChanged();
}

filterExcluding1(params:any){
  console.log(params);
  let column = params.column.colDef.field;
  let filterKey = params.value;
  debugger
  let excludeFilterComponent = this.gridApi.getFilterInstance(column)!;
  excludeFilterComponent.setModel({
  filterModels: [
  {
  type: 'notContains',
  filter: filterKey,
  },
  ],
  });
  this.gridApi.onFilterChanged();
  }




  else if (this.selectedBtn == 'internalContacts') {
    result = [
      'copy',

      {
        name: 'Export to Excel',
        action: () => {
          this.exportAsExcel()
        }
      },

      {
        name: 'Switch to Default Layout',
        action: () => {
          this.agedDetail();
          this.selectedBtn = 'agedDetail';
          //this.agedDetailOff();
        },
      },
      // {
      //   name: 'Right to left Reading order',
      //   action: () => {
      //     this.redirectToInProgress();
      //   },
      // },
      // {
      //   name: 'Show Unicode control characters',
      //   action: () => {
      //     this.redirectToInProgress();
      //   },
      // },
      // {
      //   name: 'Insert Unicode control character',
      //   action: () => {
      //     this.redirectToInProgress();
      //   },
      // }
    ]
  }
  else if (this.selectedBtn == 'emaorView') {
    result = [
      'copy',

      {
        name: 'Export to Excel',
        action: () => {
          this.exportAsExcel()
        }
      },

      // {
      //   name: 'Find',
      //   action: () => {
      //     this.redirectToInProgress();
      //   },
      // },
      {
        name: 'Switch to Default Layout',
        action: () => {
          this.agedDetail();
          this.selectedBtn = 'agedDetail';
          //this.agedDetailOff();
        },
      }
    ];
  }

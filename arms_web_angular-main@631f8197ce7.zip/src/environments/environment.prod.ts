export const environment = {
  production: true,
  baseUrl : 'https://arms-az.dev.att.com/api/',
  //baseUrl : 'https://localhost/api/',
  //baseUrl : 'http://localhost:8080/api/',
  tokenUrl : 'https://arms-az.dev.att.com/',
  //tokenUrl : 'https://localhost/'
  //tokenUrl : 'http://localhost:8080/'

};

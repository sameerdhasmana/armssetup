import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { ProfileService } from '../services/profile.service';
import { SharedService } from '../services/shared.service';

@Component({
  selector: 'app-manage-profiles',
  templateUrl: './manage-profiles.component.html',
  styleUrls: ['./manage-profiles.component.scss']
})
export class ManageProfilesComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true
  }
  columnDefs: any;
  pageSize: number = 1000;
  rowData: any;
  currRowData: any;
  gridApi: any;
  columnDefsUserInfo: ColDef[] = [
    {
      headerName: 'USER ID', field: 'user_id',
      headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true
    },
    { headerName: 'Last Name', field: 'last_name' },
    { headerName: 'First Name', field: 'first_name' },
    { headerName: 'S1 L Name', field: 's1_l_name' },
    { headerName: 'S1 F Name', field: 's1_f_name' },
    { headerName: 'S2 L Name', field: 's2_l_name' },
    { headerName: 'S2 F Name', field: 's2_f_name' }
  ];

  SelectProfile: any;
  ProfileName: any;
  selectedItem: any = {
    acna_cd: "", aecn_cd: "", customer_grp_cd: "", customer_grp_child_cd: "",
    customer_legal_nm: "", excludedAccountsExists: "", ocn_cd: ""
  };
  filteredItems: any[] = [];
  filters: any = {};
  Customer: any;
  Exclusions: any;
  ExclusionClass: any;
  OriginatingSystem: any;
  BusinessGroups: any;
  Segment: any;
  BillingPeriod: any;
  BringUpDate: any;
  FlagActivity: any;
  FlagActivityDate: any;
  r1SortOrder: any;
  r2SortOrder: any;
  r3SortOrder: any;
  r4SortOrder: any;
  r5SortOrder: any;
  BringUpType: any;
  AMTOptions: any;
  Operator: any;
  o1Operator: string = "<="
  o2Operator: string = ">="
  OperatorValue: any;
  DisputedAMT: any;
  ContestedAMT: any;
  UnappliedAMT: any;
  UnappliedValue: any;
  Filters: any = {};
  profileDetailsFilter: any = {};

  radioList = [
    { "name": "Customer", "value": "cust" },
    { "name": "ACNA", "value": "acna" },
    { "name": "OCN", "value": "ocn" },
    { "name": "CTC", "value": "ctc" },
    { "name": "AECN", "value": "aecn" }
  ]

  AAORadioList = [
    { "name": "N", "value": "N" },
    { "name": "Y", "value": "Y" }
  ]
  r1SortOrderList = [
    { "name": "Asc", "value": "ASC" },
    { "name": "Dsc", "value": "DSC" }
  ]
  r2SortOrderList = [
    { "name": "Asc", "value": "ASC" },
    { "name": "Dsc", "value": "DSC" }
  ]
  r3SortOrderList = [
    { "name": "Asc", "value": "ASC" },
    { "name": "Dsc", "value": "DSC" }
  ]
  r4SortOrderList = [
    { "name": "Asc", "value": "ASC" },
    { "name": "Dsc", "value": "DSC" }
  ]
  r5SortOrderList = [
    { "name": "Asc", "value": "ASC" },
    { "name": "Dsc", "value": "DSC" }
  ]

  selectedRadio = this.radioList[0].value;
  selectedAAORadio = this.AAORadioList[1].value;
  selectedR1Radio = this.r1SortOrderList[0].value;
  selectedR2Radio = this.r2SortOrderList[0].value;
  selectedR3Radio = this.r3SortOrderList[0].value;
  selectedR4Radio = this.r4SortOrderList[0].value;
  selectedR5Radio = this.r5SortOrderList[0].value;

  form: any = new FormGroup({
    SelectProfile: new FormControl(),
    ProfileName: new FormControl(),
    CenterProfile: new FormControl(),
    filterItems: new FormControl(),
    customersearchtype: new FormControl(),
    RollUpToParent: new FormControl(),
    Customer: new FormControl(),
    Exclusions: new FormControl({ value: "Included Accounts" }),
    ExclusionClass: new FormControl(),
    OriginatingSystem: new FormControl(),
    BusinessGroups: new FormControl(),
    Segment: new FormControl(),
    BillingPeriod: new FormControl(),
    Final: new FormControl(),
    Live: new FormControl(),
    WrOff: new FormControl(),
    BringUpDate: new FormControl(),
    FlagActivity: new FormControl(),
    FlagActivityDate: new FormControl({ value: "0" }),
    AAORadio: new FormControl(),
    r1SortOrder: new FormControl(),
    r2SortOrder: new FormControl(),
    r3SortOrder: new FormControl(),
    r4SortOrder: new FormControl(),
    r5SortOrder: new FormControl(),
    r1SortOrderRadio: new FormControl(),
    r2SortOrderRadio: new FormControl(),
    r3SortOrderRadio: new FormControl(),
    r4SortOrderRadio: new FormControl(),
    r5SortOrderRadio: new FormControl(),
    BringUpType: new FormControl(),
    AMTOptions: new FormControl(),
    Operator: new FormControl(),
    OperatorValue: new FormControl({ value: 0.00 }),
    DisputedAMT: new FormControl(),
    ContestedAMT: new FormControl(),
    UnappliedAMT: new FormControl(),
    UnappliedValue: new FormControl({ value: 0.00 })
  });

  constructor(
    private profileService: ProfileService,
    private toastr: ToastrService,
    private sharedService: SharedService
  ) {
    this.Filters.exclusionClass = [];
    this.Filters.billingPeriod = [];
    this.Filters.sortOrder = [];
    this.Filters.customerGroupList = [];
    this.Filters.AllUsers = [];
    this.Filters.originatingSystemList = [];
    this.Filters.flagActivity = [];
    this.Filters.Segment = [];
    this.Filters.profileDetails = [];
    this.profileDetailsFilter.profileDetails = [];
    this.form.controls['Final'].setValue(true);
    this.form.controls['Live'].setValue(true);
    this.Exclusions = "Included Accounts";
    this.BringUpType = "NA";
    this.AMTOptions = "NA";
    this.Operator = "NA";
    this.DisputedAMT = "NA";
    this.ContestedAMT = "NA";
    this.UnappliedAMT = "NA";
    this.FlagActivityDate = "0";
    this.OperatorValue = 0.00;
    this.UnappliedValue = 0.00;
    this.profileService.renderManageProfile().subscribe((data: any) => {
      //console.log(data);
      this.Filters = data;
      this.columnDefs = this.columnDefsUserInfo;
      this.rowData = data.AllUsers;
    },
      (error: any) => {
        console.log(error);
      });
    this.profileService.populateProfileDetails().subscribe((data: any) => {
      this.profileDetailsFilter = data;
    },
      (error: any) => {
        console.log(error);
      });
  }

  ngOnInit(): void {
  }

  filterData: any = {};
  filterItems() {
    this.filterData.queryType = this.selectedRadio
    this.filterData.groupSelected = this.form.value.BusinessGroups == "" || this.form.value.BusinessGroups == null || this.form.value.BusinessGroups == undefined ? [] : this.form.value.BusinessGroups
    this.filterData.enteredValue = this.selectedItem;
    this.filterData.originatingSystem = this.form.value.OriginatingSystem == "" || this.form.value.OriginatingSystem == null || this.form.value.OriginatingSystem == undefined ? [] : this.form.value.OriginatingSystem
    //console.log(this.filterData);
    this.profileService.populateProfileCustomers(this.filterData).subscribe((data: any) => {
      this.filteredItems = data.CustomerInfo
    },
      (failure: any) => {
        this.filteredItems = [];
      });
  }

  onCustomerKeyDown() {
    return false;
  }

  onSelect() {
    this.Customer = this.selectedItem.customer_legal_nm
  }

  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
    Please wait while your Data is loading
    </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
     border: 2px solid #444;
     background: lightgoldenrodyellow;">
     No Data Found in the System
     </span>`;

  searchValue: any;
  quickSearch() {
    this.gridApi.setQuickFilter(this.searchValue);
  }

  validateSave() {
    let msg = "";
    if (this.ProfileName == null || this.ProfileName == undefined || this.ProfileName == "") {
      msg += "Profile name can not be empty" + "\n"
    }
    if (this.Customer == null || this.Customer == undefined || this.Customer == "") {
      msg += "No Customer selected" + "\n"
    }
    return msg;
  }

  inpData: any = {};
  Save() {
    let msg = this.validateSave();
    if (msg != "") {
      this.toastr.error('', msg, {
        timeOut: 5000, closeButton: true
      });
    }
    else {
      this.inpData.profileType = this.form.controls['CenterProfile'].value == true ? "C" : "U";
      this.inpData.profileName = this.ProfileName == null || this.ProfileName == undefined ? "" : this.ProfileName
      this.inpData.profileOwner = this.profileOwner === "" ? "" : this.profileOwner;
      this.inpData.queryType = this.selectedRadio;
      this.inpData.customerGrpCd = this.selectedItem.customer_grp_cd == null || this.selectedItem.customer_grp_cd == undefined ? "" : this.selectedItem.customer_grp_cd;
      this.inpData.queryAcna = this.selectedItem.acna_cd == null || this.selectedItem.acna_cd == undefined ? "" : this.selectedItem.acna_cd;
      this.inpData.queryAecn = this.selectedItem.aecn_cd == null || this.selectedItem.aecn_cd == undefined ? "" : this.selectedItem.aecn_cd;
      this.inpData.queryOcn = this.selectedItem.ocn_cd == null || this.selectedItem.ocn_cd == undefined ? "" : this.selectedItem.ocn_cd;
      this.inpData.queryCtc = this.selectedItem.customer_grp_child_cd == null || this.selectedItem.customer_grp_child_cd == undefined ? "" : this.selectedItem.customer_grp_child_cd;
      this.inpData.queryBillName = "";
      this.inpData.exclusions = this.form.controls['Exclusions'].value == null || this.form.controls['Exclusions'].value == undefined ? "" : this.form.controls['Exclusions'].value;
      this.inpData.exclusionClass = this.form.value.ExclusionClass == "" || this.form.value.ExclusionClass == null || this.form.value.ExclusionClass == undefined ? [] : this.form.value.ExclusionClass;
      this.inpData.originatingSystem = this.form.value.OriginatingSystem == "" || this.form.value.OriginatingSystem == null || this.form.value.OriginatingSystem == undefined ? [] : this.form.value.OriginatingSystem;
      this.inpData.groupSelected = this.form.value.BusinessGroups == "" || this.form.value.BusinessGroups == null || this.form.value.BusinessGroups == undefined ? [] : this.form.value.BusinessGroups;
      let statusClause = [];
      if (this.form.controls['Final'].value == true) {
        statusClause.push('Final');
      }
      if (this.form.controls['Live'].value == true) {
        statusClause.push('Live');
      }
      if (this.form.controls['WrOff'].value == true) {
        statusClause.push('WR-OFF');
      }
      this.inpData.statusClause = statusClause;
      this.inpData.segment = this.form.value.Segment == "" || this.form.value.Segment == null || this.form.value.Segment == undefined ? [] : this.form.value.Segment;
      this.inpData.rollUptoParent = this.form.controls['RollUpToParent'].value == true ? "1" : "0";
      this.inpData.bringUpDateRef = this.form.controls['BringUpDate'].value == null || this.form.controls['BringUpDate'].value == undefined ? "" : this.form.controls['BringUpDate'].value;
      this.inpData.bringUpType = this.form.controls['BringUpType'].value == null || this.form.controls['BringUpType'].value == undefined ? "" : this.form.controls['BringUpType'].value;
      this.inpData.flagActivity = this.form.value.FlagActivity == "" || this.form.value.FlagActivity == null || this.form.value.FlagActivity == undefined ? [] : this.form.value.FlagActivity;
      if (this.form.value.FlagActivity == "" || this.form.value.FlagActivity == null || this.form.value.FlagActivity == undefined) {
        this.inpData.flagActivityDesc = [];
      }
      else {
        let flagActivityArr = [];
        for (let i = 0; i < this.inpData.flagActivity.length; i++) {
          flagActivityArr.push(
            (this.Filters.flagActivity.find((e: any) => {
              if (e.sub_activity_cd === this.inpData.flagActivity[i]) {
                return e.sub_activity_short_description;
              }
            })).sub_activity_short_description
          );
        }
        this.inpData.flagActivityDesc = flagActivityArr;
      }
      this.inpData.flagDateRef = this.FlagActivityDate == null || this.FlagActivityDate == undefined ? "" : this.FlagActivityDate;
      this.inpData.amountType = this.AMTOptions == null || this.AMTOptions == undefined ? "" : this.AMTOptions;
      this.inpData.amountOperator = this.Operator == null || this.Operator == undefined ? "" : this.Operator;
      this.inpData.amountValue = this.OperatorValue == null || this.OperatorValue == undefined ? 0 : this.OperatorValue;
      this.inpData.disputedAmountRef = this.DisputedAMT == null || this.DisputedAMT == undefined ? "" : this.DisputedAMT;
      this.inpData.contestedAmountRef = this.ContestedAMT == null || this.ContestedAMT == undefined ? "" : this.ContestedAMT;
      this.inpData.unappliedAmtOperator = this.UnappliedAMT == null || this.UnappliedAMT == undefined ? "" : this.UnappliedAMT;
      this.inpData.unappliedAmtValue = this.UnappliedValue == null || this.UnappliedValue == undefined ? 0 : this.UnappliedValue;
      this.inpData.userAssignmentInd = this.selectedAAORadio;
      this.inpData.sort1Field = this.r1SortOrder == null || this.r1SortOrder == undefined ? "" : this.r1SortOrder;
      this.inpData.sort1Order = this.selectedR1Radio;
      this.inpData.sort2Field = this.r2SortOrder == null || this.r2SortOrder == undefined ? "" : this.r2SortOrder;
      this.inpData.sort2Order = this.selectedR2Radio;
      this.inpData.sort3Field = this.r3SortOrder == null || this.r3SortOrder == undefined ? "" : this.r3SortOrder;
      this.inpData.sort3Order = this.selectedR3Radio;
      this.inpData.sort4Field = this.r4SortOrder == null || this.r4SortOrder == undefined ? "" : this.r4SortOrder;
      this.inpData.sort4Order = this.selectedR4Radio;
      this.inpData.sort5Field = this.r5SortOrder == null || this.r5SortOrder == undefined ? "" : this.r5SortOrder;
      this.inpData.sort5Order = this.selectedR5Radio;
      let loginsArr = [];
      let selectedNodes = this.gridApi.getSelectedNodes();
      let selectedData = selectedNodes.map((node: any) => node.data);
      for (let i = 0; i < selectedData.length; i++) {
        loginsArr.push(selectedData[i].user_id.toString());
      }
      this.inpData.h1Logins = loginsArr;
      //console.log(this.inpData);
      this.profileService.saveProfile(this.inpData).subscribe((data: any) => {
        if (data.msg == "success") {
          this.toastr.success('', this.ProfileName + ' saved', {
            timeOut: 5000, closeButton: true
          });
          this.profileService.populateProfileDetails().subscribe((data: any) => {
            this.profileDetailsFilter = data;
            localStorage.setItem("profileDetailsFilter", JSON.stringify(data));
            this.sharedService.setpopulateProfileDetails(data);
          },
            (error: any) => {
              console.log(error);
            });
        }
        else if (data.msg == "User Role of Manager or Data Manager Required for creating or modifying Center Profiles.") {
          this.toastr.warning('', "User Role of Manager or Data Manager Required for creating or modifying Center Profiles.", {
            timeOut: 5000, closeButton: true
          });
        }
      },
        (failure: any) => {
          console.log(failure);
          this.inpData = {};
        });
    }
  }

  loadData: any = {};
  loadResponse: any = {};
  Load() {
    if (this.SelectProfile == null || this.SelectProfile == undefined || this.SelectProfile == "" || this.SelectProfile == "New") {
      this.clearFields();
    }
    else {
      this.loadData.profileName = this.SelectProfile;
      this.loadData.profileType = (this.profileDetailsFilter.profileDetails.find((e: any) => {
        if (e.profileName === this.SelectProfile) {
          return e.profileType;
        }
      })).profileType;
      //console.log(this.loadData);
      this.profileService.loadProfile(this.loadData).subscribe((data: any) => {
        this.loadResponse = data.profileDetails;
        //console.log(this.loadResponse);
        this.fillData(this.loadResponse);
      },
        (failure: any) => {
          this.loadData = {};
        });
    }
  }

  profileOwner: string = "";
  fillData(data: any) {
    this.selectedItem = {
      acna_cd: data.profileQueryAcna, aecn_cd: data.profileQueryAecn,
      customer_grp_cd: data.customerGrpCd, customer_grp_child_cd: data.profileQueryCtc,
      customer_legal_nm: data.customerLegalNm, excludedAccountsExists: "", ocn_cd: data.profileQueryOcn
    }
    // this.selectedItem.customer_grp_cd = data.customerGrpCd;
    // this.selectedItem.acna_cd = data.profileQueryAcna;
    // this.selectedItem.aecn_cd = data.profileQueryAecn;
    // this.selectedItem.ocn_cd = data.profileQueryOcn;
    // this.selectedItem.customer_grp_child_cd = data.profileQueryCtc;
    this.profileOwner = data.profileOwner;
    this.ProfileName = data.profileName;
    if (data.profileType == "C") {
      this.form.controls['CenterProfile'].setValue(true);
    }
    else {
      this.form.controls['CenterProfile'].setValue(false);
    }
    this.form.controls['customersearchtype'].setValue(data.profileQueryType.toLowerCase());
    this.Customer = data.customerLegalNm;
    this.Exclusions = data.profileExclusions;
    this.ExclusionClass = data.exclusionClass;
    this.OriginatingSystem = data.originatingSystem;
    this.BusinessGroups = data.businessGroup;
    this.Segment = data.segment;
    if (data.statusClause.length > 0) {
      for (let i = 0; i < data.statusClause.length; i++) {
        if (data.statusClause[i] === "Final") {
          this.form.controls['Final'].setValue(true);
        }
        if (data.statusClause[i] === "Live") {
          this.form.controls['Live'].setValue(true);
        }
        if (data.statusClause[i] === "WR-OFF") {
          this.form.controls['WrOff'].setValue(true);
        }
      }
    }
    if (data.rollUpToParent == 0) {
      this.form.controls['RollUpToParent'].setValue(false);
    }
    else {
      this.form.controls['RollUpToParent'].setValue(true);
    }
    this.BringUpDate = data.bringUpRef;
    this.BringUpType = data.bringUpType;
    this.FlagActivity = data.flagActivity;
    this.FlagActivityDate = data.flagDtRef;
    this.AMTOptions = data.amountOption;
    this.Operator = data.amountOperator;
    this.OperatorValue = data.amountValue;
    this.DisputedAMT = data.disputeAmtRef;
    this.ContestedAMT = data.contestedAmtRef;
    this.UnappliedAMT = data.unappliedAmtOperator;
    this.UnappliedValue = data.unappliedAmtValue;
    this.selectedAAORadio = data.userAssignmentInd;
    this.r1SortOrder = data.sort1Field;
    this.selectedR1Radio = data.sort1Order;
    this.r2SortOrder = data.sort2Field;
    this.selectedR2Radio = data.sort2Order;
    this.r3SortOrder = data.sort3Field;
    this.selectedR3Radio = data.sort3Order;
    this.r4SortOrder = data.sort4Field;
    this.selectedR4Radio = data.sort4Order;
    this.r5SortOrder = data.sort5Field;
    this.selectedR5Radio = data.sort5Order;
    let arrLen = data.h1Logins.length;
    let UidArr = data.h1Logins;
    if (UidArr.length > 0) {
      this.gridApi.forEachNode(function (node: any) {
        for (let i = 0; i < arrLen; i++) {
          if (node.data.user_id == UidArr[i]) {
            node.setSelected(node.data.user_id === UidArr[i]);
            //console.log(node.data);
          }
        }
      });
    }
    else {
      this.gridApi.forEachNode(function (node: any) {
        node.setSelected(false);
      });
    }
  }

  validateSetDefault() {
    let msg = "";
    if (this.ProfileName == null || this.ProfileName == undefined || this.ProfileName == "") {
      msg += "Please check Profile Name/Profile Selected and try again after saving the profile with new name"
    }
    return msg;
  }

  MakeDefault() {
    let msg = this.validateSetDefault();
    if (msg != "") {
      this.toastr.error('', msg, {
        timeOut: 5000, closeButton: true
      });
    }
    else {
      let makeDefData: any = {};
      makeDefData.profileName = this.SelectProfile;
      makeDefData.profileType = (this.profileDetailsFilter.profileDetails.find((e: any) => {
        if (e.profileName === this.SelectProfile) {
          return e.profileType;
        }
      })).profileType;
      //console.log(this.loadData);
      this.profileService.setDefaultProfile(makeDefData).subscribe((data: any) => {
        if (data.msg == "success") {
          this.toastr.success('', this.ProfileName + ' is set as default', {
            timeOut: 5000, closeButton: true
          });
        }
      },
        (failure: any) => {
          console.log(failure);
        });
    }
  }

  validateDelete() {
    let msg = "";
    if (this.ProfileName == null || this.ProfileName == undefined || this.ProfileName == "") {
      msg += "Please check Profile Name/Profile Selected you want to delete and try again"
    }
    return msg;
  }

  DeleteProfile() {
    let msg = this.validateDelete();
    if (msg != "") {
      this.toastr.error('', msg, {
        timeOut: 5000, closeButton: true
      });
    }
    else {
      let deleteData: any = {};
      deleteData.profileName = this.SelectProfile;
      deleteData.profileType = (this.profileDetailsFilter.profileDetails.find((e: any) => {
        if (e.profileName === this.SelectProfile) {
          return e.profileType;
        }
      })).profileType;
      this.profileService.deleteProfile(deleteData).subscribe((data: any) => {
        if (data.msg == "success") {
          this.toastr.success('', this.ProfileName + ' has been deleted', {
            timeOut: 5000, closeButton: true
          });
          this.clearFields();
          this.profileService.populateProfileDetails().subscribe((data: any) => {
            this.profileDetailsFilter = data;
          },
            (error: any) => {
              console.log(error);
            });
        }
      },
        (failure: any) => {
          console.log(failure);
        });
    }
  }

  clearFields() {
    this.profileService.renderManageProfile().subscribe((data: any) => {
      this.columnDefs = this.columnDefsUserInfo;
      this.rowData = data.AllUsers;
    },
      (error: any) => {
        console.log(error);
      });
    this.profileOwner = "";
    this.form.controls['Final'].setValue(true);
    this.form.controls['Live'].setValue(true);
    this.form.controls['WrOff'].setValue(false);
    this.Exclusions = "Included Accounts";
    this.BringUpType = "NA";
    this.AMTOptions = "NA";
    this.Operator = "NA";
    this.DisputedAMT = "NA";
    this.ContestedAMT = "NA";
    this.UnappliedAMT = "NA";
    this.FlagActivityDate = "0";
    this.OperatorValue = 0.00;
    this.UnappliedValue = 0.00;
    this.profileOwner = "";
    this.ProfileName = "";
    this.selectedItem = {
      acna_cd: "", aecn_cd: "", customer_grp_cd: "", customer_grp_child_cd: "",
      customer_legal_nm: "", excludedAccountsExists: "", ocn_cd: ""
    };
    this.form.controls['CenterProfile'].setValue(false);
    this.form.controls['customersearchtype'].setValue('cust');
    this.Customer = "";
    this.ExclusionClass = "";
    this.OriginatingSystem = "";
    this.BusinessGroups = "";
    this.Segment = "";
    this.form.controls['RollUpToParent'].setValue(false);
    this.BringUpDate = "";
    this.FlagActivity = "";
    this.selectedAAORadio = "Y";
    this.r1SortOrder = "";
    this.selectedR1Radio = "ASC";
    this.r2SortOrder = "";
    this.selectedR2Radio = "ASC";
    this.r3SortOrder = "";
    this.selectedR3Radio = "ASC";
    this.r4SortOrder = "";
    this.selectedR4Radio = "ASC";
    this.r5SortOrder = "";
    this.selectedR5Radio = "ASC";

  }

  onCustomerTypeChange() {
    this.selectedItem = {
      acna_cd: "", aecn_cd: "", customer_grp_cd: "", customer_grp_child_cd: "",
      customer_legal_nm: "", excludedAccountsExists: "", ocn_cd: ""
    };
    this.Customer = "";
  }

}

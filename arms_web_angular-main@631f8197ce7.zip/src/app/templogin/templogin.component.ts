import {ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FiltersApiService } from '../services/filters-api.service';
import { NgxSpinnerService } from "ngx-spinner";
import { SharedService } from '../services/shared.service';
import { ProfileService } from '../services/profile.service';
import { AuthService } from '../services/auth.service';


@Component({
  selector: 'app-templogin',
  templateUrl: './templogin.component.html',
  styleUrls: ['./templogin.component.scss'],
})
export class TemploginComponent implements OnInit {




  loginData:any={};



  constructor(private cd: ChangeDetectorRef,
    private _filtersApiService: FiltersApiService, private _sharedService:SharedService,
    private router:Router,private route: ActivatedRoute,private loginSpinner : NgxSpinnerService,
    private profileService: ProfileService,
    private authService: AuthService) {
    this.loginData.userLoginCd= '';
    this.loginData.appName = 'ARMS Application';
    this.loginData.environment = 'Production';

    // this.loginData.userPcName = 'ILCDTDTB2GH9-01';
    // this.loginData.userPcLoginId = 'rr918t';
    // this.loginData.userPcIp='135.22.122.145';
    // this.loginData.globalLogonResponseCd='0';
  }
  async onFormSubmit() {
    this._filtersApiService.getFilters(this.loginData).subscribe((data:any)=>{
      //alert(12)
    //  console.log(data);
     // this._filtersApiService.subject.next(data);
      localStorage.setItem("userInfo",JSON.stringify(data))
      localStorage.setItem("envir",'')

      this.profileService.populateProfileDetails().subscribe((data: any) => {
        localStorage.setItem("profileDetailsFilter",JSON.stringify(data))
        this.router.navigate(['/query']);
        this._sharedService.onLoginComplete();
      },
        (error: any) => {
          console.log(error);
        });


   });

  // console.log(this.loginData);

  }
  reset() {
    this.loginData.userLoginCd = '';
  }

  private readonly token = 'token';

  ngOnInit() {

//    this.loginSpinner.show();
    this.route.queryParams.subscribe(async (params: any) => {
      this.loginData.userLoginCd = params.userLoginCd;
      // alert(params.userLoginCd);
      // this.onFormSubmit();
      this._filtersApiService
        .getToken({
          username: 'arms@6450',
          password: 'arms@6450@#!',
        })
        .subscribe((data: any) => {
          localStorage.setItem(this.token, data.token);
          localStorage.setItem('stTime', Date());
          localStorage.setItem('napTime', data.expDate);
          // setTimeout(() => {
          //   this.loginSpinner.hide();
          // }, 2000);
          this.onFormSubmit();
        });
    });
    setInterval(() => {
      this.autoLogout();
    }, 60000);
  }
  autoLogout() {
    console.log('Hi' + Date());
    if (this.authService.isLoggedIn()) {
      if (localStorage['token'] && localStorage['napTime']) {
        let loginTime = new Date(localStorage['stTime']);
        let validTo = new Date(localStorage['napTime']);
        //let diff  = (validTo - loginTime)
        let diff: number = +validTo - +loginTime;
        console.log(diff+"Validto-LoginTime")
        var currTime = new Date();
        var diffOfCurrentTime = +currTime - +loginTime;
        console.log(diffOfCurrentTime+"currTime-LoginTime")
        var minsRemains = Math.ceil((diff - diffOfCurrentTime) / (60 * 1000));
        console.log(minsRemains+"currTime-LoginTime")
      }
    }
  }
}

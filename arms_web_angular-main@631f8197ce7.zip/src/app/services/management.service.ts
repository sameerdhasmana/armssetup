import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ManagementService {

  baseUrl = environment.baseUrl;
  constructor(private _http: HttpClient) { }

  getAllManagers() {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "");
    return this._http.post(this.baseUrl + 'getAllManagers', { userLoginCd: userData.globalLogonUsers.user_login_cd });
  }

  outstandingBringUpReport(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'outstandingBringUpReport', data);
  }

  openFlagActivityReport(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'openFlagActivityReport', data);
  }

  renderSearchByCustomer() {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    let data: any = {};
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'renderSearchByCustomer', data);
  }

  populateSegment(data: any) {
    return this._http.post(this.baseUrl + 'populateSegment', data);
  }

  searchByAccount(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'searchByAccount', data);
  }

  searchByCustomer(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'searchByCustomer', data);
  }

  paymentTermUpdate(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'paymentTermUpdate', data);
  }
}

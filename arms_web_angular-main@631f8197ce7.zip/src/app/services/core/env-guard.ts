import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EnvGuard implements CanActivate {

  constructor(private router:Router){}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.isAuthorized(route);
  }

env:any;

  isAuthorized( route : ActivatedRouteSnapshot) : boolean {
    this.env = localStorage.getItem('envir');
    let expectedRoles = route.data['expectedEnv'];
    let isRoleMatched = expectedRoles.indexOf(this.env.toString())!== -1;
//    debugger;
    if(!isRoleMatched){
      this.router.navigate(['/preProdError401']);
    }else{
      console.log(isRoleMatched)
    }
    return isRoleMatched;

  }


}

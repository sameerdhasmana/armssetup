import { TestBed } from '@angular/core/testing';

import { EnvGuard } from './env-guard';

describe('EnvGuard', () => {
  let guard: EnvGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(EnvGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});

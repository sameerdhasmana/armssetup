import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private router:Router){}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.isAuthorized(route);
  }
userData : any;
userRoleId : any;

  isAuthorized( route : ActivatedRouteSnapshot) : boolean {
    let data = localStorage.getItem('userInfo');
    this.userData = JSON.parse(data ? data : '');
    this.userRoleId = this.userData.globalLogonUsers.userrole;
    let expectedRoles = route.data['expectedRoles'];
    let isRoleMatched = expectedRoles.indexOf(this.userRoleId.toString())!== -1;
    //debugger;
    if(!isRoleMatched){
      console.log(isRoleMatched)
      this.router.navigate(['/noRoleError401']);
    }else{
      console.log(isRoleMatched)
    }
    return isRoleMatched;

  }

}

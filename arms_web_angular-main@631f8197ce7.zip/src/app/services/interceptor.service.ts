import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor  {

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
   // console.log(req);
    let token ="Bearer "+ localStorage.getItem("token");
    let cEnv  = localStorage.getItem("envir")||"";
    const modifiedReq = req.clone({

      headers: req.headers.set('env',cEnv ).set('authorization', token),


    });
    return next.handle(modifiedReq);
  }
}



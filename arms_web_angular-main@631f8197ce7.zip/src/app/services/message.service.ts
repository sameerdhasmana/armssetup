import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class MessageMaintenanceService {

  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }

  fetchMessage(data:any){
    return this._http.post(this.baseUrl+'fetchMessage',data);
  }


  modifyMenuMsg(data:any){
    return this._http.post(this.baseUrl+'modifyMenuMsg',data);
  }
}

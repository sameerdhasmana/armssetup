import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ACNAMaintenanceService {


  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }

  acnaMaintenance(data:any){
    return this._http.post(this.baseUrl+'acnaMaintenance',data);
  }

}

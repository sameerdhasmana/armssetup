import { TestBed } from '@angular/core/testing';

import { CustomerNotesModalService } from './customer-notes-modal.service';

describe('CustomerNotesModalService', () => {
  let service: CustomerNotesModalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerNotesModalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

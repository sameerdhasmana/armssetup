import { Injectable } from "@angular/core";
import { environment } from 'src/environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class NotesActivityReportService {
    baseUrl = environment.baseUrl;

    constructor(private http: HttpClient) {}

    fetchrepUserID(data: any) {
        //console.log("Rep:" + data.managerLoginCd)
        return this.http.post(this.baseUrl+'populateH1UidDetails',data);
    }

    fetchmanagerUserID(data: any) {
        return this.http.post(this.baseUrl+'notesActivityReport',data);
    }

    fetchSubActivities(data: any) {
        return this.http.post(this.baseUrl+'populateSubActivityDesc',data);
    }

    fetchCustomers(data: any, enteredValue: string) {
        let data1 =localStorage.getItem("userInfo");
        let userData = JSON.parse(data1?data1:"");
        data.userLoginCd= userData.globalLogonUsers.user_login_cd;
        data.groupSelected= [userData.globalLogonUsers.group];
        data.region = userData.globalLogonUsers.region;
        data.billingPeriod= userData.customerBillingPeriod[0].billing_period;
        data.customerType= 0;
        data.enteredValue = enteredValue;
        return this.http.post(this.baseUrl+'populateCustomers',data);
    }

    generateReport(data: any, queryType: string, activity: any, startDate: string, endDate: string, customers: any, h1Uid: string, subActivity: any, sort: any) {
        if(queryType == "All"){
            data.queryType=queryType
            customers=[];
        }else{
            data.queryType="Not All"
        }
        
        if(activity == "R"){
            data.resolved=1;
        }else{
            data.resolved=0;
        }
        data.activityCode=[activity]
        data.startDate=startDate;
        data.endDate=endDate;
        data.customerName=customers;
        data.h1Uid=h1Uid;
        data.subactivity=subActivity;
        data.sort=sort;
        return this.http.post(this.baseUrl+'generateNotesActivityReport',data);
    }

    generateManagerReport(data: any, queryType: string, activity: any, startDate: string, endDate: string, customers: any, h1Uid: string, subActivity: any, sort: any) {
        if(queryType == "All"){
            data.queryType=queryType
            customers=[];
        }else{
            data.queryType="Not All"
        }
        
        if(activity == "R"){
            data.resolved=1;
        }else{
            data.resolved=0;
        }
        data.activityCode=[activity]
        data.startDate=startDate;
        data.endDate=endDate;
        data.customerName=customers;
        data.h1Uid=h1Uid;
        data.subactivity=subActivity;
        data.sort=sort;
        return this.http.post(this.baseUrl+'generateNotesActivityManagerReport',data);
    }

}
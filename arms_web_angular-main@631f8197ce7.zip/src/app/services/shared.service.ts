import { Injectable } from '@angular/core';
import { Subject, Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class SharedService {

  private sharedData: Subject<any> = new Subject<any>();
  sharedData$: Observable<any> = this.sharedData.asObservable();
  private filtersData: Subject<any> = new Subject<any>();
  filtersData$: Observable<any> = this.filtersData.asObservable();

  private filtersDataFromProfile: Subject<any> = new Subject<any>();
  filtersDataFromProfile$: Observable<any> = this.filtersDataFromProfile.asObservable();

  private populateProfileDetails: Subject<any> = new Subject<any>();
  populateProfileDetails$: Observable<any> = this.populateProfileDetails.asObservable();

  private CheckIfFromHeader: Subject<any> = new Subject<any>();
  CheckIfFromHeader$: Observable<any> = this.CheckIfFromHeader.asObservable();

  private onLogin: Subject<any> = new BehaviorSubject<boolean>(false);
  onLogin$: Observable<any> = this.onLogin.asObservable();

  // Observable for AIF Modal Data to share with the Filter Component
  private aifModalData: Subject<any> = new Subject<any>();
  aifModalData$: Observable<any> = this.aifModalData.asObservable();

  // Sharing the Data between the components WHen the user Changes the tabs between in tabs components
  // data passing to the Customer Auto Search Components

  setSelectedTab(newActivetab:any){
    this.sharedData.next(newActivetab);

  }

  setfilterData(filter:any){
    this.filtersData.next(filter);

  }
  
  setfilterDataFromProfile(filter:any){
    this.filtersDataFromProfile.next(filter);

  }

setpopulateProfileDetails(filter:any){
  this.populateProfileDetails.next(filter);

}

setCheckIfFromHeader(filter:any){
  this.CheckIfFromHeader.next(filter);

}

  onLoginComplete(){
    this.onLogin.next(true);
  }

  // Method for AIF Modal Data to share with the Filters Component
  setModalData(modal:any){
    this.aifModalData.next(modal);
  }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class SegmentMaintenanceService {


  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }

  fetchSegmentMaintenance(data:any){
    return this._http.post(this.baseUrl+'fetchSegmentMaintenance',data);
  }

  crudSegmentMaintenance(data:any){
    return this._http.post(this.baseUrl+'segmentUpdate',data);
  }

}

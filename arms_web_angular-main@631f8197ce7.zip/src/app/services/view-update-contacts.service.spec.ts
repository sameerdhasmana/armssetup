import { TestBed } from '@angular/core/testing';

import { ViewUpdateContactsService } from './view-update-contacts.service';

describe('ViewUpdateContactsService', () => {
  let service: ViewUpdateContactsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewUpdateContactsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

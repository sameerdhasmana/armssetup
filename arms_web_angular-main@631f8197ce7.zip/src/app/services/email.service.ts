import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class EmailService {

  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }

  emailTmpltList(data:any){
    return this._http.post(this.baseUrl+'emailTmpltList',data);
  }

  emailTmpltName(data:any){
    return this._http.post(this.baseUrl+'emailTmpltName',data);
  }

  sendEmail(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'sendEmail',data);
  }

  accountEmailupdate(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'accountEmailupdate',data);
  }


  accountMailEligibleUpdate(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'accountMailEligibleUpdate',data);
  }


}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class LetterProfileService {


  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }


  letterDetailList(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"");

    return this._http.post(this.baseUrl+'letterDetailList',{
      "userLoginCd":userData.globalLogonUsers.user_login_cd,
      "blank":"1"
      });
  }

  letterProfileFieldList(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"");

    return this._http.post(this.baseUrl+'letterProfileFieldList',{
      "userLoginCd":userData.globalLogonUsers.user_login_cd,
      "blank":"0"
      });
  }

  populateSegment(data:any){
    return this._http.post(this.baseUrl+'populateSegment',data);
  }

  letterSegment(data:any){
    return this._http.post(this.baseUrl+'letterSegment',data);
  }

  letterProfileList(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"");

    return this._http.post(this.baseUrl+'letterProfileList',{
      "userLoginCd":userData.globalLogonUsers.user_login_cd,
      "blank":"0"
      });
  }
  createLetterProfile(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'createLetterProfile',data);
  }


  saveModifyLetterProfile(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'saveModifyLetterProfile',data);
  }
  deleteLetterProfile(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'deleteLetterProfile',data);
  }

  fetchModifyLetterDetails(data:any){
    return this._http.post(this.baseUrl+'fetchModifyLetterDetails',data);
  }


}



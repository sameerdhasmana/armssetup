import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { EventListenerFocusTrapInertStrategy } from '@angular/cdk/a11y';
import { isUndefined } from 'ngx-bootstrap/chronos/utils/type-checks';
import * as saveAs from 'file-saver';

@Injectable({
  providedIn: 'root'
})
export class ReportingUtilityService {
  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }

  // Customer Tab PopulateData
  allCustomerDetails(data:any){
    
    //return this._http.post('https://arms-az.dev.att.com/api/getAllCustomers',data)
    return this._http.post(this.baseUrl+'getAllCustomers',data)

  }

   // Report PopulateData
   allReportPopulateDetails(data:any){
    
   // return this._http.post('https://arms-az.dev.att.com/api/populateReportFilter',data)
   return this._http.post(this.baseUrl+'populateReportFilter',data)
  }

   
   // CTC PopulateData
   allCTCDetails(data:any){
    
   // return this._http.post('https://arms-az.dev.att.com/api/getChildTieCodeDetails',data)
   return this._http.post(this.baseUrl+'getChildTieCodeDetails',data)

  }
  HTTPOptionsForText: Object = {
    headers: new HttpHeaders({'Content-Type': 'application/json'}),
    responseType: 'blob'
 }

 reportsAutoSearchCustomer(data: any){
  return this._http.post(this.baseUrl+'populateCustomers',data)

}

 // ACNA/AECN/OCN/CTC Tab Searching for the Customer and Populating AgedDetail Grid//

 reportsAutoSearchACNACustomer(data:any){
  let data1 =localStorage.getItem("userInfo");
  let userData = JSON.parse(data1?data1:"")
  data.region = userData.globalLogonUsers.region;
  data.userLoginCd=userData.globalLogonUsers.user_login_cd;
  data.customerGrpCd="";
  return this._http.post(this.baseUrl+'populateACNA',data)
}


  // PDF File Generate 
  getDetailsInPDFFile(data:any,reportType:any) {
    //Canned - Maintainance Reports
    if(reportType=='AllCustomerQDSOByLF' || reportType=='AllCustomerQDSOByLFW'){
            return this._http.post(this.baseUrl+'downloadMaintainanceQdsoLfwReportPdf',data,{
        responseType: 'blob'
      });
    }
    //Canned - Management-Customer Reports
    else if(reportType=='ManagementCustomerReportByAccountNumber') {
      return this._http.post(this.baseUrl+'downloadCustomerReportByAccountNumberPDF',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementCustomerReportByBillName') {
      return this._http.post(this.baseUrl+'downloadCustomerReportByBillNamePDF',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementCustomerReportBySegment') {
      return this._http.post(this.baseUrl+'downloadCustomerReportByRegionSegmentPDF',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementCustomerReportBySegmentStatus') {
      return this._http.post(this.baseUrl+'downloadCustomerReportByRegionSegmentStatusPDF',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementCustomerReportByState') {
      return this._http.post(this.baseUrl+'downloadPDFByStateCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementCustomerReportByStateSegment') {
      return this._http.post(this.baseUrl+'downloadPDFByStateSegment',data,{
        responseType: 'blob'
      });
    }
     //Canned - Management-Region Reports
    else if(reportType=='ManagementRegionReportByCustomer') {
      return this._http.post(this.baseUrl+'regionPdfReportByRegionCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportBySegment') {
      return this._http.post(this.baseUrl+'regionPdfReportByRegionSegment',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportBySegmentCustomer') {
      return this._http.post(this.baseUrl+'regionPdfReportByRegionSegmentCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportByState') {
      return this._http.post(this.baseUrl+'regionPdfReportByRegionState',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportByStateCustomer') {
      return this._http.post(this.baseUrl+'regionPdfReportByRegionStateCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportByStateSegment') {
      return this._http.post(this.baseUrl+'regionPdfReportByRegionStateSegment',data,{
        responseType: 'blob'
      });
    }
    //Canned - Management-Segment Reports
    else if(reportType=='ManagementSegmentReportBySegmentCustomer') {
      return this._http.post(this.baseUrl+'segmentPdfReportByCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementSegmentReportBySegmentRegionCustomer') {
      return this._http.post(this.baseUrl+'segmentPdfReportByRegion',data,{
        responseType: 'blob'
      });
    }
     //Canned - Management-Summary Reports
     else if(reportType=='ManagementSummaryReportByCustomer') {
      return this._http.post(this.baseUrl+'summaryPdfReportByCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementSummaryReportByCustomerStatus') {
      return this._http.post(this.baseUrl+'summaryPdfReportByCustomerStatus',data,{
        responseType: 'blob'
      });
    }
     else if(reportType=='ManagementSummaryReportBySegment') {
      return this._http.post(this.baseUrl+'summaryPdfReportBySegment',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementSummaryReportByState') {
      return this._http.post(this.baseUrl+'summaryPdfReportByState',data,{
        responseType: 'blob'
      });
    }
    else {
      return this._http.post(this.baseUrl+'',data,{
        responseType: 'blob'
      });
    }
      
  }

  // Excel File Generate
  getDetailsInExcelFile(data:any,reportType:any) {
    //Canned - Maintainance Reports
    if(reportType=='AllCustomerQDSOByLF' || reportType=='AllCustomerQDSOByLFW'){
    return this._http.post(this.baseUrl+'downloadMaintainanceQdsoLfwReportExcel',data,{
        responseType: 'blob'
      });
    }
    //Canned - Management-Customer Reports
    else if(reportType=='ManagementCustomerReportByAccountNumber') {
      return this._http.post(this.baseUrl+'downloadCustomerReportByAccountNumberExcel',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementCustomerReportByBillName') {
      return this._http.post(this.baseUrl+'downloadCustomerReportByBillNameExcel',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementCustomerReportBySegment') {
      return this._http.post(this.baseUrl+'downloadCustomerReportByRegionSegmentExcel',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementCustomerReportBySegmentStatus') {
      return this._http.post(this.baseUrl+'downloadCustomerReportByRegionSegmentStatusExcel',data,{
        responseType: 'blob'
      });
    }
    //Canned - Management-Region Reports
    else if(reportType=='ManagementRegionReportByCustomer') {
      return this._http.post(this.baseUrl+'regionExcelReportByRegionCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportBySegment') {
      return this._http.post(this.baseUrl+'regionExcelReportByRegionSegment',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportBySegmentCustomer') {
      return this._http.post(this.baseUrl+'regionExcelReportByRegionSegmentCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportByState') {
      return this._http.post(this.baseUrl+'regionExcelReportByRegionState',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportByStateCustomer') {
      return this._http.post(this.baseUrl+'regionExcelReportByRegionStateCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementRegionReportByStateSegment') {
      return this._http.post(this.baseUrl+'regionExcelReportByRegionStateSegment',data,{
        responseType: 'blob'
      });
    }
    //Canned - Management-Segment Reports
    else if(reportType=='ManagementSegmentReportBySegmentCustomer') {
      return this._http.post(this.baseUrl+'segmentExcelReportByCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementSegmentReportBySegmentRegionCustomer') {
      return this._http.post(this.baseUrl+'segmentExcelReportByRegion',data,{
        responseType: 'blob'
      });
    }
     //Canned - Management-Summary Reports
     else if(reportType=='ManagementSummaryReportByCustomer') {
      return this._http.post(this.baseUrl+'summaryExcelReportByCustomer',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementSummaryReportByCustomerStatus') {
      return this._http.post(this.baseUrl+'summaryExcelReportByCustomerStatus',data,{
        responseType: 'blob'
      });
    }
     else if(reportType=='ManagementSummaryReportBySegment') {
      return this._http.post(this.baseUrl+'summaryExcelReportBySegment',data,{
        responseType: 'blob'
      });
    }
    else if(reportType=='ManagementSummaryReportByState') {
      return this._http.post(this.baseUrl+'summaryExcelReportByState',data,{
        responseType: 'blob'
      });
    }
    else{
      return this._http.post(this.baseUrl+'',data,{
        responseType: 'blob'
      });
    }
    }

    saveTemplateReport(formData: any) {
      console.log(formData);
      return this._http.post(this.baseUrl+'saveOrUpdateTemplateFile', formData);      
  }

    deleteTemplateReport(formData: any) {
      return this._http.post(this.baseUrl+'deleteTemplateFile', formData);
    }

    selectedTemplateCriteria(formData: any) {
      return this._http.post(this.baseUrl+'loadSelectedTemplateCriteria', formData);
    }

    loadAllUserTemplateFiles(formData: any) {
      return this._http.post(this.baseUrl+'loadUserTemplateFiles', formData);
    }

}

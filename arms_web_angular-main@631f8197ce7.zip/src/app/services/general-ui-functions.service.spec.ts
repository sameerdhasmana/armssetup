import { TestBed } from '@angular/core/testing';

import { GeneralUiFunctionsService } from './general-ui-functions.service';

describe('GeneralUiFunctionsService', () => {
  let service: GeneralUiFunctionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GeneralUiFunctionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

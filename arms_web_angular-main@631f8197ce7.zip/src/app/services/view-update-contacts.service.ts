import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ViewUpdateContactsService {

  baseUrl = environment.baseUrl;
  constructor(private _http: HttpClient) { }


  searchContacts(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'searchContacts', data);
  }
  searchAccount(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'searchAccount', data);
  }

  contactAssign(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'contactAssign', data);
  }

  contactUnAssign(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'contactUnAssign', data);
  }

  fetchContact(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'fetchContact', data);
  }

  saveViewUpdateContact(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'editAddContact', data);
  }

  deleteViewUpdateContact(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'deleteContact', data);
  }

  DisplayContacts(data: any) { 
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'displayContacts', data);
  }

  DisplayAccounts(data: any) { 
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl + 'accountDisplay', data);
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AccountNotesService {

//baseUrl = 'https://arms-az.dev.att.com/api/';
baseUrl = environment.baseUrl;

  constructor(private _http:HttpClient) { }

  addAccountNotes( data:any ){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'addAccountNotes',data)

  }
  populateInTreatment(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'populateInTreatment',data)
  }

  saveAccountNotes(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.attuid=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'saveAccountNotes',data)
  }

  accountNoteText(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl+'accountNoteText',data)
  }

  resolveAccountNotes(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl+'resolveAccountNotes',data)
  }

  deleteAccountNotes(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl+'deleteAccountNotes',data)
  }

  addAccountDetails(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl+'addAccountDetails',data)
  }

  saveAccountDetails(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl+'saveAccountDetails',data)
  }

  massResolveAccountNotes(data:any){
    return this._http.post(this.baseUrl+'massResolveAccountNotes',data)
  }

  saveMassResolveAccountNotes(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'saveMassResolveAccountNotes',data)
  }

  permNotes(data:any){
    return this._http.post(this.baseUrl+'permNotes',data)
  }

  accountNoteHistory(data:any){
    return this._http.post(this.baseUrl+'accountNoteHistory',data)
  }

  deleteAccountContacts(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'deleteAccountContacts',data)
  }
  generateAccountPermNoteReport(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'generateAccountPermNoteReport',data,{
      responseType: 'blob'
    });

  }
}


import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class SearchService {

  baseUrl = environment.baseUrl;

  subject :any = new BehaviorSubject<any>(0);
  profileName:string="";
  profileType:string="";
  constructor(private _http:HttpClient) { }

  // Customer Tab Searching for the Customer and Populating AgedDetail Grid//
  autoSearch(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.customerGrpCd="";
    data.profileName=this.profileName;
    data.profileType=this.profileType;
    return this._http.post(this.baseUrl+'submitCustomerQuery',data)

  }

  // ACNA/AECN/OCN/CTC Tab Searching for the Customer and Populating AgedDetail Grid//

  autoSearchACNA(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.customerGrpCd="";
    data.profileName=this.profileName;
    data.profileType=this.profileType;
    return this._http.post(this.baseUrl+'submitACNAQuery',data)
  }

  getAIFCustomerInfo(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    //data.customerGrpCd="";
    return this._http.post(this.baseUrl+'getAIFCustomerInfo',data)
  }

  // Bill Name Tab Searching for the Customer and Populating AgedDetail Grid//
  autoSearchBillName(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.customerGrpCd="";
    data.profileName=this.profileName;
    data.profileType=this.profileType;
    return this._http.post(this.baseUrl+'submitBillNameQuery',data)
  }

  customerAgedDetail(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.profileName=this.profileName;
    data.profileType=this.profileType;
    return this._http.post(this.baseUrl+'submitCustomerQuery',data);
  }

  acnaAgedDetail(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.profileName=this.profileName;
    data.profileType=this.profileType;
    return this._http.post(this.baseUrl+'submitACNAQuery',data);

  }

  billNameAgedDetail(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.profileName=this.profileName;
    data.profileType=this.profileType;
    return this._http.post(this.baseUrl+'submitBillNameQuery',data);
  }


  customerInvoiceView(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.profileName=this.profileName;
    data.profileType=this.profileType;
    return this._http.post(this.baseUrl+'invoiceView',data);
      }

  billNameInvoiceView(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.profileName=this.profileName;
    data.profileType=this.profileType;
    return this._http.post(this.baseUrl+'billNameInvoiceView',data);
  }
  acnaInvoiceView(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.profileName=this.profileName;
    data.profileType=this.profileType;
    return this._http.post(this.baseUrl+'acnaInvoiceView',data);
  }


  customerNotes(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'customerNotes',data);
  }

  accountNotes(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'accountNotes',data);
  }

  //17) Summary Tab for Bill Name
  getBillNameSummaryDetails(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
  return this._http.post(this.baseUrl+'getBillNameSummaryDetails',data);
  }
  //18) Summary Tab for get Single Customer Summary--To Populate  Single Customer Summary Tab for Bill Name
  singleCustomerSummary(data:any){
    let profileName:string=localStorage.getItem("profileName") || "";
    let profileType:string=localStorage.getItem("profileType") || "";
    this.profileName=profileName;
    this.profileType=profileType;
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.profileName=this.profileName;
    data.profileType=this.profileType;
  return this._http.post(this.baseUrl+'singleCustomerSummary',data);
}
//19) Summary Tab for get ACNA Summary
summaryACNAQuery(data:any){
  let profileName:string=localStorage.getItem("profileName") || "";
  let profileType:string=localStorage.getItem("profileType") || "";
  this.profileName=profileName;
  this.profileType=profileType;
  let data1 =localStorage.getItem("userInfo");
  let userData = JSON.parse(data1?data1:"")
  data.region = userData.globalLogonUsers.region;
  data.userLoginCd=userData.globalLogonUsers.user_login_cd;
  data.profileName=this.profileName;
  data.profileType=this.profileType;
return this._http.post(this.baseUrl+'summaryACNAQuery',data);
}

emaorView(data:any){
  let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
     data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'emaorView',data);
}
viewInternalContacts(data:any){
  let data1 =localStorage.getItem("userInfo");
  let userData = JSON.parse(data1?data1:"")
  data.region = userData.globalLogonUsers.region;
   data.userLoginCd=userData.globalLogonUsers.user_login_cd;
  return this._http.post(this.baseUrl+'viewInternalContacts',data);
}


  // Populating only Dropdowns//

  populateCustomers(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'populateCustomers',data);
  }

  populateACNA(data:any){
    return this._http.post(this.baseUrl+'populateACNA',data);
  }

  populateBillName(data:any){
    return this._http.post(this.baseUrl+'populateBillName',data);
  }

  generateCPPOReport(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'generateCPPOReport',data,{
      responseType: 'blob'
    });
  }

  generateCustCopyReport(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'generateCustCopyReport',data,{
      responseType: 'blob'
    });
  }

  generateRepCopyReport(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'generateRepCopyReport',data,{
      responseType: 'blob'
    });
  }

  printCustomerReport(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.region = userData.globalLogonUsers.region;
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.firstName = userData.globalLogonUsers.firstname;
    data.lastName = userData.globalLogonUsers.lastname;
    return this._http.post(this.baseUrl+'printCustomerReport',data,{
      responseType: 'blob'
    });
  }


  breakdownDetails(data:any){
    return this._http.post(this.baseUrl+'breakdownDetails',data);
  }

  taxiClaimDetails(data:any){
    return this._http.post(this.baseUrl+'taxiClaimDetails',data);
  }
  accountPastDue(data:any){
    return this._http.post(this.baseUrl+'accountPastDue',data);
  }

  cashDataDetails(data:any){
    return this._http.post(this.baseUrl+'cashDataDetails',data);
  }
}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CommitmentHistoryService {

  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }

  viewCommitmentHistory(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl+'viewCommitmentHistory',data);
  }

  closeCommitmentHistory(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl+'closeCommitmentHistory',data);
  }

}




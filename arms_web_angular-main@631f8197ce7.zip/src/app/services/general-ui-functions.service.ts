import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GeneralUiFunctionsService {

  constructor() { }

  allowOnlyNumbersWithSlash(event: any) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9 & /
    if ((charCode < 48 || charCode > 57) && charCode != 47) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  allowOnlyNumbers(event: any) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  // Only AlphaNumeric
  allowOnlyAlphaNumeric(event: any) {
    var inp = String.fromCharCode(event.keyCode);
    if (/[a-zA-Z0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }


}

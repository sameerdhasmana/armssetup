import { TestBed } from '@angular/core/testing';

import { ColumnOrderService } from './column-order.service';

describe('ColumnOrderService', () => {
  let service: ColumnOrderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ColumnOrderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MaintenanceService {

  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }

  allContacts(data:any){
    return this._http.post(this.baseUrl+'allContacts',data);
  }

  populateContacts(data:any){
    return this._http.post(this.baseUrl+'populateContacts',data);
  }

  deleteContacts(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;

    return this._http.post(this.baseUrl+'deleteContacts',data);
  }

  saveContacts(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'saveContacts',data);
  }


  renderApSubGroup(data:any){
    return this._http.post(this.baseUrl+'renderApSubGroup',data);
  }

  renderApSubGroupGrid(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'renderApSubGroupGrid',data);
  }

  saveApSubGroupGrid(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'saveApSubGroupGrid',data);
  }


  manageTemplateNotes(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'manageTemplateNotes',data);
  }

  viewTemplate(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'viewTemplate',data);
  }

  saveTemplate(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'saveTemplate',data);
  }

  deleteTemplate(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'deleteTemplate',data);
  }

  custAPSubGrpDetails(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.userBusGrp=userData.globalLogonUsers.group;
    return this._http.post(this.baseUrl+'custAPSubGrpDetails',data);
  }

  apSubGroupUpdate(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    data.updateLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'apSubGroupUpdate',data);
  }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CustomerNotesModalService {
  baseUrl = environment.baseUrl;

  constructor(private _http: HttpClient) { }

  customerNotesHistory(data: any) {
    return this._http.post(this.baseUrl+'customerNotesHistory', data);
  }

  customerPermNotes(data: any) {
    return this._http.post(this.baseUrl+'customerPermNotes', data);
  }

  getAllFilters(data: any) {
    return this._http.post(this.baseUrl+'addCustomerNotes', data);
  }

  resolveNotes(data: any) {
    return this._http.post(this.baseUrl+'resolveCustomerNotes', data);
  }

  deleteNotes(data: any) {
    return this._http.post(this.baseUrl+'deleteCustomerNotes', data);
  }

  saveNotes(data:any){
    return this._http.post(this.baseUrl+'saveCustomerNotes', data);
  }

  generatePermNoteReport(data:any){
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    data.userLoginCd=userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl+'generatePermNoteReport',data,{
      responseType: 'blob'
    });

  }


}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class TransferService {


  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }

  allContacts(data:any){
    return this._http.post(this.baseUrl+'allContacts',data);
  }


  transferNotes(data:any){
    return this._http.post(this.baseUrl+'transferNotes',data);
  }

  getUsers(data:any){
    return this._http.post(this.baseUrl+'getUsers',data);
  }

  transferContacts(data:any){
    return this._http.post(this.baseUrl+'transferContacts',data);
  }

}

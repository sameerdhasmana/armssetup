import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class CustomerMaintenanceService {


  baseUrl = environment.baseUrl;
  constructor(private _http:HttpClient) { }

  fetchCustMaintenance(data:any){
    return this._http.post(this.baseUrl+'fetchCustMaintenance',data);
  }

}

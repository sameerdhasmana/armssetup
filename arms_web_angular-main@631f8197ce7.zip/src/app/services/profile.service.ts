import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  baseUrl = environment.baseUrl;

  constructor(private _http: HttpClient) { }

  renderManageProfile() {
    let data: any = {};
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;
    data.businessGroup = userData.globalLogonUsers.group;
    return this._http.post(this.baseUrl + 'renderManageProfile', data);
  }

  populateProfileDetails() {
    let data: any = {};
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl + 'populateProfileDetails', data);
  }

  populateProfileCustomers(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl + 'populateProfileCustomers', data);
  }

  saveProfile(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl + 'saveProfile', data);
  }

  loadProfile(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl + 'loadProfile', data);
  }

  setDefaultProfile(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl + 'setDefaultProfile', data);
  }

  deleteProfile(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl + 'deleteProfile', data);
  }

  executeProfile(data: any) {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    data.userLoginCd = userData.globalLogonUsers.user_login_cd;
    return this._http.post(this.baseUrl + 'executeProfile', data);
  }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FiltersApiService {

  baseUrl = environment.baseUrl;
  tokenUrl = environment.tokenUrl;

  subject :any = new BehaviorSubject<any>(0);
  constructor(private _http:HttpClient) { }


  // Populating Filters in Query Filters Component while User enters into the Environment//
   getFilters(data:any){
    return this._http.post(this.baseUrl+'populateFilter',data);
  }

  // Re-Populating Filters dynamically when User changes the Customer Group Filter into the Environment//

  changeFilters(data:any){
    return this._http.post(this.baseUrl+'repopulateFilter',data);
  }

   getToken(data:any){
    return this._http.post(this.tokenUrl+'authenticate',data);
  }
}


//http://localhost:8080/populateFilter
//http://localhost:8080/repopulateFilter
//https://arms-az.dev.att.com/arms-0.0.1-SNAPSHOT/populateFilter
//https://arms-az.dev.att.com/arms-0.0.1-SNAPSHOT/repopulateFilter

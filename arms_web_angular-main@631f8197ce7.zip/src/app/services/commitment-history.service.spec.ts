import { TestBed } from '@angular/core/testing';

import { CommitmentHistoryService } from './commitment-history.service';

describe('CommitmentHistoryService', () => {
  let service: CommitmentHistoryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommitmentHistoryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalid-session',
  templateUrl: './invalid-session.component.html',
  styleUrls: ['./invalid-session.component.scss']
})
export class InvalidSessionComponent implements OnInit {
  todayDate:any;
  constructor() {
    this.todayDate= new Date();
  }


  ngOnInit(): void {

  }

}

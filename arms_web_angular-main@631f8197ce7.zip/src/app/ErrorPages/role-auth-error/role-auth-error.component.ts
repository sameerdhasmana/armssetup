import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role-auth-error',
  templateUrl: './role-auth-error.component.html',
  styleUrls: ['./role-auth-error.component.scss']
})
export class RoleAuthErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

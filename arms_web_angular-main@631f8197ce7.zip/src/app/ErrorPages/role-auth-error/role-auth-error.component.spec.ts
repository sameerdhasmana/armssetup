import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleAuthErrorComponent } from './role-auth-error.component';

describe('RoleAuthErrorComponent', () => {
  let component: RoleAuthErrorComponent;
  let fixture: ComponentFixture<RoleAuthErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoleAuthErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleAuthErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

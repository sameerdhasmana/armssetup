import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-under-dev',
  templateUrl: './under-dev.component.html',
  styleUrls: ['./under-dev.component.scss']
})
export class UnderDevComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

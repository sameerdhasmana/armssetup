import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnvAuthErrorComponent } from './env-auth-error.component';

describe('EnvAuthErrorComponent', () => {
  let component: EnvAuthErrorComponent;
  let fixture: ComponentFixture<EnvAuthErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EnvAuthErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnvAuthErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

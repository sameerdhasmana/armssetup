import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-env-auth-error',
  templateUrl: './env-auth-error.component.html',
  styleUrls: ['./env-auth-error.component.scss']
})
export class EnvAuthErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FiltersApiService } from '../services/filters-api.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import {
  ConfirmationService,
  MessageService,
  PrimeNGConfig,
} from 'primeng/api';
import { MenuItem } from 'primeng/api';
import { SharedService } from '../services/shared.service';
import { MessageMaintenanceService } from '../services/message.service';
import { ProfileService } from '../services/profile.service';
//import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit, AfterViewInit {
  firstName: string = '';
  lastName: string = '';
  environment: string = 'Production';
  notificationNumber: number = 1;
  userRoleId: number = 1000;
  userRoleStatus: boolean = false;
  userData: any;
  items!: MenuItem[];

  // Function to Call Change Request on Environment.
  profileDetailsFilter:any=[];
  constructor(
    private _filtersApiService: FiltersApiService,
    private toastr: ToastrService,
    private router: Router,
    private confirmationService: ConfirmationService,
    private primengConfig: PrimeNGConfig,
    private _sharedService: SharedService,
    private message: MessageMaintenanceService,
    private profileService: ProfileService,
    //private envSpinner : NgxSpinnerService,
  ) {

  }

  loginUser: any = {};

  // setProfile(mode:string){
  //   console.log(mode);
  //   this.router.navigate([ '/LetterProfileManagement' ], { queryParams: { action:mode } })
  // }

  setEnv(env: string) {
//    this.envSpinner.show();
    this.environment = env;
    let data =localStorage.getItem("userInfo");
    let userId= JSON.parse(data?data:"");
    this.loginUser.userLoginCd =  userId.globalLogonUsers.user_login_cd;
    this.loginUser.appName = 'ARMS Application';
    this.loginUser.environment = this.environment;
    if (this.environment === 'Pre-Production') {
      localStorage.setItem('envir', 'ARMS6450cZv3421');
    } else {
      localStorage.setItem('envir', '');
    }
    this._filtersApiService
    .getFilters(this.loginUser)
    .subscribe((data: any) => {
      localStorage.setItem('userInfo', JSON.stringify(data));
      let data1 = localStorage.getItem('userInfo');
      this.userData = JSON.parse(data1 ? data1 : '');
      this.firstName = this.userData.globalLogonUsers.firstname;
      this.lastName = this.userData.globalLogonUsers.lastname;
    });
    this.router.navigate(['/query']);
    // setTimeout(() => {
    //   this.envSpinner.hide();
    // }, 1500);

  }

   showNotfity() {
     this.message.fetchMessage('').subscribe((data: any) => {
        this.sourceMessage = data.meesage[0].the_msg;
        this.toastr.info('', this.sourceMessage, {
          timeOut: 5000,
          closeButton: true,
        });
        this.notificationNumber = 0;
      });
  }
helpUrl:any;
  helpSection(){
    window.open(this.helpUrl, '_blank');
  }

  sourceMessage: any;

  ngOnInit() {
    // this.message.fetchMessage('').subscribe((data: any) => {
    //   this.sourceMessage = data.meesage[0].the_msg;
    // });
  }

  logout(event: Event) {
    this.confirmationService.confirm({
      target: event.target as EventTarget,
      message: 'Are you sure that you want to proceed?',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        localStorage.clear();
        window.location.href = 'https://www.e-access.att.com/';
        //window.location.href ="https://forms.office.com/r/nVqH8vpfnU";
        //this.router.navigate(['/login']);
      },
      reject: () => {
        this.router.navigate(['/query']);
      },
    });
  }
  ngAfterViewInit(): void {
    //debugger;
    this._sharedService.onLogin$.subscribe((e) => {
      let data = localStorage.getItem('userInfo');
      //alert(13)
      if (!data) {
        return;
      }
      this.userData = JSON.parse(data ? data : '');
      this.firstName = this.userData.globalLogonUsers.firstname;
      this.lastName = this.userData.globalLogonUsers.lastname;
      this.userRoleId = this.userData.globalLogonUsers.userrole;
      this.helpUrl = this.userData.helpUrl;
      let profileDetailsFilterData=localStorage.getItem('profileDetailsFilter');
      if (!profileDetailsFilterData) {
        return;
      }
      this.profileDetailsFilter = JSON.parse(profileDetailsFilterData ? profileDetailsFilterData : '');
      this._sharedService.populateProfileDetails$.subscribe((data) => {
        this.profileDetailsFilter = data;
      });
      //console.log(this.userRoleId);
      if (
        this.userRoleId == 512 ||
        this.userRoleId == 16 ||
        this.userRoleId == 32
      ) {
        this.userRoleStatus = false;
        //console.log("Check");
      } else {
        this.userRoleStatus = true;
      }

      this.primengConfig.ripple = true;
    });
  }

  ExecuteClearSelection(){
    localStorage.setItem("profileType","");
    localStorage.setItem("profileName","");
  }

  ExecuteQueryFilters(profileName:any,profileType:any){
    //console.log(profileName+" : "+profileType)
    let data = localStorage.getItem('userInfo');
    this.userData = JSON.parse(data ? data : '');
    let executeFilterData:any={};
    executeFilterData.profileName=profileName;
    executeFilterData.profileType=profileType;
    executeFilterData.businessGroup=this.userData.globalLogonUsers.group;
    executeFilterData.billingPeriod=this.userData.customerBillingPeriod[0].billing_period;
    this.profileService.executeProfile(executeFilterData).subscribe((data:any)=>{
      localStorage.setItem("profileType",profileType);
      localStorage.setItem("profileName",profileName);
      localStorage.setItem('executeFilterData', JSON.stringify(data));
      localStorage.setItem('chkFromHeaderForFilter', "1");
      localStorage.setItem('chkFromHeaderForAutoSearch', "1");
      localStorage.setItem('chkFromHeaderForTabs', "1");
      this._sharedService.setfilterDataFromProfile(data);
      this._sharedService.setCheckIfFromHeader({"chkFromHeader":"1"});
      this.router.navigate([ '/query' ])
    },
    (error:any)=>{
      console.log(error);
    });


  }
}

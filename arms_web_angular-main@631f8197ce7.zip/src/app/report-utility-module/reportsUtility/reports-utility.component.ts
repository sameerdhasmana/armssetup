import { Component, OnInit, ViewContainerRef, ViewChild, ViewEncapsulation,Injectable, Input, EventEmitter, assertPlatform  } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FiltersApiService } from '../../services/filters-api.service';
import { ReportingUtilityService } from '../../services/reportingServiceUtility';
import { Router } from '@angular/router';
// import * as FileSaver from 'file-saver';
import { PrimeNGConfig } from 'primeng/api';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, MenuItemDef } from 'ag-grid-enterprise';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatSidenav } from '@angular/material/sidenav';
import { FilterSelection } from 'src/Models/filterSelection.model';
import { SharedService } from '../../services/shared.service';
import { SearchService } from '../../services/search.service';
import { FilterService } from "primeng/api";
import {AutoCompleteModule} from 'primeng/autocomplete';
import {saveAs} from 'file-saver';
import { NgxSpinnerService } from "ngx-spinner";


interface Customer {
  customer_grp_cd: string,
  customer_legal_nm: string
}
interface Segment {
  segment_grp_cd: string,
  segment_desc: string
}
@Component({
  selector: 'app-reports-utility',
  templateUrl: './reports-utility.component.html',
  styleUrls: ['./reports-utility.component.scss']
})
export class ReportsUtilityComponent implements OnInit {
  @Input() secondCmp: ReportsUtilityComponent | undefined;
  @Input()
  update!: EventEmitter<string>;

  @ViewChild('agGrid') agGrid!: AgGridAngular;

  rowData: any;
  columnDefs: any;
  ctc_rowData: any;
  ctc_columnDefs: any;
  shwNotesGrid: boolean = false;
  pageSize: number = 10000;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
   // flex: 1,
    //minWidth: 100,
    resizable: true,
  }
  isShown: boolean = false ; // hidden by default
  activeRadioButton: string = "Customer"; // Default Customer Selection Purpose
  filteredItems: any[] = []; // AutoSearch Items Populated here in this Variable
  selectedCustomerItem: any[]=[]; // AutoSearch Selected item
  selectedSingleCustomerItem:any={};
  filters: any = {}; // Fetching the Filters data from the Tabs and Filters components .
  billingPeriod: any;
  groupSeleted:any[]=[];
  selectedBtn: string = "";
  importDateShow: boolean=true;
  superRadioButton="Customer";
  reportfilename: any;
  cGroups:any;
  deniedDisp:any;
  regGroup:any;
  reportFilters: any = {}; // Fetching the Filters data from the Tabs and Filters components .


  exclusionShow = true;
   excShow = true;
   regionShow = true;
   groupShow = true;
   deniedDispShow=true;
   originatingSystemShow=true;
   segmentShow=true;
   statusShow=true;
   finalShow=true;
   liveShow=true;
   writeOffShow=true;
   radioButtonShow=true;
   billingPeriodShow=true;
   filterCriteriaShow = true;




  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [
       'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  //populate Customer Details
  columnDefsANMR: ColDef[] = [
    { headerName: 'Customer', field: 'customer_legal_nm',
     headerCheckboxSelection: true, width:350,
     headerCheckboxSelectionFilteredOnly: true,checkboxSelection:true},
     { headerName: 'CustomerID', field: 'customer_grp_cd',width:1}];

  //populate CTC Details
  ctc_columnDefsANMR: ColDef[] = [
      { headerName: 'CTC', field: 'customer_grp_child_cd',
      headerCheckboxSelection: true, width:150,
       headerCheckboxSelectionFilteredOnly: true,checkboxSelection:true},
       { headerName: 'Bill Name', field: 'customer_legal_nm'},
       { headerName: 'Customer', field: 'customer_nm'},
      ];



     overlayLoadingTemplate =
     `<span class="ag-overlay-loading-center">
   Please wait while your Data is loading
   </span>`;
   overlayNoRowsTemplate =
     `<span style="padding: 10px;
    border: 2px solid #444;
    background: lightgoldenrodyellow;">
    No Data Found in the System
    </span>`;
    selection: FilterSelection = new FilterSelection(); // Model implemented to Store the Filters form Data
    autoCompleteShow = true;
    multipleAllow = true;


   //Declarations Of Variables
   Filters: any; // Variable to store the Initial Filters Values coming from the DB
   initialDBValues:any="";
   userID:any="";
   items: any="";
   defaultBP:any;
   defaultGroup:any=[];
   customersPopulateDataList: Customer[];
   regionsPopulateDataList:any[];
   dispIntervalPopulateDataList:any[];
   ctcPopulateDataList:any[];
  // dateList:any[];




   selectedCustomers: Customer[];
   selectedSegements: Segment[];
   // An array that holds all options in the comboo box
   loading: boolean = true;
   loginUser: any = {};
   Exclusions: any;


   selectedReportType:any;
   reportCategory:any;


   radioList1 = [
    { "name": "All" , "value" :0, "checked":true},
    { "name": "Multiple","value" :1},
    { "name": "Single","value" :2},
  ]

  radioList2 = [
    { "name": "customer" , "value" :0, "checked":true},
    { "name": "childTieCode","value" :1}
  ]
  selectedRadio = this.radioList1[0].value;
  selectedFilterCriteria = this.radioList2[0].value;

    // Form Variable to Store the Values from the Form.
    form :any=new FormGroup({
      FINAL: new FormControl(true),
      LIVE: new FormControl(true),
      WROFF: new FormControl(),
      custGroup: new FormControl(),
      accClass : new FormControl(),
      oSystem :new FormControl(),
      cGroups : new FormControl(),
      regGroup:new FormControl(),
      bPeriod : new FormControl(),
      sList : new FormControl(),
      deniedDisp : new FormControl(),
     // exclusions : new FormControl("Included Accounts")
     Exclusions: new FormControl({ value: "Included Accounts" }),
     customerItem: new FormControl(),
     templateName: new FormControl(),
     sortType: new FormControl(false)
     });

    targetProducts = [];
    sourceProducts: any = [];
    sourceProducts_groupBy: any = [];
    sourceProducts_sortBy: any = [];
    criteriaSource: any = [];
    criteriaTarget: any = [];
    clickOnTemplate = false;
    disableControl = true;
    tempSelectedTargetItem = '';
    clickedOnAddButton = false;
    radioValue = 'groupBy';

  //Initialization Of Variables
  constructor(private _filtersApiService: FiltersApiService,
    private reportingService: ReportingUtilityService,
    private router: Router,
    private primengConfig: PrimeNGConfig,
    private sharedService: SharedService,
    private search:SearchService, private spinner: NgxSpinnerService) {
    this.customersPopulateDataList=[];
    this.regionsPopulateDataList=[];
    this.dispIntervalPopulateDataList=[];
    this.selectedCustomers=[];
    this.selectedSegements=[];
    this.ctcPopulateDataList=[];
    //this.form.controls['Final'].setValue(true);
    //this.form.controls['Live'].setValue(true);
    //this.Exclusions = "Included Accounts";

   // this.dateList=[];


  }

  ngOnInit(): void {

    let data =localStorage.getItem("userInfo");
    this.Filters = JSON.parse(data?data:"");
    let userData = JSON.parse(data?data:"")
    let populateInput:any={};
    populateInput.userLoginCd=userData.globalLogonUsers.user_login_cd;
    populateInput.appName = 'ARMS Application';
    populateInput.environment= 'Pre-Production';

    this.initialDBValues = this.Filters.customerGroupList.find(
      (e:any)=>{return e.bus_unit_cd== this.Filters.globalLogonUsers.group});
    this.userID =  this.Filters.globalLogonUsers.user_login_cd;
    localStorage.setItem("userLoginCd", this.userID)

    this.defaultBP=this.Filters.customerBillingPeriod[0].billing_period;
    this.defaultGroup.push(this.Filters.globalLogonUsers.group);

     //API call to fetch Customer Details

     this.reportingService.allCustomerDetails(data).subscribe((customers_data:any)=>{
      this.customersPopulateDataList=customers_data?customers_data.CustomerInfo:"";
      this.rowData = customers_data.CustomerInfo;
      this.columnDefs = this.columnDefsANMR;

       });

      //API call to fetch Region&DispInterval Details

    this.reportingService.allReportPopulateDetails(populateInput).subscribe((data:any)=>{
    this.regionsPopulateDataList=data?data.regionDetailsList:"";
    this.dispIntervalPopulateDataList=data?data.dispIntervalDetails:"";
    this.sourceProducts = data?data.templateFieldsDetails:[];
    this.sourceProducts_groupBy = this.sourceProducts.map((product: any) => {
      return {
        english_name: product.english_name,
        isDisplay: false,
        isSelected: false
      };
    });
    this.sourceProducts_sortBy = this.sourceProducts.map((product: any) => {
      return {
        english_name: product.english_name,
        isDisplay: false,
        isSelected: false
      };
    });

  // this.ctc_rowData = data.childTieCodeDetails;
    //this.ctc_columnDefs = this.ctc_columnDefsANMR;

     });



   //List for Reports Left Pannel Content
   this.items = [
    {
        label: 'ARMS Reports',
        icon: 'pi pi-pw pi-folder',
        items: [{
                label: 'Canned Reports',
                icon: 'pi pi-fw pi-folder',
                items: [
                    {label: 'Maintainance Reports', icon: 'pi pi-pw pi-copy', items:[
                        {label: 'All Customers Q-DSO by Group and Region-LF', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(1); this.enableDisableFilters(1, event);}},
                        {label: 'All Customers Q-DSO by Group and Region-LFW', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(2); this.enableDisableFilters(2, event); }},
                        {label: 'Running Balance Report', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(3);this.enableDisableFilters(3, event); }},
                        {label: 'Summary by System', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(4);this.enableDisableFilters(4, event); }},
                        {label: 'Summary by System, Status and State', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(5); this.enableDisableFilters(5, event);}}
                    ]},
                    {label: 'Management Reports', icon: 'pi pi-pw pi-copy', items:[
                      {label: 'Customer Reports', icon: 'pi pi-fw pi-copy', items:[
                        {label: 'Customer Report by Account Level Detail by Account Number', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(6); this.enableDisableFilters(6, event);}},
                        {label: 'Customer Report by Account Level Detail by Bill Name', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(7); this.enableDisableFilters(7, event);}},
                        {label: 'Customer Report by Customer, Region, Segment', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(8); this.enableDisableFilters(8, event);}},
                        {label: 'Customer Report by Customer, Region, Segment, Status', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(9); this.enableDisableFilters(9, event);}},
                        {label: 'Customer Report by Customer, Region, State', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(10); this.enableDisableFilters(10, event);}},
                        {label: 'Customer Report by Customer, Region, State, Segment', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(11); this.enableDisableFilters(11, event);}},
                        {label: 'Customer Report by Customer, Region, Status', icon: 'pi pi-fw pi-file'}]},
                      {label: 'Director Reports', icon: 'pi pi-fw pi-copy', items:[
                        {label: 'Customer not assigned to Account Manager', icon: 'pi pi-fw pi-file'},
                        {label: 'Director Report by Account Manager and Customer', icon: 'pi pi-fw pi-file'},
                        {label: 'Director Report by Customer and Account Manager', icon: 'pi pi-fw pi-file'}]},
                      {label: 'QDSO Reports', icon: 'pi pi-fw pi-copy', items:[
                        {label: 'Assigned Customer QDSO by Region and User', icon: 'pi pi-fw pi-file'},
                        {label: 'Unassigned Customer QDSO', icon: 'pi pi-fw pi-file'}]},
                      {label: 'Region Reports', icon: 'pi pi-fw pi-copy', items:[
                        {label: 'Region Report by Region, Customer', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(18); this.enableDisableFilters(18, event);}},
                        {label: 'Region Report by Region, Segment', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(19); this.enableDisableFilters(19, event);}},
                        {label: 'Region Report by Region, Segment, Customer', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(20); this.enableDisableFilters(20, event);}},
                        {label: 'Region Report by Region, State', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(21); this.enableDisableFilters(21, event);}},
                        {label: 'Region Report by Region, State, Customer', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(22); this.enableDisableFilters(22, event);}},
                        {label: 'Region Report by Region, State, Segment', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(23); this.enableDisableFilters(23, event);}}]},
                      {label: 'Segment Reports', icon: 'pi pi-fw pi-copy', items:[
                        {label: 'Segment Report by Segment, Customer', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(24); this.enableDisableFilters(24, event); }
                      },
                        {label: 'Segment Report by Segment, Region, Customer', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(25);  this.enableDisableFilters(25, event);}}]},
                      {label: 'Summary Reports', icon: 'pi pi-fw pi-copy', items:[
                        {label:'Summary by Customer', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(26); this.enableDisableFilters(26, event);}},
                        {label:'Summary by Customer, Status', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(27); this.enableDisableFilters(27, event);}},
                        {label:'Summary by Segment', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(28); this.enableDisableFilters(28, event);}},
                        {label:'Summary by State', icon: 'pi pi-fw pi-file', style:{},
                        command: (event:any) => { this.onLeftPannelSelection(29); this.enableDisableFilters(29, event);}}]},
                      {label: 'Top 25 Customers', icon: 'pi pi-fw pi-copy', items:[
                        {label: 'Top 25 By Total Past Due', icon: 'pi pi-fw pi-file'},
                        {label: 'Top 25 By Total Receivable', icon: 'pi pi-fw pi-file'}
                      ]}
                    ]},

                    {label: 'Service Rep Reports', icon: 'pi pi-pw pi-copy', items:[
                      {label: 'ACNA Report at Account/Invoice', icon: 'pi pi-fw pi-file'},
                      {label: 'Customer at the Child tie code level', icon: 'pi pi-fw pi-copy', items:[
                        {label: 'Customer at the Child tie code level', icon: 'pi pi-fw pi-file'},
                        {label: 'Customer Child Tie Code Summary', icon: 'pi pi-fw pi-file'},
                        {label: 'Customer Child Tie Code Summary Bill Name', icon: 'pi pi-fw pi-file'}]},
                      {label: 'Customer Detail at CABS Invoice Level', icon: 'pi pi-fw pi-file'},
                      {label: 'Customer Detail at the Account Level', icon: 'pi pi-fw pi-copy', items:[
                        {label: 'Aging Detail', icon: 'pi pi-fw pi-file'},
                        {label: 'Bill Detail', icon: 'pi pi-fw pi-file'},
                        {label: 'CBA Breakdown', icon: 'pi pi-fw pi-file'}]},
                      {label: 'Customer Summary', icon: 'pi pi-fw pi-copy', items:[
                        {label: 'Customer', icon: 'pi pi-fw pi-file'},
                        {label: 'Highest Past Due', icon: 'pi pi-fw pi-file'}]},
                      {label: 'Customer Summary by Highest Due w/Perm Notes', icon: 'pi pi-fw pi-file'},
                      {label: 'Customer Summary by Region, Group, Segment, Status, Assigned', icon: 'pi pi-fw pi-file'},
                      {label: 'Customer Summary by Region, Group, Segment, Status, Assigned, Bill Name', icon: 'pi pi-fw pi-file'},
                      {label: 'Tracking Account Change', icon: 'pi pi-fw pi-file'},
                      {label: 'Transactions by Customer', icon: 'pi pi-fw pi-file'}
                    ]}
                ],
                command: (event:any) => {this.clickOnTemplate = false; 
                  this.disableControl = true;
                  this.targetProducts = [];
                  this.sourceProducts_groupBy.forEach((each: any) => {
                    each.isDisplay = false;
                    each.isDisplay = false;
                  });
                  this.sourceProducts_sortBy.forEach((each: any) => {
                    each.isDisplay = false;
                    each.isDisplay = false;
                  });
                }
            },
            {
              label: 'Template Reports',
              icon: 'pi pi-fw pi-folder',
              items: [
                  {label: 'User', icon: 'pi pi-fw pi-user-plus'},
                  {label: 'Filter', icon: 'pi pi-fw pi-filter'}
              ],
              command: (event:any) => {this.clickOnTemplate = true;},
          }
        ]
    }
  ]

  const loadAllUserRequest = {
    userLoginCd:"SD886W",
    reportType:"T"
  };
  
  this.reportingService.loadAllUserTemplateFiles(loadAllUserRequest).subscribe((response :any) => {
    response.userTemplateDetails.forEach((each: any) => {
      const selectedFormData = {
        userLoginCd:"SD886W",
        reportType:"T",
        reportName: each.reportDisplayName
      };
      this.items[0].items[1].items.push({
        label: each.reportDisplayName,
        icon: 'pi pi-fw pi-user-plus',
        command: (event:any) => {
          this.reportingService.selectedTemplateCriteria(selectedFormData).subscribe((resp: any) => {
            console.log(resp);
            const custGroup = resp.templateDetails.customerGrpCd.map((each: any) => {
                const matchedItem = this.selectedCustomerItem.filter((item: any) => item.customer_grp_cd === each);
                return matchedItem[0];
              });
            this.form.setValue({ 
              FINAL: resp.templateDetails.statusClause.some((each: any) => each === 'FINAL'),
              LIVE: resp.templateDetails.statusClause.some((each: any) => each === 'LIVE'),
              WROFF: resp.templateDetails.statusClause.some((each: any) => each === 'WROFF'),
              custGroup: custGroup,
              accClass : resp.templateDetails.exclusionClass.map((each: any) => {
                const matchedItem = this.Filters.accountsClassificationList.filter((item: any) => item.class_desc === each);
                return matchedItem[0].class_cd;
              }),
              oSystem :new FormControl(),
              cGroups : new FormControl(),
              regGroup:new FormControl(),
              bPeriod : new FormControl(),
              sList : new FormControl(),
              deniedDisp : new FormControl(),
            // exclusions : new FormControl("Included Accounts")
              Exclusions: new FormControl({ value: "Included Accounts" }),
              customerItem: new FormControl(),
              templateName: new FormControl(),
              sortType: new FormControl(false)
            })
          });
        }
      });
      this.items = [...this.items];
    });
  });

  this.primengConfig.ripple = true;
  setTimeout(() => {
    let doubleRight:any = document.getElementsByClassName("pi-angle-double-right");
    let doubleLeft:any = document.getElementsByClassName("pi-angle-double-left");
    let doubleUp:any = document.getElementsByClassName("pi-angle-double-up");
    let doubleDown:any = document.getElementsByClassName("pi-angle-double-down");
    doubleRight.item(0).parentElement.style.display="none"
    doubleLeft.item(0).parentElement.style.display="none"
    doubleUp.item(0).parentElement.style.display="none"
    doubleDown.item(0).parentElement.style.display="none"
}, 500);
  }


  onExit(){

    this.router.navigate(['/login']);
  }


  async filterData(){
    // Function to retrive the Values from the DB When the Business Group Filter Changes to Populate the Segment Values and Billing Group

       let  obj ={groupSelected:this.form.value.cGroups};
       let result = await this._filtersApiService.changeFilters(obj).subscribe((e:any)=>{
         console.log(e);
         this.Filters.customerBillingPeriod = e.customerBillingPeriod
         this.Filters.segmentList = e.segmentList;
        });
       }

       selectedItem:any=[];
       onSelect(event:any){
         console.log(event)
         this.selectedItem.push(event.customer_grp_cd)
        console.log(this.selectedItem)
      }

      onUnselect(event:any) {
        this.selectedItem = this.selectedItem.filter((each: string) => each !== event.customer_grp_cd);
      }

  onClickGeneratePDFFile(filename: string):void{

    this.spinner.show();
    let data2 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data2?data2:"")
    this.reportFilters.userLoginCd=userData.globalLogonUsers.user_login_cd;
    this.reportFilters.billingPeriod=this.form.value.bPeriod;
    this.reportFilters.originatingSystem=this.form.value.oSystem;
    //this.reportFilters.enteredValue ='';
    //Canned - Maintenance Reports
    if(this.reportCategory=='MaintenanceReports'){
    if(this.selectedReportType=='AllCustomerQDSOByLF')
       {
        this.reportFilters.reportStatus='LF';
        this.reportfilename='AllCustomerQ_DSObyGrpNRgn_LF.pdf';
       }
       else if(this.selectedReportType=='AllCustomerQDSOByLFW') {
        this.reportFilters.reportStatus='LFW';
        this.reportfilename='AllCustomerQ_DSObyGrpNRgn_LFW.pdf';
       }
      }
      //Canned - Management Reports
      else if(this.reportCategory=='ManagementReports'){
        debugger;
      //  console.log(this.selectedCustomerItem);
      this.reportFilters.customerClause=this.selectedItem;

      // this.filters.customerGrpCd=this.selectedSingleCustomerItem.customer_grp_cd;
        this.reportFilters.originatingCompanyCdClause = this.form.value.regGroup;//userData.globalLogonUsers.region;
       let statusClause = [];
        if (this.form.controls['FINAL'].value == true) {
          statusClause.push('FINAL');
        }
        if (this.form.controls['LIVE'].value == true) {
          statusClause.push('LIVE');
        }
        if (this.form.controls['WROFF'].value == true) {
          statusClause.push('WR-OFF');
        }
        this.reportFilters.statusClause = statusClause;
        this.reportFilters.exclusions = this.form.controls['Exclusions'].value == null || this.form.controls['Exclusions'].value == undefined ? "" : this.form.controls['Exclusions'].value;
        this.reportFilters.exclusionClass = this.form.value.accClass == "" || this.form.value.accClass == null || this.form.value.accClass == undefined ? [] : this.form.value.accClass;
        this.reportFilters.customerChidFlag=0;
        this.reportFilters.groupSelected=this.form.value.cGroups;

      //this.filters.deniedDispSelected=this.form.value.deniedDisp;
        this.reportFilters.segment=this.form.value.sList;
      //Customer Reports
       if(this.selectedReportType=='ManagementCustomerReportByAccountNumber') {
        this.reportFilters.disputeInterval=this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportByAccountNumber';
        this.reportfilename='Customer Report by Account Level Detail by Account Number.pdf';
       }
       else if(this.selectedReportType=='ManagementCustomerReportByBillName') {
        this.reportFilters.disputeInterval=this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportByBillName';
        this.reportfilename='Customer Report by Account Level Detail by Bill Name.pdf';
       }
       else if(this.selectedReportType=='ManagementCustomerReportBySegment') {
        this.reportFilters.disputeInterval=this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportBySegment';
        this.reportfilename='Customer Report by Account Level Detail by Region Segment.pdf';
       }
       else if(this.selectedReportType=='ManagementCustomerReportBySegmentStatus') {
        this.reportFilters.disputeInterval=this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportBySegmentStatus';
        this.reportfilename='Customer Report by Account Level Detail by Segment Status.pdf';
       }
       else if(this.selectedReportType=='ManagementCustomerReportByState') {
        this.reportFilters.disputeInterval=this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportByState';
        this.reportfilename='Customer Report by Account Level Detail by Region State.pdf';
       }
       else if(this.selectedReportType=='ManagementCustomerReportByStateSegment') {
        this.reportFilters.disputeInterval=this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportByStateSegment';
        this.reportfilename='Customer Report by Account Level Detail by Region State Segment.pdf';
       }
      //Region Reports
       else if(this.selectedReportType=='ManagementRegionReportByCustomer') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportByCustomer';
        this.reportfilename='Region Report by Region Customer.pdf';
       }
       else if(this.selectedReportType=='ManagementRegionReportBySegment') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportBySegment';
        this.reportfilename='Region Report by Region Segment.pdf';
       }
       else if(this.selectedReportType=='ManagementRegionReportBySegmentCustomer') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportBySegmentCustomer';
        this.reportfilename='Region Report by Region Segment Customer.pdf';
       }
       else if(this.selectedReportType=='ManagementRegionReportByState') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportByState';
        this.reportfilename='Region Report by Region State.pdf';
       }
       else if(this.selectedReportType=='ManagementRegionReportByStateCustomer') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportByStateCustomer';
        this.reportfilename='Region Report by Region State Customer.pdf';
       }
       else if(this.selectedReportType=='ManagementRegionReportByStateSegment') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportByStateSegment';
        this.reportfilename='Region Report by Region State Segment.pdf';
       }
       //Segment Reports
       else if(this.selectedReportType=='ManagementSegmentReportBySegmentCustomer') {
        this.reportFilters.selectedReportType='ManagementSegmentReportBySegmentCustomer';
        this.reportFilters.disputeInterval='';
        this.reportfilename='Segment Report by Segment Customer.pdf';
       }
       else if(this.selectedReportType=='ManagementSegmentReportBySegmentRegionCustomer') {
        this.reportFilters.selectedReportType='ManagementSegmentReportBySegmentRegionCustomer';
        this.reportfilename='Segment Report by Segment Region Customer.pdf';
       }
        //Summary Reports
        else if(this.selectedReportType=='ManagementSummaryReportByCustomer') {
          this.reportFilters.selectedReportType='ManagementSummaryReportByCustomer';
          this.reportfilename='Summary By Customer.pdf';
         }
         else if(this.selectedReportType=='ManagementSummaryReportByCustomerStatus') {
          this.reportFilters.selectedReportType='ManagementSummaryReportByCustomerStatus';
          this.reportfilename='Summary By Customer Status.pdf';
         }
         else if(this.selectedReportType=='ManagementSummaryReportBySegment') {
          this.reportFilters.selectedReportType='ManagementSummaryReportBySegment';
          this.reportfilename='Summary By Segment.pdf';
         }
         else if(this.selectedReportType=='ManagementSummaryReportByState') {
          this.reportFilters.selectedReportType='ManagementSummaryReportByState';
          this.reportfilename='Summary By State.pdf';
         }
      }
      else{
        this.reportFilters.selectedReportType='';
        this.reportfilename='';

      }
     //API call to download Pdf file
      this.reportingService.getDetailsInPDFFile(this.reportFilters,this.selectedReportType)
      .subscribe((blob:any)=>{
        this.spinner.hide();
        saveAs(blob, this.reportfilename);
      });
      }




  onClickGenerateExcelSheet(filename: string):void{

    this.spinner.show();
    let data2 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data2?data2:"")
    this.reportFilters.userLoginCd=userData.globalLogonUsers.user_login_cd;
    this.reportFilters.billingPeriod=this.form.value.bPeriod;
    this.reportFilters.originatingSystem=this.form.value.oSystem;
   //Canned - Maintainance Reports
   if(this.reportCategory=='MaintenanceReports'){

    if(this.selectedReportType=='AllCustomerQDSOByLF')
       {
        this.filters.reportStatus='LF';
        this.reportfilename='AllCustomerQ_DSObyGrpNRgn_LF.xlsx';
       }
       else if(this.selectedReportType=='AllCustomerQDSOByLFW') {
        this.filters.reportStatus='LFW';
        this.reportfilename='AllCustomerQ_DSObyGrpNRgn_LFW.xlsx';
       }
      }
      //Canned - Management Reports
      else if(this.reportCategory=='ManagementReports'){
        debugger;
        console.log(this.selectedItem);
        this.reportFilters.customerClause=this.selectedItem;
        this.reportFilters.originatingCompanyCdClause = this.form.value.regGroup;//userData.globalLogonUsers.region;
       let statusClause = [];
        if (this.form.controls['FINAL'].value == true) {
          statusClause.push('FINAL');
        }
        if (this.form.controls['LIVE'].value == true) {
          statusClause.push('LIVE');
        }
        if (this.form.controls['WROFF'].value == true) {
          statusClause.push('WR-OFF');
        }
        this.reportFilters.statusClause = statusClause;
        this.reportFilters.exclusions = this.form.controls['Exclusions'].value == null || this.form.controls['Exclusions'].value == undefined ? "" : this.form.controls['Exclusions'].value;
        this.reportFilters.exclusionClass = this.form.value.accClass == "" || this.form.value.accClass == null || this.form.value.accClass == undefined ? [] : this.form.value.accClass;
        this.reportFilters.customerChidFlag=0;
        this.reportFilters.groupSelected=this.form.value.cGroups;

     // this.filters.deniedDispSelected=this.form.value.deniedDisp;
        this.reportFilters.segment=this.form.value.sList;
      //Customer Reports
       if(this.selectedReportType=='ManagementCustomerReportByAccountNumber') {
        this.reportFilters.disputeInterval=  this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportByAccountNumber';
        this.reportfilename='Customer Report by Account Level Detail by Account Number.xlsx';
       }
       else if(this.selectedReportType=='ManagementCustomerReportByBillName') {
        this.reportFilters.disputeInterval=  this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportByBillName';
        this.reportfilename='Customer Report by Account Level Detail by Bill Name.xlsx';
       }
       else if(this.selectedReportType=='ManagementCustomerReportBySegment') {
        this.reportFilters.disputeInterval=  this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportBySegment';
        this.reportfilename='Customer Report by Account Level Detail by Segment.xlsx';
       }
       else if(this.selectedReportType=='ManagementCustomerReportBySegmentStatus') {
        this.reportFilters.disputeInterval=  this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportBySegmentStatus';
        this.reportfilename='Customer Report by Account Level Detail by Segment Status.xlsx';
       }
       else if(this.selectedReportType=='ManagementCustomerReportByState') {
        this.reportFilters.disputeInterval=  this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportByState';
        this.reportfilename='Customer Report by Account Level Detail by State.xlsx';
       }
       else if(this.selectedReportType=='ManagementCustomerReportByStateSegment') {
        this.reportFilters.disputeInterval=  this.form.value.deniedDisp;
        this.reportFilters.selectedReportType='ManagementCustomerReportByStateSegment';
        this.reportfilename='Customer Report by Account Level Detail by State Segment.xlsx';
       }

      //Region Reports
       else if(this.selectedReportType=='ManagementRegionReportByCustomer') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportByCustomer';
        this.reportfilename='Region Report by Region Customer.xlsx';
       }
       else if(this.selectedReportType=='ManagementRegionReportBySegment') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportBySegment';
        this.reportfilename='Region Report by Region Segment.xlsx';
       }
       else if(this.selectedReportType=='ManagementRegionReportBySegmentCustomer') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportBySegmentCustomer';
        this.reportfilename='Region Report by Region Segment Customer.xlsx';
       }
       else if(this.selectedReportType=='ManagementRegionReportByState') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportByState';
        this.reportfilename='Region Report by Region State.xlsx';
       }
       else if(this.selectedReportType=='ManagementRegionReportByStateCustomer') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportByStateCustomer';
        this.reportfilename='Region Report by Region State Customer.xlsx';
       }
       else if(this.selectedReportType=='ManagementRegionReportByStateSegment') {
        this.reportFilters.disputeInterval='';
        this.reportFilters.selectedReportType='ManagementRegionReportByStateSegment';
        this.reportfilename='Region Report by Region State Segment.xlsx';
       }
       //Segment Reports
       else if(this.selectedReportType=='ManagementSegmentReportBySegmentCustomer') {
        this.reportFilters.selectedReportType='ManagementSegmentReportBySegmentCustomer';
        this.reportfilename='Segment Report by Segment Customer.xlsx';
       }
       else if(this.selectedReportType=='ManagementSegmentReportBySegmentRegionCustomer') {
        this.reportFilters.selectedReportType='ManagementSegmentReportBySegmentRegionCustomer';
        this.reportfilename='Segment Report by Segment Region Customer.xlsx';
       }
       //Summary Reports
       else if(this.selectedReportType=='ManagementSummaryReportByCustomer') {
        this.reportFilters.selectedReportType='ManagementSummaryReportByCustomer';
        this.reportfilename='Summary By Customer.xlsx';
      }
      else if(this.selectedReportType=='ManagementSummaryReportByCustomerStatus') {
        this.reportFilters.selectedReportType='ManagementSummaryReportByCustomerStatus';
        this.reportfilename='Summary By Customer Status.xlsx';
       }
       else if(this.selectedReportType=='ManagementSummaryReportBySegment') {
        this.reportFilters.selectedReportType='ManagementSummaryReportBySegment';
        this.reportfilename='Summary By Segment.xlsx';
       }
       else if(this.selectedReportType=='ManagementSummaryReportByState') {
        this.reportFilters.selectedReportType='ManagementSummaryReportByState';
        this.reportfilename='Summary By State.xlsx';
       }
      }
      else{
        this.reportFilters.selectedReportType='';
        this.reportfilename='';
      }
     //API call to download Excel file
      this.reportingService.getDetailsInExcelFile(this.reportFilters,this.selectedReportType)
      .subscribe((blob:any)=>{
        this.spinner.hide();
        saveAs(blob, this.reportfilename);
      });

      }


  onSelectionCustomerOrCTCChange(x:any){
      let data =localStorage.getItem("userInfo");
      this.Filters = JSON.parse(data?data:"");
      let userData = JSON.parse(data?data:"")
      let populateInput:any={};
      populateInput.userLoginCd=userData.globalLogonUsers.user_login_cd;
      populateInput.appName = 'ARMS Application';
      populateInput.environment= 'Pre-Production';
      // /populateInput.groupSelected=["OMB"];

      if(x == 0){
        console.log("********Selected Customer Radio Button******")
        this.autoCompleteShow=true;
        this.superRadioButton="Customer";

    //API call to fetch Customer Details

    this.reportingService.allCustomerDetails(data).subscribe((customers_data:any)=>{
      this.customersPopulateDataList=customers_data?customers_data.CustomerInfo:"";
      this.rowData = customers_data.CustomerInfo;
      this.columnDefs = this.columnDefsANMR;

       });
      }
      else{
        console.log("********Selected CTC Radio Button******")
        this.autoCompleteShow=false;
    //API call to fetch CTC Details
    this.superRadioButton="CTC";

    this.reportingService.allCTCDetails(populateInput).subscribe((ctc_data:any)=>{
    //this.ctcPopulateDataList=ctc_data?ctc_data.childTieCodeDetails:"";
    this.rowData = ctc_data.childTieCodeDetails;
    this.columnDefs = this.ctc_columnDefsANMR;


     });


      }
      }

    /*  onSelectionAllMultipleSingleChange(y:any){
        switch (y){
        case 2:{
          console.log("********Selected All Radio Button******")
          this.autoCompleteShow=true;
          this.multipleAllow=false;
          break;
        }
        case 3:{

          console.log("********Selected Multiple Radio Button******")
          this.autoCompleteShow=false;
          this.multipleAllow=false;
          break;
        }
        case 4:{

          console.log("********Selected Single Radio Button******")
          this.autoCompleteShow=false;
          this.multipleAllow=true;
          break;
        }
        default:
          {
        }
      }
    }*/
    onSelectionAllMultipleSingleChange(y:any){
      this.form.patchValue({
        customerItem: []
      });
      this.selectedItem = [];
      if(y==2){
        console.log("********Selected Multiple Radio Button******")
        this.autoCompleteShow=false;
        this.multipleAllow=true;
      }
      else if(y==3){
        console.log("********Selected Single Radio Button******")
        this.autoCompleteShow=false;
        this.multipleAllow=false;
      }
      else{
        this.autoCompleteShow=true;
        this.multipleAllow=true;

      }
    }



    searchItems(event: any){
      console.log("***MultipleAllow: "+this.multipleAllow);

      console.log(event.query);
      this.filters.enteredValue = event.query;
      let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    //this.filters.region = userData.globalLogonUsers.region;
    this.filters.userLoginCd=userData.globalLogonUsers.user_login_cd;
    this.filters.customerGrpCd="";
    this.filters.exclusions="Included Accounts";
    this.filters.groupSelected=this.form.value.cGroups;
    this.filters.billingPeriod=this.form.value.bPeriod;
    this.filters.customerType=0;

    if(this.superRadioButton=="Customer")
    {
        this.reportingService.reportsAutoSearchCustomer(this.filters).subscribe((data: any) => {
        this.filteredItems = data["All Customers"];
      });
    }
    else if(this.superRadioButton=="CTC"){
      this.filters.tabType=5;
      this.reportingService.reportsAutoSearchACNACustomer(this.filters).subscribe((data: any) => {
        this.filteredItems = data["CTC"];
      });
    }
    }

addStyleToSelectedItem(event:any) {
  this.items[0].items[0].items.forEach((firstItem: any) => {
    firstItem.items.forEach((secondItem: any) => {
      if (secondItem.style) {
        secondItem.style= {};
      } else {
        if (secondItem.items) {
          secondItem.items.forEach((thirdItem: any) => {
            if (thirdItem.style) {
              thirdItem.style = {};
            }
          })
        }
      }
    })
  });
  event.item.style={border: '2px solid var(--blue-200)'};
}

onLeftPannelSelection(e: any){
  // Whenever a radio button is selected, update the selection mode of the ListBox
  switch (e){
    case 1:{
      console.log("********Selected Maintainance Report1******");

      this.reportCategory="MaintenanceReports";
      this.selectedReportType = "AllCustomerQDSOByLF";

      break;
    }
   case 2:
      {

        this.reportCategory="MaintenanceReports";
        this.selectedReportType = "AllCustomerQDSOByLFW";
        console.log("********Selected Maintainance Report2******");

      break;
      }
    case 3:
     {
        console.log("********Selected Maintainance Report3******");
        this.reportCategory="MaintananceReports";
        this.selectedReportType = "Mnt_Rep3";
        this.importDateShow=false;
        break;
    }
      case 4:{
        console.log("********Selected Maintainance Report4******");

        this.reportCategory="MaintananceReports";
        this.selectedReportType = "Mnt_Rep4";

        break;
      }
        case 5:{
          console.log("********Selected Maintainance Report5******");
          this.isShown=this.isShown;
          this.reportCategory="MaintananceReports";

          break;
        }
        case 6:{
          console.log("********Selected Management-Customer Report6******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementCustomerReportByAccountNumber";
          break;
        }
        case 7:{
          console.log("********Selected Management-Customer Report7******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementCustomerReportByBillName";
          break;
        }
        case 8:{
          console.log("********Selected Management-Customer Report8******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementCustomerReportBySegment";
          break;
        }
        case 9:{
          console.log("********Selected Management-Customer Report9******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementCustomerReportBySegmentStatus";
          break;
        }
        case 10:{
          console.log("********Selected Management-Customer Report10******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementCustomerReportByState";
          break;
        }
        case 11:{
          console.log("********Selected Management-Customer Report11******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementCustomerReportByStateSegment";
          break;
        }
        case 18:{
          console.log("********Selected Management-Region Report18******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementRegionReportByCustomer";
          break;
        }
        case 19:{
          console.log("********Selected Management-Region Report19******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementRegionReportBySegment";
          break;
        }
        case 20:{
          console.log("********Selected Management-Region Report20******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementRegionReportBySegmentCustomer";
          break;
        }
        case 21:{
          console.log("********Selected Management-Region Report21******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementRegionReportByState";
          break;
        }
        case 22:{
          console.log("********Selected Management-Region Report22******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementRegionReportByStateCustomer";
          break;
        }
        case 23:{
          console.log("********Selected Management-Region Report23******");
          this.isShown=this.isShown;
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementRegionReportByStateSegment";
          break;
        }
        case 24:{
          console.log("********Selected Management-Segment Report24******");
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementSegmentReportBySegmentCustomer";
          break;
        }
        case 25:{
          console.log("********Selected Management-Segment Report25******");
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementSegmentReportBySegmentRegionCustomer";
          break;
        }
        case 26:{
          console.log("********Selected Management-Summary Report26******");
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementSummaryReportByCustomer";
          break;
        }
        case 27:{
          console.log("********Selected Management-Summary Report27******");
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementSummaryReportByCustomerStatus";
          break;
        }
        case 28:{
          console.log("********Selected Management-Summary Report28******");
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementSummaryReportBySegment";
          break;
        }
        case 29:{
          console.log("********Selected Management-Summary Report29******");
          this.reportCategory="ManagementReports";
          this.selectedReportType = "ManagementSummaryReportByState";
          break;
        }
        default:{
          console.log("********Default Report******");
          this.selectedReportType = "Def_Rep";
          break;
    }

  }
  }

  enableDisableFilters(e:any, event: any)
  {
    this.addStyleToSelectedItem(event);
    this.selectedItem = [];
    this.form.reset();
  if(e==1||e==2||e==4||e==5){
    this.exclusionShow = false;
    this.excShow = false;
    this.regionShow = false;
    this.groupShow = false;
    this.deniedDispShow=false;
    this.originatingSystemShow=true;
    this.segmentShow=false;
    this.statusShow=false;
    this.finalShow=false;
    this.liveShow=false;
    this.writeOffShow=false;
    this.radioButtonShow=false;
    this.billingPeriodShow=true;
    this.filterCriteriaShow = false;
  }
  else if(e==3||e==6||e==7||e==8||e==9||e==10||e==11||e==18||e==19||e==20||e==21||e==22||e==23||e==24||e==25||e==26||e==27||e==28||e==29){
    this.exclusionShow = true;
        this.excShow = true;
        this.regionShow = true;
        this.groupShow = true;
        this.deniedDispShow=true;
        this.originatingSystemShow=true;
        this.segmentShow=true;
        this.statusShow=true;
        this.finalShow=true;
        this.liveShow=true;
        this.writeOffShow=true;
        this.radioButtonShow=true;
        this.billingPeriodShow=true;
        this.filterCriteriaShow = true;
  }


}

clickNewButton() {
  this.disableControl = false;
}

getPickListTargetSelectedItem(event: any) {
  this.tempSelectedTargetItem = event.items[0].english_name; 
}

clickCopyFromTarget() {
  if (this.radioValue === 'groupBy') {
    this.sourceProducts_groupBy.forEach((each: any) => {
      if (each.english_name === this.tempSelectedTargetItem) {
        each.isDisplay = true;
      }
    });
  } else {
    this.sourceProducts_sortBy.forEach((each: any) => {
      if (each.english_name === this.tempSelectedTargetItem) {
        each.isDisplay = true;
      }
    });
  }
}

clickedListItem(product: any, type: string) {
  if (type === 'groupBy') {
    this.sourceProducts_groupBy.forEach((each: any) => {
      if (each.english_name === product.english_name) {
        each.isSelected = true;
      } else {
        each.isSelected = false;
      }
    });
  } else {
    this.sourceProducts_sortBy.forEach((each: any) => {
      if (each.english_name === product.english_name) {
        each.isSelected = true;
      } else {
        each.isSelected = false;
      }
    });
  }
}

moveBackToSource(event: any) {
  this.tempSelectedTargetItem = '';
  this.sourceProducts_groupBy.forEach((each: any) => {
    if (each.english_name === event.items[0].english_name) {
      each.isDisplay = false;
      each.isSelected = false;
    }
  });
  this.sourceProducts_sortBy.forEach((each: any) => {
    if (each.english_name === event.items[0].english_name) {
      each.isDisplay = false;
      each.isSelected = false;
    }
  });
}

removeSelected() {
  if(this.radioValue === 'groupBy') {
    this.sourceProducts_groupBy.forEach((each: any) => {
      if (each.isSelected) {
        each.isDisplay = false;
        each.isSelected = false;
      }
    });
  } else {
    this.sourceProducts_sortBy.forEach((each: any) => {
      if (each.isSelected) {
        each.isDisplay = false;
        each.isSelected = false;
      }
    });
  }
}

changeRadioEvent(event: any) {
  this.radioValue = event.value;
}

  onClickHelp(){
    window.open("https://peoria.web.att.com/business/Wholesale/enterprise/jobaids/armsja.htm#cust_query_bk");
  }

  saveTemplateReport() {
    const status: string[] = [];
    if(this.form.get('LIVE').value) {
      status.push('LIVE');
    }
    if(this.form.get('FINAL').value) {
      status.push('FINAL');
    }
    if(this.form.get('WROFF').value) {
      status.push('WROFF');
    }
    const saveFormData = {
      userLoginCd:'SD886W',
      reportType:this.clickOnTemplate ? 'T':'C',
      reportName:this.form.get('templateName').value,
      updatedType:'I',
      exclusions:this.form.get('Exclusions').value,
      billingPeriod:this.form.get('bPeriod').value,
      customerChildFlag:this.selectedFilterCriteria,
      exclusionClass:this.form.get('accClass').value.map((each: any) => {
        const acntClassification = this.Filters.accountsClassificationList.filter((acnt: any) => acnt.class_cd === each);
        return acntClassification[0].class_desc;
      }),
      originatingSystem:this.form.get('oSystem').value,
      groupSelected:this.form.get('cGroups').value,
      statusClause:status,
      segment:this.form.get('sList').value,
      templateSelectedFields:this.targetProducts.map((each: any) => each.english_name),
      groupByFields:this.sourceProducts_groupBy.filter((each: any) => each.isDisplay)
      .map((each: any) => each.english_name),
      sortByFields:this.sourceProducts_sortBy.filter((each: any) => each.isDisplay)
      .map((each: any) => each.english_name),
      sortOrder:this.form.get('sortType').value ? 'DESC':'ASC',
      criteriaClause:[],
      originatingCompanyCdClause:this.form.get('regGroup').value,
      customerGrpCd:this.form.get('customerItem').value.map((each: any) => each.customer_grp_cd)
    }

    const selectedFormData = {
      userLoginCd:'SD886W',
      reportType:this.clickOnTemplate ? 'T':'C',
      reportName:this.form.get('templateName').value
    }

    this.reportingService.saveTemplateReport(saveFormData).subscribe(response => {
      this.items[0].items[1].items.push({
        label: this.form.get('templateName').value,
        icon: 'pi pi-fw pi-user-plus',
        command: (event:any) => {
          this.reportingService.selectedTemplateCriteria(selectedFormData).subscribe(resp => 
            console.log(resp));
        }
      });
      this.items = [...this.items];
    });
  }

  deleteTemplateReport() {
    const formData = {
      userLoginCd:'SD886W',
      reportType:this.clickOnTemplate ? 'T':'C',
      updatedType:'U',
      reportName:this.form.get('templateName').value,
    }

    this.reportingService.deleteTemplateReport(formData).subscribe(response => {
      
    });
  }
}



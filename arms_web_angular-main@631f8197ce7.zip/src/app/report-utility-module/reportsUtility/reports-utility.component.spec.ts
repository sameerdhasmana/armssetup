import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsUtilityComponent } from './reports-utility.component';

describe('ReportUtilityComponent', () => {
  let component: ReportsUtilityComponent;
  let fixture: ComponentFixture<ReportsUtilityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsUtilityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsUtilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

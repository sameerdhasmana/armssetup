import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportsUtilityComponent } from './reportsUtility/reports-utility.component';
import { MaterialModule } from '../material/material.module';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { NgxSpinnerModule } from 'ngx-spinner';
import { PickListModule } from 'primeng/picklist';


@NgModule({
  declarations: [
    ReportsUtilityComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    AgGridModule,
    BrowserAnimationsModule,
    RouterModule,
    FormsModule, ReactiveFormsModule,
    AutoCompleteModule,
    NgxSpinnerModule,
    PickListModule
  ]
})
export class ReportUtilityModule { }

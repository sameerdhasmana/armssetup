import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TemploginComponent } from "./templogin/templogin.component";
import { FilterCriteriaComponent } from "./filtersCriteria/filter-criteria.component";
import { ReportsUtilityComponent } from "./report-utility-module/reportsUtility/reports-utility.component";
import { MessageMaintenanceComponent } from './TableMaintenance/message-maintenance/message-maintenance.component';
import { CustomerusageComponent } from './TableMaintenance/customerusage/customerusage.component';
import { ACNAMaintenanceComponent } from './TableMaintenance/acna-maintenance/acna-maintenance.component';
import { AECNMaintenanceComponent } from './TableMaintenance/aecn-maintenance/aecn-maintenance.component';
import { SegmentMaintenacneComponent } from './TableMaintenance/segment-maintenacne/segment-maintenacne.component';
import { SubActMaintenacneComponent } from './TableMaintenance/sub-act-maintenacne/sub-act-maintenacne.component';
import { CustomerMaintenacneComponent } from './TableMaintenance/customer-maintenacne/customer-maintenacne.component';
import { Xref3MaintenacneComponent } from './TableMaintenance/xref3-maintenacne/xref3-maintenacne.component';
import { Xref3HistoryComponent } from './TableMaintenance/xref3-history/xref3-history.component';
import { UserAdminReportsComponent } from './UserAdministration/user-admin-reports/user-admin-reports.component';
import { RoleTaskAssignmentComponent } from './UserAdministration/user-role-task-assignment/role-task-assignment.component';
import { UserReportHierarchyComponent } from './UserAdministration/user-report-hierarchy/user-report-hierarchy.component';
import { UserMaintenanceComponent } from './UserAdministration/user-maintenance/user-maintenance.component';
import { LoginErrorComponent } from './ErrorPages/login-error/login-error.component';
import { UnauthorizedComponent } from './ErrorPages/unauthorized/unauthorized.component';
import { AuthGuard } from './services/core/auth.guard';
import { UnderDevComponent } from './ErrorPages/under-dev/under-dev.component';
import { ContactsComponent } from './maintenance/contacts/contacts.component';
import { AcctAPSubGroupComponent } from './maintenance/acct-apsub-group/acct-apsub-group.component';
import { CustomerTransferComponent } from './transfer/customer-transfer/customer-transfer.component';
import { NotesTransferComponent } from './transfer/notes-transfer/notes-transfer.component';
import { ManageTemplatesComponent } from './maintenance/manage-templates/manage-templates.component';
import { OutstandingReportComponent } from './management/outstanding-report/outstanding-report.component';
import { OpenFlagReportComponent } from './management/open-flag-report/open-flag-report.component';
import { PaymentTermsComponent } from './management/payment-terms/payment-terms.component';
import { CreateLetterProfileComponent } from './TableMaintenance/letter-profile/create-letter-profile/create-letter-profile.component';
import { ModifyLetterProfileComponent } from './TableMaintenance/letter-profile/modify-letter-profile/modify-letter-profile.component';
import { DeleteLetterProfileComponent } from './TableMaintenance/letter-profile/delete-letter-profile/delete-letter-profile.component';
import { RoleGuard } from './services/core/role-guard.guard';
import { RoleAuthErrorComponent } from './ErrorPages/role-auth-error/role-auth-error.component';
import { EnvGuard } from './services/core/env-guard';
import { EnvAuthErrorComponent } from './ErrorPages/env-auth-error/env-auth-error.component';
import { ManageProfilesComponent } from './manage-profiles/manage-profiles.component';
import { InvalidSessionComponent } from './ErrorPages/invalid-session/invalid-session.component';
import { AccessGuard } from './services/core/access.guard';
import { NotesActivityReportComponent } from './management/notes-activity-report/notes-activity-report.component';
import { NotesActivityManagerReportComponent } from './management/notes-activity-manager-report/notes-activity-manager-report.component';
import { CustApsubGroupComponent } from './maintenance/cust-apsub-group/cust-apsub-group.component';



const routes: Routes = [

  {path:'loginUser',component:TemploginComponent},
  {path:'loginUser?userLoginCd=',component:TemploginComponent},
  {path:'query',component:FilterCriteriaComponent,canActivate:[AccessGuard]},
  {path:'reportsUtility',component:ReportsUtilityComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'messagemaintenace',component:MessageMaintenanceComponent,canActivate:[AuthGuard,AccessGuard,EnvGuard],
  data: {
    expectedRoles : ['16','32','512'], expectedEnv : ['ARMS6450cZv3421']
  }},
  {path:'customerusage',component:CustomerusageComponent,canActivate:[AuthGuard,AccessGuard,EnvGuard],
  data: {
    expectedRoles : ['16','32','512'], expectedEnv : ['ARMS6450cZv3421']
  }},
  {path:'ACNAMaintenance', component:ACNAMaintenanceComponent,canActivate:[AuthGuard,AccessGuard,EnvGuard],
  data: {
    expectedRoles : ['16','32','512'], expectedEnv : ['ARMS6450cZv3421']
  }},
  {path:'AECNMaintenance', component:AECNMaintenanceComponent,canActivate:[AuthGuard,AccessGuard,EnvGuard],
  data: {
    expectedRoles : ['16','32','512'], expectedEnv : ['ARMS6450cZv3421']
  }},
  {path:'SegMaintenance',component:SegmentMaintenacneComponent,canActivate:[AuthGuard,AccessGuard,EnvGuard],
  data: {
    expectedRoles : ['16','32','512'], expectedEnv : ['ARMS6450cZv3421']
  }},
  {path:'SubActMaintenance', component:SubActMaintenacneComponent,canActivate:[AuthGuard,AccessGuard,EnvGuard],
  data: {
    expectedRoles : ['16','32','512'], expectedEnv : ['ARMS6450cZv3421']
  }},
  {path:'CustomerMaintenance',component:CustomerMaintenacneComponent,canActivate:[AuthGuard,AccessGuard,EnvGuard],
  data: {
    expectedRoles : ['16','32','512'], expectedEnv : ['ARMS6450cZv3421']
  }},
  {path:'Xref3-Maintenance', component:Xref3MaintenacneComponent,canActivate:[AuthGuard,AccessGuard,EnvGuard],
  data: {
    expectedRoles : ['16','32','512'], expectedEnv : ['ARMS6450cZv3421']
  }
},
  {path:'Xref3-History',component:Xref3HistoryComponent,canActivate:[AuthGuard,AccessGuard,EnvGuard],
  data: {
    expectedRoles : ['16','32','512'], expectedEnv : ['ARMS6450cZv3421']
  }},
  {path:'user-admin-reports', component:UserAdminReportsComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'user-role-task-assignments', component:RoleTaskAssignmentComponent,canActivate:[AuthGuard,AccessGuard]},
  {path: 'user-report-hierarchy', component:UserReportHierarchyComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'user-maintenance', component:UserMaintenanceComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'error401', component:LoginErrorComponent},
  {path:'noRoleError401', component:RoleAuthErrorComponent},
  {path:'preProdError401', component:EnvAuthErrorComponent},
  {path:'error404', component:UnauthorizedComponent},
  {path:'invalidSession', component:InvalidSessionComponent},
  {path:'inprogress',component:UnderDevComponent},
  {path:'contacts', component:ContactsComponent, canActivate:[AuthGuard,AccessGuard] },
  {path:'Account-AP-SubGroup',component:AcctAPSubGroupComponent,canActivate:[AuthGuard,AccessGuard] },
  {path:'Customer-AP-SubGroup',component:CustApsubGroupComponent,canActivate:[AuthGuard,AccessGuard] },
  {path:'customer-transfer',component:CustomerTransferComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'notes-transfer',component:NotesTransferComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'Manage-Templates-Notes',component:ManageTemplatesComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'Reporting-Utility',component:ReportsUtilityComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'OutstandingBringupReport',component:OutstandingReportComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'OpenFlagActivityReport',component:OpenFlagReportComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'PaymentTerms',component:PaymentTermsComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'CreateLetterProfile',component:CreateLetterProfileComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'ModifyLetterProfile',component:ModifyLetterProfileComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'DeleteLetterProfile',component:DeleteLetterProfileComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'ManageProfiles',component:ManageProfilesComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'Notes-Activity-Report',component:NotesActivityReportComponent,canActivate:[AuthGuard,AccessGuard]},
  {path:'Notes-Activity-Managers-Report',component:NotesActivityManagerReportComponent,canActivate:[AuthGuard,AccessGuard]},


  {path:'',component:TemploginComponent},
  {path:'#',component:FilterCriteriaComponent,canActivate:[AuthGuard]},
  //{path:'#',component:ReportsUtilityComponent,canActivate:[AuthGuard]},
  {path:'**',component:UnauthorizedComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }

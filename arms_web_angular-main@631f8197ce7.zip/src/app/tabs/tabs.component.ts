import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { SharedService } from '../services/shared.service';


@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss'],
  encapsulation : ViewEncapsulation.None
})
export class TabsComponent implements OnInit {

  radioList = [
    { "name": "All" , "value" :0},
    { "name": "My Customers","value" :1},
    { "name": "Customer Bring Ups","value" :2},
    { "name": "Account Bring Ups","value" :3}
]
 activeTab:string = "Customer";
 selectedRadio = this.radioList[0].value;
 selectedIndex:any;
 tabindex:any=0;
  constructor( private sharedService: SharedService) { }
  ngAfterViewInit(): void {
     this.sharedService.setfilterData({"customerType":this.selectedRadio})
      let chkFromHeaderForTabs = localStorage.getItem('chkFromHeaderForTabs');
        if(chkFromHeaderForTabs=="1"){
          let epdata = localStorage.getItem('executeFilterData');
          this.ExecuteProfileRsp=JSON.parse(epdata ? epdata : '');
          if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="cust"){
            this.tabindex = 0;
            this.setTab(1,"Customer",0);
          }
          else if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="acna"){
            this.tabindex = 1;
            this.setTab(2,"ACNA",1);
          }
          else if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="aecn"){
            this.tabindex = 2;
            this.setTab(3,"AECN",2);
          }
          else if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="ocn"){
            this.tabindex = 3;
            this.setTab(4,"OCN",3);
          }
          else if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="ctc"){
            this.tabindex = 4;
            this.setTab(5,"CTC",4);
          }
          localStorage.setItem('chkFromHeaderForTabs', "0");
      }
  }

  onSelectionChange(value:any): void{

    this.sharedService.setfilterData({"customerType":value});

  }
  ExecuteProfileRsp :any={};
  ngOnInit(){
    this.sharedService.filtersDataFromProfile$.subscribe((data) => {
      let chkFromHeaderForTabs = localStorage.getItem('chkFromHeaderForTabs');
        if(chkFromHeaderForTabs=="1"){
          let epdata = localStorage.getItem('executeFilterData');
          this.ExecuteProfileRsp=JSON.parse(epdata ? epdata : '');
          if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="cust"){
            this.tabindex = 1;
            this.setTab(1,"Customer",0);
          }
          else if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="acna"){
            this.tabindex = 1;
            this.setTab(2,"ACNA",1);
          }
          else if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="aecn"){
            this.tabindex = 2;
            this.setTab(3,"AECN",2);
          }
          else if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="ocn"){
            this.tabindex = 3;
            this.setTab(4,"OCN",3);
          }
          else if(this.ExecuteProfileRsp.profileDetails.profileQueryType=="ctc"){
            this.tabindex = 4;
            this.setTab(5,"CTC",4);
          }
          //localStorage.setItem('chkFromHeaderForAutoSearch', "0");
      }
      });

  }

  setTab(selectedIndex:any,activeTab:any,tab:any){
        this.tabindex = tab;
        //console.log(event.index);
        this.selectedIndex=selectedIndex;
        //console.log(this.selectedIndex);
       this.activeTab =activeTab;
       this.sharedService.setSelectedTab(this.activeTab);
       //this.sharedService.setSelectedIndex(this.selectedIndex);
       this.sharedService.setfilterData({"tabType":this.selectedIndex});
  }

  onTabSelect(event:any):any{
    //console.log(event.index);
    this.selectedIndex=event.index+1;
    //console.log(this.selectedIndex);
   this.activeTab =event.tab.textLabel;
   this.sharedService.setSelectedTab(this.activeTab);
   //this.sharedService.setSelectedIndex(this.selectedIndex);
   this.sharedService.setfilterData({"tabType":this.selectedIndex});
  }

}


import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { FilterCriteriaComponent } from './filtersCriteria/filter-criteria.component';
import { AutoSearchComponent } from './customerAutoSearch/auto-search.compomemt';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TabsComponent } from './tabs/tabs.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { TemploginComponent } from './templogin/templogin.component';
import { ToastrModule, ToastNoAnimation, ToastNoAnimationModule } from 'ngx-toastr';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ConfirmPopupModule } from "primeng/confirmpopup";
import { ToastModule } from "primeng/toast";
import { ButtonModule } from "primeng/button";
import { ConfirmationService, MessageService } from "primeng/api";
import { SplitButtonModule } from 'primeng/splitbutton';
import { InterceptorService } from './services/interceptor.service';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { PickListModule } from 'primeng/picklist';
import { LoginErrorComponent } from './ErrorPages/login-error/login-error.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { UnauthorizedComponent } from './ErrorPages/unauthorized/unauthorized.component';
import { AuthGuard } from './services/core/auth.guard';
import { AuthService } from './services/auth.service';
import { DropdownModule } from 'primeng/dropdown';
import { CustomerNotesModalComponent } from './ContextMenuItems/customer-notes-modal/customer-notes-modal.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {InputTextModule} from 'primeng/inputtext';
import { AifModalComponent } from './ContextMenuItems/aif-modal/aif-modal.component';
import { AccountNotesComponent } from './ContextMenuItems/account-notes/account-notes.component';
import { PremNotesComponent } from './ContextMenuItems/prem-notes/prem-notes.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ModifyAccountNotesComponent } from './ContextMenuItems/modify-account-notes/modify-account-notes.component';
import { AccountDetailsComponent } from './ContextMenuItems/account-details/account-details.component';
import { UnderDevComponent } from './ErrorPages/under-dev/under-dev.component';
import { EmailFuntionComponent } from './ContextMenuItems/email-funtion/email-funtion.component';
import { MaintenanceModule } from './maintenance/maintenance.module';
import { MassResolveAccNotesComponent } from './ContextMenuItems/mass-resolve-acc-notes/mass-resolve-acc-notes.component';
import { CustomerTransferComponent } from './transfer/customer-transfer/customer-transfer.component';
import { NotesTransferComponent } from './transfer/notes-transfer/notes-transfer.component';
import { CommitmentHistoryModelComponent } from './customerAutoSearch/commitment-history-model/commitment-history-model.component';
import { MailEmailMergeComponent } from './customerAutoSearch/mail-email-merge/mail-email-merge.component';
import { TableMaintenanceModule } from './TableMaintenance/table-maintenance.module';
import {UserAdministrationModule} from './UserAdministration/user-administration.module';
import { AccountNotesHistoryComponent } from './ContextMenuItems/account-notes-history/account-notes-history.component';
import {ManagementModule} from './management/management.module';
import { ViewUpdateContactsModelComponent } from './ContextMenuItems/view-update-contacts-model/view-update-contacts-model.component';
import { ContactsUpdateComponent } from './ContextMenuItems/view-update-contacts-model/contacts-update/contacts-update.component';
import { ReportUtilityModule } from './report-utility-module/report-utility-module.module';
import { RoleGuard } from './services/core/role-guard.guard';
import { RoleAuthErrorComponent } from './ErrorPages/role-auth-error/role-auth-error.component';
import { EnvAuthErrorComponent } from './ErrorPages/env-auth-error/env-auth-error.component';
import { ManageProfilesComponent } from './manage-profiles/manage-profiles.component';
import { AccountsPastDueComponent } from './ContextMenuItems/accounts-past-due/accounts-past-due.component';
import { TransposeViewComponent } from './ContextMenuItems/transpose-view/transpose-view.component';
import { BreakdownDetailsComponent } from './ContextMenuItems/breakdown-details/breakdown-details.component';
import { TaxiClaimDetailsComponent } from './ContextMenuItems/taxi-claim-details/taxi-claim-details.component';
import { CashDataDetailsComponent } from './ContextMenuItems/cash-data-details/cash-data-details.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { InvalidSessionComponent } from './ErrorPages/invalid-session/invalid-session.component';
import { HoveringHeadersComponent } from './ContextMenuItems/hovering-headers/hovering-headers.component';
import { NotesActivityReportComponent } from './management/notes-activity-report/notes-activity-report.component';

import { CustomerNotesHistoryComponent } from './ContextMenuItems/customer-notes-history/customer-notes-history.component';
import { CustomerPermNotesComponent } from './ContextMenuItems/customer-perm-notes/customer-perm-notes.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { AccountPDToolTip } from './ContextMenuItems/accounts-past-due/accounts-pd.tooltip.component';
import { SystemTooltipComponent } from './ContextMenuItems/hovering-headers/tooltip-system.component';
import { CurrentBalanceTooltipComponent } from './ContextMenuItems/hovering-headers/tooltip.curbalance.component';
import { CurrentBillingTooltipComponent } from './ContextMenuItems/hovering-headers/tooltip.curbilling.component';
import { DisputeAmtTooltipComponent } from './ContextMenuItems/hovering-headers/tooltip.disputeamt.component';
import { NotesActivityManagerReportComponent } from './management/notes-activity-manager-report/notes-activity-manager-report.component';
import { InternalContactsEMAORComponent } from './customerAutoSearch/internal-contacts-emaor/internal-contacts-emaor.component';
import { MultipleContestedAmtComponent } from './ContextMenuItems/account-details/multiple-contested-amt/multiple-contested-amt.component';
import { MultipleCommitmentAmtComponent } from './ContextMenuItems/account-details/multiple-commitment-amt/multiple-commitment-amt.component';
import { MyDateEditorComponent } from './ContextMenuItems/hovering-headers/date-picker.component';
import { DoubleCellDataType } from './ContextMenuItems/hovering-headers/double-type-cell.component';



@NgModule({

  imports: [

    BrowserModule,
    AppRoutingModule,
    NoopAnimationsModule,
    FormsModule, ReactiveFormsModule, MaterialModule,
    HttpClientModule,
    AgGridModule,
    MatTooltipModule,
    MaintenanceModule,TableMaintenanceModule,UserAdministrationModule,ManagementModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,NgxSpinnerModule,
    AutoCompleteModule,
    ConfirmPopupModule,
    ToastModule,
    ButtonModule,
    SplitButtonModule, DropdownModule,
    InputTextareaModule,
    PickListModule,
    NgxSpinnerModule,
    InputTextModule,
    NgbModule,ReportUtilityModule,
    BsDatepickerModule.forRoot()

  ],

  schemas: [CUSTOM_ELEMENTS_SCHEMA],

  declarations: [
    AppComponent,
    HeaderComponent,
    FilterCriteriaComponent,
    AutoSearchComponent,
    TabsComponent,
    TemploginComponent,
    LoginErrorComponent,
    UnauthorizedComponent,
    AifModalComponent,
    CustomerNotesModalComponent,
    AccountNotesComponent,
    PremNotesComponent,
    ModifyAccountNotesComponent,
    AccountDetailsComponent,
    UnderDevComponent,
    EmailFuntionComponent,
    MassResolveAccNotesComponent,
    CustomerTransferComponent,
    NotesTransferComponent,
    CommitmentHistoryModelComponent,
    AccountPDToolTip,SystemTooltipComponent,
    CurrentBalanceTooltipComponent,CurrentBillingTooltipComponent,
    DisputeAmtTooltipComponent,
    MailEmailMergeComponent,
    AccountNotesHistoryComponent,
    ViewUpdateContactsModelComponent,
    ContactsUpdateComponent,
    RoleAuthErrorComponent,
    EnvAuthErrorComponent,
    ManageProfilesComponent,
    AccountsPastDueComponent,
    TransposeViewComponent,
    BreakdownDetailsComponent,
    TaxiClaimDetailsComponent,
    CashDataDetailsComponent,
    InvalidSessionComponent,
    HoveringHeadersComponent,
    NotesActivityReportComponent,
    NotesActivityManagerReportComponent,
    MyDateEditorComponent,
    DoubleCellDataType,

    CustomerNotesHistoryComponent,
    CustomerPermNotesComponent,
    SpinnerComponent,
    InternalContactsEMAORComponent,
    MultipleContestedAmtComponent,
    MultipleCommitmentAmtComponent
  ],
  providers: [ConfirmationService, MessageService, AuthGuard, AuthService,RoleGuard,
    { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
  ],

  bootstrap: [AppComponent],
  entryComponents : [AifModalComponent]
})
export class AppModule { }

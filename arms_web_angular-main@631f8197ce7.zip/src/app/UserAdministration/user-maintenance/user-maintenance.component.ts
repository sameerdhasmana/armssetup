import { Component, OnInit,ViewChild } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';

@Component({
  selector: 'app-user-maintenance',
  templateUrl: './user-maintenance.component.html',
  styleUrls: ['./user-maintenance.component.scss']
})
export class UserMaintenanceComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  defaultColDef: ColDef = {
    sortable: true,
    filter: true
}
pageSize=10;

columnDefs: ColDef[] = [

  { field:'Regional Id'},{ field:'Last Name'},{ field:'First Name'},{ field:'Phone'},
  { field:'Group'},{ field:'ORG'},{ field:'Email'},{ field:'Role'},
  { field:'Review Manager ID'},{ field:'Reviewed Date'},{ field:'Status'},

];

rowData: Observable<any[]>;

constructor(private http: HttpClient) {

  this.rowData = this.http.get<any[]>('assets/UsersRecord.json');

}

  ngOnInit(): void {
  }


}

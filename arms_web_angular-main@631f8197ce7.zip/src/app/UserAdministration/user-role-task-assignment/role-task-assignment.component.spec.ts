import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleTaskAssignmentComponent } from './role-task-assignment.component';

describe('RoleTaskAssignmentComponent', () => {
  let component: RoleTaskAssignmentComponent;
  let fixture: ComponentFixture<RoleTaskAssignmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoleTaskAssignmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleTaskAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

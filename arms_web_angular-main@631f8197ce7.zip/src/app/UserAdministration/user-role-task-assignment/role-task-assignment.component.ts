import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role-task-assignment',
  templateUrl: './role-task-assignment.component.html',
  styleUrls: ['./role-task-assignment.component.scss']
})
export class RoleTaskAssignmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  public Roles=["Developer","Testing","Cloud","Support"];
  list1=[{"name":"Abhi",},{"name":"mani"},{"name":"gowtham"}];
  list2=[];

}

import { Component, OnInit,ViewChild } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';


@Component({
  selector: 'app-user-report-hierarchy',
  templateUrl: './user-report-hierarchy.component.html',
  styleUrls: ['./user-report-hierarchy.component.scss']
})
export class UserReportHierarchyComponent implements OnInit {

  @ViewChild('agGrid') agGrid!: AgGridAngular;

  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    width:100
}
pageSize=1000;

columnDefs: ColDef[] = [

  { field:'OVERRIDDEN'},{ field:'H1UID'},{ field:'H1PID'},{ field:'H2UID'},
  { field:'H2PID'},{ field:'H3UID'},{ field:'H3PID'},{ field:'H4UID'},{ field:'H4PID'},{ field:'H5UID'},
  { field:'H5PID'},{ field:'H6UID'},{ field:'H6PID'},{ field:'H7UID'},{ field:'H7PID'},{ field:'H8UID'},
  { field:'H8PID'},{ field:'H9UID'},{ field:'H9PID'},
];

rowData: Observable<any[]>;

constructor(private http: HttpClient) {

  this.rowData = this.http.get<any[]>('assets/ReportHierarchyMaintenanceRecord.json');

}

  ngOnInit(): void {
  }


}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserReportHierarchyComponent } from './user-report-hierarchy.component';

describe('UserReportHierarchyComponent', () => {
  let component: UserReportHierarchyComponent;
  let fixture: ComponentFixture<UserReportHierarchyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserReportHierarchyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserReportHierarchyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAdminReportsComponent } from './user-admin-reports.component';

describe('UserAdminReportsComponent', () => {
  let component: UserAdminReportsComponent;
  let fixture: ComponentFixture<UserAdminReportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserAdminReportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAdminReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NofityManagersModalComponent } from './nofity-managers-modal.component';

describe('NofityManagersModalComponent', () => {
  let component: NofityManagersModalComponent;
  let fixture: ComponentFixture<NofityManagersModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NofityManagersModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NofityManagersModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

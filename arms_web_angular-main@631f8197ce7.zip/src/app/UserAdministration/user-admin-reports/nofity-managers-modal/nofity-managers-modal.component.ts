import { Component, Inject, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PrimeNGConfig } from 'primeng/api';
import {ConfirmationService} from 'primeng/api';
import {Message} from 'primeng/api';

@Component({
  selector: 'app-nofity-managers-modal',
  templateUrl: './nofity-managers-modal.component.html',
  styleUrls: ['./nofity-managers-modal.component.scss'],
  providers: [ConfirmationService]
})
export class NofityManagersModalComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<NofityManagersModalComponent>,
    private toastr: ToastrService,
    private primengConfig: PrimeNGConfig,
    private confirmationService: ConfirmationService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
  }


  ngOnInit(): void {
  }

  closeModal(){
    this.dialogRef.close();
  }




      msgs: Message[] = [];

      sendEmail() {
        this.confirmationService.confirm({
            message: 'You are about to Execute - arms_usermaintenance_notify_mgrs_expired_users Database Procedure. Are you sure ? ',
            header: 'User Admin-Manager Verification Email',
            icon: 'pi pi-info-circle',
            accept: () => {
                this.msgs = [{severity:'info', summary:'Confirmed', detail:'Sending...'}];
                this.dialogRef.close({ msg: 'success' });
            },
            reject: () => {
                this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
            }
        });
    }


}

import { Component, OnInit,ViewChild } from '@angular/core';
import { UserAdminReportsService } from 'src/app/services/userAdminReports.service';
import { MatSidenav } from '@angular/material/sidenav';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import {
  ColDef,
  ColumnApi,
  GetContextMenuItemsParams,
  GridOptions,
  MenuItemDef,
} from 'ag-grid-enterprise';
import "@ag-grid-community/core/dist/styles/ag-grid.css";
import "@ag-grid-community/core/dist/styles/ag-theme-material.css";
import { NofityManagersModalComponent } from './nofity-managers-modal/nofity-managers-modal.component';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";



@Component({
  selector: 'app-user-admin-reports',
  templateUrl: './user-admin-reports.component.html',
  styleUrls: ['./user-admin-reports.component.scss']
})

export class UserAdminReportsComponent implements OnInit {
  @ViewChild('sidenav') sidenav: MatSidenav | undefined;
  @ViewChild('agGrid') agGrid!: AgGridAngular;


  constructor(
    private adminReports : UserAdminReportsService,
    private dialog: MatDialog ) { }
  radioList = [
    { "name": "Expired User Report(past 90 days)" , "value" :1},
    { "name": "Expired User To Be Disabled Report","value" :2},
    { "name": "Users To Be Deleted Report","value" :3},
    { "name": "Users To Be Removed Report","value" :4},
    { "name": "All Deleted Report","value" :5},
    { "name": "All Active in 90 Day Report","value" :6},
    { "name": "All Active 90 + 30 Day Report","value" :7},
    { "name": "All Non-Active Report","value" :8},
    { "name": "Security Audit Log Report","value" :9},
    { "name": "Security Audit Alter Report","value" :10},
    { "name": "Users Suits Report","value" :11}
]

selectedRadio = this.radioList[0].value;
checked = false;
showGrid = false;
defaultExcelExportParams:any;
selectedRadioName:any;

onRadioChange(value:any): void{
  console.log(value);
}

inputgenerateReport:any={};

generateReport(){
  this.showGrid = true;
  if(this.selectedRadio === 1 ){

    this.defaultExcelExportParams=  {
      fileName: 'expiredUserReport-'+Date()
    }
    if(this.checked){
      //console.log(this.checked);
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.id = "modal-component";
      dialogConfig.height = "80%";
      dialogConfig.width = "80%";
      dialogConfig.data = {
      }
      const modalDialog = this.dialog.open(NofityManagersModalComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {
        if (res.msg == "success") {
          this.inputgenerateReport.reportTabs = this.selectedRadio;
          this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
            this.selectedRadioName = "Expired User Report(past 90 days)";
            this.rowData= data.expiredUserReport;
            let dbfields = Object.keys(data.expiredUserReport[0]);
            this.columnDefs = dbfields.map((e:any)=>{
              let obj:any={};
              obj.field = e
              return obj;
            })
          });
          this.gridApi.showLoadingOverlay();
        }
      })
    }else{
      this.inputgenerateReport.reportTabs = this.selectedRadio;
      this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
        this.selectedRadioName = "Expired User Report(past 90 days)";
        this.rowData= data.expiredUserReport;
        let dbfields = Object.keys(data.expiredUserReport[0]);
        this.columnDefs = dbfields.map((e:any)=>{
          let obj:any={};
          obj.field = e
          return obj;
        })
      });
      this.gridApi.showLoadingOverlay();
    }
  } else if (this.selectedRadio === 2 ){

    this.defaultExcelExportParams=  {
      fileName: 'expiredUserToDisabled-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "Expired User To Be Disabled Report";
      this.rowData= data.expiredUserToDisabled;
      let dbfields = Object.keys(data.expiredUserToDisabled[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  } else if (this.selectedRadio === 3 ){

    this.defaultExcelExportParams=  {
      fileName: 'userToBeDeletedReport-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "Users To Be Deleted Report";
      this.rowData= data.userToBeDeletedReport;
      let dbfields = Object.keys(data.userToBeDeletedReport[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  }else if (this.selectedRadio === 4 ){

    this.defaultExcelExportParams=  {
      fileName: 'UserToBeRemoveReport-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "Users To Be Removed Report";
      this.rowData= data.UserToBeRemoveReport;
      let dbfields = Object.keys(data.UserToBeRemoveReport[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  }else if (this.selectedRadio === 5 ){

    this.defaultExcelExportParams=  {
      fileName: 'allDeletedReport-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "All Deleted Report";
      this.rowData= data.allDeletedReport;
      let dbfields = Object.keys(data.allDeletedReport[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  }else if (this.selectedRadio === 6 ){

    this.defaultExcelExportParams=  {
      fileName: 'AllActiveIn90DaysReport-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "All Active in 90 Day Report";
      this.rowData= data.AllActiveIn90DaysReport;
      let dbfields = Object.keys(data.AllActiveIn90DaysReport[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  }else if (this.selectedRadio === 7 ){

    this.defaultExcelExportParams=  {
      fileName: 'AllActiveIn90+30DaysReport-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "All Active 90 + 30 Day Report";
      this.rowData= data.AllActiveIn9030DaysReport;
      let dbfields = Object.keys(data.AllActiveIn9030DaysReport[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  }else if (this.selectedRadio === 8 ){

    this.defaultExcelExportParams=  {
      fileName: 'allNonActiveStatusAll-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "All Non-Active Report";
      this.rowData= data.allNonActiveStatusAll;
      let dbfields = Object.keys(data.allNonActiveStatusAll[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  }else if (this.selectedRadio === 9 ){

    this.defaultExcelExportParams=  {
      fileName: 'securityAuditLogDailyGui-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "Security Audit Log Report";
      this.rowData= data.securityAuditLogDailyGui;
      let dbfields = Object.keys(data.securityAuditLogDailyGui[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  }else if (this.selectedRadio === 10 ){

    this.defaultExcelExportParams=  {
      fileName: 'securityAuditAlertGui-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "Security Audit Alter Report";
      this.rowData= data.securityAuditAlertGui;
      let dbfields = Object.keys(data.securityAuditAlertGui[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  }else {

    this.defaultExcelExportParams=  {
      fileName: 'userSuits_report-'+Date()
    }
    this.inputgenerateReport.reportTabs = this.selectedRadio;
    this.adminReports.userAdminReports(this.inputgenerateReport).subscribe((data: any) => {
      this.selectedRadioName = "Users Suits Report";
      this.rowData= data.userSuits_report;
      let dbfields = Object.keys(data.userSuits_report[0]);
      this.columnDefs = dbfields.map((e:any)=>{
        let obj:any={};
        obj.field = e
        return obj;
      })
    });
    this.gridApi.showLoadingOverlay();

  }


}

// columnDefsEUR : ColDef[] = [
//   { field: 'lname' },
//   { field: 'fname' },
//   { field: 'description' },
// ];

rowData: any = [];
columnDefs: any;
pageSize: number = 300;
defaultColDef: ColDef = {
  sortable: true,
  filter: true,
  // flex: 1,
  //minWidth: 100,
  resizable: true,
};
overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
overlayNoRowsTemplate = `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

gridApi: any;
onGridReady(params: any) {
  this.gridApi = params.api;
}
exportAsExcel(){
  this.gridApi.exportDataAsExcel();
}




  ngOnInit(): void {
  }

}

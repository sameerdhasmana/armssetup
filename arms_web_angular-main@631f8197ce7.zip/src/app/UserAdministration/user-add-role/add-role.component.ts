import { Component, OnInit } from '@angular/core';
import {ChangeDetectionStrategy} from '@angular/core';


@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AddRoleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  list1=[{"name":"CRICKET",},{"name":"Football"},{"name":"Hockey"}];
  list2=[];

}

import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserAdminReportsComponent } from './user-admin-reports/user-admin-reports.component';
import { AddRoleComponent } from './user-add-role/add-role.component';
import { RoleTaskAssignmentComponent } from './user-role-task-assignment/role-task-assignment.component';
import { UserReportHierarchyComponent } from './user-report-hierarchy/user-report-hierarchy.component';
import { UserMaintenanceComponent } from './user-maintenance/user-maintenance.component';

import { MaterialModule } from '../material/material.module';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterModule} from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NofityManagersModalComponent } from './user-admin-reports/nofity-managers-modal/nofity-managers-modal.component';



@NgModule({
  declarations: [
    UserAdminReportsComponent,
    AddRoleComponent,
    RoleTaskAssignmentComponent,
    UserReportHierarchyComponent,    UserMaintenanceComponent, NofityManagersModalComponent,

  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    CommonModule,
    AgGridModule,
    MaterialModule,
    BrowserAnimationsModule,
    RouterModule,
    FormsModule,ReactiveFormsModule

  ]
})
export class UserAdministrationModule { }

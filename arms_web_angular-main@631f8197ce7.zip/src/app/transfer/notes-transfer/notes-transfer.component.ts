import { Component, OnInit } from '@angular/core';
import { TransferService } from 'src/app/services/transfer.service';
import { PrimeNGConfig } from 'primeng/api';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-notes-transfer',
  templateUrl: './notes-transfer.component.html',
  styleUrls: ['./notes-transfer.component.scss']
})
export class NotesTransferComponent implements OnInit {

  users :any=[];
  sourceUser :any;
  targetUser :any;

  constructor(private transfer : TransferService,
    private primengConfig: PrimeNGConfig,
    private toastr: ToastrService,) { }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.transfer.getUsers('').subscribe((data: any) => {
      this.users = data.AllUsers;
        });
  }


  inputData:any={};

  notesTransfer(){
    this.inputData.userLoginCdFrom = this.sourceUser.user_login_cd;
    this.inputData.userLoginCdTo = this.targetUser.user_login_cd;
    console.log(this.inputData);

    this.transfer.transferNotes(this.inputData).subscribe((data: any) => {

      if (data.msg == "success") {

        this.toastr.success('', 'Notes Transfer Successfully Completed', {
          timeOut: 5000, closeButton: true
        });

      }else if(data.errorMsg){
        this.toastr.error('', 'Notes Transfer Error , Please Try Again', {
          timeOut: 5000, closeButton: true
        });
      }
    }, (error: any) => {
      let newError = error.error.errorMsg

      this.toastr.error('', 'Notes Transfer Error , Please Try Again, '+newError, {
        timeOut: 5000, closeButton: true
      });

      }
    );
   }


}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotesTransferComponent } from './notes-transfer.component';

describe('NotesTransferComponent', () => {
  let component: NotesTransferComponent;
  let fixture: ComponentFixture<NotesTransferComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotesTransferComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotesTransferComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

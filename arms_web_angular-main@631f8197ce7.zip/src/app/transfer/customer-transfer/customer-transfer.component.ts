import { Component, OnInit } from '@angular/core';
import { TransferService } from 'src/app/services/transfer.service';
import { PrimeNGConfig } from 'primeng/api';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-customer-transfer',
  templateUrl: './customer-transfer.component.html',
  styleUrls: ['./customer-transfer.component.scss']
})
export class CustomerTransferComponent implements OnInit {

  customers :any=[];
  sourceCustomer :any;
  targetCustomer :any;

  constructor(private transfer : TransferService,
    private primengConfig: PrimeNGConfig,
    private toastr: ToastrService,) { }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.transfer.allContacts('').subscribe((data: any) => {
      this.customers = data.CustomerInfo;
        });
  }


  inputData:any={};

  customerTransfer(){
    this.inputData.customerGrpCdFrom = this.sourceCustomer.customer_grp_cd;
    this.inputData.customerGrpCdTo = this.targetCustomer.customer_grp_cd;
    //console.log(this.inputData);

    this.transfer.transferContacts(this.inputData).subscribe((data: any) => {

      if (data.msg == "success") {
        this.toastr.success('', 'Customer Transfer Successfully Completed', {
          timeOut: 5000, closeButton: true
        });

      }else if(data.errorMsg){
        this.toastr.error('', 'Customer Transfer Error , Please Try Again', {
          timeOut: 5000, closeButton: true
        });
      }
    }, (error: any) => {
      //console.log(error,"Test Error")
      let newError = error.error.errorMsg

      this.toastr.error('', 'Customer Transfer Error , Please Try Again, '+newError, {
        timeOut: 5000, closeButton: true
      });

      }
    );
  }


}

import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { FormControl, FormGroup } from '@angular/forms';
import { FiltersApiService } from '../services/filters-api.service';
import { Router } from '@angular/router';
import { FilterSelection } from 'src/Models/filterSelection.model';
import { SharedService } from '../services/shared.service';
import { ProfileService } from '../services/profile.service';

@Component({
  selector: 'app-customer-query',
  templateUrl: './filter-criteria.component.html',
  styleUrls: ['./filter-criteria.component.scss'],
})
export class FilterCriteriaComponent implements OnInit,AfterViewInit{

  @ViewChild('sidenav') sidenav: MatSidenav | undefined;

 // selectedExclusions = 'Included Accounts'; // Default Selection of the Included Accounts in the Exclusions Filter

  onClickHelp(){
    window.open("https://peoria.web.att.com/business/Wholesale/enterprise/jobaids/armsja.htm#cust_query_bk");
  }
  onExit(){

    this.router.navigate(['/login']);
  }

 /**
  *
  */

  selection: FilterSelection = new FilterSelection(); // Model implemented to Store the Filters form Data

// Form Variable to Store the Values from the Form.
  form :any=new FormGroup({
    FINAL: new FormControl(true),
    LIVE: new FormControl(true),
    WROFF: new FormControl(),
    custGroup: new FormControl(),
    accClass : new FormControl(),
    oSystem :new FormControl(),
    cGroups : new FormControl(),
    bPeriod : new FormControl(),
    sList : new FormControl(),
    exclusions : new FormControl("Included Accounts")

   });

   defaultBP:any;
   defaultGroup:any=[];
   aifOriginatingSystem :any=[];


  constructor(
    private _filtersApiService: FiltersApiService,
    private router: Router,
    private sharedService: SharedService,
    private profileService: ProfileService
  ) { }

 initialDBValues:any="";
 userID:any="";

 Filters: any; // Variable to store the Initial Filters Values coming from the DB
 ExecuteProfileRsp :any={};
 ngOnInit() {

    //Function to load the Filter Values initially

    let data =localStorage.getItem("userInfo");
    this.Filters = JSON.parse(data?data:"");
    this.initialDBValues = this.Filters.customerGroupList.find(
      (e:any)=>{return e.bus_unit_cd== this.Filters.globalLogonUsers.group});
    this.userID =  this.Filters.globalLogonUsers.user_login_cd;
    //console.log(this.userID);
    //localStorage.setItem("userLoginCd", this.userID)

    this.defaultBP=this.Filters.customerBillingPeriod[0].billing_period;
    this.defaultGroup.push(this.Filters.globalLogonUsers.group);


    this.sharedService.filtersDataFromProfile$.subscribe((data) => {
      // console.log(data.profileName)
      // console.log(data.profileType)
      // console.log("From Filter")
      let chkFromHeaderForFilter = localStorage.getItem('chkFromHeaderForFilter');
      if(chkFromHeaderForFilter=="1"){
      let epdata = localStorage.getItem('executeFilterData');
      this.ExecuteProfileRsp=JSON.parse(epdata ? epdata : '');
      this.fillFiltersFromExecuteProfile(this.ExecuteProfileRsp);
      //localStorage.setItem('chkFromHeaderForFilter', "0");
    }
    });
  }

  fillFiltersFromExecuteProfile(data:any){
    this.defaultGroup = data.profileDetails.businessGroup;
    this.aifOriginatingSystem = data.profileDetails.originatingSystem;
    this.form.controls['sList'].setValue(data.profileDetails.segment);
    this.form.controls['exclusions'].setValue(data.profileDetails.profileExclusions);
    let ecArr=[];
    for (let i = 0; i < data.profileDetails.exclusionClass.length; i++) {
      ecArr.push(
        (this.Filters.accountsClassificationList.find((e: any) => {
          if (e.class_desc === data.profileDetails.exclusionClass[i]) {
            return e.class_cd;
          }
        })).class_cd
      );
    }
    this.form.controls['accClass'].setValue(ecArr);
    if (data.profileDetails.statusClause.length > 0) {
      for (let i = 0; i < data.profileDetails.statusClause.length; i++) {
        if (data.profileDetails.statusClause[i] === "Final") {
          this.form.controls['FINAL'].setValue(true);
        }
        if (data.profileDetails.statusClause[i] === "Live") {
          this.form.controls['LIVE'].setValue(true);
        }
        if (data.profileDetails.statusClause[i] === "WR-OFF") {
          this.form.controls['WROFF'].setValue(true);
        }
      }
    }
  }

  ngAfterViewInit(): void {
    let chkFromHeaderForFilter = localStorage.getItem('chkFromHeaderForFilter');
      if(chkFromHeaderForFilter=="1"){
        let epdata = localStorage.getItem('executeFilterData');
        this.ExecuteProfileRsp=JSON.parse(epdata ? epdata : '');
        this.fillFiltersFromExecuteProfile(this.ExecuteProfileRsp);
        localStorage.setItem('chkFromHeaderForFilter', "0");
      }


    this.form.valueChanges.subscribe((form:any) => {
     // console.log(this.form);
      // debugger;
      let filters:any={}
      filters.statusClause=[];
      if (form.LIVE) {
        filters.statusClause.push("LIVE");
      }
      if (form.FINAL) {
        filters.statusClause.push("FINAL");
      }
     if(form.WROFF){
        filters.statusClause.push("WR-OFF");
      }
      filters.billingPeriod = form.bPeriod;
      filters.groupSelected= form.cGroups;
      filters.exclusions= form.exclusions;
      filters.exclusionClass=form.accClass;
      filters.originatingSystem=form.oSystem;
      filters.segment=form.sList;
    this.sharedService.setfilterData(filters);

    });

    let statusClause =[];

    if (this.form.controls.LIVE.value) {
      statusClause.push("LIVE");
    }
    if (this.form.controls.FINAL.value) {
      statusClause.push("FINAL");
    }
   if(this.form.controls.WROFF.value){
      statusClause.push("WR-OFF");
    }
    this.sharedService.setfilterData({billingPeriod:this.defaultBP,
      groupSelected:this.defaultGroup,
      exclusions: this.form.controls.exclusions.value,statusClause:statusClause});

      this.sharedService.aifModalData$.subscribe((e:any) => {
        this.defaultBP = e.billingPeriod;
        debugger
        this.defaultGroup=[];
        this.defaultGroup.push(e.groupSelected)
        this.form.controls.cGroups.setValue(this.defaultGroup);
        this.aifOriginatingSystem=[];
        this.aifOriginatingSystem.push(e.originatingSystem);
        this.form.controls.oSystem.setValue(this.aifOriginatingSystem);
      });
  }



  //upFilter : any; // Filter4 Customer Group Filters change detection data stored

  async filterData(){
// Function to retrive the Values from the DB When the Business Group Filter Changes to Populate the Segment Values and Billing Group

   let  obj ={groupSelected:this.form.value.cGroups};
   let result = await this._filtersApiService.changeFilters(obj).subscribe((e:any)=>{
     //console.log(e);
     this.Filters.customerBillingPeriod = e.customerBillingPeriod
     this.Filters.segmentList = e.segmentList;

    });
  }



}


import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotesActivityManagerReportComponent } from './notes-activity-manager-report.component';

describe('NotesActivityManagerReportComponent', () => {
  let component: NotesActivityManagerReportComponent;
  let fixture: ComponentFixture<NotesActivityManagerReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotesActivityManagerReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotesActivityManagerReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

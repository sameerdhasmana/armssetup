import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FilterSelection } from 'src/Models/filterSelection.model';
import { SharedService } from '../../services/shared.service';
import { ReportingUtilityService } from '../../services/reportingServiceUtility';
import { FiltersApiService } from '../../services/filters-api.service';
import { MatSidenav } from '@angular/material/sidenav';
import { NotesActivityReportService } from 'src/app/services/notes-activity-report.service';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { getDate } from 'ngx-bootstrap/chronos/utils/date-getters';
import { CellDoubleClickedEvent, ITooltipParams, ValueFormatterParams } from 'ag-grid-community';
import { ColDef, ColumnMovedEvent, DragStoppedEvent, GetContextMenuItemsParams, GridOptions, GridReadyEvent, MenuItemDef } from 'ag-grid-community';
import { sampleTime } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { GeneralUiFunctionsService } from 'src/app/services/general-ui-functions.service';
import { HoveringHeadersComponent } from '../hovering-headers.component';
import { ViewAccountNotesComponent } from '../notes-activity-report/view-account-notes/view-account-notes.component';
import { ViewCustomerNotesComponent } from '../notes-activity-report/view-customer-notes/view-customer-notes.component';
import { NgxSpinnerService } from "ngx-spinner";

interface Customer {
  customer_grp_cd: string,
  customer_legal_nm: string,
  ExcludedAccountsExists: string
}

interface Manager {
  manager_uid: string
}

interface RepUser {
  h1uid: string,
  userid: string
}

interface SubActivity {
  sub_activity_short_description: string
}

interface Activity {
  description: string
}

@Component({
  selector: 'app-notes-activity-manager-report',
  templateUrl: './notes-activity-manager-report.component.html',
  styleUrls: ['./notes-activity-manager-report.component.scss']
})
export class NotesActivityManagerReportComponent implements OnInit {
  @ViewChild('sidenav') sidenav: MatSidenav | undefined;

  constructor(
    private _filtersApiService: FiltersApiService,
    private sharedService: SharedService,
    private reportingService: ReportingUtilityService,
    private notesreportActivityService: NotesActivityReportService,
    private _generalUiFnService: GeneralUiFunctionsService,
    private toastr: ToastrService,
    private loadingSpinner: NgxSpinnerService,
    private dialog: MatDialog
  ) {
    this.showGrid = false;
    this.showMultiple = false;
    this.showAll = true;
    this.showSingle = false;
    this.selectedCustomers = [];
    this.customersPopulateDataList = [];
    this.mUserList = [];
    this.repUserList = [];
    this.sActivityList = [];
    this.customerList = [];
    this.activityList = [{ description: 'Resolved' }, { description: 'Perm Note' }, { description: 'No Action' }, { description: 'Bankruptcy' }, { description: 'Credit Information' }, { description: 'In treatment' }];
  }
  selectedCustomers: Customer[];
  customersPopulateDataList: Customer[];
  mUserList: Manager[];
  sActivityList: any = [];
  Filters: any;
  initialDBValues: any = "";
  defaultActivity: any = [];
  defaultSubActivity: any = [];
  //defaultrepUserID: any = [];
  defaultrepH1UID: any = [];
  defaultmUserID: any = [];
  radioList = [
    { "name": "All", "value": 0 },
    { "name": "Multiple", "value": 1 },
    { "name": "Single", "value": 2 },
  ];
  radioList2 = [
    { "name": "Customer", "value": 1 },
    { "name": "User Id", "value": 2 }
  ];
  selectedRadio = this.radioList[0].name;
  selectedRadio2 = this.radioList2[0].value;
  selectedItem: any = [];
  //selectedCustomer: any;
  customers: any[] = [];
  repUserList: RepUser[];
  customerList: Customer[];
  activityList: Activity[];
  datePicker1: any;
  startDate: string = '';
  datePicker2: any;
  endDate: string = '';
  showGrid: boolean;
  pageSize: number = 1000;
  rowData: any;
  showMultiple: boolean;
  showSingle: boolean;
  showAll: boolean;

  defaultColDef: ColDef = {
    sortable: true,
    filter: true
  }
  columnDefs: any;
  columnDefsNAR: ColDef[] = [

    { headerName: 'Customer', field: 'customer', resizable: true },
    { headerName: 'User', field: 'userName' },
    { headerName: 'Manager', field: 'mgrUid' },
    { headerName: 'Insert Date', field: 'insertDate' },
    { headerName: 'Month', field: 'month' },
    { headerName: 'Note', field: 'noteType' },
    { headerName: 'Acct Number', field: 'acctNbr' },
    { headerName: 'Activty', field: 'activity', resizable: true },
    { headerName: 'Sub Activity', field: 'subActivity', resizable: true },
    { headerName: 'BU Date', field: 'buDate' },
    {
      headerName: 'Commitment', field: 'commitmentAmt', type: 'rightAligned',
      valueFormatter: currencyFormatter,
      cellStyle: params => {
        if (params.value < 0) {
          return { color: 'red' };//,backgroundColor: 'green'
        }
        return null;
      }
    },

    {
      headerName: 'Note Text', field: 'noteText', resizable: true,
      tooltipComponent: HoveringHeadersComponent,
      tooltipValueGetter: toolTipValueGetter
    },
    { headerName: 'System', field: 'originatingSystem' },
  ];

  // Form Variable to Store the Values from the Form.
  // forms :any=new FormGroup({
  //   aList : new FormControl(),
  //   saList : new FormControl(),
  //   mUserID : new FormControl(),
  //   rUserID : new FormControl(),
  //   ALL: new FormControl(true),
  //   Multiple: new FormControl(),
  //   Customer: new FormControl(),
  //   UserID: new FormControl(),
  //   radio: new FormControl()
  //  });

  ngOnInit(): void {
    let data = localStorage.getItem("userInfo");
    this.Filters = JSON.parse(data ? data : "");

    //Populating Activity
    this.defaultActivity = this.activityList[5].description;

    //Fetching Subactivity
    this.notesreportActivityService.fetchSubActivities('').subscribe((subActivity_data: any) => {
      this.sActivityList = subActivity_data.subActivityList;
    });

    //Fetching Managers
    this.notesreportActivityService.fetchmanagerUserID('').subscribe((manager_data: any) => {
      const list = manager_data.Managers;
      for (const key in list) {
        this.mUserList.push(list[key]);
      }
      this.defaultmUserID.push(this.mUserList[0].manager_uid);
      //console.log("Manager:" + this.defaultmUserID);

      //Fetching Reps
      // this.notesreportActivityService.fetchrepUserID({ "managerLoginCd": this.defaultmUserID }).subscribe((respData: any) => {
      //   const list = respData.h1UidDetails;
      //   for (const key in list) {
      //     this.repUserList.push(list[key]);
      //     if (key == "0") {
      //       if (list[key].hasOwnProperty('userid')) {
      //         this.defaultrepUserID[0] = this.repUserList[0].userid;
      //       }
      //       else {
      //         this.defaultrepUserID = [];
      //       }
      //     }
      //   }
      // });
    });
  }
  defaultExcelExportParams: any;
  runTemplate() {
    if(!this.defaultmUserID[0]){
      this.toastr.error(
        '',
        'You have to Select a Manager User Id',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
      return;
    }
    this.showGrid = true;
    this.defaultrepH1UID = [];
    let subactivities: any = [];
    this.defaultExcelExportParams = {
      fileName:
        'NotesActivityManagerReport-' + Date(),
    };
    //Prepare H1UId Array
    // for (const key in this.defaultrepUserID) {
    //   this.defaultrepH1UID.push(this.defaultrepUserID[key].slice(0, 6));
    // }

    //Prepare subActivityArray
    for (const key in this.defaultSubActivity) {
      subactivities.push(this.defaultSubActivity[key].sub_activity_short_description);
    }
    //console.log(subactivities);
    this.loadingSpinner.show();
    this.notesreportActivityService.generateManagerReport({}, this.selectedRadio, this.defaultActivity.slice(0, 1), this.startDate, this.endDate, this.selectedItem, this.defaultmUserID, subactivities, this.selectedRadio2)
      .subscribe((respData: any) => {
        this.loadingSpinner.hide();
        this.columnDefs = this.columnDefsNAR;
        this.rowData = respData.NotesActivity;
        // console.log(respData);
      });

    //this.gridApi.showLoadingOverlay();
  }

  accountNotes() {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
      let inpData: any = {};
      inpData.accountNumber = selectedData[0].acctNbr;
      inpData.acntNoteOrgSys = selectedData[0].originatingSystem;
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.id = 'view-account-notes-component';
      dialogConfig.height = '100%';
      dialogConfig.width = '100%';
      dialogConfig.data = {
        inpData: inpData
      };
      const modalDialog = this.dialog.open(ViewAccountNotesComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {
        if (res.msg == 'success') {
          this.runTemplate();
        }
      });
    }
    else {
      this.toastr.error(
        '',
        'Please Select Account Number from the Grid',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }

  customerNotes() {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
      let inpData: any = {};
      let custArr: any = this.currRowData.customer.split(" ");
      let customerGrpCd: any = custArr[custArr.length - 1];
      //console.log(customerGrpCd);
      inpData.customerGrpCd = customerGrpCd;
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.id = 'view-customer-notes-component';
      dialogConfig.height = '100%';
      dialogConfig.width = '100%';
      dialogConfig.data = {
        inpData: inpData
      };
      const modalDialog = this.dialog.open(ViewCustomerNotesComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {
        if (res.msg == 'success') {
          this.runTemplate();
        }
      });

    }
    else {
      this.toastr.error(
        '',
        'Please Select Customer from the Grid',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
    //console.log('row', event.data);
  }

  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
    Please wait while your Data is loading
    </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
     border: 2px solid #444;
     background: lightgoldenrodyellow;">
     No Data Found in the System
     </span>`;

  helpTemplate() {
    window.open('https://peoria.web.att.com/business/Wholesale/enterprise/jobaids/armsja.htm#Notes_act_Rpt', '_blank')
  }

  gridOptions: GridOptions = {
    onCellDoubleClicked: (
      event: CellDoubleClickedEvent
    ) => console.log('Cell was Double clicked'),

    // onColumnMoved: (
    //   event : ColumnMovedEvent
    // ) => this.columnMovedCustomEvent(event)

    // onDragStopped:(
    //   event: DragStoppedEvent
    // ) =>  this.DragStoppedCustomEvent(event),


  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (!selectedData[0]) {
      return [];
    }
    var result: (string | any)[] = [
      'copy',
      'copyWithHeaders',
      'export',
      {
        name: 'Account Notes',
        disabled: selectedData[0].noteType == "A" ? false : true,
        action: () => {
          this.accountNotes();
        }
      },
      {
        name: 'Customer Notes',
        disabled: selectedData[0].noteType == "A" ? true : false,
        action: () => {
          this.customerNotes();
        }
      },
      {
        name: 'Help',
        action: () => {
          this.helpTemplate();
        }
      },
    ];
    return result;
  }

  onSelectionChange(value: any): void {
    this.selectedRadio = value;
    if (value == "Multiple") {
      this.showSingle = false;
      this.showMultiple = true;
      this.showAll = false;
      this.selectedItem = [];
    } else if (value == "Single") {
      this.showMultiple = false;
      this.showSingle = true;
      this.showAll = false;
      this.selectedItem = [];
    } else {
      this.showMultiple = false;
      this.showSingle = false;
      this.showAll = true;
      this.selectedItem = [];
    }
  }

  onSelectionChange2(value: any): void {
    this.selectedRadio2 = value;
  }

  addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    //Start Date
    this.startDate = (this.datePicker1.getMonth() + 1) + '/' + this.datePicker1.getDate() + '/' + this.datePicker1.getFullYear();
  }

  addEvent2(type: string, event: MatDatepickerInputEvent<Date>) {
    //End Date
    this.endDate = (this.datePicker2.getMonth() + 1) + '/' + this.datePicker2.getDate() + '/' + this.datePicker2.getFullYear();
  }

  search(event: any) {
    //Fetching Customers
    let query = event.query;
    this.notesreportActivityService.fetchCustomers({}, query).subscribe((respData: any) => {
      this.customerList = respData["All Customers"];
    });
  }

  searchCustomer(event: any) {
    //Fetching Customer
    let query = event.query;
    //console.log(query);
    this.notesreportActivityService.fetchCustomers({}, query).subscribe((respData: any) => {
      this.customerList = respData["All Customers"];
    });

  }

  onSelect(event: any) {
    this.selectedItem.push(event.customer_grp_cd);
  }

  clearSearchItems() {
    this.selectedItem = [];
  }

  // populateRepUserID() {
  //   this.notesreportActivityService.fetchrepUserID({ "managerLoginCd": this.defaultmUserID }).subscribe((respData: any) => {
  //     const list = respData.h1UidDetails;
  //     this.repUserList = [];
  //     for (const key in list) {
  //       this.repUserList.push(list[key]);
  //       if (key == "0") {
  //         if (list[key].hasOwnProperty('userid')) {
  //           this.defaultrepUserID[0] = this.repUserList[0].userid;
  //         }
  //         else {
  //           this.defaultrepUserID = [];
  //         }
  //       }
  //     }
  //     if (this.repUserList.length == 0) {
  //       this.defaultrepUserID = [];
  //     }
  //     //console.log(this.defaultrepUserID);
  //     //console.log(this.repUserList);
  //   });
  // }

  // updateRepUserID() {
  //   this.defaultrepUserID = this.defaultrepUserID;
  //   //console.log(this.defaultrepUserID);
  // }

  updateSubActivity() {
    if (this.defaultActivity != "In treatment") {
      this.defaultSubActivity = [];
      this.sActivityList = [];
    } else {
      this.notesreportActivityService.fetchSubActivities('').subscribe((subActivity_data: any) => {
        this.sActivityList = subActivity_data.subActivityList;
      });
    }
  }

  allowOnlyNumbersWithSlash(event: any) {
    return this._generalUiFnService.allowOnlyNumbersWithSlash(event);
  }

}

function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}
const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewModifyAccountNotesComponent } from './view-modify-account-notes.component';

describe('ViewModifyAccountNotesComponent', () => {
  let component: ViewModifyAccountNotesComponent;
  let fixture: ComponentFixture<ViewModifyAccountNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewModifyAccountNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewModifyAccountNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

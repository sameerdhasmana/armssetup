import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, GetContextMenuItemsParams, ITooltipParams, MenuItemDef, ValueFormatterParams } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { HoveringHeadersComponent } from 'src/app/ContextMenuItems/hovering-headers/hovering-headers.component';
import { AccountNotesService } from 'src/app/services/accountNotes.service';
import { SearchService } from 'src/app/services/search.service';
import { SharedService } from 'src/app/services/shared.service';
import { ViewAddAccountNotesComponent } from './view-add-account-notes/view-add-account-notes.component';
import { ViewModifyAccountNotesComponent } from './view-modify-account-notes/view-modify-account-notes.component';
import {ConfirmationService} from 'primeng/api';
import {Message} from 'primeng/api';


@Component({
  selector: 'app-view-account-notes',
  templateUrl: './view-account-notes.component.html',
  styleUrls: ['./view-account-notes.component.scss'],
  providers: [ConfirmationService]
})
export class ViewAccountNotesComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    resizable: true,
  }
  columnDefs: any;
  pageSize: number = 1000;
  rowData: any;
  msgs: Message[] = [];
  inpData: any;
  filters: any = {};
  groupSeleted: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<ViewAccountNotesComponent>,
    private dialog: MatDialog,
    private toastr: ToastrService,
    private searchService: SearchService,
    private sharedService: SharedService,
    private accountNotesService: AccountNotesService,
    private primengConfig: PrimeNGConfig,
    private confirmationService: ConfirmationService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.inpData = data.inpData
  }

  ngOnInit(): void {
    this.accountNotes(this.inpData);
    this.sharedService.filtersData$.subscribe((data: any) => {
      this.filters = { ...this.filters, ...data };
      //this.billingPeriod = this.filters.billingPeriod;
      this.groupSeleted = this.filters.groupSelected;
    });
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
    //console.log('row', event.data);
  }

  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

  closeModal() {
    this.dialogRef.close({ msg: 'cancelled' });
  }

  columnDefsAN: ColDef[] = [
    { headerName: 'Notes ID', field: 'notes_id' },
    { headerName: 'Customer ID', field: 'customer_grp_cd' },
    { headerName: 'Billing Period', field: 'billing_period' },
    {
      headerName: 'Resolved', field: 'resolved',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      }
    },
    { headerName: 'Next Call Back Dt', field: 'next_call_back_date' },
    {
      headerName: 'Commitment Amt', field: 'commitment_amt',
      valueFormatter: currencyFormatter,type: 'rightAligned',
      cellStyle: params => {
        if (params.value < 0) {
          return { color: 'red' };//,backgroundColor: 'green'
        }
        return null;
      }
    },
    { headerName: 'Talked to', field: 'talked_to' },
    {
      headerName: 'Notes', field: 'notes', resizable: true,
      tooltipComponent: HoveringHeadersComponent,
      tooltipValueGetter: toolTipValueGetter
    },
    { headerName: 'Activity CD', field: 'activity_cd' },
    {
      headerName: 'In Treatment', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'I') ? 'checked' : ''} />`;
      }
    },
    {
      headerName: 'Perm Note', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'P') ? 'checked' : ''} />`;
      }
    },
    {
      headerName: 'Credit Information', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'C') ? 'checked' : ''} />`;
      }
    },
    {
      headerName: 'Bankruptcy', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'B') ? 'checked' : ''} />`;
      }
    },
    {
      headerName: 'No Action', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'N') ? 'checked' : ''} />`;
      }
    },

    {
      headerName: 'Copy to Biller', field: 'copy_to_biller',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      }
    },
    { headerName: 'Copy Biller Value', field: 'copy_biller_value' },
    { headerName: 'Biller Note Prem', field: 'biller_note_perm' },
    { headerName: 'SubDesc', field: 'subdesc' },
    { headerName: 'Bring Up Type', field: 'bring_up_type' },
    {
      headerName: 'Send to Adapt', field: 'send_to_adapt',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      }
    },
    {
      headerName: 'My Bring Up', field: 'my_bring_up',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      }
    },
    { headerName: 'System', field: 'originating_system' },
    {
      headerName: 'Contested Amt', field: 'contested_amt',type: 'rightAligned',
      valueFormatter: currencyFormatter,
      cellStyle: params => {
        if (params.value < 0) {
          return { color: 'red' };//,backgroundColor: 'green'
        }
        return null;
      }
    },
    { headerName: 'Root Cause', field: 'root_cause' },
    { headerName: 'Next Action', field: 'next_action' },
    { headerName: 'Commitment Date', field: 'commitment_date' },
    { headerName: 'User ID', field: 'user_login_cd' },
    { headerName: 'Call Type', field: 'call_type' },
    { headerName: 'Payment Method', field: 'payment_method' },
    { headerName: 'Phone#', field: 'customer_phone_number' },
    { headerName: 'Ext', field: 'customer_phone_number_extn' },
    { headerName: 'Email', field: 'customer_email' },
    { headerName: 'ATTUID/CACS', field: 'contact_attuid' },
    { headerName: 'Account No', field: 'account_number' },
    { headerName: 'Insert Data', field: 'insert_date' },
    { headerName: 'Logged By', field: 'logged_by' },

  ];

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (!selectedData[0]) {
      return [];
    }
    var result: (string | any)[] = [
      {
        name: 'Add Note',
        action: () => {
          this.addAccountNotes('Add', this.currRowData);
        }
      },
      {
        name: 'Modify Note',
        action: () => {
          this.ModfiyAccountNotes('Modify', this.currRowData);
        }
      },
      {
        name: 'Delete Note',
        action: () => {
          this.confirmDeleteAccountNotes(this.currRowData);
        }
      },
      {
        name: 'Resolve Note',
        action: () => {
          this.resolveAccountNotes(this.currRowData);
        }
      },
      'copy',
      'copyWithHeaders',
      'export'
    ];
    return result;
  }

  addAccountNotes(Mode: string, currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let groupSeleted = this.groupSeleted;
    if (selectedData[0]) {
      let selectedAccountNumbers = selectedData[0].account_number;
      let originatingSystem = selectedData[0].originating_system;
      let selectedAccountNumbersArray: any = [];
      selectedAccountNumbersArray.push(selectedData[0].account_number);
      let originatingSystemArray: any = [];
      originatingSystemArray.push(selectedData[0].originating_system);
      let customerGrpCd = selectedData[0].customer_grp_cd;

      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.id = 'view-add-account-notes-component';
      dialogConfig.height = '90%';
      dialogConfig.width = '70%';
      dialogConfig.data = {
        Mode: Mode,
        selectedAccountNumbers: selectedAccountNumbers,
        originatingSystem: originatingSystem,
        customerGrpCd: customerGrpCd,
        currRowData: currRD,
        billingPeriod: selectedData[0].billing_period,
        originatingSystemArray: originatingSystemArray,
        selectedAccountNumbersArray: selectedAccountNumbersArray,
        groupSeleted: groupSeleted
      };
      const modalDialog = this.dialog.open(ViewAddAccountNotesComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {
        if (res.msg == 'success') {
          this.accountNotes(this.inpData);
        }
      });
    }
    else {
      this.toastr.error(
        '',
        'Please Select Account Number from the Grid',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }

  ModfiyAccountNotes(Mode: string, currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
    let groupSeleted = this.groupSeleted;
    let selectedAccountNumbers = selectedData[0].account_number;
    let originatingSystem = selectedData[0].originating_system;
    let selectedAccountNumbersArray = selectedData.map((e: any) => {
      return e.account_number;
    });
    let originatingSystemArray = selectedData.map((e: any) => {
      return e.originating_system;
    });
    let customerGrpCd = selectedData[0].customer_grp_cd;

    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '90%';
    dialogConfig.width = '70%';
    dialogConfig.data = {
      Mode: Mode,
      selectedAccountNumbers: selectedAccountNumbers,
      originatingSystem: originatingSystem,
      customerGrpCd: customerGrpCd,
      currRowData: currRD,
      billingPeriod: selectedData[0].billing_period,
      originatingSystemArray: originatingSystemArray,
      selectedAccountNumbersArray: selectedAccountNumbersArray,
      groupSeleted: groupSeleted,
    };
    const modalDialog = this.dialog.open(
      ViewModifyAccountNotesComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.accountNotes(this.inpData);
      }
    });
  }
  else{
    this.toastr.error(
      '',
      'Please Select Account Number from the Grid',
      {
        timeOut: 5000,
        closeButton: true,
      }
    );
  }
  }

  resolveAccountNotes(currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let groupSeleted = this.groupSeleted;
    if (selectedData[0]) {
      let resolveAccountNotesData: any = {};
      resolveAccountNotesData.noteId = currRD.notes_id;
      resolveAccountNotesData.notes = currRD.notes;
      this.accountNotesService.resolveAccountNotes(resolveAccountNotesData)
        .subscribe(
          (data: any) => {
            //console.log(data);
            if (data.msg == 'success') {
              this.accountNotes(this.inpData);
              this.currRowData = null;
              this.toastr.success('', 'Account Notes : Note Resolved!', {
                timeOut: 5000,
                closeButton: true,
              });
            }
          },
          (error: any) => {
            //console.log(error,"ResolveNoteError")
            if (error.error.errorMsg) {
              let errorX = error.error.errorMsg;
              this.accountNotes(this.inpData);
              this.currRowData = null;
              this.toastr.error(
                '',
                'Account Notes : Error in Operation!' + errorX,
                {
                  timeOut: 5000,
                  closeButton: true,
                }
              );
            }
          }
        );
    }
    else {
      this.toastr.error(
        '',
        'Account Notes : Select a Note to Resolve!',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }

  confirmDeleteAccountNotes(rowData:any) {
    let rowCount = this.gridApi.getSelectedNodes().length;
      this.confirmationService.confirm({
        message: "You are about to delete "+rowCount+"Record(s)."+
        "If you Click Yes,you won't be able to undo this Delete operation."+
        "Are you sure you want to delete these Records",
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.msgs = [{severity:'info', summary:'Confirmed', detail:'You have accepted'}];
            this.deleteAccountNotes(rowData)
        },
        reject: () => {
          this.toastr.info(
            '',
            'Account Notes : Cancelled the Delete Operation!',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );

        }
    });
    }


  deleteAccountNotes(currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let groupSeleted = this.groupSeleted;
    if (selectedData[0]) {
      let deleteAccNotesData: any = {};
      let noteListArrAccs: any = [];
      for (let i of selectedData) {
        noteListArrAccs.push(i.notes_id.toString());
      }
      deleteAccNotesData.noteIdList = noteListArrAccs;
      this.accountNotesService
        .deleteAccountNotes(deleteAccNotesData)
        .subscribe(
          (data: any) => {
            //console.log(data);
            if (data.msg == 'success') {
              this.accountNotes(this.inpData);
              this.currRowData = null;
              noteListArrAccs = [];
              this.toastr.success(
                '',
                'Account Notes : Note Deleted Successfully!',
                {
                  timeOut: 5000,
                  closeButton: true,
                }
              );
            }
          },
          (error: any) => {
            noteListArrAccs = [];
            if (error.error.errorMsg) {
              let errorX = error.error.errorMsg;
              this.accountNotes(this.inpData);
              this.currRowData = null;
              this.toastr.error(
                '',
                'Account Notes : Error in Operation!' + errorX,
                {
                  timeOut: 5000,
                  closeButton: true,
                }
              );
            }
          }
        );
    }
    else {
      this.toastr.error(
        '',
        'Account Notes : Select a Note to Delete!',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }

  accountNotes(inpData: any) {
    this.searchService.accountNotes(this.inpData).subscribe((data: any) => {
      this.columnDefs = this.columnDefsAN;
      // this.columnDefs = data.GridHeaders;
      this.rowData = data.AccountNotes;
    },
      (error: any) => {
        this.columnDefs = this.columnDefsAN;
        // this.columnDefs = data.GridHeaders;
        this.rowData = [];
        console.log(error);
      });
  }

}

function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAddAccountNotesComponent } from './view-add-account-notes.component';

describe('ViewAddAccountNotesComponent', () => {
  let component: ViewAddAccountNotesComponent;
  let fixture: ComponentFixture<ViewAddAccountNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAddAccountNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAddAccountNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

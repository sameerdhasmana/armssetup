import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAccountNotesComponent } from './view-account-notes.component';

describe('ViewAccountNotesComponent', () => {
  let component: ViewAccountNotesComponent;
  let fixture: ComponentFixture<ViewAccountNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAccountNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAccountNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

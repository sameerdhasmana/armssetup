import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAddCustomerNotesComponent } from './view-add-customer-notes.component';

describe('ViewAddCustomerNotesComponent', () => {
  let component: ViewAddCustomerNotesComponent;
  let fixture: ComponentFixture<ViewAddCustomerNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAddCustomerNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAddCustomerNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Inject, OnInit, AfterViewInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { CustomerNotesModalService } from 'src/app/services/customer-notes-modal.service';
import { GeneralUiFunctionsService } from 'src/app/services/general-ui-functions.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-view-add-customer-notes',
  templateUrl: './view-add-customer-notes.component.html',
  styleUrls: ['./view-add-customer-notes.component.scss']
})
export class ViewAddCustomerNotesComponent implements OnInit {
  commitDueDt: any;
  bringUpDt: any;
  Mode: string = "";
  rowData: any;
  customerGroupCd: any;
  billingPeriod: any;
  allFilters: any;


  rdbResolved: boolean = false;
  ddGroup: string = "";
  txtCommitDueDate: string = "";
  txtCommitment: number = 0;
  txtBringUpDate: string = "";
  ddTalkedTo: string = "";
  txtContested: number = 0;
  ddSubActivity: string = "";
  ddRootCause: string = "";
  ddNextAction: string = "";
  txtArNotes: string = "";

  form: any = new FormGroup({
    Resolved: new FormControl(),
    radioNotes: new FormControl(),
    Group: new FormControl(),
    CommitDueDate: new FormControl(),
    Commitment: new FormControl(),
    BringUpDate: new FormControl(),
    TalkedTo: new FormControl(),
    Contested: new FormControl(),
    SubActivity: new FormControl({ value: "", disabled: true }),
    RootCause: new FormControl({ value: "", disabled: true }),
    NextAction: new FormControl({ value: "", disabled: true }),
    Notes: new FormControl()
  })

  constructor(private _CustNotesModalService: CustomerNotesModalService,
    private _generalUiFnService: GeneralUiFunctionsService,
    private toastr: ToastrService,
    public dialogRef: MatDialogRef<ViewAddCustomerNotesComponent>,
    @Inject(MAT_DIALOG_DATA) data: any) {
    this.Mode = data.Mode;
    this.rowData = data.currRowData;
    this.customerGroupCd = data.customerGroupCd;
    this.billingPeriod = data.billingPeriod;
  }
  loginUser: any = {};
  ngOnInit(): void {
    let data = localStorage.getItem("userInfo");
    this.Filters = JSON.parse(data ? data : "");
    this.loginUser.userLoginCd = this.Filters.globalLogonUsers.user_login_cd;
    this.loginUser.customerGrpCd = this.Mode == "Add" ? this.customerGroupCd : this.rowData.customer_grp_cd;
    this._CustNotesModalService.getAllFilters(this.loginUser).subscribe((data: any) => {
      //console.log(data);
      this.allFilters = data;
    });

  }
  ngAfterViewInit(): void {

    if (this.Mode == "Add") {
      this.ddGroup = "ASC"
    }
    if (this.Mode != "Add") {
      //this.rdbResolved = this.rowData.resolved == 0 ? false : true;
      this.rdbResolved = !!this.rowData.resolved;
      this.ddGroup = this.rowData.group;
      this.txtCommitDueDate = (this.rowData.commitment_date).trim() == "" ? this.txtCommitDueDate : (this.rowData.commitment_date).trim();
      this.txtCommitment = this.rowData.commitment_amt;
      this.txtBringUpDate = this.rowData.next_call_back_date.trim() == "" ? this.txtBringUpDate : (this.rowData.next_call_back_date).trim();
      this.ddTalkedTo = this.rowData.talked_to;
      this.txtContested = this.rowData.contested_amt;
      this.txtArNotes = this.rowData.notes;

      if (this.rowData.activity_cd == "I") {
        this.form.controls['radioNotes'].setValue('InTreatment');
        this.EnableDisableControls('2', false);
        //this.ddSubActivity = this.rowData.subdesc;
        // this.ddRootCause = this.rowData.root_cause;
        // this.ddNextAction = this.rowData.next_action;
        this.ddSubActivity = (this.allFilters.subActivityList.find((e: any) => {
          if (e.sub_activity_short_description == this.rowData.subdesc) {
            return e.sub_activity_cd;
          }
        })).sub_activity_cd;
        this.ddRootCause = (this.allFilters.rootCauseList.find((e: any) => {
          if (e.rc_desc == this.rowData.root_cause) {
            return e.rc_cd;
          }
        })).rc_cd;
        this.ddNextAction = (this.allFilters.nextActionList.find((e: any) => {
          if (e.nxtact_desc == this.rowData.next_action) {
            return e.nxtact_cd;
          }
        })).nxtact_cd;
      }
      else if (this.rowData.activity_cd == "C") {
        this.form.controls['radioNotes'].setValue('CreditInformation');
        this.EnableDisableControls('1', true);
      }
      else if (this.rowData.activity_cd == "P") {
        this.form.controls['radioNotes'].setValue('PermNote');
        this.EnableDisableControls('1', true);
      }
      else if (this.rowData.activity_cd == "B") {
        this.form.controls['radioNotes'].setValue('Bankruptcy');
        this.EnableDisableControls('1', true);
      }
      else if (this.rowData.activity_cd == "N") {
        this.form.controls['radioNotes'].setValue('NoAction');
        this.EnableDisableControls('1', true);
      }
    }
  }

  EnableDisableControls(Mode: string, isClear: boolean) {
    if (Mode == "1") {
      this.form.controls['SubActivity'].disable();
      this.form.controls['RootCause'].disable();
      this.form.controls['NextAction'].disable();
      if (isClear) {
        this.clearValues();
      }
    }
    else {
      this.form.controls['SubActivity'].enable();
      this.form.controls['RootCause'].enable();
      this.form.controls['NextAction'].enable();
    }
    if (this.form.controls['radioNotes'].value == "CreditInformation") {
      this.form.controls['Resolved'].setValue(false);
    }
  }

  clearValues() {
    this.form.controls['SubActivity'].setValue("");
    this.form.controls['RootCause'].setValue("");
    this.form.controls['NextAction'].setValue("");
  }

  saveCustomerNotes: any = {};
  Filters: any;
  defaultGroup: any = [];
  Save() {
    let errMsg: string = this.validateSave();
    if (errMsg != "") {
      this.toastr.error('', errMsg, {
        timeOut: 5000, closeButton: true
      });
    }
    else {
      let data = localStorage.getItem("userInfo");
      this.Filters = JSON.parse(data ? data : "");
      this.defaultGroup = [];
      this.defaultGroup.push(this.ddGroup);
      const datepipe: DatePipe = new DatePipe('en-US')
      let BringUpDt = datepipe.transform(this.txtBringUpDate, 'MM/dd/YYYY');
      let CommitDueDt = datepipe.transform(this.txtCommitDueDate, 'MM/dd/YYYY');

      this.saveCustomerNotes.modeType = this.Mode == "Add" ? 1 : 2;
      this.saveCustomerNotes.noteId = this.Mode == "Add" ? 0 : this.rowData.notes_id;
      this.saveCustomerNotes.billingPeriod = this.Mode == "Add" ? (this.billingPeriod == undefined || this.billingPeriod == null ? this.Filters.customerBillingPeriod[0].billing_period : this.billingPeriod) : this.rowData.billing_period;
      this.saveCustomerNotes.groupSelected = this.defaultGroup;
      this.saveCustomerNotes.customerGrpCd = this.Mode == "Add" ? this.customerGroupCd : this.rowData.customer_grp_cd;
      this.saveCustomerNotes.resolved = this.rdbResolved == true ? 1 : 0;
      this.saveCustomerNotes.activityCode = (this.form.controls['radioNotes'].value == null || this.form.controls['radioNotes'].value == undefined) ? "" : (this.form.controls['radioNotes'].value.toString()).substring(0, 1);
      this.saveCustomerNotes.commitmentAmt = this.txtCommitment;
      this.saveCustomerNotes.bringupDate = BringUpDt?.toString();
      this.saveCustomerNotes.subActivity = this.form.controls['SubActivity'].value == null || this.form.controls['SubActivity'].value == undefined ? "" : this.form.controls['SubActivity'].value.toString();
      this.saveCustomerNotes.talkedTo = this.ddTalkedTo;
      this.saveCustomerNotes.userLoginCd = this.Filters.globalLogonUsers.user_login_cd;
      this.saveCustomerNotes.notes = this.txtArNotes;
      this.saveCustomerNotes.contestedAmt = this.txtContested;
      this.saveCustomerNotes.rcCode = this.form.controls['RootCause'].value == null || this.form.controls['RootCause'].value == undefined ? "" : this.form.controls['RootCause'].value.toString();
      this.saveCustomerNotes.nxtactCode = this.form.controls['NextAction'].value == null || this.form.controls['NextAction'].value == undefined ? "" : this.form.controls['NextAction'].value.toString();
      this.saveCustomerNotes.commitmentDate = CommitDueDt?.toString();

      //console.log(this.saveCustomerNotes);
      this._CustNotesModalService.saveNotes(this.saveCustomerNotes).subscribe((data: any) => {
        //console.log(data);
        if (data.msg == "success") {
          this.saveCustomerNotes = null;
          this.dialogRef.close({ msg: 'success' });
          this.toastr.success('', 'Customer Notes : Note Saved!', {
            timeOut: 5000, closeButton: true
          });
        }
      }, (error: any) => {
        this.toastr.error('', 'Customer Notes : Unable to save the Note. Please try again later!', {
          timeOut: 5000, closeButton: true
        });
      });
    }
  }

  validateSave() {
    let strMsg: string = "";
    if (this.form.controls['BringUpDate'].status == "INVALID" || this.form.controls['CommitDueDate'].status == "INVALID") {
      strMsg = "Please select a valid date";
      return strMsg;
    }
    const datepipe: DatePipe = new DatePipe('en-US')
    let newBringUpDt: any = datepipe.transform(this.txtBringUpDate, 'MM/dd/YYYY');
    let newCommitDueDt: any = datepipe.transform(this.txtCommitDueDate, 'MM/dd/YYYY');
    let CurrentDt = new Date();
    let Crrdt: any = datepipe.transform(CurrentDt, 'MM/dd/YYYY');
    var newCrrdt = new Date(Crrdt?.toString());

    if (newBringUpDt != "" && newBringUpDt != null && newBringUpDt != undefined) {
      var BUdt = new Date(newBringUpDt?.toString());
      if (BUdt.getDay() == 0 || BUdt.getDay() == 6) {
        strMsg = "Bring Up Date: Weekends are not allowed!";
      }
      if (BUdt.getFullYear() == newCrrdt.getFullYear()) {
        if (BUdt.getMonth() == newCrrdt.getMonth()) {
          if (BUdt.getDate() < newCrrdt.getDate()) {
            strMsg = "Bring Up Date: Past Dates are not allowed!";
          }
        }
        if (BUdt.getMonth() < newCrrdt.getMonth()) {
          strMsg = "Bring Up Date: Past Dates are not allowed!";
        }
      }
      else if (BUdt.getFullYear() < newCrrdt.getFullYear()) {
        strMsg = "Bring Up Date: Past Dates are not allowed!";
      }
    }
    if (newCommitDueDt != "" && newCommitDueDt != null && newCommitDueDt != undefined) {
      var CDdt = new Date(newCommitDueDt?.toString());
      if (CDdt.getDay() == 0 || CDdt.getDay() == 6) {
        strMsg = "Commit Due Date: Weekends are not allowed!";
      }
      if (CDdt.getFullYear() == newCrrdt.getFullYear()) {
        if (CDdt.getMonth() == newCrrdt.getMonth()) {
          if (CDdt.getDate() < newCrrdt.getDate()) {
            strMsg = "Commit Due Date: Past Dates are not allowed!";
          }
        }
        if (CDdt.getMonth() < newCrrdt.getMonth()) {
          strMsg = "Commit Due  Date: Past Dates are not allowed!";
        }
      }
      else if (CDdt.getFullYear() < newCrrdt.getFullYear()) {
        strMsg = "Commit Due Date: Past Dates are not allowed!";
      }
    }
    else if (this.form.controls['radioNotes'].value == null || this.form.controls['radioNotes'].value == undefined || this.form.controls['radioNotes'].value == "") {
      if (this.rdbResolved == true) {
        strMsg = "Please select at least one check box for activity";
      }
      else {
        strMsg = "Notes can not be added or modified without at least one status. Please select one or more status check boxes!";
      }
    }
    else {
      if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "I") {
        if (this.form.controls['SubActivity'].value == null || this.form.controls['SubActivity'].value == undefined || this.form.controls['SubActivity'].value == "") {
          strMsg = "Please select subactivity";
        }
        else if (this.txtArNotes.trim() == "") {
          strMsg = "Please type some notes";
        }
      }
      else if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "C") {
        if (this.txtArNotes.trim() == "") {
          strMsg = "Please add/modify notes to reflect credit information";
        }
      }
      else if (this.ddGroup == null || this.ddGroup == undefined || this.ddGroup == "") {
        strMsg = "Please select a group";
      }
    }
    return strMsg;
  }

  closeModal() {
    this.dialogRef.close({ msg: 'cancelled' });
  }

  allowOnlyNumbersWithSlash(event: any) {
    return this._generalUiFnService.allowOnlyNumbersWithSlash(event);
  }

}

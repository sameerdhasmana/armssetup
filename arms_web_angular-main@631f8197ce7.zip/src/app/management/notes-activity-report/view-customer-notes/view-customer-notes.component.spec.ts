import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCustomerNotesComponent } from './view-customer-notes.component';

describe('ViewCustomerNotesComponent', () => {
  let component: ViewCustomerNotesComponent;
  let fixture: ComponentFixture<ViewCustomerNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewCustomerNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCustomerNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

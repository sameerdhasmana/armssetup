import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, GetContextMenuItemsParams, ITooltipParams, MenuItemDef, ValueFormatterParams } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { HoveringHeadersComponent } from 'src/app/ContextMenuItems/hovering-headers/hovering-headers.component';
import { CustomerNotesModalService } from 'src/app/services/customer-notes-modal.service';
import { SearchService } from 'src/app/services/search.service';
import { SharedService } from 'src/app/services/shared.service';
import { ViewAddCustomerNotesComponent } from './view-add-customer-notes/view-add-customer-notes.component';
import {ConfirmationService} from 'primeng/api';
import {Message} from 'primeng/api';



@Component({
  selector: 'app-view-customer-notes',
  templateUrl: './view-customer-notes.component.html',
  styleUrls: ['./view-customer-notes.component.scss'],
  providers: [ConfirmationService]
})
export class ViewCustomerNotesComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    resizable: true,
  }
  columnDefs: any;
  pageSize: number = 1000;
  rowData: any;
  msgs: Message[] = [];
  inpData: any;
  filters: any = {};
  groupSeleted: any[] = [];
  billingPeriod: any;

  constructor(
    public dialogRef: MatDialogRef<ViewCustomerNotesComponent>,
    private dialog: MatDialog,
    private toastr: ToastrService,
    private searchService: SearchService,
    private sharedService: SharedService,
    private _CustNotesModalService: CustomerNotesModalService,
    private primengConfig: PrimeNGConfig,
    private confirmationService: ConfirmationService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.inpData = data.inpData
  }

  ngOnInit(): void {
    this.customerNotes(this.inpData);
    this.sharedService.filtersData$.subscribe((data: any) => {
      this.filters = { ...this.filters, ...data };
      this.billingPeriod = this.filters.billingPeriod;
      this.groupSeleted = this.filters.groupSelected;
    });
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
    //console.log('row', event.data);
  }

  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

  closeModal() {
    this.dialogRef.close({ msg: 'cancelled' });
  }

  columnDefsCN: ColDef[] = [
    { headerName: 'Notes ID', field: 'notes_id' },
    { headerName: 'Customer ID', field: 'customer_grp_cd' },
    { headerName: 'Billing Period', field: 'billing_period' },
    {
      headerName: 'Resolved', field: 'resolved',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      }
    },
    { headerName: 'Next Call Back Dt', field: 'next_call_back_date' },
    {
      headerName: 'Commitment Amt', field: 'commitment_amt',
      valueFormatter: currencyFormatter,
      cellStyle: params => {
        if (params.value < 0) {
          return { color: 'red' };//,backgroundColor: 'green'
        }
        return null;
      }
    },
    { headerName: 'Talked to', field: 'talked_to' },
    {
      headerName: 'Notes', field: 'notes', resizable: true,
      tooltipComponent: HoveringHeadersComponent,
      tooltipValueGetter: toolTipValueGetter
    },
    { headerName: 'Activity CD', field: 'activity_cd' },
    {
      headerName: 'In Treatment', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'I') ? 'checked' : ''} />`;
      }
    },
    {
      headerName: 'Perm Note', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'P') ? 'checked' : ''} />`;
      }
    },
    {
      headerName: 'Credit Information', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'C') ? 'checked' : ''} />`;
      }
    },
    {
      headerName: 'Bankruptcy', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'B') ? 'checked' : ''} />`;
      }
    },
    {
      headerName: 'No Action', field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${(params.value == 'N') ? 'checked' : ''} />`;
      }
    },

    { headerName: 'Sub Desc', field: 'subdesc' },
    { headerName: 'Group', field: 'group' },
    {
      headerName: 'Contested Amt', field: 'contested_amt',
      valueFormatter: currencyFormatter,
      cellStyle: params => {
        if (params.value < 0) {
          return { color: 'red' };//,backgroundColor: 'green'
        }
        return null;
      }
    },
    { headerName: 'Root Cause', field: 'root_cause' },
    { headerName: 'Next Action', field: 'next_action' },
    { headerName: 'Commitment Date', field: 'commitment_date' },
    { headerName: 'User ID', field: 'user_login_cd' },
    { headerName: 'Insert Date', field: 'insert_date' },
    { headerName: 'Log By', field: 'logged_by' },

  ];

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (!selectedData[0]) {
      return [];
    }
    var result: (string | any)[] = [
      {
        name: 'Add Note',
        action: () => {
          this.addModfiyCustomerNotes('Add', this.currRowData);
        }
      },
      {
        name: 'Modify Note',
        action: () => {
          this.addModfiyCustomerNotes('Modify', this.currRowData);
        }
      },
      {
        name: 'Delete Note',
        action: () => {
          this.confirmDeleteCustomerNotes(this.currRowData);
        }
      },
      {
        name: 'Resolve Note',
        action: () => {
          this.resolveCustomerNotes(this.currRowData);
        }
      },
      'copy',
      'copyWithHeaders',
      'export'
    ];
    return result;
  }

  addModfiyCustomerNotes(Mode: string, currRD: any) {
    if (Mode == 'Add') {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.id = 'modal-component';
      dialogConfig.height = '90%';
      dialogConfig.width = '70%';
      dialogConfig.data = {
        Mode: Mode,
        currRowData: currRD,
        customerGroupCd: this.inpData.customerGrpCd,
        billingPeriod: this.billingPeriod,
      };
      const modalDialog = this.dialog.open(
        ViewAddCustomerNotesComponent,
        dialogConfig
      );
      modalDialog.afterClosed().subscribe((res: any) => {
        if (res.msg == 'success') {
          this.customerNotes(this.inpData);
          this.currRowData = null;
        } else if (res.msg == 'cancelled') {
          this.customerNotes(this.inpData);
          this.currRowData = null;
        }
      });
    } else {
      if (currRD != undefined && currRD != null && currRD != '') {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.id = 'modal-component';
        dialogConfig.height = '90%';
        dialogConfig.width = '70%';
        dialogConfig.data = {
          Mode: Mode,
          currRowData: currRD,
          customerGroupCd: this.inpData.customerGrpCd,
        };
        const modalDialog = this.dialog.open(
          ViewAddCustomerNotesComponent,
          dialogConfig
        );
        modalDialog.afterClosed().subscribe((res: any) => {
          if (res.msg == 'success') {
            this.customerNotes(this.inpData);
            this.currRowData = null;
          } else if (res.msg == 'cancelled') {
            this.customerNotes(this.inpData);
            this.currRowData = null;
          }
        });
      } else {
        this.toastr.error(
          '',
          'Customer Notes : Select a Note to ' + Mode + '!',
          {
            timeOut: 5000,
            closeButton: true,
          }
        );
      }
    }
  }

  resolveCustomerNotes(currRD: any) {
    let resolveNotesData: any = {};
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
      resolveNotesData.userLoginCd = currRD.user_login_cd;
      resolveNotesData.noteId = currRD.notes_id;
      resolveNotesData.notes = currRD.notes;
      this._CustNotesModalService.resolveNotes(resolveNotesData).subscribe(
        (data: any) => {
          //console.log(data);
          if (data.msg == 'success') {
            this.customerNotes(this.inpData);
            this.currRowData = null;
            this.toastr.success('', 'Customer Notes : Note Resolved!', {
              timeOut: 5000,
              closeButton: true,
            });
          }
        },
        (error: any) => {
          //console.log(error,"ResolveNoteError")
          if (error.error.errorMsg) {
            let errorX = error.error.errorMsg;
            this.customerNotes(this.inpData);
            this.currRowData = null;
            this.toastr.error(
              '',
              'Customer Notes : Error in Operation!' + errorX,
              {
                timeOut: 5000,
                closeButton: true,
              }
            );
          }
        }
      );
    } else {
      this.toastr.error('', 'Customer Notes : Select a Note to Resolve!', {
        timeOut: 5000,
        closeButton: true,
      });
    }
  }

  confirmDeleteCustomerNotes(rowData:any) {
    let rowCount = this.gridApi.getSelectedNodes().length;
      this.confirmationService.confirm({
        message: "You are about to delete "+rowCount+"Record(s)."+
        "If you Click Yes,you won't be able to undo this Delete operation."+
        "Are you sure you want to delete these Records",
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.msgs = [{severity:'info', summary:'Confirmed', detail:'You have accepted'}];
            this.deleteCustomerNotes(rowData)
        },
        reject: () => {
          this.toastr.info(
            '',
            'Customer Notes : Cancelled the Delete Operation!',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );

        }
    });
    }


  deleteCustomerNotes(currRD: any) {
    let deleteNotesData: any = {};
    let noteListArr: any = [];
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
      for (let i of selectedData) {
        noteListArr.push(i.notes_id.toString());
      }
      deleteNotesData.noteIdList = noteListArr;
      this._CustNotesModalService.deleteNotes(deleteNotesData).subscribe(
        (data: any) => {
          //console.log(data);
          if (data.msg == 'success') {
            this.customerNotes(this.inpData);
            this.currRowData = null;
            noteListArr = [];
            this.toastr.success('', 'Customer Notes : Note Deleted!', {
              timeOut: 5000,
              closeButton: true,
            });
          }
        },
        (error: any) => {
          noteListArr = [];
        }
      );
    } else {
      this.toastr.error('', 'Customer Notes : Select a Note to Delete!', {
        timeOut: 5000,
        closeButton: true,
      });
    }
  }


  customerNotes(inpData: any) {
    this.searchService.customerNotes(this.inpData).subscribe((data: any) => {
      this.columnDefs = data.GridHeaders.map((item: any, i: number) => Object.assign({}, item,
        this.columnDefsCN.find((c: any) => {
          return item.headerName == c.headerName
        })
      ));
      this.rowData = data.CustomerNotes;
    },
      (error: any) => {
        this.columnDefs = this.columnDefsCN;
        // this.columnDefs = data.GridHeaders;
        this.rowData = [];
        console.log(error);
      });
  }

}

function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});


import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, MenuItemDef } from 'ag-grid-enterprise';
import { ToastrService } from 'ngx-toastr';
import { AllModules } from '@ag-grid-enterprise/all-modules';
import { PrimeNGConfig } from 'primeng/api';
import { CellDoubleClickedEvent, ColumnApi, GridOptions, GridReadyEvent, ValueFormatterParams } from 'ag-grid-community';
import { Router } from '@angular/router';
import { ManagementService } from 'src/app/services/management.service';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-open-flag-report',
  templateUrl: './open-flag-report.component.html',
  styleUrls: ['./open-flag-report.component.scss']
})
export class OpenFlagReportComponent implements OnInit {

  @ViewChild('agGrid') agGrid!: AgGridAngular;

  constructor(
    private management : ManagementService,
    private toastr: ToastrService,
    private router : Router,
    private primengConfig: PrimeNGConfig,
    private loadingSpinner: NgxSpinnerService,
  ) { }

  gridOptions: GridOptions ={
    onCellDoubleClicked : (
      event: CellDoubleClickedEvent
  ) =>   console.log("Hi") //this.addModifyContact("Modify",this.currRowData)
  }

  defaultExcelExportParams:any;
  managers: any = [];
  selectedManager: any;
  rowData: any;
  columnDefs: any;
  showOpenFlagGrid: boolean = false;
  pageSize: number = 2000;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true
  }



  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.management.getAllManagers().subscribe((data: any) => {
      this.managers = data.Managers;
    });
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  gridColumnApi!: ColumnApi;
  modules = AllModules;

  onGridReady(params:GridReadyEvent) {
    this.gridColumnApi = params.columnApi;
    this.gridApi = params.api;
    //this.gridApi.sizeColumnsToFit();
  }


  columnDefsOF: ColDef[] = [
    { headerName: 'Assigned CAS(User)', field: 'Assigned_CAS' },
    { headerName: 'Account Nbr', field: 'account_number'},
    { headerName: 'Customer', field: 'Customer' },
    { headerName: 'Bill Name', field: 'Bill_Name' },
    { headerName: 'Status', field: 'status' },
    { headerName: 'Flag Age', field: 'flag_age' },
    { headerName: 'Flag Activity', field: 'flag_activity' },
    { headerName: 'Current Bill Amt', field: 'current_billing_amt',
    type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }
   },
    { headerName: 'Current Balance Amt', field: 'current_balance_amt',
    type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }
  },
    { headerName: '30 Days Amt', field: '30_days_amt',
    type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }
  },
    { headerName: '60 Days Amt', field: '60_days_amt',
    type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
     } },
    { headerName: '90 Days Amt', field: '90_days_amt', type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: '120 Days Amt', field: '120_days_amt', type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Past Due Amt', field: 'past_due_amt', type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Collectable Amt', field: 'collectable_amt', type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Bill Dt', field: 'bill_dt' },
    { headerName: 'Treatment Step', field: 'treatment_step' },
    { headerName: 'Originating System', field: 'originating_system' },
    { headerName: 'AP Sub Group', field: 'ap_sub_group' },
    { headerName: 'State', field: 'state' },
      ];

  inputData: any = {};

  selectionTrigger(event:any) {
    if(event.value === '' || event.value === null ){
      this.clearSearch(event.value)
      return
    }
    this.showOpenFlagGrid = false;
    this.loadingSpinner.show();
    this.inputData.managerLoginCd = this.selectedManager;
    this.defaultExcelExportParams=  {
    fileName: 'OpenFlagActivtyReport-'+ this.selectedManager+'-'+Date()
  }
    this.showOpenFlagGrid = true;
    this.management.openFlagActivityReport(this.inputData).subscribe((data: any) => {
      this.loadingSpinner.hide();
      this.columnDefs = this.columnDefsOF;
      this.rowData = data.OpenFlagActivity;
      this.gridApi.showLoadingOverlay();
    });
  }

  clearSearch(event:any){
    this.rowData=[];
    this.showOpenFlagGrid = false;
  }


  onExit(){
    this.router.navigate(['/query']);
   }


  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
  `<span class="ag-overlay-loading-center">
  No Data Found in the System
  </span>`;


   exportAsExcel(){
    if(this.rowData.length!=0){
      this.gridApi.exportDataAsExcel();
      this.toastr.success('', 'Open Flag Activity Report : Download Completed!', {
        timeOut: 5000, closeButton: true
      });
     }else{
      this.gridApi.exportDataAsExcel();
      this.toastr.info('', 'Open Flag Activity Report : No Reports available!', {
        timeOut: 5000, closeButton: true
      });
     }
   }
}
function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

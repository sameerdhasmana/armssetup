import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OutstandingReportComponent } from './outstanding-report/outstanding-report.component';
import { OpenFlagReportComponent } from './open-flag-report/open-flag-report.component';
import { AgGridModule } from 'ag-grid-angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../material/material.module';
import { RouterModule } from '@angular/router';
import 'ag-grid-enterprise';
import { PaymentTermsComponent } from './payment-terms/payment-terms.component';
import { UpdatePaymentTermComponent } from './payment-terms/update-payment-term/update-payment-term.component';
import { SaveUpdatePaymentTermComponent } from './payment-terms/update-payment-term/save-update-payment-term/save-update-payment-term.component';
import { ViewAccountNotesComponent } from './notes-activity-report/view-account-notes/view-account-notes.component';
import { ViewAddAccountNotesComponent } from './notes-activity-report/view-account-notes/view-add-account-notes/view-add-account-notes.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgxSpinnerModule } from "ngx-spinner";
import { ViewCustomerNotesComponent } from './notes-activity-report/view-customer-notes/view-customer-notes.component';
import { ViewAddCustomerNotesComponent } from './notes-activity-report/view-customer-notes/view-add-customer-notes/view-add-customer-notes.component';
import { ViewModifyAccountNotesComponent } from './notes-activity-report/view-account-notes/view-modify-account-notes/view-modify-account-notes.component';
import { HoveringHeadersComponent } from './hovering-headers.component';



@NgModule({
  declarations: [
    OutstandingReportComponent,
    OpenFlagReportComponent,
    PaymentTermsComponent,
    UpdatePaymentTermComponent,
    SaveUpdatePaymentTermComponent,
    ViewAccountNotesComponent,
    ViewAddAccountNotesComponent,
    ViewCustomerNotesComponent,
    ViewAddCustomerNotesComponent,
    ViewModifyAccountNotesComponent,
    ViewAddAccountNotesComponent,
    HoveringHeadersComponent
  ],
  imports: [
    CommonModule,
    AgGridModule,
    MaterialModule,
    BrowserAnimationsModule,
    RouterModule,
    FormsModule,ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    NgxSpinnerModule

  ]
})
export class ManagementModule { }

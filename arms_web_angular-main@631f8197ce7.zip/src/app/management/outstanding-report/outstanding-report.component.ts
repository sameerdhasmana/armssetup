import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, MenuItemDef } from 'ag-grid-enterprise';
import { ToastrService } from 'ngx-toastr';
import { AllModules } from '@ag-grid-enterprise/all-modules';
import { PrimeNGConfig } from 'primeng/api';
import { CellDoubleClickedEvent, ColumnApi, GridOptions, ValueFormatterParams } from 'ag-grid-community';
import { Router } from '@angular/router';
import { ManagementService } from 'src/app/services/management.service';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-outstanding-report',
  templateUrl: './outstanding-report.component.html',
  styleUrls: ['./outstanding-report.component.scss']
})
export class OutstandingReportComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  constructor(
    private management : ManagementService,
    private toastr: ToastrService,
    private router : Router,
    private primengConfig: PrimeNGConfig,
    private loadingSpinner: NgxSpinnerService,
  ) { }

  gridOptions: GridOptions ={
    onCellDoubleClicked : (
      event: CellDoubleClickedEvent
  ) =>   console.log("Hi") //this.addModifyContact("Modify",this.currRowData)
  }

  defaultExcelExportParams:any;
  managers: any = [];
  selectedManager: any;
  rowData: any;
  columnDefs: any;
  showOutFlagGrid: boolean = false;
  pageSize: number = 2000;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true
  }



  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.management.getAllManagers().subscribe((data: any) => {
      this.managers = data.Managers;
    });
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  gridColumnApi!: ColumnApi;
  modules = AllModules;

  onGridReady(params:any) {
    this.gridColumnApi = params.columnApi;
    this.gridApi = params.api;
    //this.gridApi.sizeColumnsToFit();
  }


  columnDefsOB: ColDef[] = [
    { headerName: 'Assigned CAS(User)', field: 'Assigned_CAS' },
    { headerName: 'Bring Up Date', field: 'Bring_Up_Date' },
    { headerName: 'Account Nbr', field: 'account_number'},
    { headerName: 'Customer', field: 'Customer' },
    { headerName: 'Bill Name', field: 'Bill_Name' },
    { headerName: 'Past Due Amt', field: 'past_due_amt', type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Status', field: 'status' },
    { headerName: 'State', field: 'state' },
    { headerName: 'System', field: 'system' }
  ];

  inputData: any = {};

  selectionTrigger(event:any) {
    if(event.value === '' || event.value === null ){
      this.clearSearch(event.value)
      return
    }
    this.showOutFlagGrid = false;
    this.loadingSpinner.show();
    this.inputData.managerLoginCd = this.selectedManager;
   this.defaultExcelExportParams=  {
    fileName: 'outstandingBringUpReport-'+ this.selectedManager+'-'+Date()
  }
    this.management.outstandingBringUpReport(this.inputData).subscribe((data: any) => {
      this.loadingSpinner.hide();
      this.showOutFlagGrid = true;
      this.columnDefs = this.columnDefsOB;
      this.rowData = data.OutstandingBringUp;
      this.gridApi.showLoadingOverlay();
    });
  }

  clearSearch(event:any){
    this.rowData=[];
    this.showOutFlagGrid = false;
  }

  onExit(){
    this.router.navigate(['/query']);
   }


  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
  `<span class="ag-overlay-loading-center">
  No Data Found in the System
  </span>`;


   searchValue: any;
   quickSearch(){
   this.gridApi.setQuickFilter(this.searchValue);
   }
   exportAsExcel(){
    if(this.rowData.length!=0){
     this.gridApi.exportDataAsExcel();
     this.toastr.success('', 'Outstanding Bringups Report : Download Completed!', {
       timeOut: 5000, closeButton: true
     });
    }else{
    this.gridApi.exportDataAsExcel();
    this.toastr.info('', 'Outstanding Bringups Report : No Reports available!', {
       timeOut: 5000, closeButton: true
     });
    }
  }
  }

  function currencyFormatter(params: ValueFormatterParams) {
    return '$' + formatNumber(params.value);
  }

  function formatNumber(number: number) {
    // this puts commas into the number eg 1000 goes to 1,000,
    // i pulled this from stack overflow, i have no idea how it works
    return Math.floor(number)
      .toString()
      .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  }


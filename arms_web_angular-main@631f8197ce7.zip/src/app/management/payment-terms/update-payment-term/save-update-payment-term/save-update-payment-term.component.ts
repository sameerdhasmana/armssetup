import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { ManagementService } from 'src/app/services/management.service';

@Component({
  selector: 'app-save-update-payment-term',
  templateUrl: './save-update-payment-term.component.html',
  styleUrls: ['./save-update-payment-term.component.scss']
})
export class SaveUpdatePaymentTermComponent implements OnInit {
  originatingSystem: any;
  selectedAccountNumbers: any;

  PaymentTerms: number = 0;
  chkIfDisabled: boolean = true;
  form: any = new FormGroup({
    PaymentTerms: new FormControl()
  });

  constructor(
    public dialogRef: MatDialogRef<SaveUpdatePaymentTermComponent>,
    private toastr: ToastrService,
    private managementService: ManagementService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.originatingSystem = data.originatingSystem;
    this.selectedAccountNumbers = data.selectedAccountNumbers;
  }

  ngOnInit(): void {
  }

  Save() {
    let obj = {
      originatingSystem: this.originatingSystem,
      selectedAccountNumbers: this.selectedAccountNumbers,
      paymentTerm: this.PaymentTerms == null || this.PaymentTerms == undefined ? 0 : this.PaymentTerms
    }
    this.managementService.paymentTermUpdate(obj).subscribe((data: any) => {
      this.toastr.success('', 'Payment Terms saved for selected account number(s) successfully', {
        timeOut: 5000, closeButton: true
      });
      this.dialogRef.close({ msg: "success" });
    });
  }

  onPaymentTermsChange(event: any) {
    if (event.target.value == 0 || event.target.value == "") {
      this.chkIfDisabled = true;
    }
    else {
      this.chkIfDisabled = false;
    }
  }

  closeModal() {
    this.dialogRef.close({ msg: "cancelled" });
  }

}

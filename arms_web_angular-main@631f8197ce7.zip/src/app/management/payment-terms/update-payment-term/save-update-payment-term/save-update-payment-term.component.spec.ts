import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveUpdatePaymentTermComponent } from './save-update-payment-term.component';

describe('SaveUpdatePaymentTermComponent', () => {
  let component: SaveUpdatePaymentTermComponent;
  let fixture: ComponentFixture<SaveUpdatePaymentTermComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaveUpdatePaymentTermComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveUpdatePaymentTermComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { ManagementService } from 'src/app/services/management.service';
import { SaveUpdatePaymentTermComponent } from './save-update-payment-term/save-update-payment-term.component';

@Component({
  selector: 'app-update-payment-term',
  templateUrl: './update-payment-term.component.html',
  styleUrls: ['./update-payment-term.component.scss']
})
export class UpdatePaymentTermComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true
  }
  columnDefs: any;
  pageSize: number = 1000;
  rowData: any;
  currRowData: any;
  gridApi: any;
  columnDefsUPT: ColDef[] = [
    {
      headerName: 'Account', field: 'account_number',
      headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true
    },
    { headerName: 'Payment', field: 'payment_terms' },
    { headerName: 'System', field: 'originating_system' }
  ];

  activeTab: string;
  tblData: any;
  constructor(
    public dialogRef: MatDialogRef<UpdatePaymentTermComponent>,
    private toastr: ToastrService,
    public matDialog: MatDialog,
    private managementService: ManagementService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.activeTab = data.activeTab;
    this.tblData = data.tblData;
    if (this.activeTab == "Search By Account Number") {
      this.searchByAccount(this.tblData);
    }
    else {
      this.searchByCustomer(this.tblData);
    }
  }

  searchByAccount(tblData: any) {
    this.managementService.searchByAccount(tblData).subscribe((data: any) => {
      this.rowData = data.PaymentTerm;
      this.columnDefs = this.columnDefsUPT;
    });
  }

  searchByCustomer(tblData: any) {
    this.managementService.searchByCustomer(tblData).subscribe((data: any) => {
      this.rowData = data.PaymentTerm;
      this.columnDefs = this.columnDefsUPT;
    });
  }

  ngOnInit(): void {
  }

  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  UpdatePaymentTerm() {
    let originatingSystem = [];
    let selectedAccountNumbers = [];
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (!selectedData[0]) {
      this.toastr.error('', 'Please select an Account number!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    for (let i = 0; i < selectedData.length; i++) {
      if (selectedData[i].originating_system != "") {
        originatingSystem.push(selectedData[i].originating_system.toString());
      }
    }
    for (let i = 0; i < selectedData.length; i++) {
      selectedAccountNumbers.push(selectedData[i].account_number.toString());
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = "Save Update Payment Terms";
    dialogConfig.height = "45%";
    dialogConfig.width = "27%";
    dialogConfig.data = {
      originatingSystem: originatingSystem,
      selectedAccountNumbers: selectedAccountNumbers
    }
    const modalDialog = this.matDialog.open(SaveUpdatePaymentTermComponent, dialogConfig);
    modalDialog.afterClosed().subscribe((res: any) => {
      if (this.activeTab == "Search By Account Number") {
        this.searchByAccount(this.tblData);
      }
      else {
        this.searchByCustomer(this.tblData);
      }
    });
  }

  closeModal() {
    this.dialogRef.close();
  }

  RedirectToHelp() {
    window.open('https://peoria.web.att.com/business/Wholesale/enterprise/jobaids/armsja.htm#Notes_act_Rpt', '_blank')
  }

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
    Please wait while your Data is loading
    </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
     border: 2px solid #444;
     background: lightgoldenrodyellow;">
     No Data Found in the System
     </span>`;

     searchValue: any;
     quickSearch(){
     this.gridApi.setQuickFilter(this.searchValue);
     }

}

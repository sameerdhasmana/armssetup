import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePaymentTermComponent } from './update-payment-term.component';

describe('UpdatePaymentTermComponent', () => {
  let component: UpdatePaymentTermComponent;
  let fixture: ComponentFixture<UpdatePaymentTermComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatePaymentTermComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatePaymentTermComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

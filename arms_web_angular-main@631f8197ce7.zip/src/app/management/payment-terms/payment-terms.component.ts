import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, ColumnMovedEvent, DragStoppedEvent, GetContextMenuItemsParams, GridOptions, GridReadyEvent, MenuItemDef } from 'ag-grid-community';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from 'ngx-toastr';
import { ManagementService } from 'src/app/services/management.service';
import { UpdatePaymentTermComponent } from './update-payment-term/update-payment-term.component';

@Component({
  selector: 'app-payment-terms',
  templateUrl: './payment-terms.component.html',
  styleUrls: ['./payment-terms.component.scss']
})
export class PaymentTermsComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true
  }
  columnDefs: any;
  pageSize: number = 1000;
  rowData: any;
  currRowData: any;
  gridApi: any;
  columnDefsCustomerInfo: ColDef[] = [
    { headerName: 'customer_grp_cd', field: 'customer_grp_cd', hide: true },
    {
      headerName: 'Customer', field: 'customer_legal_nm',
      headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true,
      width: 360
    }
  ];

  activeTab: string = "Search By Account Number";
  AccountNumber: string = "";
  Groups: any;
  OriginatingSystem: any;
  Segment: any = [];
  Filters: any;
  segmentList: any;

  form: any = new FormGroup({
    AccountNumber: new FormControl(),
    Groups: new FormControl(),
    OriginatingSystem: new FormControl(),
    Segment: new FormControl()
  });

  constructor(
    private managementService: ManagementService,
    private toastr: ToastrService,
    public matDialog: MatDialog
  ) { }

  ngOnInit(): void {
    this.managementService.renderSearchByCustomer().subscribe((data: any) => {
      this.Filters = data;
      //console.log(this.Filters);
      this.columnDefs = this.columnDefsCustomerInfo;
      this.rowData = data.CustomerInfo;
    });

  }

  validateSearch() {
    let msg = "";
    if (this.activeTab == "Search By Account Number" && this.AccountNumber == "") {
      msg = "The Account number you entered does not exist in the database. Please try again.";
    }
    return msg;
  }

  search() {
    let msg = this.validateSearch();
    if (msg != "") {
      this.toastr.error('', msg, {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    if (this.activeTab == "Search By Account Number") {
      let obj = { accountNumber: this.AccountNumber };
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.id = "Update Payment Terms";
      dialogConfig.height = "90%";
      dialogConfig.width = "90%";
      dialogConfig.data = {
        activeTab: this.activeTab,
        tblData: obj
      }
      const modalDialog = this.matDialog.open(UpdatePaymentTermComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {

      })
    }
    else {
      let customerGroupCdArr = [];
      let selectedNodes = this.gridApi.getSelectedNodes();
      let selectedData = selectedNodes.map((node: any) => node.data);
      for (let i = 0; i < selectedData.length; i++) {
        customerGroupCdArr.push(selectedData[i].customer_grp_cd.toString());
      }
      let obj = {
        originatingSystem: this.form.value.OriginatingSystem == "" ? [] : this.form.value.OriginatingSystem,
        segment: this.form.value.Segment == "" ? [] : this.form.value.Segment,
        groupSelected: this.form.value.Groups == "" ? [] : this.form.value.Groups,
        customerGrpCdList: customerGroupCdArr
      };
      if (obj.customerGrpCdList.length == 0) {
        this.toastr.error('', 'The customer you selected does not exist in the database. Please try again.', {
          timeOut: 5000, closeButton: true
        });
        return;
      }
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.id = "Update Payment Terms";
      dialogConfig.height = "90%";
      dialogConfig.width = "72%";
      dialogConfig.data = {
        activeTab: this.activeTab,
        tblData: obj
      }
      const modalDialog = this.matDialog.open(UpdatePaymentTermComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {

      })
    }
  }

  async filterData() {
    let obj = { groupSelected: this.form.value.Groups };
    if (obj.groupSelected.length == 0) {
      this.segmentList = [];
    }
    else {
      let result = await this.managementService.populateSegment(obj).subscribe((e: any) => {
        this.segmentList = e.Segment;
      },
        (error: any) => {
          console.log(error);
        });
    }
  }

  onTabSelect(event: any): any {
    this.activeTab = event.tab.textLabel;
  }

  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
    Please wait while your Data is loading
    </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
     border: 2px solid #444;
     background: lightgoldenrodyellow;">
     No Data Found in the System
     </span>`;

     searchValue: any;
     quickSearch(){
     this.gridApi.setQuickFilter(this.searchValue);
     }

}

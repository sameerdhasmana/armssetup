import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-xref3-maintenacne',
  templateUrl: './xref3-maintenacne.component.html',
  styleUrls: ['./xref3-maintenacne.component.scss']
})
export class Xref3MaintenacneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

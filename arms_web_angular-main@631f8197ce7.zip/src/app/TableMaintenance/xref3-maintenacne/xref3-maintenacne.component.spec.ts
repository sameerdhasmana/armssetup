import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Xref3MaintenacneComponent } from './xref3-maintenacne.component';

describe('Xref3MaintenacneComponent', () => {
  let component: Xref3MaintenacneComponent;
  let fixture: ComponentFixture<Xref3MaintenacneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Xref3MaintenacneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Xref3MaintenacneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

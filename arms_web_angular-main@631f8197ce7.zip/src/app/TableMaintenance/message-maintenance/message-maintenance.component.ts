import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageMaintenanceService } from 'src/app/services/message.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-message-maintenance',
  templateUrl: './message-maintenance.component.html',
  styleUrls: ['./message-maintenance.component.scss'],
})
export class MessageMaintenanceComponent implements OnInit {
  messageDB: any;

  constructor(
    private router: Router,
    private message: MessageMaintenanceService,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.message.fetchMessage('').subscribe((data: any) => {
      this.messageDB = data.meesage[0].the_msg;
    });
  }

  saveMessageInputs: any = {};
  onSave() {
    this.saveMessageInputs.menuMsg = this.messageDB;
    this.message.modifyMenuMsg(this.saveMessageInputs).subscribe(
      (data: any) => {
        console.log(data);
        if (data.msg == 'success') {
          this.toastr.success('', 'Message Update Successfully', {
            timeOut: 5000,
            closeButton: true,
          });
        }
      },
      (error: any) => {
        this.toastr.error('', 'Error in updating the Message', {
          timeOut: 5000,
          closeButton: true,
        });
      }
    );
  }

  onExit() {
    this.router.navigate(['/query']);
  }
}

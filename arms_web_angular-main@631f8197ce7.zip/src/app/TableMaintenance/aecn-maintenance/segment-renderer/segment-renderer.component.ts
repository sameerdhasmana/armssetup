import { Component, ViewChild, ViewContainerRef,OnInit } from "@angular/core";
import { ICellEditorAngularComp } from 'ag-grid-angular';
import { ICellEditorParams } from "ag-grid-enterprise";

@Component({
  selector: 'app-segment-renderer',
  templateUrl: './segment-renderer.component.html',
  styleUrls: ['./segment-renderer.component.scss']
})
export class SegmentRendererComponent implements OnInit,ICellEditorAngularComp   {
  private params!: ICellEditorParams & { managers: string[] };

private cellValue :any;
selectedManager : any;
managers : any=[];
private selectedIndex!: number;
constructor(){}


getValue() {
  return this.selectedManager;
}

isPopup(): boolean {
  return true;
}

  @ViewChild("group", { read: ViewContainerRef })
  public group!: ViewContainerRef;

  agInit(params: any) {

    this.managers =  params.managers;
    this.params = params;
    this.selectedManager = params.value;
    this.selectedIndex = this.managers.findIndex((item:any) => {
      return item === this.params.value;
  });

  }

  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }


  refresh(params:any):boolean {
return true;
  }

  ngAfterViewInit() {
    window.setTimeout(() => {
        this.group.element.nativeElement.focus();
    });
    this.selectFavouriteVegetableBasedOnSelectedIndex();
}
private selectFavouriteVegetableBasedOnSelectedIndex() {
  this.selectedManager = this.managers[this.selectedIndex];
}

onKeyDown(event: any): void {
  const key = event.key;
  if (key === 'ArrowUp' || key === 'ArrowDown') {
      this.preventDefaultAndPropagation(event);

      if (key == 'ArrowUp') {
          // up
          this.selectedIndex = this.selectedIndex === 0 ? this.managers.length - 1 : this.selectedIndex - 1;
      } else if (key == 'ArrowDown') {
          // down
          this.selectedIndex = this.selectedIndex === this.managers.length - 1 ? 0 : this.selectedIndex + 1;
      }
      this.selectFavouriteVegetableBasedOnSelectedIndex();
  }
}

private preventDefaultAndPropagation(event: any) {
  event.preventDefault();
  event.stopPropagation();
}



}

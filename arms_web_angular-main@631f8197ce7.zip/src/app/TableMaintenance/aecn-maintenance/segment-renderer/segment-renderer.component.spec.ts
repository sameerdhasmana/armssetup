import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SegmentRendererComponent } from './segment-renderer.component';

describe('SegmentRendererComponent', () => {
  let component: SegmentRendererComponent;
  let fixture: ComponentFixture<SegmentRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SegmentRendererComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SegmentRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AECNMaintenanceComponent } from './aecn-maintenance.component';

describe('AECNMaintenanceComponent', () => {
  let component: AECNMaintenanceComponent;
  let fixture: ComponentFixture<AECNMaintenanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AECNMaintenanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AECNMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

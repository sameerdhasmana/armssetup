import { Component, OnInit,ViewChild } from '@angular/core';
import { ColDef, ICellEditorParams, KeyCreatorParams } from 'ag-grid-community';
import {  GridOptions, Module } from "@ag-grid-community/core";
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import "@ag-grid-community/core/dist/styles/ag-grid.css";
import "@ag-grid-community/core/dist/styles/ag-theme-material.css";
import { SegmentRendererComponent } from './segment-renderer/segment-renderer.component';
import { ManagementService } from 'src/app/services/management.service';
import { CheckboxControlValueAccessor } from '@angular/forms';
import { ClientSideRowModelModule } from "@ag-grid-community/client-side-row-model";

import {

  GridReadyEvent,
  ICellRendererComp,
  ICellRendererParams,

} from 'ag-grid-community';

@Component({
  selector: 'app-aecn-maintenance',
  templateUrl: './aecn-maintenance.component.html',
  styleUrls: ['./aecn-maintenance.component.scss']
})
export class AECNMaintenanceComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;
  modules: Module[] = [ClientSideRowModelModule];
  public gridOptions!: GridOptions;


  defaultColDef: ColDef = {
    sortable: true,
    filter: true
}
pageSize=1000;
managers:any=[];


columnDefs: ColDef[] = [
  { field:'Segment',
  headerName : 'Segment-POpUp',
cellEditorParams: {
vegetables: this.managers
},
editable: true
},
  { field:'AECN',width:100, editable:true},
  { field:'Customer',width:300},
  { field:'Notes',width:800, resizable: true,editable:true,
  cellEditorPopup: true,
  cellEditor: 'agLargeTextCellEditor',},
  { field:'AutoAssign',width:150,}
];

rowData: Observable<any[]>;

constructor(private http: HttpClient,
  private management :  ManagementService) {

  this.rowData = this.http.get<any[]>('assets/AecnMaintenanceRecord.json');

}


ngOnInit(): void {
  this.management.getAllManagers().subscribe((data: any) => {
    this.managers = data.Managers;
  });
  }
}

class TestRendererComponent implements ICellRendererComp {
  eGui!: HTMLElement;

  init(params: ICellRendererParams) {
    this.eGui = document.createElement('div');
    this.eGui.innerHTML = `${params.value.name}`;
  }

  getGui() {
    return this.eGui;
  }

  refresh(params: ICellRendererParams): boolean {
    return false;
  }
}

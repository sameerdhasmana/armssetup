import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CellRendererTestComponent } from './cell-renderer-test.component';

describe('CellRendererTestComponent', () => {
  let component: CellRendererTestComponent;
  let fixture: ComponentFixture<CellRendererTestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CellRendererTestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CellRendererTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

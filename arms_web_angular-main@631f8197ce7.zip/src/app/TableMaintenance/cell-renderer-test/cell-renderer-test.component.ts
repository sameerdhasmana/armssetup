import { Component, OnInit } from '@angular/core';
import { ColDef, GridReadyEvent, ValueGetterParams } from 'ag-grid-community';


@Component({
  selector: 'app-cell-renderer-test',
  templateUrl: './cell-renderer-test.component.html',
  styleUrls: ['./cell-renderer-test.component.scss']
})
export class CellRendererTestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  public columnDefs: ColDef[] = [
    {
      headerName: 'CustomerID',
      field:'customer_grp_cd'

    },
    {
      headerName: 'CustomerName',
      field:'customer_legal_nm',
      //valueGetter: customerNameGetter,
    },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 75,
    // cellClass: 'number-cell'
  };

  public rowData: any[] | null =[
    {
        "customer_grp_cd": "A990952"
    },
    {
        "customer_grp_cd": "C101621"
    },
    {
        "customer_grp_cd": "O376702"
    }
  ];
  onGridReady(params: GridReadyEvent) {}

  customerNameGetter = function (params: ValueGetterParams) {
    return params.node ? params.node.rowIndex : null;
  };


}

import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { CheckBoxRenderComponent } from './check-box-render/check-box-render.component';
import { SegmentMaintenanceService } from 'src/app/services/segmentMaintenance.service';
import {
  CellDoubleClickedEvent,
  CellEditingStoppedEvent,
  CellValueChangedEvent,
  ColDef,
  ColumnApi,
  GetContextMenuItemsParams,
  GridOptions,
  MenuItemDef,
  RowEditingStoppedEvent,
  RowValueChangedEvent,
  ValueFormatterParams,
} from 'ag-grid-community';
import 'ag-grid-enterprise';
import { ToastrService } from 'ngx-toastr';
import { DropdownRenderComponent } from './dropdown-render/dropdown-render.component';
import { DropdownIconRendererComponent } from '../CellRendering/dropdown-icon-renderer/dropdown-icon-renderer.component';
import { SubgroupDropdownComponent } from '../CellRendering/subgroup-dropdown/subgroup-dropdown.component';
import { RowDataTransaction } from '@ag-grid-community/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PrimeNGConfig } from 'primeng/api';
import { NewSegmentComponent } from './new-segment/new-segment.component';

@Component({
  selector: 'app-segment-maintenacne',
  templateUrl: './segment-maintenacne.component.html',
  styleUrls: ['./segment-maintenacne.component.scss'],
})
export class SegmentMaintenacneComponent implements OnInit, AfterViewInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  constructor(
    private segmentMaintenance: SegmentMaintenanceService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private primengConfig: PrimeNGConfig
  ) {}

  rowData: any = [];
  columnDefs: any;
  pageSize: number = 3000;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    resizable: true,
  };

  businessGroup: any = [];
  segmentList: any = [];
  businessGroupArray: any = [];
  segmentListArray: any = [];
  defaultExcelExportParams: any;
  inputsNgOnInIt: any = {};
  inputsForUpdate: any = {};
  inputsForDelete: any = {};

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.inputsNgOnInIt.strSort = '';
    this.inputsNgOnInIt.strFilter = '';
    this.defaultExcelExportParams = {
      fileName: 'SegmentMaintenanceReport-' + Date(),
    };
    this.segmentMaintenance
      .fetchSegmentMaintenance(this.inputsNgOnInIt)
      .subscribe((data: any) => {
        this.businessGroup = data.customerGroupList;
        this.segmentList = data.segmentMaintenanceGroup;
        this.businessGroupArray = data.customerGroupList.map((e: any) => {
          return e.busUnitCode;
        });
        this.segmentListArray = data.segmentMaintenanceGroup.map((e: any) => {
          return e.segmentGroupCode;
        });
        this.columnDefs = this.columnDefsSM(
          this.businessGroupArray,
          this.segmentListArray
        );
        this.rowData = data.segmentMaintenance;
      });
  }

  columnDefsSM(businessGroupArray: any, segmentListArray: any) {
    return [
      { headerName: 'Segment', field: 'segment', width: 140, editable: true },
      {
        headerName: 'Description',
        field: 'description',
        width: 300,
        editable: true,
      },

      {
        headerName: 'Segment Group',
        field: 'segmentGroup',
        cellEditor: 'agRichSelectCellEditor',
        cellRenderer: DropdownIconRendererComponent,
        cellEditorPopup: true,
        cellEditorParams: {
          values: segmentListArray,
          cellHeight: 20,
          cellEditor: SubgroupDropdownComponent,
          searchDebounceDelay: 500,
        },
        editable: true,
      },
      {
        headerName: 'Business Group',
        field: 'businessUnit',
        cellEditor: 'agRichSelectCellEditor',
        cellRenderer: DropdownIconRendererComponent,
        cellEditorPopup: true,
        cellEditorParams: {
          values: businessGroupArray,
          cellHeight: 20,
          cellEditor: SubgroupDropdownComponent,
          searchDebounceDelay: 500,
        },
        editable: true,
      },
      {
        headerName: 'Exclude Web TAXI Flag',
        field: 'excludeWebTaxiFlag',
        width: 200,
        cellRenderer: CheckBoxRenderComponent,
        editable: true,
      },
    ];
  }

  onCellValueChanged(params: CellValueChangedEvent) {
    // notice that the data always contains the keys rather than values after editing
    console.log('onCellValueChanged: ', params);
    this.inputsForUpdate.function = 'U';
    if (
      this.currRowData.description == null ||
      this.currRowData.segment == null ||
      this.currRowData.segmentGroup == null ||
      this.currRowData.businessUnit == null ||
      this.currRowData.excludeWebTaxiFlag == null
    ) {
      console.log('Put data');
    } else {
      this.inputsForUpdate.description = this.currRowData.description;
      this.inputsForUpdate.segment = this.currRowData.segment;
      this.inputsForUpdate.segmentGroup = this.currRowData.segmentGroup;
      this.inputsForUpdate.businessUnit = this.currRowData.businessUnit;
      this.inputsForUpdate.excludeWebTaxiFlag =
        this.currRowData.excludeWebTaxiFlag;
      let data = localStorage.getItem('userInfo');
      let userData = JSON.parse(data ? data : '');
      this.inputsForUpdate.userLoginCd =
        userData.globalLogonUsers.user_login_cd;
      //console.log(this.inputsForUpdate);
      this.segmentMaintenance
        .crudSegmentMaintenance(this.inputsForUpdate)
        .subscribe(
          (data: any) => {
            if (data.msg === 'success') {
              this.segmentgrid();
              this.toastr.success('', 'Segment Data Modified!', {
                timeOut: 5000,
                closeButton: true,
              });
            }
          },
          (error: any) => {
            if (error.error.errorMsg == 'Please select the necessary inputs') {
              this.toastr.error('', error.error.errorMsg, {
                timeOut: 5000,
                closeButton: true,
              });
            }
          }
        );
    }
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  columnApi!: ColumnApi;

  onGridReady(params: any) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
  }
  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [];
    if (
      this.currRowData == null ||
      this.currRowData == undefined ||
      this.currRowData == ''
    ) {
      return [];
    }
    var result: (string | any)[] = [
      {
        name: 'Add Record',
        action: () => {
          this.addNewRow(this.businessGroup, this.segmentList);
        },
      },
      {
        name: 'Delete Record',
        action: () => {
          this.deleteRow();
        },
      },

      'copy',
      'copyWithHeaders',
      'export',
      {
        name: 'Help',
        action: () => {
          this.RedirectToHelp();
        },
      },
    ];
    return result;
  };

  helpUrl:any;

ngAfterViewInit(): void {
  let userData:any;
let data = localStorage.getItem('userInfo');
if (!data) {
  return;
}
userData = JSON.parse(data ? data : '');
this.helpUrl = userData.helpUrl;
}


RedirectToHelp() {
    window.open(this.helpUrl, '_blank');
}


  editType: any;
  addNewRow(businessGroup: any, segmentList: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '40%';
    dialogConfig.width = '80%';
    dialogConfig.data = {
      segmentListArray: segmentList,
      businessGroupArray: businessGroup,
    };
    const modalDialog = this.dialog.open(NewSegmentComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(
      (res: any) => {
        if (res.msg == 'success') {
          this.segmentgrid();
          this.toastr.success(
            '',
            'Segment Maintenace : New Segment Inserted Successfully',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );
        }
      },
      (error: any) => {
        if (error.error.errorMsg == 'Please select the necessary inputs') {
          this.toastr.error('', error.error.errorMsg, {
            timeOut: 5000,
            closeButton: true,
          });
        }
      }
    );
  }

  segmentgrid() {
    this.inputsNgOnInIt.strSort = '';
    this.inputsNgOnInIt.strFilter = '';
    this.defaultExcelExportParams = {
      fileName: 'SegmentMaintenanceReport-' + Date(),
    };
    this.segmentMaintenance
      .fetchSegmentMaintenance(this.inputsNgOnInIt)
      .subscribe((data: any) => {
        this.businessGroup = data.customerGroupList;
        this.segmentList = data.segmentMaintenanceGroup;
        this.businessGroupArray = data.customerGroupList.map((e: any) => {
          return e.busUnitCode;
        });
        this.segmentListArray = data.segmentMaintenanceGroup.map((e: any) => {
          return e.segmentGroupCode;
        });
        this.columnDefs = this.columnDefsSM(
          this.businessGroupArray,
          this.segmentListArray
        );
        this.rowData = data.segmentMaintenance;
      });
  }
  addNewRow1() {
    this.gridApi.applyTransaction({ add: [{}] });
    this.editType = 'fullRow';
    //console.log(this.gridApi.getFocusedCell().rowIndex);
    let trans: RowDataTransaction = {
      add: [{}],
      addIndex: this.gridApi.getFocusedCell().rowIndex + 1,
    };
    this.gridApi.applyTransaction(trans);
  }

  deleteRow() {
    this.inputsForDelete.function = 'D';
    this.inputsForDelete.description = this.currRowData.description;
    this.inputsForDelete.segment = this.currRowData.segment;
    this.inputsForDelete.segmentGroup = this.currRowData.segmentGroup;
    this.inputsForDelete.businessUnit = this.currRowData.businessUnit;
    this.inputsForDelete.excludeWebTaxiFlag =
      this.currRowData.excludeWebTaxiFlag;
    let data = localStorage.getItem('userInfo');
    let userData = JSON.parse(data ? data : '');
    this.inputsForDelete.userLoginCd = userData.globalLogonUsers.user_login_cd;
    console.log(this.inputsForDelete);
    this.segmentMaintenance
      .crudSegmentMaintenance(this.inputsForDelete)
      .subscribe((data: any) => {
        console.log(data);
        if (data.msg == 'success') {
          this.segmentgrid();
          this.toastr.success('', 'Segment  Deleted!', {
            timeOut: 5000,
            closeButton: true,
          });
        }
      });
  }

  overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
  overlayNoRowsTemplate = `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;
}

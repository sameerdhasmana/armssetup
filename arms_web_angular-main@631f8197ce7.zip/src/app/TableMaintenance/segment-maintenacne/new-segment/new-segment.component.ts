import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { MaintenanceService } from 'src/app/services/maintenance.service';
import { SegmentMaintenanceService } from 'src/app/services/segmentMaintenance.service';

@Component({
  selector: 'app-new-segment',
  templateUrl: './new-segment.component.html',
  styleUrls: ['./new-segment.component.scss']
})
export class NewSegmentComponent implements OnInit {


  segment:any;
  description:any;
  businessGroupArray:any=[];
  segmentListArray:any=[];
  segmentGroup:any;
  businessUnit:any;
  webTaxiFlag:boolean=false;

  constructor(public dialogRef: MatDialogRef<NewSegmentComponent>,
    private toastr: ToastrService,
    private primengConfig: PrimeNGConfig,
    private segmentMaintenance : SegmentMaintenanceService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.segmentListArray = data.segmentListArray;
    this.businessGroupArray = data.businessGroupArray;
    console.log(this.segmentListArray);
    console.log(this.businessGroupArray);


  }

  ngOnInit(): void {
  }
  validateAddRecord(){
    let strMsg: string = "";
    if (this.form.controls['SegmentName'].value == "" || this.form.controls['SegmentName'].value == undefined ||
    this.form.controls['SegmentName'].value == null) {
      strMsg = "Segment Name Can not be Empty";
    } else if (this.form.controls['DescriptionName'].value == "" || this.form.controls['DescriptionName'].value == undefined ||
    this.form.controls['DescriptionName'].value == null) {
      strMsg = "Description Can not be Empty";
    } else if (this.form.controls['SegmentGroupName'].value == "" || this.form.controls['SegmentGroupName'].value == undefined ||
    this.form.controls['SegmentGroupName'].value == null) {
      strMsg = "Segment Group Can not be Empty";
    }else if (this.form.controls['BusinessGroupName'].value == "" || this.form.controls['BusinessGroupName'].value == undefined ||
    this.form.controls['BusinessGroupName'].value == null) {
      strMsg = "Business Group Can not be Empty";
    }
        return strMsg;
      }

  form: any = new FormGroup({
    SegmentName: new FormControl(),
    DescriptionName: new FormControl(),
    BusinessGroupName : new FormControl(),
    SegmentGroupName : new FormControl(),
    webTaxiFlagCheck : new FormControl()
  })

  onSubmit() {
    if (this.form.valid) {
      console.log("Form Submitted!");
      this.form.reset();
    }
  }

  resetForm(){
    this.form.reset();
  }
  addRec:any={}
  addRecord(){
    let errMsg: string = this.validateAddRecord();
    if (errMsg != "") {
      this.toastr.error('', errMsg, {
        timeOut: 5000, closeButton: true
      });
    }
    else {

    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    this.addRec.segment = this.segment;
    this.addRec.description = this.description;
    this.addRec.segmentGroup = this.segmentGroup;
    this.addRec.businessUnit = this.businessUnit;
    this.addRec.excludeWebTaxiFlag = this.webTaxiFlag == true ? 1 : 0;
    this.addRec.insertLoginCd = userData.globalLogonUsers.user_login_cd;
    this.addRec.function = 'I';
    console.log(this.addRec);

    this.segmentMaintenance.crudSegmentMaintenance(this.addRec).subscribe((data: any) => {
      if (data.msg == "success") {
        this.dialogRef.close({ msg: 'success' });
      }
    },
      (error: any) => {
        if(error.error.errorMsg=='Please select the necessary inputs'){
        this.toastr.error('', error.error.errorMsg, {
          timeOut: 5000, closeButton: true
        });
      }
      });
  }
  }

  closeModal() {
    this.dialogRef.close({ msg:"cancelled" });
  }


}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckBoxRenderComponent } from './check-box-render.component';

describe('CheckBoxRenderComponent', () => {
  let component: CheckBoxRenderComponent;
  let fixture: ComponentFixture<CheckBoxRenderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckBoxRenderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckBoxRenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SegmentMaintenacneComponent } from './segment-maintenacne.component';

describe('SegmentMaintenacneComponent', () => {
  let component: SegmentMaintenacneComponent;
  let fixture: ComponentFixture<SegmentMaintenacneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SegmentMaintenacneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SegmentMaintenacneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import {
  ColDef,
  ColumnApi, GridApi,
  RowNodeTransaction,
  GetContextMenuItemsParams,
  MenuItemDef,
} from 'ag-grid-enterprise';
import { LetterProfileService } from 'src/app/services/letter-profile.service';
import "@ag-grid-community/core/dist/styles/ag-grid.css";
import "@ag-grid-community/core/dist/styles/ag-theme-material.css";
import { ToastrService } from 'ngx-toastr';
import { ModifyCheckBoxComponent } from './modify-check-box/modify-check-box.component';
import { FormControl, FormGroup } from '@angular/forms';



@Component({
  selector: 'app-modify-letter-profile',
  templateUrl: './modify-letter-profile.component.html',
  styleUrls: ['./modify-letter-profile.component.scss']
})
export class ModifyLetterProfileComponent implements OnInit {

  @ViewChild('agGrid') agGrid!: AgGridAngular;


  //content: string = 'Letter Profile Management/';

  profilesArray: any = [];
  selectedProfile: any;
  mode: any;
  groupArray: any = [];
  selectedGroup: any;
  selectedCheckBox: any;
  profileName: any;
  profileDesc: any;
  rowData: any = [];
  columnDefs: any;
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    // flex: 1,
    //minWidth: 100,
    resizable: true,
  };
  stateArray: any = [];
  selectedState: any;
  lettersArray: any = [];
  selectedLetter: any;
  oriSysArray: any = [];
  selectedOriSys: any;
  returnAddressArray: any = [];
  selectedreturnAddress: any;
  modPrifleArray: any = [];
  selectedModProfile: any;
  segmentArray: any = [];
  selectedSegment: any;

  form: any = new FormGroup({
    fSelectedModProfile : new FormControl(),
    fSelectedGroup: new FormControl(),
    fSelectedSegment: new FormControl(),
    fSelectedOriSys: new FormControl(),
    fSelectedState: new FormControl(),
    fSelectedLetter: new FormControl(),
    fModProfileName: new FormControl(),
    fModProfileDesc: new FormControl(),
    fSelectedCheckBox: new FormControl(),
    fSelectedreturnAddress: new FormControl(),
  });


  constructor(
    private router: Router,
    private letterProfile: LetterProfileService,
    private toastr: ToastrService,

  ) {
  }


  ngAfterContentInit(): void { }

  async fetchSegmentList() {
    let obj = { groupSelected: this.selectedGroup };
    let result = await this.letterProfile.letterSegment(obj).subscribe((e: any) => {
      //console.log(e);
      this.segmentArray = e.letterSegmentList;
    });


  }
  onClickHelp() {
    window.open("https://peoria.web.att.com/business/Wholesale/enterprise/jobaids/armsja.htm#Notes_act_Rpt");
  }
  onExit() {

    this.router.navigate(['/query']);
  }


  ngOnInit(): void {
      this.letterProfile.letterProfileList('').subscribe((data: any) => {
        this.modPrifleArray =  data.letterProfileField;
      });
      this.letterProfile.letterProfileFieldList('').subscribe((data: any) => {
        this.rowData = data.letterProfileField;
        this.columnDefs = this.columnDefsLP;
      });
      this.letterProfile.letterDetailList('').subscribe((data: any) => {
        this.stateArray = data.stateCode;
        this.lettersArray = data.lettertypes;
        this.oriSysArray = data.originatingSystemList;
        this.groupArray = data.businessGroupList;
        this.returnAddressArray = data.letterReturnAddress;
      });



  }

modProfileDesc:any;
modProfileName:any;
populateModDetailsInput : any={};

populateMod(){
this.populateModDetailsInput.letterProfilesId = this.selectedModProfile?.letter_profile_id;
this.letterProfile.fetchModifyLetterDetails(this.populateModDetailsInput).subscribe(async (data: any) => {
console.log(data);
this.modProfileName = data.letterProfileField[0].letterProfilesName;
this.modProfileDesc = data.letterProfileField[0].letterProfilesDesc;
this.selectedCheckBox = data.letterProfileField[0].acctApplicability;
this.selectedLetter = data.letterProfileField[0].letterTypeId;
this.selectedreturnAddress = data.letterProfileField[0].returnAddrId;
this.form.controls.fSelectedGroup.setValue(data.letterProfileField[0]?.busUnitCdList);
this.selectedGroup = data.letterProfileField[0]?.busUnitCdList;
this.form.controls.fSelectedOriSys.setValue(data.letterProfileField[0]?.originatingSystemList);
this.form.controls.fSelectedState.setValue(data.letterProfileField[0]?.stateCdList);
await  this.fetchSegmentList()
this.form.controls.fSelectedSegment.setValue(data.letterProfileField[0]?.segmentCdList);
let result = [];
for(let i=0; i<this.rowData?.length; i++) {
  let obj = data.letterProfileFieldSelectedIds.find((e:any)=>{    return e.letterProfileFieldId == this.rowData[i].letterProfileFieldId;
  })

  if(obj)
  result.push({
   ...this.rowData[i],
   ...obj
  });
  else
  result.push({
    ...this.rowData[i]
   });

}
this.rowData= result;
});
}

selectAllOnes(){
  this.gridApi.forEachNode( (node:any) => {
    node.setSelected(node.data.fieldPrepopulated === '1'  || node.data.fieldRequired === '1'|| node.data.fieldEditable === '1' );
  });
}
modifyProfileInputs:any={};
  modifyProfile(){
    this.selectAllOnes();
this.modifyProfileInputs.letterProfilesId = this.selectedModProfile?.letter_profile_id;
this.modifyProfileInputs.letterProfileName = this.modProfileName;
this.modifyProfileInputs.letterProfilesDesc = this.modProfileDesc;
this.modifyProfileInputs.letterTypeId = this.selectedLetter;
this.modifyProfileInputs.acctApplicability = this.selectedCheckBox;
this.modifyProfileInputs.returnAddrId = this.selectedreturnAddress;
this.modifyProfileInputs.busUnitCdList = this.selectedGroup;
this.modifyProfileInputs.segment = this.selectedSegment;
this.modifyProfileInputs.originatingSystem = this.selectedOriSys;
this.modifyProfileInputs.stateCdList = this.selectedState;
let selectedNodes = this.gridApi.getSelectedNodes();
let selectedData = selectedNodes.map((node: any) => node.data);
this.modifyProfileInputs.letterProfileList = selectedData;
console.log(this.modifyProfileInputs);
this.letterProfile.saveModifyLetterProfile(this.modifyProfileInputs).subscribe((data: any) => {
  if (data.msg == "success") {
    this.toastr.success('', 'Letter Profile: Modified Successfully', {
      timeOut: 5000, closeButton: true
    });
  }
}, (error: any) => {
  this.toastr.error('', 'Error in Modifying Lette Profile, Please try again', {
    timeOut: 5000, closeButton: true
  });
});
this.modProfileName = '';
this.modProfileDesc = '';
this.selectedreturnAddress = '';
this.selectedLetter = '';
this.selectedState = '';
this.letterProfile.letterProfileFieldList('').subscribe((data: any) => {
  this.rowData = data.letterProfileField;
  this.columnDefs = this.columnDefsLP;
});
  }

  columnDefsLP: ColDef[] =

    [
      {
        headerName: 'ProfileID',
        field: 'letterProfileFieldId',
        checkboxSelection: true
      },
      { headerName: 'Field Name', field: 'letterProfileField' },
      { headerName: 'Field Description', field: 'letterProfileDesc' },
      {
        headerName: 'Editable',
        field: 'fieldEditable',
        cellRendererFramework: ModifyCheckBoxComponent,
        editable: true
      },
      {
        headerName: 'Required',
        field: 'fieldRequired',
        cellRendererFramework: ModifyCheckBoxComponent,
        editable: true
      },
      {
        headerName: 'Prepopulated',
        field: 'fieldPrepopulated',
        cellRendererFramework: ModifyCheckBoxComponent,
        editable: true
      }
    ];

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  };

  overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate = `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  columnApi!: ColumnApi;
  getRowId : any;
  // public getRowId: GetRowIdFunc = function (params: GetRowIdParams) {
  //   return params.data.trade;
  // };

  onGridReady(params: any) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;

  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyCheckBoxComponent } from './modify-check-box.component';

describe('ModifyCheckBoxComponent', () => {
  let component: ModifyCheckBoxComponent;
  let fixture: ComponentFixture<ModifyCheckBoxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModifyCheckBoxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyCheckBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateLetterProfileComponent } from './create-letter-profile.component';

describe('CreateLetterProfileComponent', () => {
  let component: CreateLetterProfileComponent;
  let fixture: ComponentFixture<CreateLetterProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateLetterProfileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateLetterProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

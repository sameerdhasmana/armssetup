import { Component, OnInit, ViewChild } from '@angular/core';
import {  Router } from '@angular/router';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import {
  ColDef,
  ColumnApi,
  GetContextMenuItemsParams,
  MenuItemDef,
  RefreshCellsParams,
} from 'ag-grid-enterprise';
import { LetterProfileService } from 'src/app/services/letter-profile.service';
import "@ag-grid-community/core/dist/styles/ag-grid.css";
import "@ag-grid-community/core/dist/styles/ag-theme-material.css";
import { ToastrService } from 'ngx-toastr';
import { CreateCheckBoxComponent } from './create-check-box/create-check-box.component';


@Component({
  selector: 'app-create-letter-profile',
  templateUrl: './create-letter-profile.component.html',
  styleUrls: ['./create-letter-profile.component.scss']
})
export class CreateLetterProfileComponent implements OnInit {

  @ViewChild('agGrid') agGrid!: AgGridAngular;


  //content: string = 'Letter Profile Management/';

  profilesArray: any = [];
  selectedProfile: any;
  mode: any;
  groupArray: any = [];
  selectedGroup: any;
  selectedCheckBox: any;
  profileName: any;
  profileDesc: any;
  rowData: any = [];
  columnDefs: any;
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    // flex: 1,
    //minWidth: 100,
    resizable: true,
  };
  stateArray: any = [];
  selectedState: any;
  lettersArray: any = [];
  selectedLetter: any;
  oriSysArray: any = [];
  selectedOriSys: any;
  returnAddressArray: any = [];
  selectedreturnAddress: any;
  modPrifleArray: any = [];
  selectedModProfile: any;
  segmentArray: any = [];
  selectedSegment: any;
  delPrifleArray : any=[];
  deletedProfileID : any;




  constructor(
    private router: Router,
    private letterProfile: LetterProfileService,
    private toastr: ToastrService,

  ) {
  }


  ngAfterContentInit(): void { }

  async fetchSegmentList() {
    let obj = { groupSelected: this.selectedGroup };
    let result = await this.letterProfile.letterSegment(obj).subscribe((e: any) => {
      //console.log(e);
      this.segmentArray = e.letterSegmentList;
    });


  }
  onClickHelp() {
    window.open("https://peoria.web.att.com/business/Wholesale/enterprise/jobaids/armsja.htm#Notes_act_Rpt");
  }

  onExit() {
    this.router.navigate(['/query']);
  }


  ngOnInit(): void {

      this.letterProfile.letterDetailList('').subscribe((data: any) => {
        this.stateArray = data.stateCode;
        this.lettersArray = data.lettertypes;
        this.oriSysArray = data.originatingSystemList;
        this.groupArray = data.businessGroupList;
        this.returnAddressArray = data.letterReturnAddress;
      });

      this.letterProfile.letterProfileFieldList('').subscribe((data: any) => {
        this.rowData = data.letterProfileField;
        this.columnDefs = this.columnDefsLP;
      });
  }

  saveProfileInputs: any = {};

  createProfile() {
    this.saveProfileInputs.returnAddrId = this.selectedreturnAddress;
    this.saveProfileInputs.originatingSystem = this.selectedOriSys;
    this.saveProfileInputs.letterTypeId = this.selectedLetter;
    this.saveProfileInputs.stateCdList = this.selectedState;
    this.saveProfileInputs.busUnitCdList = this.selectedGroup;
    this.saveProfileInputs.segment = this.selectedSegment;
    this.saveProfileInputs.acctApplicability = this.selectedCheckBox;
    this.saveProfileInputs.letterProfileName = this.profileName;
    this.saveProfileInputs.letterProfilesDesc = this.profileDesc;
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    this.saveProfileInputs.letterProfileList = selectedData;

    //console.log(this.saveProfileInputs);
    this.letterProfile.createLetterProfile(this.saveProfileInputs).subscribe((data: any) => {
      if (data.msg == "success") {
        this.toastr.success('', 'Letter Profile: Created Successfully', {
          timeOut: 5000, closeButton: true
        });
      }
    }, (error: any) => {
        let errorX = error.error.message;
        this.toastr.info('', errorX, {
          timeOut: 5000, closeButton: true
        });
      this.toastr.error('', 'Error in Creating Lette Profile, Please try again', {
        timeOut: 5000, closeButton: true
      });
    });
    this.profileName = '';
    this.profileDesc = '';
    this.selectedreturnAddress = '';
    this.selectedLetter = '';
    this.selectedState = '';
    this.letterProfile.letterProfileFieldList('').subscribe((data: any) => {
      this.rowData = data.letterProfileField;
      this.columnDefs = this.columnDefsLP;
    });


  }

  refreshCells = (
    params: RefreshCellsParams = {}
) => console.log(params,'RefreshApplied')


  columnDefsLP: ColDef[] =

    [
      {
        headerName: 'ProfileID',
        field: 'letterProfileFieldId',
        checkboxSelection: true
      },
      { headerName: 'Field Name', field: 'letterProfileField' },
      { headerName: 'Field Description', field: 'letterProfileDesc' },
      {
        headerName: 'Editable',
        field: 'fieldEditable',
        cellRendererFramework: CreateCheckBoxComponent,
        editable: true
      },
      {
        headerName: 'Required',
        field: 'fieldRequired',
        cellRendererFramework: CreateCheckBoxComponent,
        editable: true
      },
      {
        headerName: 'Prepopulated',
        field: 'fieldPrepopulated',
        cellRendererFramework: CreateCheckBoxComponent,
        editable: true
      }
    ];

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  };

  overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate = `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  columnApi!: ColumnApi;

  onGridReady(params: any) {

    this.gridApi = params.api;
    this.columnApi = params.columnApi;
  }
}

import {  Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { LetterProfileService } from 'src/app/services/letter-profile.service';
import { ToastrService } from 'ngx-toastr';
import {ConfirmationService} from 'primeng/api';
import {Message} from 'primeng/api';
import { PrimeNGConfig } from 'primeng/api';




@Component({
  selector: 'app-delete-letter-profile',
  templateUrl: './delete-letter-profile.component.html',
  styleUrls: ['./delete-letter-profile.component.scss'],
  providers: [ConfirmationService]
})
export class DeleteLetterProfileComponent implements OnInit {

  constructor(
    private router: Router,
    private letterProfile: LetterProfileService,
    private toastr: ToastrService,private confirmationService: ConfirmationService,
     private primengConfig: PrimeNGConfig
  ) { }


  delPrifleArray : any=[];
  deletedProfileID : any;


  ngOnInit(): void {
    this.letterProfile.letterProfileList('').subscribe((data: any) => {
      this.delPrifleArray =  data.letterProfileField;
    });
    this.primengConfig.ripple = true;
  }

  deleteprofileInputs :  any={};
  deleteProfile(){
this.deleteprofileInputs.letterProfilesId =  this.deletedProfileID;
    this.letterProfile.deleteLetterProfile(this.deleteprofileInputs).subscribe((data: any) => {
      if (data.msg == "success") {
        this.letterProfile.letterProfileList('').subscribe((data: any) => {
          this.delPrifleArray =  data.letterProfileField;
        });

        this.toastr.success('', 'Letter Profile : Deleted Successfully', {
          timeOut: 5000, closeButton: true
        });
      }
    }, (error: any) => {
      this.toastr.error('', 'Error in Deleting Lette Profile, Please try again', {
        timeOut: 5000, closeButton: true
      });
    });
  }

  onExit() {

    this.router.navigate(['/query']);
  }

  msgs: Message[] = [];

  confirm() {
    this.confirmationService.confirm({
        message: 'Do you want to delete this record?',
        header: 'Delete Confirmation',
        icon: 'pi pi-info-circle',
        accept: () => {
          this.deleteProfile()
            this.msgs = [{severity:'info', summary:'Confirmed', detail:'Profile deleted'}];
        },
        reject: () => {
            this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
        }
    });
}

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteLetterProfileComponent } from './delete-letter-profile.component';

describe('DeleteLetterProfileComponent', () => {
  let component: DeleteLetterProfileComponent;
  let fixture: ComponentFixture<DeleteLetterProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteLetterProfileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteLetterProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

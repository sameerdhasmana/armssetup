import { Component, OnInit, ViewChild } from '@angular/core';
import { MaintenanceService } from 'src/app/services/maintenance.service';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, MenuItemDef } from 'ag-grid-enterprise';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { CellDoubleClickedEvent, GridOptions } from 'ag-grid-community';
import { CustomerUsageService } from 'src/app/services/customerUsage.service';


@Component({
  selector: 'app-customerusage',
  templateUrl: './customerusage.component.html',
  styleUrls: ['./customerusage.component.scss']
})
export class CustomerusageComponent implements OnInit {

  @ViewChild('agGrid') agGrid!: AgGridAngular;

  constructor(
    private customerUsage : CustomerUsageService,
    private toastr: ToastrService,
    private primengConfig: PrimeNGConfig
  ) { }

  gridOptions: GridOptions ={
  }

  customers: any = [];
  selectedCustomer: any;
  rowData: any;
  columnDefs: any;
  showContactsGrid: boolean = false;
  pageSize: number = 30;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
  //  flex:1
  }

inputngData:any={
  "strSort":"table_desc"
};
inputData: any = {};
defaultExcelExportParams : any;
  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.defaultExcelExportParams=  {
      fileName: 'CustomerUsageReport-'+Date()
    }

    this.customerUsage.customerInfo(this.inputngData).subscribe((data: any) => {
      this.customers = data.CustomerInfo;
    },(error:any)=>{
      console.log(error)
      this.toastr.error('', 'Customer Usage : Error in loading Customers, Pls try again later', {
        timeOut: 5000, closeButton: true
      });
    });
    this.inputData.customerGrpCD = '';
    this.inputData.strSort = "table_desc";
    this.customerUsage.fetchCustomerUsage(this.inputData).subscribe((data: any) => {
      this.showContactsGrid = true;
      this.rowData = data.CustomerInfo;
      this.columnDefs = this.columnDefsCU;
      this.gridApi.showLoadingOverlay();
    },(error:any)=>{
      console.log(error)
      this.toastr.error('', 'Customer Usage : Error in Table, Pls try again later', {
        timeOut: 5000, closeButton: true
      });
    });
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }



  selectionTrigger() {
    this.defaultExcelExportParams=  {
      fileName: 'CustomerUsageReport-'+ this.selectedCustomer.customer_grp_cd+'-'+Date()
    }
    this.inputData.customerGrpCD = this.selectedCustomer.customer_grp_cd;
    this.inputData.strSort = "table_desc";
    this.customerUsage.fetchCustomerUsage(this.inputData).subscribe((data: any) => {
      this.showContactsGrid = true;
      this.rowData = data.CustomerInfo;
      this.columnDefs = this.columnDefsCU;
      this.gridApi.showLoadingOverlay();
    },(error:any)=>{
      console.log(error)
      this.toastr.error('', 'Customer Usage : Error in Table, Pls try again later', {
        timeOut: 5000, closeButton: true
      });
    });
  }



  columnDefsCU: ColDef[] = [
    { field: 'tableName', width:300 },
    { field: 'tableDesc' ,width:300},
    { field: 'countOfCustomer', width:300}
];

overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
overlayNoRowsTemplate = `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

}

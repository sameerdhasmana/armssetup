import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerusageComponent } from './customerusage.component';

describe('CustomerusageComponent', () => {
  let component: CustomerusageComponent;
  let fixture: ComponentFixture<CustomerusageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerusageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerusageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

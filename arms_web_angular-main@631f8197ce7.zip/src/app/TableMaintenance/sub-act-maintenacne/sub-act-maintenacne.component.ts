import { Component, OnInit,ViewChild } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';

@Component({
  selector: 'app-sub-act-maintenacne',
  templateUrl: './sub-act-maintenacne.component.html',
  styleUrls: ['./sub-act-maintenacne.component.scss']
})
export class SubActMaintenacneComponent implements OnInit {

  @ViewChild('agGrid') agGrid!: AgGridAngular;

  defaultColDef: ColDef = {
    sortable: true,
    filter: true
}
pageSize=1000;

columnDefs: ColDef[] = [

  { field:'Sub  Activity'},{ field:'Short Description'},{ field:'Long Description'},{ field:'Day'},
  { field:'Payment Terms'},{ field:'Group'},{ field:'Customer'},{ field:'Amount'},
  { field:'Status'},{ field:'Sub Activity Type'},{ field:'State'},{ field:'System'},
  { field:'AP Sub Group'},{ field:'Segment'},{ field:'Auto Bring Up'},{ field:'Auto Threshold'},
  { field:'Avg Age Days'},{ field:'AR%'},{ field:'Past Due'},{ field:'Collectable PD'},

];

rowData: Observable<any[]>;

constructor(private http: HttpClient) {

  this.rowData = this.http.get<any[]>('assets/SubActivityMaintenanceRecord.json');

}

  ngOnInit(): void {
  }

}

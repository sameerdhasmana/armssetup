import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubActMaintenacneComponent } from './sub-act-maintenacne.component';

describe('SubActMaintenacneComponent', () => {
  let component: SubActMaintenacneComponent;
  let fixture: ComponentFixture<SubActMaintenacneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubActMaintenacneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubActMaintenacneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

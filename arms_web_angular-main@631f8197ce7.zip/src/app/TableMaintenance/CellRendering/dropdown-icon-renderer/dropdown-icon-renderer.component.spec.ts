import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DropdownIconRendererComponent } from './dropdown-icon-renderer.component';

describe('DropdownIconRendererComponent', () => {
  let component: DropdownIconRendererComponent;
  let fixture: ComponentFixture<DropdownIconRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DropdownIconRendererComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DropdownIconRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

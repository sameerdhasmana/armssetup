import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from '@ag-grid-community/core';


@Component({
  selector: 'app-dropdown-icon-renderer',
  templateUrl: './dropdown-icon-renderer.component.html',
  styleUrls: ['./dropdown-icon-renderer.component.scss']
})
export class DropdownIconRendererComponent implements OnInit {

  ngOnInit(): void {
  }
  public displayValue!: string;

  agInit(params: ICellRendererParams): void {
        this.displayValue = params.value
  }

  refresh(params: ICellRendererParams) {
    return false;
  }
}







import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubgroupDropdownComponent } from './subgroup-dropdown.component';

describe('SubgroupDropdownComponent', () => {
  let component: SubgroupDropdownComponent;
  let fixture: ComponentFixture<SubgroupDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubgroupDropdownComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubgroupDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

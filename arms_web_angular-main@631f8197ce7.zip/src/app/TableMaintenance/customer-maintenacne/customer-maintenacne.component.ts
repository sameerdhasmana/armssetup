import { Component, OnInit, ViewChild } from '@angular/core';
import {
  CellDoubleClickedEvent,
  CellEditingStoppedEvent,
  ColDef,
  ColumnApi,
  GetContextMenuItemsParams,
  GridOptions,
  MenuItemDef,
} from 'ag-grid-community';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { CustomerMaintenanceService } from 'src/app/services/CustomerMaintenance.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-customer-maintenacne',
  templateUrl: './customer-maintenacne.component.html',
  styleUrls: ['./customer-maintenacne.component.scss'],
})
export class CustomerMaintenacneComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  constructor(
    private customerMaintenance: CustomerMaintenanceService,
    private toastr: ToastrService
  ) {}

  inputsNgOnInIt :  any = {};
  ngOnInit(): void {
    this.inputsNgOnInIt.strSort = "";
    this.inputsNgOnInIt.strFilter = "";
    this.customerMaintenance
      .fetchCustMaintenance(this.inputsNgOnInIt)
      .subscribe((data: any) => {
        this.rowData = data.customerMaintenance;
        this.columnDefs =  this.columnDefsCM;
      });
  }

  rowData: any = [];
  columnDefs: any;
  pageSize: number = 3000;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    resizable: true,
  };

  columnDefsCM: ColDef[] = [
    {
      headerName: 'Parent Name',
      field: 'parentName',
      width: 300,
      resizable: true,
    },
    {
      headerName: 'Tie Code',
      field: 'tieCode',
      width: 150,
      filter: 'agSetColumnFilter',
    },
    {
      headerName: 'Note',
      field: 'note',
      width: 950,
      filter: 'agSetColumnFilter',
      editable: true,
      cellEditorPopup: true,
      cellEditor: 'agLargeTextCellEditor',
      flex: 2,
    },
    { headerName: 'Priority', field: 'priority', width: 120, resizable: true },
  ];

  gridOptions: GridOptions = {
    onCellEditingStopped: (event: CellEditingStoppedEvent) =>
      this.editNote(event.data),
  };

  editNote(event: any) {
    console.log(event);
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  gridApi: any;
  columnApi!: ColumnApi;

  onGridReady(params: any) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
  }

  setTieCodeFilter() {
    let filterInstance = this.gridApi.getFilterInstance('Note')!;
    filterInstance.setModel({ values: ['AGID'] });
    this.gridApi.onFilterChanged();
  }

  selectJohnAndKenny() {
    const instance = this.gridApi.getFilterInstance('athlete')!;
    instance.setModel({ values: ['John Joe Nevin', 'Kenny Egan'] });
    this.gridApi.onFilterChanged();
  }

  selectEverything() {
    const instance = this.gridApi.getFilterInstance('athlete')!;
    instance.setModel(null);
    this.gridApi.onFilterChanged();
  }

  selectNothing() {
    const instance = this.gridApi.getFilterInstance('athlete')!;
    instance.setModel({ values: [] });
    this.gridApi.onFilterChanged();
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  };

  overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate = `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerMaintenacneComponent } from './customer-maintenacne.component';

describe('CustomerMaintenacneComponent', () => {
  let component: CustomerMaintenacneComponent;
  let fixture: ComponentFixture<CustomerMaintenacneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerMaintenacneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerMaintenacneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

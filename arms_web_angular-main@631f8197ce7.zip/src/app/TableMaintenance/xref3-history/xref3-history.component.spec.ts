import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Xref3HistoryComponent } from './xref3-history.component';

describe('Xref3HistoryComponent', () => {
  let component: Xref3HistoryComponent;
  let fixture: ComponentFixture<Xref3HistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Xref3HistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Xref3HistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

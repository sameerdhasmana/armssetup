import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-xref3-history',
  templateUrl: './xref3-history.component.html',
  styleUrls: ['./xref3-history.component.scss']
})
export class Xref3HistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

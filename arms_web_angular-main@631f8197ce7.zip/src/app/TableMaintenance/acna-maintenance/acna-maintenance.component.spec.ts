import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ACNAMaintenanceComponent } from './acna-maintenance.component';

describe('ACNAMaintenanceComponent', () => {
  let component: ACNAMaintenanceComponent;
  let fixture: ComponentFixture<ACNAMaintenanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ACNAMaintenanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ACNAMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

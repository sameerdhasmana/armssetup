import { Component, ViewChild, ViewContainerRef ,OnInit} from "@angular/core";
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellEditorParams } from "@ag-grid-community/core";

@Component({
  selector: 'app-acna-checkbox',
  templateUrl: './acna-checkbox.component.html',
  styleUrls: ['./acna-checkbox.component.scss']
})
export class AcnaCheckboxComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }
  params: any;

  checked = false;

  agInit(params: any): void {
      this.params = params;
      this.checked = this.params.value === "1";
  }

  // demonstrates how you can do "inline" editing of a cell
  onChange(checked: boolean) {
      this.checked = checked;
      this.params.node.setDataValue(this.params.colDef, this.checked ? "1" : "0");

      if (this.params.eGridCell) {
          this.params.eGridCell.focus();
      }
  }

  refresh(params: any): boolean {
      return false;
  }

}

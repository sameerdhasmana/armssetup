import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcnaCheckboxComponent } from './acna-checkbox.component';

describe('AcnaCheckboxComponent', () => {
  let component: AcnaCheckboxComponent;
  let fixture: ComponentFixture<AcnaCheckboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcnaCheckboxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AcnaCheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

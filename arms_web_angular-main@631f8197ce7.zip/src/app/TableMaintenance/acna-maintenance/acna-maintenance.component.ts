import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import {
  CellDoubleClickedEvent,
  CellEditingStoppedEvent,
  CellValueChangedEvent,
  ColDef,
  ColumnApi,
  GetContextMenuItemsParams,
  GetRowIdFunc,
  GetRowIdParams,
  GridOptions,
  ITooltipParams,
  MenuItemDef,
  ValueFormatterParams,
} from 'ag-grid-community';
import 'ag-grid-enterprise';
import { ACNAMaintenanceService } from 'src/app/services/acnaMaintenance.service';
import { AcnaCheckboxComponent } from './acna-checkbox/acna-checkbox.component';
import { AcnaDropdownComponent } from './acna-dropdown/acna-dropdown.component';
import { HoveringHeadersComponent } from 'src/app/ContextMenuItems/hovering-headers/hovering-headers.component';


@Component({
  selector: 'app-acna-maintenance',
  templateUrl: './acna-maintenance.component.html',
  styleUrls: ['./acna-maintenance.component.scss']
})
export class ACNAMaintenanceComponent implements OnInit {

  @ViewChild('agGrid') agGrid!: AgGridAngular;

  constructor(
    private acnaMaintenanceService : ACNAMaintenanceService
  ) { }


rowId:any;
//getRowId :any;
//public getRowId: GetRowIdFunc = (params: GetRowIdParams) => params.data.id;

rowIdChange(){
  const rowNode = this.gridApi.getRowNode(this.rowId-1);
  rowNode.setSelected(true,true);
  this.gridApi.ensureIndexVisible(this.rowId-1, 'middle');
  //this.jumpToRowID(this.rowId)
}


// jumpToRowID(rowId:any){
//   if (this.gridApi.getInfiniteRowCount() < rowId+1) {
//     this.gridApi.setRowCount(rowId+1, false);
//   }
//   this.gridApi.ensureIndexVisible(rowId, 'middle');

//   this.gridApi.forEachNode((node:any) => {
//     if (node.rowIndex === rowId-1) {
//       node.setSelected(true);
//     }
//   });
// };


  columnDefsACNA(customerNames:any,segmentListArray:any){
return[
  { headerName:'ID',field:'id', valueGetter:'node.id'},
  { headerName:'ACNA', field:'acna', width:90,  resizable: true },
  { headerName:'Master', field:'acnaMaster',width:100, editable:true},
  { headerName:'Seg', field:'segmentCode',width:90},
  { headerName:'Parent Name', field:'parentName',width:200, resizable: true},
  { headerName:'Customer', field:'customerGroupCode',width:200},
  {
    headerName: 'Notes',
    field: 'notes',
    width: 485,
    filter: 'agSetColumnFilter',
    editable: true,
    cellEditorPopup: true,
    cellEditor: 'agLargeTextCellEditor',
    flex: 2,
    tooltipComponent: HoveringHeadersComponent,
    tooltipValueGetter: toolTipValueGetter

  },
  { headerName:'AutoAssign', field:'autoAssign',width:150,cellRenderer: AcnaCheckboxComponent,},
];
  }


customerList :  any=[];
segmentList: any =[];
segmentListArray: any = [];
defaultExcelExportParams :  any;
inputsNgOnInIt: any = {};


ngOnInit(): void {
  this.inputsNgOnInIt.strSort = "";
  this.inputsNgOnInIt.strFilter = "";
  this.defaultExcelExportParams=  {
    fileName: 'ACNAMaintenanceReport-'+Date()
  }
  this.acnaMaintenanceService
    .acnaMaintenance(this.inputsNgOnInIt)
    .subscribe((data: any) => {
      this.customerList = data.tableMaintenanceAcnaComboRecords;
      this.segmentList = data.Segment;
      // this.businessGroupArray = data.customerGroupList.map((e: any) => { return e.busUnitCode });
      // this.segmentListArray = data.segmentMaintenanceGroup.map((e: any) => { return e.segmentGroupCode });
      // this.columnDefs = this.columnDefsSM(this.businessGroupArray,this.segmentListArray);
      this.rowData = data.tableMaintenanceAcnaAllRecords;
      this.columnDefs =  this.columnDefsACNA(this.customerNames,this.segmentList);
      this.gridApi.showLoadingOverlay();
    });
}

extractValues(mappings: Record<string, string>) {
  return Object.keys(mappings);
}
customerNames = this.extractValues(this.customerList);

// lookupKey(mappings: Record<string, string>, name: string) {
//   const keys = Object.keys(mappings);
//   for (let i = 0; i < keys.length; i++) {
//     const key = keys[i];
//     if (mappings[key] === name) {
//       return key;
//     }
//   }
// }
lookupValue(mappings: Record<string, string>, key: string) {
  return mappings[key];
}

rowData: any = [];
columnDefs: any;
pageSize: number = 3000;
defaultColDef: ColDef = {
  sortable: true,
  filter: true,
  resizable: true,
};

gridOptions: GridOptions = {
  onCellDoubleClicked: (
    event: CellDoubleClickedEvent
  ) => this.editSegment()
}
onCellValueChanged(params: CellValueChangedEvent) {
  // notice that the data always contains the keys rather than values after editing
  console.log('onCellValueChanged: ', params);
}


editSegment() {
}

currRowData: any;
onRowClicked(event: any) {
  this.currRowData = event.data;
}
gridApi: any;
columnApi!: ColumnApi;

onGridReady(params: any) {

  this.gridApi = params.api;
  this.columnApi = params.columnApi;
}
getContextMenuItems = (
  params: GetContextMenuItemsParams
): (string | MenuItemDef)[] => {
  var result: (string | any)[] = [
    {
      name: 'Add Row',
      action: () => {
        this.addNewRow();
      }
    },

    'copy',
    'copyWithHeaders',
    'export',
  ];
  return result;
};

addNewRow(){
  this.gridApi.applyTransaction({add:[{}]});
}

overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
overlayNoRowsTemplate = `<span style="padding: 10px;
border: 2px solid #444;
background: lightgoldenrodyellow;">
No Data Found in the System
</span>`;


}
const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acna-dropdown',
  templateUrl: './acna-dropdown.component.html',
  styleUrls: ['./acna-dropdown.component.scss']
})
export class AcnaDropdownComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

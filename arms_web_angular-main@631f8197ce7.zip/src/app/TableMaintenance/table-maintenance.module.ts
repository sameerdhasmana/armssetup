import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerusageComponent } from './customerusage/customerusage.component';
import { ACNAMaintenanceComponent } from './acna-maintenance/acna-maintenance.component';
import { AECNMaintenanceComponent } from './aecn-maintenance/aecn-maintenance.component';
import { SegmentMaintenacneComponent } from './segment-maintenacne/segment-maintenacne.component';
import { SubActMaintenacneComponent } from './sub-act-maintenacne/sub-act-maintenacne.component';
import { CustomerMaintenacneComponent } from './customer-maintenacne/customer-maintenacne.component';
import { Xref3MaintenacneComponent } from './xref3-maintenacne/xref3-maintenacne.component';
import { Xref3HistoryComponent } from './xref3-history/xref3-history.component';

import { MessageMaintenanceComponent } from './message-maintenance/message-maintenance.component';

import { MaterialModule } from '../material/material.module';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterModule} from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { SegmentRendererComponent } from './aecn-maintenance/segment-renderer/segment-renderer.component';
import { CreateLetterProfileComponent } from './letter-profile/create-letter-profile/create-letter-profile.component';
import { ModifyLetterProfileComponent } from './letter-profile/modify-letter-profile/modify-letter-profile.component';
import { DeleteLetterProfileComponent } from './letter-profile/delete-letter-profile/delete-letter-profile.component';
import { CreateCheckBoxComponent } from './letter-profile/create-letter-profile/create-check-box/create-check-box.component';
import { ModifyCheckBoxComponent } from './letter-profile/modify-letter-profile/modify-check-box/modify-check-box.component';
import { CellRendererTestComponent } from './cell-renderer-test/cell-renderer-test.component';
import { CheckBoxRenderComponent } from './segment-maintenacne/check-box-render/check-box-render.component';
import { DropdownRenderComponent } from './segment-maintenacne/dropdown-render/dropdown-render.component';
import { AcnaCheckboxComponent } from './acna-maintenance/acna-checkbox/acna-checkbox.component';
import { AcnaDropdownComponent } from './acna-maintenance/acna-dropdown/acna-dropdown.component';
import { DropdownIconRendererComponent } from './CellRendering/dropdown-icon-renderer/dropdown-icon-renderer.component';
import { SubgroupDropdownComponent } from './CellRendering/subgroup-dropdown/subgroup-dropdown.component';
import { NewSegmentComponent } from './segment-maintenacne/new-segment/new-segment.component';




@NgModule({
  declarations: [
    MessageMaintenanceComponent,
    CustomerusageComponent,
    ACNAMaintenanceComponent,
    AECNMaintenanceComponent,
    SegmentMaintenacneComponent,
    SubActMaintenacneComponent,
    CustomerMaintenacneComponent,
    Xref3MaintenacneComponent,
    Xref3HistoryComponent,
    SegmentRendererComponent,
    CreateLetterProfileComponent,
    ModifyLetterProfileComponent,
    DeleteLetterProfileComponent,
    CreateCheckBoxComponent,
    ModifyCheckBoxComponent,
    CellRendererTestComponent,
    CheckBoxRenderComponent,
    DropdownRenderComponent,
    AcnaCheckboxComponent,
    AcnaDropdownComponent,
    SubgroupDropdownComponent,
    DropdownIconRendererComponent,
    NewSegmentComponent

  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    CommonModule,
    AgGridModule,
    MaterialModule,
    BrowserAnimationsModule,
    RouterModule,
    FormsModule,ReactiveFormsModule

  ]
})
export class TableMaintenanceModule { }

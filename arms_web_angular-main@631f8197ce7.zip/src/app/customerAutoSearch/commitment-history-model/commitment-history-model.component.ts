import {  Component, Inject, OnInit,ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, MenuItemDef, ValueFormatterParams } from 'ag-grid-enterprise';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PrimeNGConfig } from 'primeng/api';
import { CommitmentHistoryService } from 'src/app/services/commitment-history.service';


@Component({
  selector: 'app-commitment-history-model',
  templateUrl: './commitment-history-model.component.html',
  styleUrls: ['./commitment-history-model.component.scss']
})
export class CommitmentHistoryModelComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  parentRowData :any;
  selectedAccountNumbers:any;
  originatingSystem :any;

  rowData: any;
  columnDefs: any;
  shwNotesGrid: boolean = false;
  pageSize: number = 30;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
   // flex: 1,
    //minWidth: 100,
    resizable: true,
  }


  constructor(
    public dialogRef: MatDialogRef<CommitmentHistoryModelComponent>,
    private toastr: ToastrService,
    private commitmentHisotry : CommitmentHistoryService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.parentRowData = data.currRowData;
    this.selectedAccountNumbers = data.selectedAccountNumbers;
    this.originatingSystem = data.originatingSystem;
  }

inputData:any={};

  ngOnInit(): void {

    this.inputData.selectedAccountNumbers = this.selectedAccountNumbers;
    this.inputData.originatingSystem =  this.originatingSystem;

    this.primengConfig.ripple = true;
    this.commitmentHisotry.viewCommitmentHistory(this.inputData).subscribe((data: any) => {

      this.columnDefs = this.columnDefsCH;
      this.rowData = data.CommitmentHistory;
      this.gridApi.showLoadingOverlay();



    });
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(
      (document.getElementById('quickFilter') as HTMLInputElement).value
    );
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [
       {
        name: 'Close',
        action: () => {
          this.closeHistory();
        },
      },
      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  columnDefsCH: ColDef[] = [

     { headerName: 'Account Number', field: 'account_number',
     headerCheckboxSelection: true,
     headerCheckboxSelectionFilteredOnly: true,
     checkboxSelection: true},


     { headerName: 'System', field: 'originating_system'},
     { headerName: 'Date Entered', field: 'date_entered'},
     { headerName: 'Amount', field: 'amount',
     valueFormatter: currencyFormatter,type: 'rightAligned',
     cellStyle: (params) => {
       if (params.value < 0) {
         return { color: 'red' }; //,backgroundColor: 'green'
       }
       return null;
     },},
     { headerName: 'Due Date', field: 'due_date'},
     { headerName: 'Status', field: 'status'},

    ];

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

   closeModal(){
     this.dialogRef.close();
   }

   closeHistoryInputs:any={};

   closeHistory(){

    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node:any) => node.data);
    let selectedAccountNumbers= selectedData.map((e:any)=>{return e.account_number});
    let originatingSystem = selectedData.map((e:any)=>{return e.originating_system});
    let selectedAmount = selectedData.map((e:any)=>{return e.amount});
    let selectedDueDate = selectedData.map((e:any)=>{return e.due_date});
    this.closeHistoryInputs.selectedAccountNumbers = selectedAccountNumbers;
    this.closeHistoryInputs.originatingSystem = originatingSystem;
    this.closeHistoryInputs.selectedAmount = selectedAmount;
    this.closeHistoryInputs.selectedDueDate = selectedDueDate;

    this.commitmentHisotry.closeCommitmentHistory(this.closeHistoryInputs).subscribe((data: any) => {
      if (data.msg == "success") {
        this.closeHistoryInputs = null;
        this.dialogRef.close({ msg: 'success' });
        this.toastr.success('', 'Success : Selected Commitment Hisotry Closed Successfully', {
          timeOut: 5000, closeButton: true
        });

      }else if(data.errorMsg){
        this.toastr.error('', 'Failure : Error!! Please select the necessary inputs', {
          timeOut: 5000, closeButton: true
        });
      }
    },
      (error: any) => {
        this.toastr.error('', 'Failure : Error!! Please select the necessary inputs', {
          timeOut: 5000, closeButton: true
        });
      }
    );


   }

}

function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

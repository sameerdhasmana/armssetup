import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommitmentHistoryModelComponent } from './commitment-history-model.component';

describe('CommitmentHistoryModelComponent', () => {
  let component: CommitmentHistoryModelComponent;
  let fixture: ComponentFixture<CommitmentHistoryModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommitmentHistoryModelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommitmentHistoryModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

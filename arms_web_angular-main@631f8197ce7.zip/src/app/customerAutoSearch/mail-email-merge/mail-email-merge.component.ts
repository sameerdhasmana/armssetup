import {  Component, Inject, OnInit,ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PrimeNGConfig } from 'primeng/api';
import { EmailService } from 'src/app/services/email.service';
import {MatDialogModule} from '@angular/material/dialog';


@Component({
  selector: 'app-mail-email-merge',
  templateUrl: './mail-email-merge.component.html',
  styleUrls: ['./mail-email-merge.component.scss']
})

export class MailEmailMergeComponent implements OnInit {

  parentRowData :any;
  selectedAccountNumbers :any;
  originatingSystem : any;
  title :any;
  titleState : boolean = false;
  emailMailValue:any;
  mailMergeValue:any;

  mailMerge = [
    {name: 'Yes', code: '1'},
    {name: 'No', code: '0'}
  ];

  mailEmail = [
    {name: 'Mail', code: 'M'},
    {name: 'Email', code: 'E'}
  ];

  constructor(
    public dialogRef: MatDialogRef<MailEmailMergeComponent>,
    private toastr: ToastrService,
    private emailService : EmailService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.title = data.title;
    this.parentRowData = data.currRowData;
    this.selectedAccountNumbers = data.selectedAccountNumbers;
    this.originatingSystem = data.originatingSystem;


  }

saveMailEmailInputs : any = {};

  saveMailEmail(){
    this.saveMailEmailInputs.selectedAccountNumbers =  this.selectedAccountNumbers;
    this.saveMailEmailInputs.originatingSystem =  this.originatingSystem;
    this.saveMailEmailInputs.email = this.emailMailValue;
    this.emailService.accountEmailupdate(this.saveMailEmailInputs).subscribe((data: any) => {
      //console.log(data+'Email Inputs');
      if (data.MESSAGE == "success") {
        this.saveMailEmailInputs = null;
        this.dialogRef.close({ msg: 'success' });
        this.toastr.success('', 'Account is Updated Successfully!', {
          timeOut: 5000, closeButton: true
        });
      }else{
        this.saveMailEmailInputs = null;
        this.dialogRef.close({ msg: 'failure' });
        this.toastr.error('', 'Error!!, PLease Try again later !', {
          timeOut: 5000, closeButton: true
        });

      }
    }, (error: any) => {
      this.toastr.error('', 'Error!!, PLease Try again later !', {
        timeOut: 5000, closeButton: true
      });
    });

  }

  saveMailMergeInputs :  any ={};

  saveMailMerge(){
    this.saveMailMergeInputs.selectedAccountNumbers =  this.selectedAccountNumbers;
    this.saveMailMergeInputs.originatingSystem =  this.originatingSystem;
    this.saveMailMergeInputs.mailMergeEligible = this.mailMergeValue;
    this.emailService.accountMailEligibleUpdate(this.saveMailMergeInputs).subscribe((data: any) => {
      //console.log(data+'Email Inputs');
      if (data.MESSAGE == "success") {
        this.saveMailMergeInputs = null;
        this.dialogRef.close({ msg: 'success' });
        this.toastr.success('', 'Account is Updated Successfully!', {
          timeOut: 5000, closeButton: true
        });
      }else{
        this.saveMailMergeInputs = null;
        this.dialogRef.close({ msg: 'failure' });
        this.toastr.error('', 'Error!!, PLease Try again later !', {
          timeOut: 5000, closeButton: true
        });

      }
    }, (error: any) => {
      this.toastr.error('', 'Error!!, PLease Try again later !', {
        timeOut: 5000, closeButton: true
      });
    });
  }




  closeModal(){
    this.dialogRef.close();
  }


  ngOnInit(): void {
    if(this.title == 'mailEmail'){
this.titleState = true;
    }else{
      this.titleState = false;
    }
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MailEmailMergeComponent } from './mail-email-merge.component';

describe('MailEmailMergeComponent', () => {
  let component: MailEmailMergeComponent;
  let fixture: ComponentFixture<MailEmailMergeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MailEmailMergeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MailEmailMergeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

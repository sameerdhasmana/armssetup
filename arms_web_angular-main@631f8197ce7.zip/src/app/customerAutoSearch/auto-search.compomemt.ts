import { AfterViewInit, Component, Input, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../services/shared.service';
import { FilterService } from "primeng/api";
import { HttpClient } from '@angular/common/http';
import { SearchService } from '../services/search.service';
import { ToastrService } from 'ngx-toastr';
import { ColDef,  DragStoppedEvent, ExcelStyle, GetContextMenuItemsParams, GridOptions, ITooltipParams, MenuItemDef, ModelUpdatedEvent, RowClassRules, ValueFormatterParams, ValueParserParams } from 'ag-grid-community';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { CustomerPrintService } from '../services/print/customer.print';
import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { AifModalComponent } from '../ContextMenuItems/aif-modal/aif-modal.component';
import { CustomerNotesModalComponent } from '../ContextMenuItems/customer-notes-modal/customer-notes-modal.component';
import { CustomerNotesModalService } from '../services/customer-notes-modal.service';
import { AccountNotesComponent } from '../ContextMenuItems/account-notes/account-notes.component';
import { PremNotesComponent } from '../ContextMenuItems/prem-notes/prem-notes.component';
import { AccountNotesService } from '../services/accountNotes.service';
import { ModifyAccountNotesComponent } from '../ContextMenuItems/modify-account-notes/modify-account-notes.component';
import { AccountDetailsComponent } from '../ContextMenuItems/account-details/account-details.component';
import { EmailFuntionComponent } from '../ContextMenuItems/email-funtion/email-funtion.component';
import { MassResolveAccNotesComponent } from '../ContextMenuItems/mass-resolve-acc-notes/mass-resolve-acc-notes.component';
import { CommitmentHistoryModelComponent } from './commitment-history-model/commitment-history-model.component';
import { CellDoubleClickedEvent } from 'ag-grid-community';
import { MailEmailMergeComponent } from './mail-email-merge/mail-email-merge.component';
import { AccountNotesHistoryComponent } from '../ContextMenuItems/account-notes-history/account-notes-history.component';
import { ColumnOrderService } from '../services/column-order.service';
import { ViewUpdateContactsModelComponent } from '../ContextMenuItems/view-update-contacts-model/view-update-contacts-model.component';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable'
import { AccountsPastDueComponent } from '../ContextMenuItems/accounts-past-due/accounts-past-due.component';
import { TransposeViewComponent } from '../ContextMenuItems/transpose-view/transpose-view.component';
import {saveAs} from 'file-saver';
import { BreakdownDetailsComponent } from '../ContextMenuItems/breakdown-details/breakdown-details.component';
import { TaxiClaimDetailsComponent } from '../ContextMenuItems/taxi-claim-details/taxi-claim-details.component';
import { CashDataDetailsComponent } from '../ContextMenuItems/cash-data-details/cash-data-details.component';
import * as moment from 'moment';
import { HoveringHeadersComponent } from '../ContextMenuItems/hovering-headers/hovering-headers.component';
import { CustomerNotesHistoryComponent } from '../ContextMenuItems/customer-notes-history/customer-notes-history.component';
import { CustomerPermNotesComponent } from '../ContextMenuItems/customer-perm-notes/customer-perm-notes.component';
import { NgxSpinnerService } from "ngx-spinner";
import { AccountPDToolTip } from '../ContextMenuItems/accounts-past-due/accounts-pd.tooltip.component';
import { SystemTooltipComponent } from '../ContextMenuItems/hovering-headers/tooltip-system.component';
import { CurrentBalanceTooltipComponent } from '../ContextMenuItems/hovering-headers/tooltip.curbalance.component';
import { CurrentBillingTooltipComponent } from '../ContextMenuItems/hovering-headers/tooltip.curbilling.component';
import { DisputeAmtTooltipComponent } from '../ContextMenuItems/hovering-headers/tooltip.disputeamt.component';
import { InternalContactsEMAORComponent } from './internal-contacts-emaor/internal-contacts-emaor.component';
import {ConfirmationService} from 'primeng/api';
import {Message} from 'primeng/api';
import { PrimeNGConfig } from 'primeng/api';



interface Subject {
  name: string,
  code: string
}


@Component({
  selector: 'app-cust-query',
  templateUrl: './auto-search.compomemt.html',
  styleUrls: ['./auto-search.compomemt.scss'],
  providers: [FilterService,ConfirmationService],
})
export class AutoSearchComponent implements OnInit,AfterViewInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;
//  @ViewChild('acnaValue', {static: false}) auto:any;
  chkIfAccountNotesActive: boolean = false;
  chkIfCustomerNotesActive: boolean = false;
  selectedBtn: string = '';
  activeTab: string = 'Customer'; // Default Customer Selection Purpose
  checked = false; // Roll Up Parent Selection Purpose
  ctcCheckBox = true;
  customerType: any;
  // showInvoice =true;
  showInternalContacts = true;
  showEmaor = true;
  showAccNotes = true;
  showAgedDtl = false;
  msgs: Message[] = [];
  selectedItem: any = { customer_legal_nm: '' }; // AutoSearch Selected item
  acctInvFanItem: any;
  filteredItems: any[] = []; // AutoSearch Items Populated here in this Variable
  items: any[] = []; // Deprecated Prototype Purpose
  filters: any = {}; // Fetching the Filters data from the Tabs and Filters components .
  userData: any;
  pageSize: number = 1000;
  tooltipShowDelay:number = 500;
  tooltipHideDelay:number = 2000;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true
  };
  columnDefs: any;
  showGrid: boolean;
  defaultExcelExportParams: any;

  subjects: Subject[];
  headerHeight:any=30;
  selectedSubjectCode: any;

  constructor(
    private sharedService: SharedService,
    private filterService: FilterService,
    private http: HttpClient,
    private accountNotesService: AccountNotesService,
    private search: SearchService,
    private customerPrint: CustomerPrintService,
    private toastr: ToastrService,
    private primengConfig: PrimeNGConfig,
    private confirmationService: ConfirmationService,
    private router: Router,
    private dialog: MatDialog,
    public matDialog: MatDialog,
    private columnOrder: ColumnOrderService,
    private _CustNotesModalService: CustomerNotesModalService,
    private pdfSpinner: NgxSpinnerService,
  ) {
    this.showGrid = false;

    this.subjects = [
      { name: 'account', code: 'ACCT' },
      { name: 'invoice', code: 'INV NBR' },
      { name: 'FAN', code: 'FAN' },
    ];
  }
  billingPeriod: any;
  groupSeleted: any[] = [];
  ngOnInit() {
    this.sharedService.sharedData$.subscribe(
      (sharedData) => {
        this.activeTab = sharedData;
        this.showGrid = false;
        // this.selectedBtn = 'agedDetail';
        // this.showAgedDtl= true;
        // this.invoiceViewStatus = false;
        if (this.activeTab=='CTC') {
          this.checked =true;
        }
        else{
          this.checked = false;
        }
        this.selectedItem={}
      }
    );
    this.sharedService.filtersData$.subscribe((data) => {
      this.filters = { ...this.filters, ...data };
      this.selectedItem = {};
      this.showGrid = false;

      this.customerType = this.filters.customerType;
      //console.log(this.customerType);
      this.billingPeriod = this.filters.billingPeriod;
      this.groupSeleted = this.filters.groupSelected;

      //console.log("check :" + this.groupSeleted);
    });
    this.sharedService.filtersDataFromProfile$.subscribe((data) => {

      let chkFromHeaderForAutoSearch = localStorage.getItem('chkFromHeaderForAutoSearch');
      if(chkFromHeaderForAutoSearch=="1"){
        let epdata = localStorage.getItem('executeFilterData');
        this.ExecuteProfileRsp=JSON.parse(epdata ? epdata : '');
        if (this.activeTab === 'Customer') {
          this.selectedItem = {"ExcludedAccountsExists": "","customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        } else if (this.activeTab === 'ACNA') {
          this.selectedItem = {"acna_cd": this.ExecuteProfileRsp.profileDetails.profileQueryAcna,"customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        } else if (this.activeTab === 'AECN') {
          this.selectedItem = {"aecn_cd": this.ExecuteProfileRsp.profileDetails.profileQueryAecn,"customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        } else if (this.activeTab === 'CTC') {
          this.selectedItem = {"autorun_flag": "N","customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_grp_child_cd":this.ExecuteProfileRsp.profileDetails.profileQueryCtc,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        } else if (this.activeTab === 'OCN') {
          this.selectedItem = {"ocn_cd": this.ExecuteProfileRsp.profileDetails.profileQueryOcn,"customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        }        this.DisplayAgedDetailsFromExecuteProfile(this.ExecuteProfileRsp);
        //this.onSelect();
        //localStorage.setItem('chkFromHeaderForAutoSearch', "0");
    }
    });
  }
  helpUrl:any;
  userId:any;
  ExecuteProfileRsp :any={};
  ngAfterViewInit(): void {
    this.sharedService.filtersDataFromProfile$.subscribe((data) => {
    let chkFromHeaderForAutoSearch = localStorage.getItem('chkFromHeaderForAutoSearch');
      if(chkFromHeaderForAutoSearch=="1"){
        let epdata = localStorage.getItem('executeFilterData');
        this.ExecuteProfileRsp=JSON.parse(epdata ? epdata : '');
        if (this.activeTab === 'Customer') {
          this.selectedItem = {"ExcludedAccountsExists": "","customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        } else if (this.activeTab === 'ACNA') {
          this.selectedItem = {"acna_cd": this.ExecuteProfileRsp.profileDetails.profileQueryAcna,"customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        } else if (this.activeTab === 'AECN') {
          this.selectedItem = {"aecn_cd": this.ExecuteProfileRsp.profileDetails.profileQueryAecn,"customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        } else if (this.activeTab === 'CTC') {
          this.selectedItem = {"autorun_flag": "N","customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_grp_child_cd":this.ExecuteProfileRsp.profileDetails.profileQueryCtc,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        } else if (this.activeTab === 'OCN') {
          this.selectedItem = {"ocn_cd": this.ExecuteProfileRsp.profileDetails.profileQueryOcn,"customer_grp_cd": this.ExecuteProfileRsp.profileDetails.customerGrpCd,"customer_legal_nm": this.ExecuteProfileRsp.profileDetails.customerLegalNm};
        }
        this.DisplayAgedDetailsFromExecuteProfile(this.ExecuteProfileRsp);
        //this.onSelect();
        localStorage.setItem('chkFromHeaderForAutoSearch', "0");
    }
  });
// debugger;
//   if(this.activeTab === 'CTC'){
//     this.checked=true;
//   }
let data = localStorage.getItem('userInfo');
if (!data) {
  return;
}
this.userData = JSON.parse(data ? data : '');
this.helpUrl = this.userData.helpUrl;
this.userId =  this.userData.globalLogonUsers.user_login_cd;
  }

DisplayAgedDetailsFromExecuteProfile(ExecuteProfileRsp:any){
  this.chkIfCustomerNotesActive = false;
  this.chkIfAccountNotesActive = false;
  this.invoiceViewStatusChkForColumnOrder = false;
  this.customerNotesStatusCheckForColumnOrder = false;
  this.showGrid = true;
  this.showAccNotes = true;
  this.agedDetailStatuscheckForColumnOrder = true;
  this.accountNotesStatusCheckForColumnOrder = false;
  this.summaryStatusCheckforColumnOrder = false;
  this.showEmaor = true;
  this.showInternalContacts = true;

  this.columnDefs = ExecuteProfileRsp.GridHeaders;
  this.rowData = ExecuteProfileRsp.AgedDetail;
}

  columnDefsAD: ColDef[] = [
    { headerName: 'SVID Name', field: 'svid_name', resizable: true },
    { headerName: 'Account Nbr', field: 'account_number',
    tooltipField: 'account_number',
    tooltipComponent: AccountPDToolTip
  },
    { headerName: 'Bill Name', field: 'bill_name', resizable: true },
    { headerName: 'Bring Up Date', field: 'nextcall'},
    { headerName: 'Next Action', field: 'next_action' },
    { headerName: 'Payment Terms', field: 'payment_terms' },
    { headerName: 'EMAOR', field: 'emaor' },
    { headerName: 'EMAOR Eff Dt', field: 'emaor_eff_dt' },
    { headerName: '# EMAOR', field: 'emaor_cnt' },
    { headerName: 'Past Due', field: 'past_due', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
      },
      cellClassRules: {
        currencyField:(params) => {
          return params.value;
        },
        zeroCurrencyField:(params) => {
          return params.value === 0
        },
      },
},
    { headerName: '60+AMT', field: 'amt_60' ,aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }
},
    { headerName: '90+AMT', field: 'amt_90' ,aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }},
    { headerName: 'Total Amt', field: 'total_amt' ,aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }},
    { headerName: 'Collectable Total', field: 'collectable',aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Collectable PD', field: 'collectable_pd',aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Unapplied Amt', field: 'unapplied_amt' ,aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }},
    { headerName: 'Dispute Amt', field: 'dispute_amt',aggFunc: 'sum',type: 'rightAligned',
    tooltipField: 'dispute_amt',
    tooltipComponent: DisputeAmtTooltipComponent,
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'`<div style="text-align:right;">${date}</div>`
      }
      return null;
  } },
    { headerName: 'Last Dt Worked', field: 'last_dt_worked' },
    { headerName: 'Last Action Taken', field: 'sub_activity_cd' },
    { headerName: 'System', field: 'originating_system'},
    { headerName: 'State', field: 'state_cd' },
    { headerName: 'Seg', field: 'seg',
    tooltipField: 'seg',
    tooltipComponent: SystemTooltipComponent
    },
    { headerName: 'FAN/ZBU', field: 'zbu' },
    { headerName: 'Biller Status', field: 'biller_status' },
    { headerName: 'Status', field: 'status' },
    { headerName: 'OCN/CACS', field: 'ocn' },
    { headerName: 'Hot Note', field: 'hot_note' },
    { headerName: 'AP Sub Group', field: 'ap_sub_grp_nm' },
    {
      headerName: 'Current Balance Amt',
      field: 'current_balance_amt',
      aggFunc: 'sum',type: 'rightAligned',
      tooltipField: 'current_balance_amt',
      tooltipComponent: CurrentBalanceTooltipComponent,
      valueFormatter: currencyFormatter,
      cellStyle: params => {
        if (params.value < 0) {
            return {color: 'red'};//,backgroundColor: 'green'
        }
        return null;
    }
    },
    { headerName: '30+ Amt', field: 'past_due_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: '30 PD Amt', field: 'past_due_30_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: '30 PD Age', field: 'age_0_30' },
    { headerName: '60 PD Amt', field: 'past_due_60_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }
  },
    { headerName: '60 PD Age', field: 'age_31_60' },
    { headerName: '90 PD Amt', field: 'past_due_90_amt', aggFunc: 'sum' ,type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }},
    { headerName: '90 PD Age', field: 'age_61_90' },
    { headerName: '120 PD Amt', field: 'past_due_120_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: '120 PD Age', field: 'age_91_120' },
    { headerName: 'Flag Activity', field: 'flag_activity' },
    { headerName: 'Flag Activity Dt', field: 'flag_activity_date' },
    { headerName: 'Avg Age', field: 'avg_age' },
    { headerName: 'Flag Age', field: 'flag_age' },
    { headerName: 'Commitment Amt', field: 'commitment_amt',aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Contested Charges', field: 'contested_charges',aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Total ND Amt', field: 'total_nd_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Promotional Balance', field: 'promo_cr', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Current Billing Amt', field: 'current_billing_amt' , aggFunc: 'sum',type: 'rightAligned',
    tooltipField: 'current_billing_amt',
    tooltipComponent: CurrentBillingTooltipComponent,
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Bill Dt', field: 'bill_date'},
    { headerName: 'Final Bill Dt', field: 'final_bill_date' },
    { headerName: 'Wr-Off Dt', field: 'write_off_date' },
    { headerName: 'Last Adjust  Amt', field: 'last_adjustment_amt', aggFunc: 'sum',type: 'rightAligned',
    tooltipField: 'last_adjustment_amt',
    tooltipComponent: CurrentBalanceTooltipComponent,
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Last Adjust  Dt', field: 'last_adjustment_date',
    tooltipField: 'last_adjustment_date',
    tooltipComponent: CurrentBalanceTooltipComponent
   },

    { headerName: 'Adjust App Amt', field: 'adjustment_applied_amt', aggFunc: 'sum',type: 'rightAligned',
    tooltipField: 'adjustment_applied_amt',
    tooltipComponent: CurrentBalanceTooltipComponent,
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Last Pymnt Amt', field: 'last_payment_amt', aggFunc: 'sum',type: 'rightAligned',
    tooltipField: 'last_payment_amt',
    tooltipComponent: CurrentBalanceTooltipComponent,
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Last Pymnt Dt', field: 'last_payment_date',
    tooltipField: 'last_payment_date',
    tooltipComponent: CurrentBalanceTooltipComponent
  },
    { headerName: 'Pymnts App Amt', field: 'payment_applied_amt' , aggFunc: 'sum',type: 'rightAligned',
    tooltipField: 'payment_applied_amt',
    tooltipComponent: CurrentBalanceTooltipComponent,
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Customer Name', field: 'customer_name' },
    { headerName: 'Bill Address 2', field: 'bill_address_2' },
    { headerName: 'Bill Address 3', field: 'bill_address_3' },
    { headerName: 'Bill Address 4', field: 'bill_address_4' },
    { headerName: 'Bill City', field: 'bill_city' },
    { headerName: 'Bill State', field: 'bill_state' },
    { headerName: 'Bill ZIP', field: 'bill_zip' },
    { headerName: 'Contact Name', field: 'contact_name' },
    { headerName: 'Contact TN', field: 'contact_tn' },
    { headerName: 'Contact Email', field: 'contact_email' },
    { headerName: 'Email/Mail', field: 'email_or_mail' },
    { headerName: 'Mail Merge Eligible', field: 'mail_merge_eligible' },
    { headerName: '1Net/MACNA', field: 'macna_cd' },
    { headerName: 'ACNA', field: 'acna' },
    { headerName: 'AECN', field: 'aecn' },
    { headerName: 'Assigned', field: 'collections_userid' },
    { headerName: 'CD/AP', field: 'check_digit' },
    { headerName: 'Class', field: 'class_desc' },
    { headerName: 'CTC', field: 'ctc' },
    { headerName: 'SVID', field: 'svid' },
    { headerName: 'Root Cause', field: 'root_cause' },
    { headerName: 'Invoice Billed', field: 'invoice_billed' },
    { headerName: 'Exclude', field: 'excluded',
     cellRenderer: (params:any) => {
      return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;}
   },
    { headerName: 'Notes Detail', field: 'notes_exists',
    cellRenderer: (params:any) => {
     return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;} },
    { headerName: 'Billing Period', field: 'billing_period' },

  ];



  columnDefsAN: ColDef[] = [
    { headerName: 'Notes ID', field: 'notes_id' },
    { headerName: 'Customer ID', field: 'customer_grp_cd' },
    { headerName: 'Billing Period', field: 'billing_period' },
    { headerName: 'Resolved', field: 'resolved' ,
     cellRenderer: (params:any) => {
      return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;}
  },
    { headerName: 'Next Call Back Dt', field: 'next_call_back_date' },
    { headerName: 'Commitment Amt', field: 'commitment_amt',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Talked to', field: 'talked_to' },
    { headerName: 'Notes', field: 'notes',resizable:true,
    tooltipComponent: HoveringHeadersComponent,
    tooltipValueGetter: toolTipValueGetter
  },
    { headerName: 'Activity CD', field: 'activity_cd' },
    { headerName: 'In Treatment', field: 'activity_cd' ,
    cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='I') ? 'checked' : ''} />`;} },
    { headerName: 'Perm Note', field: 'activity_cd' ,
      cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='P') ? 'checked' : ''} />`;} },
    { headerName: 'Credit Information', field: 'activity_cd' ,
      cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='C') ? 'checked' : ''} />`;} },
    { headerName: 'Bankruptcy', field: 'activity_cd' ,
      cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='B') ? 'checked' : ''} />`;} },
    { headerName: 'No Action', field: 'activity_cd' ,
      cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='N') ? 'checked' : ''} />`;} },

    { headerName: 'Copy to Biller', field: 'copy_to_biller',
    cellRenderer: (params:any) => {
     return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;} },
    { headerName: 'Copy Biller Value', field: 'copy_biller_value'},
    { headerName: 'Biller Note Prem', field: 'biller_note_perm' },
    { headerName: 'SubDesc', field: 'subdesc' },
    { headerName: 'Bring Up Type', field: 'bring_up_type' },
    { headerName: 'Send to Adapt', field: 'send_to_adapt',
    cellRenderer: (params:any) => {
     return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;} },
    { headerName: 'My Bring Up', field: 'my_bring_up',
    cellRenderer: (params:any) => {
     return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;} },
    { headerName: 'System', field: 'originating_system' },
    { headerName: 'Contested Amt', field: 'contested_amt',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Root Cause', field: 'root_cause' },
    { headerName: 'Next Action', field: 'next_action' },
    { headerName: 'Commitment Date', field: 'commitment_date' },
    { headerName: 'User ID', field: 'user_login_cd' },
    { headerName: 'Call Type', field: 'call_type' },
    { headerName: 'Payment Method', field: 'payment_method' },
    { headerName: 'Phone#', field: 'customer_phone_number' },
    { headerName: 'Ext', field: 'customer_phone_number_extn' },
    { headerName: 'Email', field: 'customer_email' },
    { headerName: 'ATTUID/CACS', field: 'contact_attuid' },
    { headerName: 'Account No', field: 'account_number' },
    { headerName: 'Insert Data', field: 'insert_date' },
    { headerName: 'Logged By', field: 'logged_by' },

  ];
  columnDefsCN: ColDef[] = [
    { headerName: 'Notes ID', field: 'notes_id'},
    { headerName: 'Customer ID', field: 'customer_grp_cd' },
    { headerName: 'Billing Period', field: 'billing_period' },
    { headerName: 'Resolved', field: 'resolved',
    cellRenderer: (params:any) => {
     return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;} },
    { headerName: 'Next Call Back Dt', field: 'next_call_back_date' },
    { headerName: 'Commitment Amt', field: 'commitment_amt',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Talked to', field: 'talked_to' },
    { headerName: 'Notes', field: 'notes',resizable:true,
    tooltipComponent: HoveringHeadersComponent,
    tooltipValueGetter: toolTipValueGetter
  },
    { headerName: 'Activity CD', field: 'activity_cd' },
    { headerName: 'In Treatment', field: 'activity_cd' ,
    cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='I') ? 'checked' : ''} />`;} },
    { headerName: 'Perm Note', field: 'activity_cd' ,
      cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='P') ? 'checked' : ''} />`;} },
    { headerName: 'Credit Information', field: 'activity_cd' ,
      cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='C') ? 'checked' : ''} />`;} },
    { headerName: 'Bankruptcy', field: 'activity_cd' ,
      cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='B') ? 'checked' : ''} />`;} },
    { headerName: 'No Action', field: 'activity_cd' ,
      cellRenderer: (params:any) => {
      return `<input type='checkbox' ${(params.value=='N') ? 'checked' : ''} />`;} },

    { headerName: 'Sub Desc', field: 'subdesc' },
    { headerName: 'Group', field: 'group' },
    { headerName: 'Contested Amt', field: 'contested_amt',
    valueFormatter: currencyFormatter,type: 'rightAligned',
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Root Cause', field: 'root_cause' },
    { headerName: 'Next Action', field: 'next_action' },
    { headerName: 'Commitment Date', field: 'commitment_date' },
    { headerName: 'User ID', field: 'user_login_cd' },
    { headerName: 'Insert Date', field: 'insert_date' },
    { headerName: 'Log By', field: 'logged_by' },

  ];
  columnDefsIV: ColDef[] = [
    { headerName: 'Invoice Nbr', field: 'invoice_number' },
    { headerName: 'Account Nbr', field: 'account_number' },
    { headerName: 'Region', field: 'region' },
    { headerName: 'ACNA', field: 'acna' },
    { headerName: 'MACNA', field: 'macna' },
    { headerName: 'State', field: 'state' },
    { headerName: 'Seg', field: 'seg' },
    { headerName: 'Status', field: 'status' },
    { headerName: 'Current Billing Amt', field: 'current_billing_amt',
    valueFormatter: currencyFormatter,type: 'rightAligned',
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'Current Balance Amt', field: 'current_balance_amt' ,
    valueFormatter: currencyFormatter,type: 'rightAligned',
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }},
    { headerName: '30+ Amt', field: 'amt_30',
    valueFormatter: currencyFormatter,type: 'rightAligned',
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: '30 PD Amt', field: 'amt_30_days',
    valueFormatter: currencyFormatter,type: 'rightAligned',
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: '60 PD Amt', field: 'amt_60_days',
    valueFormatter: currencyFormatter,type: 'rightAligned',
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: '90 PD Amt', field: 'amt_90_days',
    valueFormatter: currencyFormatter,type: 'rightAligned',
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: '120 PD Amt', field: 'amt_120_days',
    valueFormatter: currencyFormatter,type: 'rightAligned',
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'ZBU', field: 'zbu' },
    { headerName: 'Class', field: 'class_desc' },
    { headerName: 'System', field: 'originating_system' },
    { headerName: 'Exclude', field: 'excluded',
    cellRenderer: (params:any) => {
     return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;} },
    { headerName: 'Billing Period', field: 'billing_period' },
    { headerName: 'Customer', field: 'customer' },
    { headerName: 'Originating System', field: 'originating_system' },
    { headerName: 'Bill Name', field: 'bill_name' },
    { headerName: 'Bill Date', field: 'bill_date' },
  ];

  columnDefsSummary: ColDef[] = [
    { headerName: 'Segment', field: 'seg' },
    {
      headerName: 'Current Billing Amt',
      field: 'current_billing_amt',
      aggFunc: 'sum',type: 'rightAligned',
      valueFormatter: currencyFormatter,
      cellStyle: params => {
        if (params.value < 0) {
            return {color: 'red'};//,backgroundColor: 'green'
        }
        return null;
    }
    },
    {
      headerName: 'Current Balance Amt',
      field: 'current_balance_amt',
      aggFunc: 'sum',type: 'rightAligned',
      valueFormatter: currencyFormatter,
      cellStyle: params => {
        if (params.value < 0) {
            return {color: 'red'};//,backgroundColor: 'green'
        }
        return null;
    }
    },
    { headerName: '30 PD Amt', field: 'past_due_30_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: '60 PD Amt', field: 'past_due_60_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: '90 PD Amt', field: 'past_due_90_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: '120 PD Amt', field: 'past_due_120_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: '30+ Amt', field: 'past_due_amt', aggFunc: 'sum',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }  },
    { headerName: 'Total Amt', field: 'total_amt', aggFunc: 'sum' ,type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
    { headerName: 'In Dispute', field: 'dispute_amt', aggFunc: 'sum' ,type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  } },
  ];

  print() {
    this.pdfSpinner.show();
    debugger;
    if(this.selectedItem?.customer_legal_nm)
    this.filters.enteredValue = this.selectedItem.customer_legal_nm;
    else this.filters.enteredValue = this.selectedItem;
    this.search.printCustomerReport(this.filters).subscribe(
      (blob:any)=>{
        saveAs(blob, 'Report.pdf')
        this.pdfSpinner.hide();
      },(error:any)=>{
        console.log(error);
        let message = error.message;
        this.toastr.error(message,'Error in downloading Report , Please try again later',
          {
            timeOut: 5000,
            closeButton: true,
          }
        )
        this.pdfSpinner.hide();
      }
    )
  }

  onSelect(eveny:any) {
    //this.rowData=[];
    this.showGrid=false;
    this.selectedBtn = 'agedDetail';
    this.agedDetail();
  }

  filterItems() {
    this.filters.enteredValue = this.selectedItem;
    if (this.activeTab === 'Customer') {
      this.filters.rollUp = 1
    }else{
      this.filters.rollUp = this.checked ? 1 : 0;
    }

    if (this.activeTab === 'Customer') {
      this.search.autoSearch(this.filters).subscribe(
        (data: any) => {
          if (this.customerType === 0) {
            this.filteredItems = data['All Customers'];
          } else if (this.customerType === 1) {
            this.filteredItems = data['My Customers'];
          } else if (this.customerType === 2) {
            this.filteredItems = data['Customer Bring Ups'];
          } else if (this.customerType === 3) {
            this.filteredItems = data['Account Bring Ups'];
          }
        },
        (failure: any) => {
          this.filteredItems = [];
        }
      );
    } else if (this.activeTab === 'ACNA') {
      this.search.autoSearchACNA(this.filters).subscribe(
        (data: any) => {
          this.filteredItems = data['ACNA'];
        },
        (failure: any) => {
          this.filteredItems = [];
        }
      );
    } else if (this.activeTab === 'AECN') {
      this.search.autoSearchACNA(this.filters).subscribe(
        (data: any) => {
          this.filteredItems = data['AECN'];
        },
        (failure: any) => {
          this.filteredItems = [];
        }
      );
    } else if (this.activeTab === 'CTC') {
      this.search.autoSearchACNA(this.filters).subscribe(
        (data: any) => {
          this.filteredItems = data['CTC'];
        },
        (failure: any) => {
          this.filteredItems = [];
        }
      );
    } else if (this.activeTab === 'OCN') {
      this.search.autoSearchACNA(this.filters).subscribe(
        (data: any) => {
          this.filteredItems = data['OCN'];
        },
        (failure: any) => {
          this.filteredItems = [];
        }
      );
    } else if (this.activeTab === 'Bill Name') {
      this.search.autoSearchBillName(this.filters).subscribe(
        (data: any) => {
          this.filteredItems = data['Bill_Name'];
        },
        (failure: any) => {
          this.filteredItems = [];
        }
      );
    }
  }

  rowData: any;
  agedDetailStatuscheckForColumnOrder = false;

  agedDetail() {
    this.defaultExcelExportParams = {
      fileName:
        'AgedDetailReport-' + this.selectedItem.customer_grp_cd + '-' + Date(),
        author:this.userId,
        sheetName:'Aged-Detail'
    };
    if (this.selectedItem != null) {
      this.chkIfCustomerNotesActive = false;
      this.chkIfAccountNotesActive = false;
      this.invoiceViewStatusChkForColumnOrder = false;
      this.customerNotesStatusCheckForColumnOrder = false;
      //this.showGrid = true;
      this.showAccNotes = true;
      this.agedDetailStatuscheckForColumnOrder = true;
      this.accountNotesStatusCheckForColumnOrder = false;
      this.summaryStatusCheckforColumnOrder = false;
      this.showEmaor = true;
      this.showInternalContacts = true;
      this.filters.customerGrpCd = this.selectedItem.customer_grp_cd;
      //this.filters.billName = this.selectedItem.customer_nm;
      //this.filters.ctcValue = this.selectedItem.customer_grp_child_cd;
      //this.filters.acnaValue = this.selectedItem.acna_cd || '';
      if(this.activeTab === 'ACNA'){
        this.filters.acnaValue = this.selectedItem.acna_cd;
        this.filters.billName = '';
        this.filters.ctcValue = '';
      } else if(this.activeTab === 'AECN'){
        this.filters.acnaValue = this.selectedItem.aecn_cd;
        this.filters.billName = '';
        this.filters.ctcValue = '';
      } else if(this.activeTab === 'OCN'){
        this.filters.acnaValue = this.selectedItem.ocn_cd;
        this.filters.billName = '';
        this.filters.ctcValue = '';
      } else if(this.activeTab === 'CTC'){
        this.filters.ctcValue = this.selectedItem.customer_grp_child_cd;
        this.filters.acnaValue = '';
        this.filters.billName = '';
      } else if(this.activeTab === 'Bill Name'){
        this.filters.billName = this.selectedItem.customer_nm;
        this.filters.ctcValue = '';
        this.filters.acnaValue = '';
      }
      this.currRowData = null;
      this.selectedBtn == 'agedDetail'
        this.showAgedDtl = false;
        this.invoiceViewStatus = true;
      if (this.activeTab === 'Customer') {
        this.search.customerAgedDetail(this.filters).subscribe((data: any) => {
          //this.columnDefs = this.columnDefsAD;
         // this.columnDefs = data.GridHeaders;
          this.showGrid = true;
          this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
            this.columnDefsAD.find((c:any)=>{
              return item.headerName == c.headerName
            })
            ));
          this.rowData = data.AgedDetail;
          //this.gridApi.showLoadingOverlay();
        },(error:any)=> {
          console.log(error)
          if (error.error.errorMsg) {
            let errorX = error.error.errorMsg;
            this.toastr.error('', 'Error! ' + errorX, {
              timeOut: 5000,
              closeButton: true,
            });
          }

        });
      } else if (this.activeTab === 'Bill Name') {
        this.search.billNameAgedDetail(this.filters).subscribe((data: any) => {
          //this.columnDefs = this.columnDefsAD;
          //this.columnDefs = data.GridHeaders;
          this.showGrid = true;
          //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsAD )
          this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
            this.columnDefsAD.find((c:any)=>{
              return item.headerName == c.headerName
            })
            ));
          this.rowData = data.AgedDetail;
          this.gridApi.showLoadingOverlay();
        });
      } else if (
        this.activeTab === 'ACNA' ||
        this.activeTab === 'AECN' ||
        this.activeTab === 'CTC' ||
        this.activeTab === 'OCN'
      ) {
        this.search.acnaAgedDetail(this.filters).subscribe((data: any) => {
          //this.columnDefs = this.columnDefsAD;
          //this.columnDefs = data.GridHeaders;
          this.showGrid = true;
          //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsAD )
          this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
            this.columnDefsAD.find((c:any)=>{
              return item.headerName == c.headerName
            })
            ));
          this.rowData = data.AgedDetail;
          this.gridApi.showLoadingOverlay();
        },(error:any) => {

        });
      } else {
        this.aifSearch()
      }
    } else {
      this.toastr.warning(
        '',
        'Aged Detail Query: Please Choose the Customer from the Auto Search Button',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }

  invoiceViewStatusChkForColumnOrder = false;
  invoiceView() {
    this.defaultExcelExportParams = {
      fileName:
        'InvoiceViewReport-' + this.selectedItem.customer_grp_cd + '-' + Date(),
    };
    if (this.activeTab === 'Customer') {
      this.filters.rollUp = 1
    }else{
      this.filters.rollUp = this.checked ? 1 : 0;
    }
    //this.showInvoice = false;
    this.showGrid = true;
    this.invoiceViewStatusChkForColumnOrder = true;
    this.accountNotesStatusCheckForColumnOrder = false;
    this.summaryStatusCheckforColumnOrder = false;
    this.chkIfCustomerNotesActive = false;
    this.customerNotesStatusCheckForColumnOrder = false;
    this.agedDetailStatuscheckForColumnOrder = false;
    this.chkIfAccountNotesActive = false;
    this.filters.customerGrpCd = this.selectedItem.customer_grp_cd;
    //this.filters.billName = this.selectedItem.customer_nm;
    if(this.activeTab === 'ACNA'){
      this.filters.acnaValue = this.selectedItem.acna_cd;
      this.filters.billName = '';
      this.filters.ctcValue = '';
    } else if(this.activeTab === 'AECN'){
      this.filters.acnaValue = this.selectedItem.aecn_cd;
      this.filters.billName = '';
      this.filters.ctcValue = '';
    } else if(this.activeTab === 'OCN'){
      this.filters.acnaValue = this.selectedItem.ocn_cd;
      this.filters.billName = '';
      this.filters.ctcValue = '';
    } else if(this.activeTab === 'CTC'){
      this.filters.ctcValue = this.selectedItem.customer_grp_child_cd;
      this.filters.acnaValue = '';
      this.filters.billName = '';
    } else if(this.activeTab === 'Bill Name'){
      this.filters.billName = this.selectedItem.customer_nm;
      this.filters.ctcValue = '';
      this.filters.acnaValue = '';
    }
    this.currRowData = null;
    if (this.activeTab === 'ACCT/INV/FAN') {
      this.filters.customerType = 0;
    }
    if (this.activeTab === 'Customer' || this.activeTab === 'ACCT/INV/FAN') {
      this.search.customerInvoiceView(this.filters).subscribe((data: any) => {
        //this.columnDefs = this.columnDefsIV;
        //this.columnDefs = data.GridHeaders;
        //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsIV )
        this.selectedBtn = "invoiceview";
        this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
          this.columnDefsIV.find((c:any)=>{
            return item.headerName == c.headerName
          })
          ));
        this.rowData = data.InvoiceView;
        this.gridApi.showLoadingOverlay();
      });
    } else if (this.activeTab === 'Bill Name') {
      this.search.billNameInvoiceView(this.filters).subscribe((data: any) => {
        //this.columnDefs = this.columnDefsIV;
        //this.columnDefs = data.GridHeaders;
        //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsIV )
        this.selectedBtn = "invoiceview";
        this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
          this.columnDefsIV.find((c:any)=>{
            return item.headerName == c.headerName
          })
          ));
        this.rowData = data.InvoiceView;
        this.gridApi.showLoadingOverlay();
      });
    } else {
      this.search.acnaInvoiceView(this.filters).subscribe((data: any) => {
        //this.columnDefs = this.columnDefsIV;
        //this.columnDefs = data.GridHeaders;
        //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsIV )
        this.selectedBtn = "invoiceview";
        this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
          this.columnDefsIV.find((c:any)=>{
            return item.headerName == c.headerName
          })
          ));
        this.rowData = data.InvoiceView;
        this.gridApi.showLoadingOverlay();
      });
    }
  }

  customerNotesStatusCheckForColumnOrder = false;

  customerNotes() {
    this.defaultExcelExportParams = {
      fileName:
        'CustomerNotesReport-' +
        this.selectedItem.customer_grp_cd +
        '-' +
        Date(),
    };
    if (this.selectedItem != null) {
      this.chkIfCustomerNotesActive = true;
      this.summaryStatusCheckforColumnOrder = false;
      this.accountNotesStatusCheckForColumnOrder = false;
      this.chkIfAccountNotesActive = false;
      this.invoiceViewStatusChkForColumnOrder = false;
      this.customerNotesStatusCheckForColumnOrder = true;
      this.agedDetailStatuscheckForColumnOrder = false;
      this.showGrid = true;
      this.filters.customerGrpCd = this.selectedItem.customer_grp_cd;
      this.search.customerNotes(this.filters).subscribe((data: any) => {
        //this.columnDefs = this.columnDefsCN;
        //this.columnDefs = data.GridHeaders;
        //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsCN )
        this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
          this.columnDefsCN.find((c:any)=>{
            return item.headerName == c.headerName
          })
          ));
        this.rowData = data.CustomerNotes;
        this.gridApi.showLoadingOverlay();
        this.selectedBtn = 'customerNotes';
        this.currRowData = null;
      });
    } else {
      this.toastr.warning(
        '',
        'Customer Notes : Please Choose the Customer from the Auto Search Button',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }
  summaryStatusCheckforColumnOrder = false;
  summary() {
    this.defaultExcelExportParams = {
      fileName:
        'SummaryReport-' + this.selectedItem.customer_grp_cd + '-' + Date(),
    };

    if (this.selectedItem != null) {
      this.chkIfCustomerNotesActive = false;
      this.chkIfAccountNotesActive = false;
      this.invoiceViewStatusChkForColumnOrder = false;
      this.customerNotesStatusCheckForColumnOrder = false;
      this.accountNotesStatusCheckForColumnOrder = false;
      this.summaryStatusCheckforColumnOrder = true;
      this.showGrid = true;
      this.agedDetailStatuscheckForColumnOrder = false;
      this.filters.customerGrpCd = this.selectedItem.customer_grp_cd;
      this.filters.billName = this.selectedItem.customer_nm;
      this.filters.ctcValue = this.selectedItem.customer_grp_child_cd;
      this.filters.acnaValue = this.selectedItem.acna_cd;
      if (this.activeTab === 'Customer') {
        this.filters.rollUp = 1
      }else{
        this.filters.rollUp = this.checked ? 1 : 0;
      }
      this.currRowData = null;

      if (this.activeTab === 'Customer') {
        this.search
          .singleCustomerSummary(this.filters)
          .subscribe((data: any) => {
            //this.columnDefs = this.columnDefsSummary;
            //this.columnDefs = data.GridHeaders;
            //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsSummary )
            this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
              this.columnDefsSummary.find((c:any)=>{
                return item.headerName == c.headerName
              })
              ));
            this.rowData = data.SummaryDetail;
            this.gridApi.showLoadingOverlay();
            this.selectedBtn = 'summary';
          });
      } else if (this.activeTab === 'Bill Name') {
        this.search
          .getBillNameSummaryDetails(this.filters)
          .subscribe((data: any) => {
            //this.columnDefs = this.columnDefsSummary;
            //this.columnDefs = data.GridHeaders;
            //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsSummary )
            this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
              this.columnDefsSummary.find((c:any)=>{
                return item.headerName == c.headerName
              })
              ));
            this.rowData = data.SummaryDetail;
            this.gridApi.showLoadingOverlay();
            this.selectedBtn = 'summary';
          });
      } else {
        this.search.summaryACNAQuery(this.filters).subscribe((data: any) => {
          //this.columnDefs = this.columnDefsSummary;
          //this.columnDefs = data.GridHeaders;
          //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsSummary )
          this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
            this.columnDefsSummary.find((c:any)=>{
              return item.headerName == c.headerName
            })
            ));
          this.rowData = data.SummaryDetail;
          this.gridApi.showLoadingOverlay();
          this.selectedBtn = 'summary';
        });
      }
    } else {
      this.toastr.warning(
        '',
        'Summary : Please Choose the Customer from the Auto Search Button',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [];

    if (this.selectedBtn == 'agedDetail') {
      if(this.currRowData == null || this.currRowData == undefined || this.currRowData == ""){
        return [];
      }
      result = [
        'copy',
        {
          name: 'Sort Ascending',
          action: () => {
            this.sortByAsc( params);
          },
        },
        {
          name: 'Sort Decending',
          action: () => {
            this.sortByDesc( params);
          },
        },
        {
          name: 'Clear Sort',
          disabled : !this.sortStatus,
          action: () => {
            this.clearSort();
          },
        },

        {
          name: 'Filter By Selection ('+ params.value+')',
          action: () => {
            this.customFilter( params);
          },
        },
        {
          name: 'Filter Excluding Selection ('+ params.value+')',
          action: () => {
            this.filterExcluding( params);
          },
        },
        {
          name: 'Remove All Filters',
          disabled: !this.filterStatus,
          action: () => {
            this.resetAllFilters()
          },
        },
        {
          //name: 'Account Notes ' + params.value,
          name: 'View Account Notes',
          disabled: !this.invoiceViewStatus,
          action: () => {
            this.accountNotes();
          },
        },
        {
          name: 'View Customer Notes',
          disabled: !this.invoiceViewStatus,
          action: () => {
            this.customerNotes();
          },
        },
        {
          name: 'View Internal Contacts',
          disabled: !this.invoiceViewStatus,
          action: () => {
            //this.internalContacts();
            this.internalContactsEMAOR("Internal Contacts Report",this.currRowData);
          },
        },
        {
          name: 'View/Update Contacts',
          action: () => {
            this.viewUpdateContacts(this.currRowData);
          },
        },
        {
          name: 'View EMAOR',
          disabled: !this.invoiceViewStatus,
          action: () => {
            //this.emaorView();
            this.internalContactsEMAOR("EMAOR View",this.currRowData);
          },
        },
        {
          name: 'Update',
          subMenu: [
            {
              name: 'Account Details Update',
              subMenu: [
                {
                  name: 'Add Account Notes',
                  action: () => {
                    this.accountDetailsModal('Add', this.currRowData);
                  },
                },
                {
                  name: 'Add AP Sub Group',
                  action: () => {
                    this.accountDetailsModal('Add', this.currRowData);
                  },
                },
                {
                  name: 'Add Contact Information',
                  action: () => {
                    this.accountDetailsModal('Add', this.currRowData);
                  },
                },
                {
                  name: 'Mass Resolve Account Notes',
                  action: () => {
                    this.massResolveAcNotes(this.currRowData);
                  },
                },
                {
                  name: 'Update Hot Notes',
                  action: () => {
                    this.accountDetailsModal('Add', this.currRowData);
                  },
                },
                {
                  name: 'Commitment History',
                  action: () => {
                    this.commintmentHistory(this.currRowData);
                  },
                },
              ],
            },
            {
              name: 'Mail Field Update',
              subMenu: [
                {
                  name: 'Email/Mail',
                  action: () => {
                    this.mailEmail(this.currRowData);
                  },
                },
                {
                  name: 'Mail Merge Eligible',
                  action: () => {
                    this.mailMerge(this.currRowData);
                  },
                },
              ],
            },
          ],
        },
        {
          name: 'Email Functionality',
          // disabled: this.invoiceViewStatus,
          action: () => {
            this.emailFunction();
          },
        },
        {
          name: 'Letter Functionality',
          // disabled: this.invoiceViewStatus,
          action: () => {
            this.redirectToInProgress();
          },
        },
        {
          name: 'CPPO',
          action: () => {
            this.generateCPPOReport();
          },
        },
        {
          name: 'Cust Copy',
          action: () => {
            this.generateCustCopyReport();
          },
        },
        {
          name: 'Rep Copy',
          action: () => {
            this.generateRepCopyReport();
          },
        },

        {
          name: 'Export to Excel',
          action: () => {
            this.exportAsExcel()
          }
        },
        {
          name: 'Export to Excel (Banruptcy)',
          action: () => {
            this.redirectToInProgress();
          },
        },
        {
          name: 'Switch to Invoice View',
          disabled: !this.invoiceViewStatus,
          action: () => {
            this.invoiceView();
            this.agedDetailOff();
            this.selectedBtn = 'invoiceView';
          },
        },
        {
          name: 'Show Transpose View',
          action: () => {
            this.transposeView(this.currRowData);
          },
        },
        {
          name: 'High Light Excluded Accounts',
          checked: this.highLightchecked,
          action: () => {
            this.highLightExcluded()
          },
        },
        // {
        //   name: 'Switch to Default Layout',
        //   disabled: this.invoiceViewStatus,
        //   action: () => {
        //     this.agedDetail();
        //     this.selectedBtn = 'agedDetail';

        //     this.agedDetailOff();
        //   },
        // },
        // {
        //   name: 'Hide Query Screen',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        {
          name: 'Help',
          action: () => {
            this.RedirectToHelp();
          },
        }
      ];
    }
    else if (this.selectedBtn == 'invoiceview') {
      result = [
        'copy',

        // {
        //   name: 'Find',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        {
          name: 'Customer Notes',
          disabled: this.invoiceViewStatus,
          action: () => {
            this.customerNotes();
          },
        },
        {
          name: 'Cust Copy',
          action: () => {
            this.generateCustCopyReport();
          },
        },
        {
          name: 'Rep Copy',
          action: () => {
            this.generateRepCopyReport();
          },
        },
        {
          name: 'Export to Excel',
          action: () => {
            this.exportAsExcel()
          }
        },

        {
          name: 'Switch to Account View',
          disabled: this.invoiceViewStatus,
          action: () => {
            this.agedDetail();
            this.selectedBtn = 'agedDetail';
            //this.agedDetailOff();
          },
        },
        {
          name: 'High Light Excluded Accounts',
          action: () => {
            this.redirectToInProgress();
          },
        },
        // {
        //   name: 'Switch to Default Layout',
        //   disabled: !this.invoiceViewStatus,
        //   action: () => {
        //     this.agedDetail();
        //     this.selectedBtn = 'agedDetail';

        //     this.agedDetailOff();
        //   },
        // },
        // {
        //   name: 'Hide Query Screen',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        {
          name: 'Help',
          action: () => {
            this.RedirectToHelp();
          },
        }
      ];
    }
    else if (this.selectedBtn == 'customerNotes') {
      if(this.currRowData == null || this.currRowData == undefined || this.currRowData == ""){
        return [];
      }
      result = [
        'copy',

        {
          name: 'Export to Excel',
          action: () => {
            this.exportAsExcel()
          }
        },

        // {
        //   name: 'Find',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        {
          name: 'Add Note',
          action: () => {
            this.openModal('Add', this.currRowData);
          },
        },
        {
          name: 'Modify Note',
          action: () => {
            this.openModal('Modify', this.currRowData);
          },
        },
        {
          name: 'Delete Note',
          action: () => {
            this.confirmDeleteCustomerNotes();
          },
        },
        {
          name: 'Resolve Note',
          action: () => {
            this.resolveNotes(this.currRowData);
          },
        },
        {
          name: 'Contacts',
          action: () => {
            this.RedirectToContacts();
          },
        },
        {
          name: 'Perm Notes',
          action: () => {
            this.customerNotesPermNotes(this.currRowData);
          },
        },
        {
          name: 'History',
          action: () => {
            this.customerNotesHistory(this.currRowData);
          },
        },
        // {
        //   name: 'Hide Query Screen',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        // {
        //   name: 'Hover Note',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        {
          name: 'Help',
          action: () => {
            this.RedirectToHelp();
          },
        },
      ];
    } else if (this.selectedBtn == 'accountNotes') {
      if(this.currRowData == null || this.currRowData == undefined || this.currRowData == ""){
        return [];
      }
      result = [
        'copy',

        {
          name: 'Export to Excel',
          action: () => {
            this.exportAsExcel()
          }
        },

        // {
        //   name: 'Find',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        {
          name: 'Add Note',
          action: () => {
            this.accountNotesModal('Add', this.currRowData);
          },
        },
        {
          name: 'Modify Note',
          action: () => {
            this.modifyAccNotes('Modify', this.currRowData);
          },
        },
        {
          name: 'Delete Note',
          action: () => {
            this.confirmDeleteAccountNotes();
          },
        },
        {
          name: 'Resolve Note',
          action: () => {
            this.resolveAccountNotes(this.currRowData);
          },
        },
        {
          name: 'Contacts',
          action: () => {
            this.RedirectToContacts();
          },
        },
        {
          name: 'Perm Notes',
          action: () => {
            this.premNotes(this.currRowData);
          },
        },
        {
          name: 'History',
          action: () => {
            this.accountNotesHistory(this.currRowData);
          },
        },
        // {
        //   name: 'Hide Query Screen',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        // {
        //   name: 'Hover Note',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        {
          name: 'Cancel Letter',
          action: () => {
            this.redirectToInProgress();
          },
        },
        {
          name: 'Help',
          action: () => {
            this.RedirectToHelp();
          },
        }
      ];
    }
    else if (this.selectedBtn == 'summary') {
      result = [
        'copy',

        {
          name: 'Export to Excel',
          action: () => {
            this.exportAsExcel()
          }
        },

        // {
        //   name: 'Find',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        {
          name: 'Switch to Default Layout',
          action: () => {
            if(this.invoiceViewStatus){
              this.agedDetail();
              this.selectedBtn = 'agedDetail';
            }
            else{
              this.invoiceView();
              this.selectedBtn = 'invoiceview';
            }
          },
        },
        // {
        //   name: 'Hide Query Screen',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        {
          name: 'Help',
          action: () => {
            this.RedirectToHelp();
          },
        },
      ]
    }
    else {
      if(this.currRowData == null || this.currRowData == undefined || this.currRowData == ""){
        return [];
      }
      result = [
        {
          //name: 'Account Notes ' + params.value,
          name: 'View Account Notes',
          disabled: !this.invoiceViewStatus,
          action: () => {
            this.accountNotes();
          },
        },
        {
          name: 'View EMAOR',
          disabled: !this.invoiceViewStatus,
          action: () => {
            this.emaorView();
          },
        },
        {
          name: 'View Internal Contacts',
          disabled: !this.invoiceViewStatus,
          action: () => {
            this.internalContacts();
          },
        },
        {
          name: 'Switch to Invoice View',
          disabled: !this.invoiceViewStatus,
          action: () => {
            this.invoiceView();
            this.agedDetailOff();
            this.selectedBtn = 'invoiceView';
          },
        },
        {
          name: 'Switch to Default Layout',
          disabled: this.invoiceViewStatus,
          action: () => {
            this.agedDetail();
            this.selectedBtn = 'agedDetail';
            this.agedDetailOff();
          },
        },
        {
          name: 'Email Functionality',
          // disabled: this.invoiceViewStatus,
          action: () => {
            this.emailFunction();
          },
        },
        'copy',

        {
          name: 'Export to Excel',
          action: () => {
            this.exportAsExcel()
          }
        },


      ];
    }
    return result;
  };

  redirectToInProgress(){
    this.router.navigate(['/inprogress']);
  }

  RedirectToHelp() {
    window.open(this.helpUrl, '_blank');
//    window.open('https://peoria.web.att.com/business/Wholesale/enterprise/jobaids/armsja.htm#cust_query_bk', '_blank')
  }

  RedirectToContacts() {
    this.router.navigate(['/contacts']);
  }
  highLightchecked:boolean = false;
  highLightExcluded(){
    this.highLightchecked = !this.highLightchecked;
    if(this.highLightchecked === true){
      this.gridApi.forEachNode(function (node:any) {
       node.setSelected(node.data?.excluded === 1);
      });
      this.gridApi.redrawRows();
    } else{
      this.gridApi.deselectAll()
      this.gridApi.redrawRows();
    }
  }
  //rowClassRules:any;
  rowClassRules: RowClassRules = {
    'highLight-info': (params:any) => {
      var highLightRows = params.data?.excluded;
      return highLightRows === 1 && params.node.selected;
     }
  };

  openModal(Mode: string, currRD: any) {
    if (Mode == 'Add') {
      const dialogConfig = new MatDialogConfig();
      // The user can't close the dialog by clicking outside its body
      dialogConfig.disableClose = true;
      dialogConfig.id = 'modal-component';
      dialogConfig.height = '100%';
      dialogConfig.width = '100%';
      dialogConfig.data = {
        Mode: Mode,
        currRowData: currRD,
        customerGroupCd: this.selectedItem.customer_grp_cd,
        billingPeriod: this.billingPeriod,
      };
      const modalDialog = this.matDialog.open(
        CustomerNotesModalComponent,
        dialogConfig
      );
      modalDialog.afterClosed().subscribe((res: any) => {
        if (res.msg == 'success') {
          this.customerNotes();
          this.currRowData = null;
        } else if (res.msg == 'cancelled') {
          this.customerNotes();
          this.currRowData = null;
        }
      });
    } else {
      if (currRD != undefined && currRD != null && currRD != '') {
        const dialogConfig = new MatDialogConfig();
        // The user can't close the dialog by clicking outside its body
        dialogConfig.disableClose = true;
        dialogConfig.id = 'modal-component';
        dialogConfig.height = '100%';
        dialogConfig.width = '100%';
        dialogConfig.data = {
          Mode: Mode,
          currRowData: currRD,
          customerGroupCd: this.selectedItem.customer_grp_cd,
        };
        const modalDialog = this.matDialog.open(
          CustomerNotesModalComponent,
          dialogConfig
        );
        modalDialog.afterClosed().subscribe((res: any) => {
          if (res.msg == 'success') {
            this.customerNotes();
            this.currRowData = null;
          } else if (res.msg == 'cancelled') {
            this.customerNotes();
            this.currRowData = null;
          }
        });
      } else {
        this.toastr.error(
          '',
          'Customer Notes : Select a Note to ' + Mode + '!',
          {
            timeOut: 5000,
            closeButton: true,
          }
        );
      }
    }
  }

  resolveNotesData: any = {};
  resolveNotes(currRd: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
      this.resolveNotesData.userLoginCd = currRd.user_login_cd;
      this.resolveNotesData.noteId = currRd.notes_id;
      this.resolveNotesData.notes = currRd.notes;
      this._CustNotesModalService.resolveNotes(this.resolveNotesData).subscribe(
        (data: any) => {
          //console.log(data);
          if (data.msg == 'success') {
            this.customerNotes();
            this.currRowData = null;
            this.toastr.success('', 'Customer Notes : Note Resolved!', {
              timeOut: 5000,
              closeButton: true,
            });
          }
        },
        (error: any) => {
          //console.log(error,"ResolveNoteError")
          if (error.error.errorMsg) {
            let errorX = error.error.errorMsg;
            this.customerNotes();
            this.currRowData = null;
            this.toastr.error(
              '',
              'Customer Notes : Error in Operation!' + errorX,
              {
                timeOut: 5000,
                closeButton: true,
              }
            );
          }
        }
      );
    } else {
      this.toastr.error('', 'Customer Notes : Select a Note to Resolve!', {
        timeOut: 5000,
        closeButton: true,
      });
    }
  }
  confirmDeleteCustomerNotes() {
    let rowCount = this.gridApi.getSelectedNodes().length;
      this.confirmationService.confirm({
        message: "You are about to delete "+rowCount+"Record(s)."+
        "If you Click Yes,you won't be able to undo this Delete operation."+
        "Are you sure you want to delete these Records",
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.msgs = [{severity:'info', summary:'Confirmed', detail:'You have accepted'}];
            this.deleteNotes()
        },
        reject: () => {
          this.toastr.info(
            '',
            'Customer Notes : Cancelled the Delete Operation!',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );

        }
    });
    }


  deleteNotesData: any = {};
  noteListArr: any = [];
  deleteNotes() {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
      for (let i of selectedData) {
        this.noteListArr.push(i.notes_id.toString());
      }
      this.deleteNotesData.noteIdList = this.noteListArr;
      this._CustNotesModalService.deleteNotes(this.deleteNotesData).subscribe(
        (data: any) => {
          //console.log(data);
          if (data.msg == 'success') {
            this.customerNotes();
            this.currRowData = null;
            this.noteListArr = [];
            this.toastr.success('', 'Customer Notes : Note Deleted!', {
              timeOut: 5000,
              closeButton: true,
            });
          }
        },
        (error: any) => {
          this.noteListArr = [];
        }
      );
    } else {
      this.toastr.error('', 'Customer Notes : Select a Note to Delete!', {
        timeOut: 5000,
        closeButton: true,
      });
    }
  }

  invoiceViewStatus: boolean = true;

  agedDetailOff() {
    this.showAgedDtl = !this.showAgedDtl;
    this.invoiceViewStatus = !this.invoiceViewStatus;
  }
  gridApi: any;
  gridColumnApi : any;
  onGridReady(params: any) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  selectedAccNumber: any;
  accountNotesStatusCheckForColumnOrder = false;
  accountNotes() {
    this.defaultExcelExportParams = {
      fileName:
        'AccountNotesReport-' +
        this.selectedItem.customer_grp_cd +
        '-' +
        Date(),
    };
    this.chkIfCustomerNotesActive = false;
    this.chkIfAccountNotesActive = true;
    this.agedDetailStatuscheckForColumnOrder = false;
    this.invoiceViewStatusChkForColumnOrder = false;
    this.customerNotesStatusCheckForColumnOrder = false;
    this.accountNotesStatusCheckForColumnOrder = true;
    this.summaryStatusCheckforColumnOrder = false;
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    //console.log(`Selected Nodes:\n${JSON.stringify(selectedData)}`);
    this.showAccNotes = false;
    this.showGrid = true;
    this.currRowData = null;
    if (selectedData[0]) {
      this.selectedAccNumber = selectedData[0].account_number;
      this.filters.accountNumber = selectedData[0].account_number;
      this.filters.acntNoteOrgSys = selectedData[0].originating_system;
      this.search.accountNotes(this.filters).subscribe((data: any) => {
        //this.columnDefs = this.columnDefsAN;
       // this.columnDefs = data.GridHeaders;
       //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsAN )
       this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
        this.columnDefsAN.find((c:any)=>{
          return item.headerName == c.headerName
        })
        ));
        this.rowData = data.AccountNotes;
        this.gridApi.showLoadingOverlay();
        this.selectedBtn = 'accountNotes';
      });
      return selectedData;
    } else {
      this.rowData = [];
      this.toastr.error(
        '',
        'Account Notes : Please Select the Account Numbers from Aged Dtl Grid',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
      this.selectedBtn = 'accountNotes';
    }
  }

  resolveAccountNotesData: any = {};
  resolveAccountNotes(currRd: any) {
      let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
      //this.resolveAccountNotesData.userLoginCd = currRd.user_login_cd;
      this.resolveAccountNotesData.noteId = currRd.notes_id;
      this.resolveAccountNotesData.notes = currRd.notes;
      this.accountNotesService
        .resolveAccountNotes(this.resolveAccountNotesData)
        .subscribe(
          (data: any) => {
            //console.log(data);
            if (data.msg == 'success') {
              this.accountNotes();
              this.currRowData = null;
              this.toastr.success('', 'Account Notes : Note Resolved!', {
                timeOut: 5000,
                closeButton: true,
              });
            }
          },
          (error: any) => {
            //console.log(error,"ResolveNoteError")
            if (error.error.errorMsg) {
              let errorX = error.error.errorMsg;
              this.accountNotes();
              this.currRowData = null;
              this.toastr.error(
                '',
                'Account Notes : Error in Operation!' + errorX,
                {
                  timeOut: 5000,
                  closeButton: true,
                }
              );
            }
          }
        );
    } else {
      this.toastr.error('', 'Account Notes : Select a Note to Resolve!', {
        timeOut: 5000,
        closeButton: true,
      });
    }
  }

  deleteAccNotesData: any = {};
  noteListArrAccs: any = [];

  confirmDeleteAccountNotes() {
    let rowCount = this.gridApi.getSelectedNodes().length;
      this.confirmationService.confirm({
        message: "You are about to delete "+rowCount+"Record(s)."+
        "If you Click Yes,you won't be able to undo this Delete operation."+
        "Are you sure you want to delete these Records",
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.msgs = [{severity:'info', summary:'Confirmed', detail:'You have accepted'}];
            this.deleteAccountNotes()
        },
        reject: () => {
          this.toastr.info(
            '',
            'Account Notes : Cancelled the Delete Operation!',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );

        }
    });
    }


  deleteAccountNotes() {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
      for (let i of selectedData) {
        this.noteListArrAccs.push(i.notes_id.toString());
      }
      this.deleteAccNotesData.noteIdList = this.noteListArrAccs;
      this.accountNotesService
        .deleteAccountNotes(this.deleteAccNotesData)
        .subscribe(
          (data: any) => {
            //console.log(data);
            if (data.msg == 'success') {
              this.accountNotes();
              this.currRowData = null;
              this.noteListArrAccs = [];
              this.toastr.success(
                '',
                'Account Notes : Note Deleted Successfully!',
                {
                  timeOut: 5000,
                  closeButton: true,
                }
              );
            }
          },
          (error: any) => {
            this.noteListArrAccs = [];
          }
        );
    } else {
      this.toastr.error('', 'Account Notes : Select a Note to Delete!', {
        timeOut: 5000,
        closeButton: true,
      });
    }
  }

  columnDefsEMAOR: ColDef[] = [
    { headerName: 'Email', field: 'email' },
    { headerName: 'Primary', field: 'primary' },
    { headerName: 'Eff Date', field: 'eff_date' },
    { headerName: 'Fisrt Name', field: 'first_name' },
    { headerName: 'Last Name', field: 'last_name' },
    { headerName: 'Acct Number', field: 'account_number' },
    { headerName: 'System', field: 'system' },
    { headerName: 'Notes', field: 'notes',resizable:true,
    tooltipComponent: HoveringHeadersComponent,
    tooltipValueGetter: toolTipValueGetter
  },
  ];
  emaorView() {
    this.defaultExcelExportParams = {
      fileName:
        'EMAORReport-' + this.selectedItem.customer_grp_cd + '-' + Date(),
    };
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    //console.log(`Selected Nodes:\n${JSON.stringify(selectedData)}`);
    this.showEmaor = false;
    this.showGrid = true;
    this.chkIfCustomerNotesActive = false;
    this.chkIfAccountNotesActive = false;
    this.currRowData = null;
    if (selectedData[0]) {
      this.filters.selectedAccountNumbers = selectedData.map((e: any) => {
        return e.account_number;
      });
      this.filters.originatingSystem = selectedData.map((e: any) => {
        return e.originating_system;
      });
      this.search.emaorView(this.filters).subscribe((data: any) => {
        this.columnDefs = this.columnDefsEMAOR;
        this.rowData = data.EmaorView;
        this.gridApi.showLoadingOverlay();
        this.selectedBtn = 'emaorView';
      });
      return selectedData;
    } else {
      this.rowData = [];
      this.toastr.error(
        '',
        'EMAOR View :  Please Select the Account Numbers from Aged Dtl Grid',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }

  columnDefsVIC: ColDef[] = [
    { headerName: 'Acct Number', field: 'account_number' },
    { headerName: 'Biller', field: 'biller' },
    { headerName: 'Collector', field: 'collector' },
    { headerName: 'Center Phone', field: 'center_phone' },
    { headerName: 'Extension', field: 'extension' },
    { headerName: 'Account Name', field: 'account_name' },
    { headerName: 'ATTUID', field: 'ae_attuid' },
    { headerName: 'Sales Manager', field: 'sales_mgr' },
    { headerName: 'Branch Manager', field: 'branch_mgr' },
  ];

  internalContactsEMAOR(Mode: string, currRD: any) {
      let selectedNodes = this.gridApi.getSelectedNodes();
      let selectedData = selectedNodes.map((node: any) => node.data);
      if (selectedData[0]) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.id = 'modal-component';
      dialogConfig.height = '100%';
      dialogConfig.width = '100%';
      dialogConfig.data = {
        Mode: Mode,
        selectedData: selectedData,
        customerGrpCd: this.selectedItem.customer_grp_cd,
        defaultExcelExportParams: this.defaultExcelExportParams
      };
      const modalDialog = this.dialog.open(InternalContactsEMAORComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {
        if (res.msg == 'success') {

        }
      });
    }
    else{
      this.toastr.error(
        '',
        'Please Select a record from the Grid',
        {
          timeOut: 4000,
          closeButton: true,
        }
      );
    }
  }

  internalContacts() {
    this.defaultExcelExportParams = {
      fileName:
        'InternalContactsReport-' +
        this.selectedItem.customer_grp_cd +
        '-' +
        Date(),
    };
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    //console.log(`Selected Nodes:\n${JSON.stringify(selectedData)}`);
    this.showInternalContacts = false;
    this.showGrid = true;
    this.chkIfCustomerNotesActive = false;
    this.chkIfAccountNotesActive = false;
    this.currRowData = null;
    if (selectedData[0]) {
      this.filters.selectedAccountNumbers = selectedData.map((e: any) => {
        return e.account_number;
      });
      this.filters.originatingSystem = selectedData.map((e: any) => {
        return e.originating_system;
      });
      this.search.viewInternalContacts(this.filters).subscribe((data: any) => {
        this.columnDefs = this.columnDefsVIC;
        this.rowData = data.ViewInternalContacts;
        this.gridApi.showLoadingOverlay();
        this.selectedBtn = 'internalContacts';
      });
      return selectedData;
    } else {
      this.rowData = [];
      this.toastr.error(
        '',
        'Internal Contacts : Please Select the Account Numbers from Aged Dtl Grid',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }
  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
    //console.log('row', this.currRowData);
    this.rowId=event.rowIndex+1;
  }

  overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
    Please wait while your Data is loading
    </span>`;
  overlayNoRowsTemplate = `<span style="padding: 10px;
     border: 2px solid #444;
     background: lightgoldenrodyellow;">
     No Data Found in the System
     </span>`;

  //dialogResult: any[] = [];
  //dialogOutput: any[] = [];
  selectionTrigger(){
    this.defaultExcelExportParams = {
      fileName: 'AgedDetailReport-' + this.acctInvFanItem + '-' + Date(),
    };

    this.filters.rollUp = this.checked ? 1 : 0;

    this.filters.acctInvFan = this.acctInvFanItem;
    this.filters.acctInvFanType = this.selectedSubjectCode;
    this.filters.enteredValue = this.acctInvFanItem;
    this.filters.acntNoteOrgSys = '';
    this.filters.customerGrpCd = this.selectedItem.customer_grp_cd;
    debugger;
    this.search.getAIFCustomerInfo(this.filters).subscribe(
      (data: any) => {
          this.showGrid = true;
          this.rowData = data.AgedDetail;
          //this.columnDefs = this.columnDefsAD;
          //this.columnDefs = Object.assign( data.GridHeaders , this.columnDefsAD )
          this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
            this.columnDefsAD.find((c:any)=>{
              return item.headerName == c.headerName
            })
            ));
          this.gridApi.showLoadingOverlay();
          this.selectedBtn = 'agedDetail';

  })
}

aifCustomerInfo :any=[];

  aifSearch() {
    this.defaultExcelExportParams = {
      fileName: 'AgedDetailReport-' + this.acctInvFanItem + '-' + Date(),
    };

    this.filters.rollUp = this.checked ? 1 : 0;
    this.filters.acctInvFan = this.acctInvFanItem;
    this.filters.acctInvFanType = this.selectedSubjectCode;
    this.filters.enteredValue = this.acctInvFanItem;
    this.filters.acntNoteOrgSys = '';
    this.filters.customerGrpCd = this.selectedItem.customer_grp_cd;
    this.chkIfCustomerNotesActive = false;
    this.chkIfAccountNotesActive = false;
    this.invoiceViewStatusChkForColumnOrder = false;
    this.customerNotesStatusCheckForColumnOrder = false;
   // this.showGrid = true;
    this.showAccNotes = true;
    this.agedDetailStatuscheckForColumnOrder = true;
    this.accountNotesStatusCheckForColumnOrder = false;
    this.summaryStatusCheckforColumnOrder = false;
    this.showEmaor = true;
    this.showInternalContacts = true;
    this.selectedBtn = 'agedDetail';
    this.search.getAIFCustomerInfo(this.filters).subscribe(
      (data: any) => {
          //this.selectedItem = data.AIFCustomerInfo[0];
          if('AIFCustomerInfo' in data){
          if(data.AIFCustomerInfo.length <2){
            this.aifCustomerInfo= data.AIFCustomerInfo;
            debugger
            this.selectedBtn = 'agedDetail';
            this.showGrid = true;
            this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
              this.columnDefsAD.find((c:any)=>{
                return item.headerName == c.headerName
              })
              ));
              this.rowData = data.AgedDetail;
            //this.columnDefs = this.columnDefsAD;
            //this.gridApi.showLoadingOverlay();
            this.selectedItem=data.AIFCustomerInfo[0];
          }else if(data.AIFCustomerInfo.length >= 2) {
            debugger
            this.aifCustomerInfo= data.AIFCustomerInfo;
            //console.log(data.AIFCustomerInfo.length)
          }
          } else if(data.AgedDetail) {
          debugger;
          this.selectedBtn = 'agedDetail';
          this.showGrid = true;
          this.columnDefs = data.GridHeaders.map((item:any, i:number) => Object.assign({}, item,
            this.columnDefsAD.find((c:any)=>{
              return item.headerName == c.headerName
            })
            ));
          this.rowData = data.AgedDetail;
          //this.columnDefs = this.columnDefsAD;
          //this.gridApi.showLoadingOverlay();
        } else {
          let dialogResult = data.AIFAlternateBillperiodGroup;
          let selectedDropdown = this.selectedSubjectCode;
          const dialogConfig = new MatDialogConfig();
          dialogConfig.disableClose = true;
          dialogConfig.id = 'modal-component';
          dialogConfig.height = '60%';
          dialogConfig.width = '60%';
          dialogConfig.data = {
            dialogResult: dialogResult,
            selectedDropdown : selectedDropdown
          };
          const modalDialog = this.dialog.open(AifModalComponent, dialogConfig);
          modalDialog.afterClosed().subscribe((res: any) => {
            if (res.msg == 'success') {
              this.aifSearch();
            } else {
              this.toastr.error('', 'Cancelled', {
                timeOut: 5000,
                closeButton: true,
              });
            }
          });
        }
      },
      (error: any) => {
        debugger
//        console.log(error.errorId,error.message+'AIFErrorlog');
        let errorId = error.error.errorId
        let errorMsg = error.error.errorMsg
        if (errorMsg) {
          this.toastr.error('', 'ACCT/INV/FAN Search Error! ' + 'errorID: '+ errorId +' ErrorMsg: '+ errorMsg +' Please contact ARMS Administrator', {
            timeOut: 5000,
            closeButton: true,
          });
        }
      }
    );
  }
  accountNotesModal(Mode: string, currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let groupSeleted = this.groupSeleted;
    if (selectedData[0]) {
    let selectedAccountNumbers = selectedData[0].account_number;
    let originatingSystem = selectedData[0].originating_system;
    let selectedAccountNumbersArray = selectedData.map((e: any) => {
      return e.account_number;
    });
    let originatingSystemArray = selectedData.map((e: any) => {
      return e.originating_system;
    });
    let customerGrpCd = this.selectedItem.customer_grp_cd;

    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      Mode: Mode,
      selectedAccountNumbers: selectedAccountNumbers,
      originatingSystem: originatingSystem,
      customerGrpCd: customerGrpCd,
      currRowData: currRD,
      billingPeriod: this.billingPeriod,
      originatingSystemArray: originatingSystemArray,
      selectedAccountNumbersArray: selectedAccountNumbersArray,
      groupSeleted: groupSeleted,
    };
    const modalDialog = this.dialog.open(AccountNotesComponent, dialogConfig);
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.accountNotes();
      }
    });
  }
  else{
    this.toastr.error(
      '',
      'Please Select Account Number from the Grid',
      {
        timeOut: 5000,
        closeButton: true,
      }
    );
  }
  }

  // premNotes(Mode: string, currRD: any) {
  //   const dialogConfig = new MatDialogConfig();
  //   // The user can't close the dialog by clicking outside its body
  //   dialogConfig.disableClose = true;
  //   dialogConfig.id = "modal-component";
  //   dialogConfig.height = "90%";
  //   dialogConfig.width = "70%";
  //   dialogConfig.data = {
  //     Mode: Mode
  //   }
  //   const modalDialog = this.dialog.open(PremNotesComponent, dialogConfig);
  // }

  modifyAccNotes(Mode: string, currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
    let groupSeleted = this.groupSeleted;
    let selectedAccountNumbers = selectedData[0].account_number;
    let originatingSystem = selectedData[0].originating_system;
    let selectedAccountNumbersArray = selectedData.map((e: any) => {
      return e.account_number;
    });
    let originatingSystemArray = selectedData.map((e: any) => {
      return e.originating_system;
    });
    let customerGrpCd = this.selectedItem.customer_grp_cd;

    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      Mode: Mode,
      selectedAccountNumbers: selectedAccountNumbers,
      originatingSystem: originatingSystem,
      customerGrpCd: customerGrpCd,
      currRowData: currRD,
      billingPeriod: this.billingPeriod,
      originatingSystemArray: originatingSystemArray,
      selectedAccountNumbersArray: selectedAccountNumbersArray,
      groupSeleted: groupSeleted,
    };
    const modalDialog = this.dialog.open(
      ModifyAccountNotesComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.accountNotes();
      }
    });
  }
  else{
    this.toastr.error(
      '',
      'Please Select Account Number from the Grid',
      {
        timeOut: 5000,
        closeButton: true,
      }
    );
  }
  }

  accountDetailsModal(Mode: string, currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
    let groupSeleted = this.groupSeleted;
    let selectedAccountNumbers = selectedData[0].account_number;
    let originatingSystem = selectedData[0].originating_system;
    let selectedAccountNumbersArray = selectedData.map((e: any) => {
      return e.account_number;
    });
    let originatingSystemArray = selectedData.map((e: any) => {
      return e.originating_system;
    });
    let customerGrpCd = this.selectedItem.customer_grp_cd;

    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      Mode: Mode,
      selectedAccountNumbers: selectedAccountNumbers,
      originatingSystem: originatingSystem,
      customerGrpCd: customerGrpCd,
      currRowData: currRD,
      billingPeriod: this.billingPeriod,
      originatingSystemArray: originatingSystemArray,
      selectedAccountNumbersArray: selectedAccountNumbersArray,
      groupSeleted: groupSeleted,
    };
    const modalDialog = this.dialog.open(AccountDetailsComponent, dialogConfig);
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.accountNotes();
      }
    });
  }
  else{
    this.toastr.error(
      '',
      'Please Select the Account Number from Aged Dtl Grid',
      {
        timeOut: 5000,
        closeButton: true,
      }
    );
  }
  }

  emailFunction() {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    //let selectedAccountNumber = selectedData[0].account_number;
    //let originatingSystem = selectedData[0].originating_system;
    let selectedAccountNumbersArray = selectedData.map((e: any) => {
      return e.account_number;
    });
    let originatingSystemArray = selectedData.map((e: any) => {
      return e.originating_system;
    });

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      selectedAccountNumber: selectedAccountNumbersArray,
      originatingSystem: originatingSystemArray,
    };
    const modalDialog = this.dialog.open(EmailFuntionComponent, dialogConfig);
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        //this.accountNotes();
      }
    });
  }

  viewUpdateContacts(currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    // alert(`Selected Nodes:\n${JSON.stringify(selectedData)}`);
    //let allRows  = JSON.stringify(selectedData);
    let allRows = selectedData;
    //return selectedData;

    let account_number = selectedData[0].account_number;
    let svid = selectedData[0].svid;
    let customer_name = selectedData[0].customer_name;
    let fan = selectedData[0].zbu;
    let originating_system = selectedData[0].originating_system;

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      allRows: allRows,
      currRowData: currRD,
      originating_system: originating_system,
      account_number: account_number,
      svid: svid,
      customer_name: customer_name,
      fan: fan,
    };
    const modalDialog = this.dialog.open(
      ViewUpdateContactsModelComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        // this.accountNotes();
      }
    });
  }

  massResolveAcNotes(currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    //let selectedAccountNumber = selectedData[0].account_number;
    //let originatingSystem = selectedData[0].originating_system;
    let selectedAccountNumbersArray = selectedData.map((e: any) => {
      return e.account_number;
    });
    let originatingSystemArray = selectedData.map((e: any) => {
      return e.originating_system;
    });

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      currRowData: currRD,
      selectedAccountNumber: selectedAccountNumbersArray,
      originatingSystem: originatingSystemArray,
    };
    const modalDialog = this.dialog.open(
      MassResolveAccNotesComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        //this.accountNotes();
      }
    });
  }

  commintmentHistory(currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let selectedAccountNumbersArray = selectedData.map((e: any) => {
      return e.account_number;
    });
    let originatingSystemArray = selectedData.map((e: any) => {
      return e.originating_system;
    });
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      currRowData: currRD,
      selectedAccountNumbers: selectedAccountNumbersArray,
      originatingSystem: originatingSystemArray,
    };
    const modalDialog = this.dialog.open(
      CommitmentHistoryModelComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.agedDetail();
      }
    });
  }

  mailEmail(currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let selectedAccountNumbersArray = selectedData.map((e: any) => {
      return e.account_number;
    });
    let originatingSystemArray = selectedData.map((e: any) => {
      return e.originating_system;
    });
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'mailEmail';
    dialogConfig.height = '50%';
    dialogConfig.width = '50%';
    dialogConfig.data = {
      title: 'mailEmail',
      currRowData: currRD,
      selectedAccountNumbers: selectedAccountNumbersArray,
      originatingSystem: originatingSystemArray,
    };
    const modalDialog = this.dialog.open(MailEmailMergeComponent, dialogConfig);
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.agedDetail();
      } else {
        this.agedDetail();
      }
    });
  }

  mailMerge(currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let selectedAccountNumbersArray = selectedData.map((e: any) => {
      return e.account_number;
    });
    let originatingSystemArray = selectedData.map((e: any) => {
      return e.originating_system;
    });
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'mailMerge';
    dialogConfig.height = '50%';
    dialogConfig.width = '50%';
    dialogConfig.data = {
      title: 'mailMerge',
      currRowData: currRD,
      selectedAccountNumbers: selectedAccountNumbersArray,
      originatingSystem: originatingSystemArray,
    };
    const modalDialog = this.dialog.open(MailEmailMergeComponent, dialogConfig);
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.agedDetail();
      } else {
        this.agedDetail();
      }
    });
  }


    onCellDoubleClicked(event: CellDoubleClickedEvent){
      if (this.selectedBtn == 'agedDetail') {
        if(event.column.getColId() === 'account_number'){
          this.accountPastDue(event)
        } else if(event.column.getColId() === 'seg') {
          this.accountNotes()
        } else if(event.column.getColId() === 'current_billing_amt') {
          this.breakdownDetails()
        } else if(event.column.getColId() === 'dispute_amt') {
          this.taxiClaimDetails()
        } else if(event.column.getColId() === 'current_balance_amt'){
          this.cashDataDetails(0,0)
        } else if(event.column.getColId() === 'payment_applied_amt' || event.column.getColId() === 'last_payment_date'
        || event.column.getColId() === 'last_payment_amt'){
          this.cashDataDetails(1,0)
        } else if(event.column.getColId() === 'last_adjustment_amt' || event.column.getColId() === 'last_adjustment_date'
        || event.column.getColId() === 'adjustment_applied_amt'){
          this.cashDataDetails(0,1)
        } else{
          //console.log('DoubleClickEvent'+event)
        }
      }

  }

  // else if(event.column.getColId() === 'adjustment_applied_amt' ||
  // event.column.getColId() === 'last_adjustment_date' || event.column.getColId() === 'payment_applied_amt'||
  //     event.column.getColId() === 'last_payment_date' || event.column.getColId() === 'last_payment_amt' ||
  //event.column.getColId() === 'last_adjustment_amt' || event.column.getColId() === 'current_balance_amt' ) {
  //       console.log(event.value)
  //       this.cashDataDetails()
  //     }

  onDragStopped(event: any) {
    //console.log(event);
    this.DragStoppedCustomEvent(event)
  }

  resetColumns(){
    //console.log('Reset Columns')
    if (this.agedDetailStatuscheckForColumnOrder) {
      let moduleName = 'AgedDetail';
      this.columnOrder
      .resetColumnOrder({moduleName:moduleName})
      .subscribe((data: any) => {
        if (data.msg == 'success') {
          this.agedDetail()
          this.toastr.success('', 'Column Order Reset Successfully', {
            timeOut: 5000,
            closeButton: true,
          });
        } else {
          this.toastr.error(
            '',
            'Error!! in resetting the Column Order, Please try again lsater',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );
        }
      });
    } else if (this.invoiceViewStatusChkForColumnOrder) {
      let moduleName = 'InvoiceView';
      this.columnOrder
      .resetColumnOrder({moduleName:moduleName})
      .subscribe((data: any) => {
        if (data.msg == 'success') {
          this.invoiceView()
          this.toastr.success('', 'Column Order Reset Successfully', {
            timeOut: 5000,
            closeButton: true,
          });
        } else {
          this.toastr.error(
            '',
            'Error!! in resetting the Column Order, Please try again lsater',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );
        }
      });

    }else if (this.summaryStatusCheckforColumnOrder) {
      let moduleName = 'SummaryDetail';
      this.columnOrder
      .resetColumnOrder({moduleName:moduleName})
      .subscribe((data: any) => {
        if (data.msg == 'success') {
          this.summary()
          this.toastr.success('', 'Column Order Reset Successfully', {
            timeOut: 5000,
            closeButton: true,
          });
        } else {
          this.toastr.error(
            '',
            'Error!! in resetting the Column Order, Please try again lsater',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );
        }
      });

    }else if (this.accountNotesStatusCheckForColumnOrder) {
      let moduleName = 'AccountNotes';
      this.columnOrder
      .resetColumnOrder({moduleName:moduleName})
      .subscribe((data: any) => {
        if (data.msg == 'success') {
          this.agedDetail()
          this.toastr.success('', 'Column Order Reset Successfully', {
            timeOut: 5000,
            closeButton: true,
          });
        } else {
          this.toastr.error(
            '',
            'Error!! in resetting the Column Order, Please try again lsater',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );
        }
      });

    } else if (this.customerNotesStatusCheckForColumnOrder) {
      let moduleName = 'CustomerNotes';
      this.columnOrder
      .resetColumnOrder({moduleName:moduleName})
      .subscribe((data: any) => {
        if (data.msg == 'success') {
          this.customerNotes()
          this.toastr.success('', 'Column Order Reset Successfully', {
            timeOut: 5000,
            closeButton: true,
          });
        } else {
          this.toastr.error(
            '',
            'Error!! in resetting the Column Order, Please try again lsater',
            {
              timeOut: 5000,
              closeButton: true,
            }
          );
        }
      });

  }
  }

  DragStoppedCustomEvent(params: any) {
    if (this.agedDetailStatuscheckForColumnOrder) {
      let moduleName = 'AgedDetail';
      let columnDragState = params.columnApi.getColumnState();
      //console.log(columnDragState, "columnDragState")
      const colIds = params.columnApi.getAllDisplayedColumns().map((e: any) => {
        return e.colDef;
      });
      //console.log(colIds);
      let agedDtlColumnStatus = colIds.map((item: any, i: any) =>
        Object.assign({}, item, columnDragState[i])
      );
//      console.log(agedDtlColumnStatus)
      let newString = JSON.stringify(agedDtlColumnStatus);
      console.log(newString, "AgedDetail")
      let inputAgedDtl: any = {};
      inputAgedDtl.moduleName = moduleName;
      inputAgedDtl.headerParams = newString;
      this.columnOrder
        .saveHeaderParameters(inputAgedDtl)
        .subscribe((data: any) => {
          if (data.msg == 'success') {
            this.toastr.success('', 'Column Order Saved Successfully', {
              timeOut: 5000,
              closeButton: true,
            });
          } else {
            this.toastr.error(
              '',
              'Error!! in saving the Column Order, Please try again lsater',
              {
                timeOut: 5000,
                closeButton: true,
              }
            );
          }
        });
    } else if (this.invoiceViewStatusChkForColumnOrder) {
      let moduleName = 'InvoiceView';
      let columnDragState = params.columnApi.getColumnState();
      const colIds = params.columnApi.getAllDisplayedColumns().map((e: any) => {
        return e.colDef;
      });
      let agedDtlColumnStatus = colIds.map((item: any, i: any) =>
        Object.assign({}, item, columnDragState[i])
      );
      let newString = JSON.stringify(agedDtlColumnStatus);
      //console.log(newString, "InovoiceView")
      let inputAgedDtl: any = {};
      inputAgedDtl.moduleName = moduleName;
      inputAgedDtl.headerParams = newString;
      this.columnOrder
        .saveHeaderParameters(inputAgedDtl)
        .subscribe((data: any) => {
          if (data.msg == 'success') {
            this.toastr.success('', 'Column Order Saved Successfully', {
              timeOut: 5000,
              closeButton: true,
            });
          } else {
            this.toastr.error(
              '',
              'Error!! in saving the Column Order, Please try again lsater',
              {
                timeOut: 5000,
                closeButton: true,
              }
            );
          }
        });
    } else if (this.summaryStatusCheckforColumnOrder) {
      let moduleName = 'SummaryDetail';
      let columnDragState = params.columnApi.getColumnState();
      const colIds = params.columnApi.getAllDisplayedColumns().map((e: any) => {
        return e.colDef;
      });
      let agedDtlColumnStatus = colIds.map((item: any, i: any) =>
        Object.assign({}, item, columnDragState[i])
      );
      let newString = JSON.stringify(agedDtlColumnStatus);
      //console.log(newString, "Summary")
      let inputAgedDtl: any = {};
      inputAgedDtl.moduleName = moduleName;
      inputAgedDtl.headerParams = newString;
      this.columnOrder
        .saveHeaderParameters(inputAgedDtl)
        .subscribe((data: any) => {
          if (data.msg == 'success') {
            this.toastr.success('', 'Column Order Saved Successfully', {
              timeOut: 5000,
              closeButton: true,
            });
          } else {
            this.toastr.error(
              '',
              'Error!! in saving the Column Order, Please try again lsater',
              {
                timeOut: 5000,
                closeButton: true,
              }
            );
          }
        });
    } else if (this.accountNotesStatusCheckForColumnOrder) {
      let moduleName = 'AccountNotes';
      let columnDragState = params.columnApi.getColumnState();
      const colIds = params.columnApi.getAllDisplayedColumns().map((e: any) => {
        return e.colDef;
      });
      let agedDtlColumnStatus = colIds.map((item: any, i: any) =>
        Object.assign({}, item, columnDragState[i])
      );
      let newString = JSON.stringify(agedDtlColumnStatus);
      //console.log(newString, "AccountNotes")
      let inputAgedDtl: any = {};
      inputAgedDtl.moduleName = moduleName;
      inputAgedDtl.headerParams = newString;
      this.columnOrder
        .saveHeaderParameters(inputAgedDtl)
        .subscribe((data: any) => {
          if (data.msg == 'success') {
            this.toastr.success('', 'Column Order Saved Successfully', {
              timeOut: 5000,
              closeButton: true,
            });
          } else {
            this.toastr.error(
              '',
              'Error!! in saving the Column Order, Please try again lsater',
              {
                timeOut: 5000,
                closeButton: true,
              }
            );
          }
        });
    } else if (this.customerNotesStatusCheckForColumnOrder) {
      let moduleName = 'CustomerNotes';
      let columnDragState = params.columnApi.getColumnState();
      const colIds = params.columnApi.getAllDisplayedColumns().map((e: any) => {
        return e.colDef;
      });
      let agedDtlColumnStatus = colIds.map((item: any, i: any) =>
        Object.assign({}, item, columnDragState[i])
      );
      let newString = JSON.stringify(agedDtlColumnStatus);
      //console.log(newString, "CustomerNotes")
      let inputAgedDtl: any = {};
      inputAgedDtl.moduleName = moduleName;
      inputAgedDtl.headerParams = newString;
      this.columnOrder
        .saveHeaderParameters(inputAgedDtl)
        .subscribe((data: any) => {
          if (data.msg == 'success') {
            this.toastr.success('', 'Column Order Saved Successfully', {
              timeOut: 5000,
              closeButton: true,
            });
          } else {
            this.toastr.error(
              '',
              'Error!! in saving the Column Order, Please try again lsater',
              {
                timeOut: 5000,
                closeButton: true,
              }
            );
          }
        });
    }
  }

  customerNotesHistory(currRD: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'customer-notes-history-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      customerGrpCd: this.selectedItem.customer_grp_cd
    };
    const modalDialog = this.dialog.open(
      CustomerNotesHistoryComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.customerNotes();
      }
    });
  }

  accountNotesHistory(currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
    let selectedAccountNumber = selectedData[0].account_number;
    let originatingSystem = selectedData[0].originating_system;
    // let selectedAccountNumbersArray= selectedData.map((e:any)=>{return e.account_number});
    // let originatingSystemArray = selectedData.map((e:any)=>{return e.originating_system});

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      currRowData: currRD,
      selectedAccountNumber: selectedAccountNumber,
      originatingSystem: originatingSystem,
    };
    const modalDialog = this.dialog.open(
      AccountNotesHistoryComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.accountNotes();
      }
    });
  }
  else {
    this.toastr.error('', 'Select Account Number to view History!', {
      timeOut: 5000,
      closeButton: true,
    });
  }
  }

  customerNotesPermNotes(currRD: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'customer-perm-notes-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      customerGrpCd: this.selectedItem.customer_grp_cd
    };
    const modalDialog = this.dialog.open(CustomerPermNotesComponent, dialogConfig);
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.customerNotes();
      }
    });
  }

  premNotes(currRD: any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
    let selectedAccountNumber = selectedData[0].account_number;
    let originatingSystem = selectedData[0].originating_system;
    // let selectedAccountNumbersArray= selectedData.map((e:any)=>{return e.account_number});
    // let originatingSystemArray = selectedData.map((e:any)=>{return e.originating_system});

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      currRowData: currRD,
      selectedAccountNumber: selectedAccountNumber,
      originatingSystem: originatingSystem,
    };
    const modalDialog = this.dialog.open(PremNotesComponent, dialogConfig);
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        this.accountNotes();
      }
    });
  }
  else {
    this.toastr.error('', 'Select Account Number to view Perm Notes!', {
      timeOut: 5000,
      closeButton: true,
    });
  }
  }

  searchValue: any;
  quickSearch() {
    this.gridApi.setQuickFilter(this.searchValue);
  }

  exportAsExcel() {
    this.gridApi.exportDataAsExcel();
  }


  generateCPPOReport() {
    this.pdfSpinner.show();
    this.filters.rollUp = this.checked ? 1 : 0;
    this.filters.stateFilter ='';
    this.filters.exclusiveAccess =0;
    this.filters.customerGrpCd = this.selectedItem.customer_grp_cd;
    this.filters.customerName = this.selectedItem.customer_legal_nm;
    this.search.generateCPPOReport(this.filters).subscribe(
      (blob:any)=>{
        saveAs(blob, 'CPPOReport.pdf')
        this.pdfSpinner.hide();
      },(error:any)=>{
        console.log(error);
        let message = error.message;
        this.toastr.error(message,'Error in downloading CPPO Report , Please try again later',
          {
            timeOut: 5000,
            closeButton: true,
          }
        )
        this.pdfSpinner.hide();
      }
    )
  }
  generateCustCopyReport() {
    this.pdfSpinner.show();
    this.filters.rollUp = this.checked ? 1 : 0;
    this.filters.stateFilter ='';
    this.filters.exclusiveAccess =0;
    this.filters.customerGrpCd = this.selectedItem.customer_grp_cd;
    this.filters.customerName = this.selectedItem.customer_legal_nm;
    this.search.generateCustCopyReport(this.filters).subscribe(
      (blob:any)=>{
        saveAs(blob, 'CustomerAccountCopy.pdf')
        this.pdfSpinner.hide();
      },(error:any)=>{
        console.log(error);
        let message = error.message;
        this.toastr.error(message,'Error in downloading CUSTCOPY Report , Please try again later',
          {
            timeOut: 5000,
            closeButton: true,
          }
        )
        this.pdfSpinner.hide();
      }
    )
  }

  generateRepCopyReport(){
    this.pdfSpinner.show();
    this.filters.rollUp = this.checked ? 1 : 0;
    this.filters.stateFilter ='';
    this.filters.exclusiveAccess =0;
    this.filters.customerGrpCd = this.selectedItem.customer_grp_cd;
    this.filters.customerName = this.selectedItem.customer_legal_nm;
    this.search.generateRepCopyReport(this.filters).subscribe(
      (blob:any)=>{
        saveAs(blob, 'RepAccountCopy.pdf')
        this.pdfSpinner.hide();
      },(error:any)=>{
        console.log(error);
        let message = error.message;
        this.toastr.error(message,'Error in downloading REPCOPY Report , Please try again later',
          {
            timeOut: 5000,
            closeButton: true,
          }
        )
        this.pdfSpinner.hide();
      }
    )
  }

  accountPastDue(event:any) {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let accountNumber = selectedData[0].account_number;
    let acntNoteOrgSys = selectedData[0].originating_system;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      accountNumber: accountNumber,
      acntNoteOrgSys: acntNoteOrgSys,
    };
    const modalDialog = this.dialog.open(
      AccountsPastDueComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
console.log('Account Past Due for Single Account is Closed Now')
      }
    });
  }

  transposeView(currRD: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      currRowData :  currRD,
    };
    const modalDialog = this.dialog.open(
      TransposeViewComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
        console.log('Transpose View Model is Closed Now')

      }
    });
  }

  breakdownDetails(){
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let accountNumber = selectedData[0].account_number;
    let acntNoteOrgSys = selectedData[0].originating_system;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      accountNumber: accountNumber,
      acntNoteOrgSys: acntNoteOrgSys,
    };
    const modalDialog = this.dialog.open(
      BreakdownDetailsComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
console.log('Account Breakdown Model is Closed Now')
      }
    });
  }

  taxiClaimDetails(){
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let accountNumber = selectedData[0].account_number;
    let acntNoteOrgSys = selectedData[0].originating_system;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      accountNumber: accountNumber,
      acntNoteOrgSys: acntNoteOrgSys,
    };

    const modalDialog = this.dialog.open(
      TaxiClaimDetailsComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
console.log('Taxi Claim Details Model is Closed Now')
      }
    });
  }

  cashDataDetails(byPayment:any,byAdjustment:any){
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let accountNumber = selectedData[0].account_number;
    let acntNoteOrgSys = selectedData[0].originating_system;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '100%';
    dialogConfig.width = '100%';
    dialogConfig.data = {
      byPayment : byPayment,
      byAdjustment : byAdjustment,
      accountNumber: accountNumber,
      acntNoteOrgSys: acntNoteOrgSys,
    };

    const modalDialog = this.dialog.open(
      CashDataDetailsComponent,
      dialogConfig
    );
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == 'success') {
console.log('Cash Data Details Model is Closed Now')
      }
    });

  }

rowId:any;
rowCount:any;
  rowIdChange(){
    this.rowCount = this.gridApi.getDisplayedRowCount()
    if(this.rowId < this.rowCount){
      const rowNode = this.gridApi.getRowNode(this.rowId-1);
      rowNode.setSelected(true,true);
      this.gridApi.ensureIndexVisible(this.rowId-1, 'middle');
    } else{
      const rowNode = this.gridApi.getRowNode(1);
      rowNode.setSelected(true,true);
      this.gridApi.ensureIndexVisible(1, 'middle');
      this.toastr.error(
        '',
        'Entered Row ID is not available inthis Page' + '!',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
  }
newPageSize:any;
  pageSizeFunc(){
  this.gridApi.paginationSetPageSize(Number(this.newPageSize));
  this.rowCount = this.gridApi.getDisplayedRowCount();
  //console.log(this.rowCount)
  }
  autoSearchClear(event:any){
//console.log(event)
this.rowData=[];
this.rowId='';
this.showGrid=false;
this.newPageSize ='';
  }

  public excelStyles: ExcelStyle[] = [
    {
    id: "currencyField",
    numberFormat: {
        //format: "[$$] #,##0.00"
        format: "$#,##0.00_);[Red]($#,##0.00)"
    }
  },
  {
    id: "zeroCurrencyField",
    numberFormat: {
        format: "[$$]#,##0.00"
    }
  }
  ];

  gridOptions:GridOptions ={
    suppressCsvExport:true,
  }
filterStatus:boolean=false;
sortStatus:boolean =false;
onModelUpdated(params:any){
//console.log(params);
//console.log(params.api.filterManager.activeColumnFilters.length);
if(params.api.filterManager.activeColumnFilters.length>0){
  this.filterStatus = true;
}
// console.log(this.gridColumnApi);
// console.log(this.gridColumnApi.getColumnState());
console.log(params.columnApi.getColumnState());
 let selectedNodes = params.columnApi.getColumnState();
 let selectedData = selectedNodes.map((e: any) => {
  return e.sort;
 });
 this.sortStatus = selectedData.filter((e:any)=>{
 return e != null
  })?.length>0;
 console.log(this.sortStatus);

}
  customFilter(params:any){
    console.log(params);
    let column = params.column.colDef.field;
    let filterComponent = this.gridApi.getFilterInstance(column)!;
    filterComponent.setModel({ values: [params.value] });
    this.gridApi.onFilterChanged();
  }

  filterExcluding(params:any) {
    console.log(params);
    let column = params.column.colDef.field;
    let filterKey = params.value;

    let currentFilterValues = this.gridApi
    .getFilterInstance(column)
    .getValues();
    console.log(currentFilterValues);

    let newFilterValues = currentFilterValues.filter(
      (column:any) => column != filterKey
    );
    console.log(newFilterValues);
    let filterComponent = this.gridApi.getFilterInstance(column)!;
    filterComponent.setModel({ values: newFilterValues });
    this.gridApi.onFilterChanged();
  }


  resetAllFilters(){
    this.gridApi.setFilterModel(null);
  }

  sortByAsc(params:any) {
    console.log(params);
    let column = params.column.colDef.field;
    this.gridColumnApi.applyColumnState({
      state: [{ colId: column, sort: 'asc' }],
      defaultState: { sort: null },
    });
  }
  sortByDesc(params:any) {
    console.log(params);
    let column = params.column.colDef.field;
    this.gridColumnApi.applyColumnState({
      state: [{ colId: column, sort: 'desc' }],
      defaultState: { sort: null },
    });
  }

  clearSort() {
    this.gridColumnApi.applyColumnState({
      defaultState: { sort: null },
    });
  }

  onCellKeyDown(e:any){
    console.log(e);
    let event = e.event;

    let KEY_A = 65;

    // If Ctrl + A pressed, select all nodes
    if (event.ctrlKey && event.which === KEY_A) {
        e.api.selectAll();
    }
  }


}

function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}
function dateFormatter(params:any) {
  var dateAsString = params.data.date;
  var dateParts = dateAsString.split('-');
  return `${dateParts[0]} - ${dateParts[1]} - ${dateParts[2]}`;
}

const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

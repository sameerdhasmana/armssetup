import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, GetContextMenuItemsParams, ITooltipParams, MenuItemDef, ValueFormatterParams } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { HoveringHeadersComponent } from 'src/app/management/hovering-headers.component';
import { CustomerNotesModalService } from 'src/app/services/customer-notes-modal.service';
import { SearchService } from 'src/app/services/search.service';


@Component({
  selector: 'app-internal-contacts-emaor',
  templateUrl: './internal-contacts-emaor.component.html',
  styleUrls: ['./internal-contacts-emaor.component.scss']
})
export class InternalContactsEMAORComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;
  rowData: any;
  columnDefs: any;
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    // flex: 1,
    //minWidth: 100,
    resizable: true,
  }

  Mode: string = "";
  customerGrpCd: string = "";
  selectedData: any;
  mDefaultExcelExportParams: any;
  constructor(
    public dialogRef: MatDialogRef<InternalContactsEMAORComponent>,
    private toastr: ToastrService,
    private customerNotesService: CustomerNotesModalService,
    private search: SearchService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.Mode = data.Mode;
    this.selectedData = data.selectedData;
    this.customerGrpCd = data.customerGrpCd;
    this.mDefaultExcelExportParams = data.defaultExcelExportParams;
  }
  defaultExcelExportParams: any;
  filters: any = {};
  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.filters.selectedAccountNumbers = this.selectedData.map((e: any) => {
      return e.account_number;
    });
    this.filters.originatingSystem = this.selectedData.map((e: any) => {
      return e.originating_system;
    });
    if (this.Mode == "Internal Contacts Report") {
      this.search.viewInternalContacts(this.filters).subscribe((data: any) => {
        this.columnDefs = this.columnDefsVIC;
        this.rowData = data.ViewInternalContacts;
      },
        (error: any) => {
          console.log(error);
        });
    }
    else if (this.Mode == "EMAOR View") {
      this.search.emaorView(this.filters).subscribe((data: any) => {
        this.columnDefs = this.columnDefsEMAOR;
        this.rowData = data.EmaorView;
      },
        (error: any) => {
          console.log(error);
        });
    }
    this.defaultExcelExportParams = this.mDefaultExcelExportParams;
  }
  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [];
    if (this.Mode == "Internal Contacts Report") {
      result = [
        'copy',
        'copyWithHeaders',
        'export'
        // {
        //   name: 'Right to left Reading order',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        // {
        //   name: 'Show Unicode control characters',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // },
        // {
        //   name: 'Insert Unicode control character',
        //   action: () => {
        //     this.redirectToInProgress();
        //   },
        // }
      ]
    }
    else if (this.Mode == "EMAOR View") {
      result = [
        'copy',
        'copyWithHeaders',
        'export'
      ];
    }
    return result;
  }

  columnDefsEMAOR: ColDef[] = [
    { headerName: 'Email', field: 'email' },
    { headerName: 'Primary', field: 'primary' },
    { headerName: 'Eff Date', field: 'eff_date' },
    { headerName: 'Fisrt Name', field: 'first_name' },
    { headerName: 'Last Name', field: 'last_name' },
    { headerName: 'Acct Number', field: 'account_number' },
    { headerName: 'System', field: 'system' },
    {
      headerName: 'Notes', field: 'notes', resizable: true,
      tooltipComponent: HoveringHeadersComponent,
      tooltipValueGetter: toolTipValueGetter
    },
  ];

  columnDefsVIC: ColDef[] = [
    { headerName: 'Account Number', field: 'account_number' },
    { headerName: 'Biller', field: 'biller' },
    { headerName: 'Collector', field: 'collector' },
    { headerName: 'Center Phone', field: 'center_phone' },
    { headerName: 'Extension', field: 'extension' },
    { headerName: 'Account Name', field: 'account_name' },
    { headerName: 'AE ATTUID', field: 'ae_attuid' },
    { headerName: 'Sales Mgr', field: 'sales_mgr' },
    { headerName: 'Branch Mgr', field: 'branch_mgr' },
  ];

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

  closeModal() {
    this.dialogRef.close({ msg: 'success' });
  }

}
const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

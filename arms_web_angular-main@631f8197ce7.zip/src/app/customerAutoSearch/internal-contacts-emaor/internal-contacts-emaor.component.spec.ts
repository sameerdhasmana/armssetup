import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InternalContactsEMAORComponent } from './internal-contacts-emaor.component';

describe('InternalContactsEMAORComponent', () => {
  let component: InternalContactsEMAORComponent;
  let fixture: ComponentFixture<InternalContactsEMAORComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InternalContactsEMAORComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InternalContactsEMAORComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

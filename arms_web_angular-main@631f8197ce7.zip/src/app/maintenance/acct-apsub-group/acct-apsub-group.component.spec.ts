import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcctAPSubGroupComponent } from './acct-apsub-group.component';

describe('AcctAPSubGroupComponent', () => {
  let component: AcctAPSubGroupComponent;
  let fixture: ComponentFixture<AcctAPSubGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcctAPSubGroupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AcctAPSubGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

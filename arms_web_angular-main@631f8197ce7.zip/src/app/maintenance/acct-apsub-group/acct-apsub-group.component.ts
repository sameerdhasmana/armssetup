import {  Component, Inject, OnInit,ViewChild } from '@angular/core';
import { MaintenanceService } from 'src/app/services/maintenance.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, GridOptions, MenuItemDef } from 'ag-grid-enterprise';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PrimeNGConfig } from 'primeng/api';
import { CellDoubleClickedEvent, CellValueChangedEvent } from 'ag-grid-community';
import { SubgroupDropdownComponent } from './subgroup-dropdown/subgroup-dropdown.component';
import { CellChangedEvent } from 'ag-grid-community/dist/lib/entities/rowNode';
import { DropdownIconRendererComponent } from './dropdown-icon-renderer/dropdown-icon-renderer.component';


@Component({
  selector: 'app-acct-apsub-group',
  templateUrl: './acct-apsub-group.component.html',
  styleUrls: ['./acct-apsub-group.component.scss']
})
export class AcctAPSubGroupComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  constructor(
    private maintenance : MaintenanceService,
    private toastr: ToastrService,
    public matDialog: MatDialog,
    private primengConfig: PrimeNGConfig,
  ) {
   }

  Filters :any;
  inputData:any={};
  billingPeriod : any=[];
  CustomerInfo :any =[];
  selectedBillingPeriod :any;
  selectedCustomer : any;
  columnDefs: any;
  showGrid: boolean = false;
  pageSize: number = 100;
  rowData:any;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    resizable: true,
  }
  defaultExcelExportParams: any;
  ngOnInit(): void {
    let data = localStorage.getItem("userInfo");
    this.Filters = JSON.parse(data ? data : "");
    this.inputData.group = this.Filters.globalLogonUsers.group;
    this.inputData.region = this.Filters.globalLogonUsers.region;
    this.maintenance.renderApSubGroup(this.inputData).subscribe((data: any) => {
      this.billingPeriod = data.billingPeriod;
      this.CustomerInfo = data.CustomerInfo;
      this.selectedBillingPeriod = data.billingPeriod[0];
    });
  }

subGroupArray:any=[];
  selectionTrigger(){
    this.defaultExcelExportParams = {
      fileName:
        'Account-AP-SubGroup-' + this.selectedCustomer.customer_grp_cd + '-' + Date(),
    };
    if(!this.selectedCustomer){
      this.toastr.error('', "The text you entered isn't an item in the Customer list."+"\n"+"Select an item from the list, or enter text that matches one of the listed items.", {
        timeOut: 5000,
        closeButton: true,
      });
      return;
    }
    let data = localStorage.getItem("userInfo");
    this.Filters = JSON.parse(data ? data : "");
    this.inputData.group = this.Filters.globalLogonUsers.group;
    this.inputData.region = this.Filters.globalLogonUsers.region;
    this.inputData.customerGrpCd = this.selectedCustomer.customer_grp_cd;
    this.inputData.billingPeriod = this.selectedBillingPeriod[0];
    this.maintenance.renderApSubGroupGrid(this.inputData).subscribe((data: any) => {
      this.showGrid = true;
      this.rowData =data.apSubGroupGrid;
      this.subGroupArray = data.APSubGroup.map((e: any) => { return e.ap_sub_grp_nm });
      //console.log(this.subGroupArray)
      this.columnDefs = this.columnDefsACC(this.subGroupArray)
      //this.gridApi.showLoadingOverlay();
      if(this.subGroupArray.length===0){
        this.toastr.info('', 'Account AP Sub Group Module : No SubGroups Associated with this Customer', {
          timeOut: 5000, closeButton: true
        });

      }
        });
  }

  onCellValueChanged(params: CellValueChangedEvent) {
    //console.log('onCellValueChanged: ', params);
    if (this.subGroupArray.length>0){
      let savesubGroupInput:any={}
      savesubGroupInput.accountNumber = params.data.account_number;
      savesubGroupInput.apSubGroupName =  params.data.sub_group;
      savesubGroupInput.acntNoteOrgSys = params.data.system;
      this.maintenance.saveApSubGroupGrid(savesubGroupInput).subscribe((data: any) => {
        if (data.msg == "success") {
          this.toastr.success('', 'Account AP Sub Group Module : Success Sub Group Changed', {
            timeOut: 5000, closeButton: true
          });

        }else if(data.errorMsg){
          this.toastr.error('', 'Account AP Sub Group Module : Error!!', {
            timeOut: 5000, closeButton: true
          });
        }
      },
        (error: any) => {
          if(error.error.errorMsg=='Please select the necessary inputs'){
          this.toastr.error('', error.error.errorMsg, {
            timeOut: 5000, closeButton: true
          });
        }
        }
      );
    } else{
      this.toastr.error('', 'Account AP Sub Group Module : No SubGroups Associated with this Customer', {
        timeOut: 5000, closeButton: true
      });

    }
  }
  columnDefsACC(subGroupArray:any){
    return [
      { headerName: 'BillName', field: 'bill_name'},
      { headerName: 'System', field: 'system'},
      { headerName: 'Segment', field: 'segment'},
      { headerName: 'State', field: 'state'},
      { headerName: 'AcctNmbr', field: 'account_number'},
      { headerName: 'SubGroup', field: 'sub_group',
      cellEditor: 'agRichSelectCellEditor',
      cellRenderer: DropdownIconRendererComponent,
      cellEditorPopup: true,
      cellEditorParams: {
        values: subGroupArray,
        cellHeight: 20,
        cellEditor: SubgroupDropdownComponent,
        searchDebounceDelay: 500
      },
      editable: true
    }
  ]
}


  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(
      (document.getElementById('quickFilter') as HTMLInputElement).value
    );
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [
      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

overlayLoadingTemplate =
  `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
overlayNoRowsTemplate =
  `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;
 clearGrid(){
this.rowData=[];
this.showGrid=false;
 }

}

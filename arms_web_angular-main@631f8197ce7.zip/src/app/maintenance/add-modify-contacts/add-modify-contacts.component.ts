import { AfterViewInit, Component, Inject, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MaintenanceService } from 'src/app/services/maintenance.service';


@Component({
  selector: 'app-add-modify-contacts',
  templateUrl: './add-modify-contacts.component.html',
  styleUrls: ['./add-modify-contacts.component.scss']
})
export class AddModifyContactsComponent implements OnInit , AfterViewInit{


  Mode: string = "";
  rowData: any;
  priority :any;
  firstName :any;
  lastName :any;
  title :any;
  address : any;
  phone : any;
  extn : any;
  fax :any;
  city :any;
  state :any;
  zip :any;
  email: any;
  emailFormControl = new FormControl('', [Validators.required, Validators.email]);
  notes :any;
  customerGrpCd :any;

  constructor(
    public dialogRef: MatDialogRef<AddModifyContactsComponent>,
    private maintenance : MaintenanceService,
    private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {

    this.Mode = data.Mode;
    this.rowData = data.currRowData;
    this.customerGrpCd = data.customerGrpCd;

//    console.log(this.rowData,'This is Row Data');
  }

  ContactsForm:  any = new FormGroup({
    Priority : new FormControl(),
    FirstName : new FormControl(),
    LastName : new FormControl(),
    Title : new FormControl(),
    Address : new FormControl(),
    Phone : new FormControl(),
    Extn : new FormControl(),
    Fax : new FormControl(),
    City : new FormControl(),
    State : new FormControl(),
    Zip : new FormControl(),
    Email : new FormControl(),
    Notes : new FormControl()


  });


  ngOnInit(): void {
  }

  sequence :any;
  modeType:any = 1;


  ngAfterViewInit(): void {
    if (this.Mode != "Add") {
      this.priority = this.rowData.priority;
      this.firstName = this.rowData.first_name;
      this.lastName =  this.rowData.last_name;
      this.address =  this.rowData.address;
      this.city =  this.rowData.city;
      this.state = this.rowData.state;
      this.zip = this.rowData.zip;
      this.title = this.rowData.title;
      this.phone = this.rowData.phone;
      this.extn = this.rowData.extension;
      this.fax  = this.rowData.fax_number;
      this.email = this.rowData.email;
      this.sequence = this.rowData.sequence;
      this.notes = this.rowData.notes;
      this.modeType = 2;
    }else{
      this.sequence = 0;
    }

  }

  savingContactDta :any={};

  saveContact(){

    this.savingContactDta.customerGrpCd = this.customerGrpCd;
    this.savingContactDta.firstName = this.firstName;
    this.savingContactDta.lastName = this.lastName;
    this.savingContactDta.address = this.address;
    this.savingContactDta.city = this.city;
    this.savingContactDta.state = this.state;
    this.savingContactDta.zip = this.zip;
    this.savingContactDta.title = this.title;
    this.savingContactDta.phoneNumber = this.phone;
    this.savingContactDta.phoneNumberExtn = this.extn;
    this.savingContactDta.faxNumber = this.fax;
    this.savingContactDta.email = this.email;
    this.savingContactDta.sequence = this.sequence;
    this.savingContactDta.notes = this.notes;
    this.savingContactDta.priority = this.priority;
    this.savingContactDta.modeType = this.modeType;

    //console.log(this.savingContactDta);
    this.maintenance.saveContacts(this.savingContactDta).subscribe((data: any) => {
      if (data.msg == "success") {
        this.savingContactDta = null;
        this.dialogRef.close({ msg: 'success' });
        this.toastr.success('', 'Contacts : Contact Saved', {
          timeOut: 5000, closeButton: true
        });

      }else if(data.errorMsg){
        this.toastr.error('', 'Contacts : Error!! Please select the necessary inputs', {
          timeOut: 5000, closeButton: true
        });
      }
    },
      (error: any) => {

      }
    );
  }

  closeModal() {
    this.dialogRef.close();
  }

  clearSearch(){

  }


}

import {  Component, Inject, OnInit,ViewChild,AfterViewInit } from '@angular/core';
import { MaintenanceService } from 'src/app/services/maintenance.service';
import { ToastrService } from 'ngx-toastr';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, MenuItemDef } from 'ag-grid-enterprise';
import { PrimeNGConfig } from 'primeng/api';
import { CellValueChangedEvent, ITooltipParams } from 'ag-grid-community';
import { HoveringHeadersComponent } from '../hovering-headers.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AddSubgroupComponent } from './add-subgroup/add-subgroup.component';




@Component({
  selector: 'app-cust-apsub-group',
  templateUrl: './cust-apsub-group.component.html',
  styleUrls: ['./cust-apsub-group.component.scss']
})
export class CustApsubGroupComponent implements OnInit , AfterViewInit{
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  constructor(
    private maintenance : MaintenanceService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private primengConfig: PrimeNGConfig,
  ) {
   }

  filters :any;
  inputData:any={};
  CustomerInfo :any =[];
  selectedCustomer : any;
  columnDefs: any;
  showGrid: boolean = false;
  pageSize: number = 100;
  rowData:any;
  headerHeight = 30;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    resizable: true,
  }
  defaultExcelExportParams: any;
  columnDefsCSG: ColDef[] = [
     { headerName: 'AP Sub Grp Name', field: 'apSubGrpName'},
     { headerName: 'Customer Name', field: 'customerGrpCd'},
     { headerName: 'Description', field: 'apSubGrpDesc',
     resizable: true,editable:true,width:850
     },
  ];
  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.inputData.strFilter='';
    this.inputData.strSort='';
    this.inputData.customerGrpCd= '';
    this.maintenance.custAPSubGrpDetails(this.inputData).subscribe((data: any) => {
      this.CustomerInfo = data.apSubGroupDetails;
    });
  }


  selectionTrigger(){
    this.defaultExcelExportParams = {
      fileName:
        'Customer-AP-SubGroup-' + this.selectedCustomer.customer_grp_cd + '-' + Date(),
    };
    if(!this.selectedCustomer){
      this.toastr.error('', "The text you entered isn't an item in the Customer list."+"\n"+"Select an item from the list, or enter text that matches one of the listed items.", {
        timeOut: 5000,
        closeButton: true,
      });
      return;
    }
    this.inputData.strFilter='';
    this.inputData.strSort='';
    this.inputData.customerGrpCd = this.selectedCustomer.customerGrpCd;
    this.maintenance.custAPSubGrpDetails(this.inputData).subscribe((data: any) => {
      this.showGrid = true;
      this.rowData = data.customerSubGrp;
      this.columnDefs = this.columnDefsCSG;
        });
  }

  onCellValueChanged(params: CellValueChangedEvent) {
    console.log(params);
    this.updateRecord(params)
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [];
    result = [
      {
        name: 'Add Record',
        action: () => {
          this.addNewRecord(this.currRowData)
        }
      },
      {
        name: 'Delete Record',
        action: () => {
          this.deleteRecord(this.currRowData)
        }
      },
      'copy',
      'copyWithHeaders',
      'export',
      {
        name: 'Help',
        action: () => {
          this.RedirectToHelp()
        }
      },

    ];
    return result;
  }
  updateData:any={};
  updateRecord(params:any){
    this.updateData.apSubGroupName = params.data.apSubGrpName;
    this.updateData.groupDesc = params.data.apSubGrpDesc;
    this.updateData.customerGrpCd = params.data.customerGrpCd;
    this.updateData.function = 'U';
    this.maintenance.apSubGroupUpdate(this.updateData).subscribe((data: any) => {
      if (data.MESSAGE == "success") {
        this.toastr.success('', 'Customer AP Sub Group Module : Success AP Sub Group Modified', {
          timeOut: 5000, closeButton: true
        });

      }else if(data.errorMsg){
        this.toastr.error('', 'Customer AP Sub Group Module : Error!!', {
          timeOut: 5000, closeButton: true
        });
      }
    },
      (error: any) => {
        if(error.error.errorMsg=='Please select the necessary inputs'){
        this.toastr.error('', error.error.errorMsg, {
          timeOut: 5000, closeButton: true
        });
      }
      });

  }


  addRec:any={}
  addRecord(curRowData:any){
    console.log(curRowData);
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    this.addRec.apSubGroupName = curRowData.data.apSubGrpName;
    this.addRec.groupDesc = curRowData.data.apSubGrpDesc;
    this.addRec.customerGrpCd = curRowData.data.customerGrpCd;
    this.addRec.insertLoginCd = userData.globalLogonUsers.user_login_cd;
    this.addRec.function = 'I';
    this.maintenance.apSubGroupUpdate(this.addRec).subscribe((data: any) => {
      if (data.MESSAGE == "success") {
        this.selectionTrigger()
        this.toastr.success('', 'Customer AP Sub Group Module : Success AP Sub Group Inserted', {
          timeOut: 5000, closeButton: true
        });

      }else if(data.errorMsg){
        this.toastr.error('', 'Customer AP Sub Group Module : Error!!', {
          timeOut: 5000, closeButton: true
        });
      }
    },
      (error: any) => {
        if(error.error.errorMsg=='Please select the necessary inputs'){
        this.toastr.error('', error.error.errorMsg, {
          timeOut: 5000, closeButton: true
        });
      }
      });
  }

  addNewRecord(curRowData:any) {
    // let selectedNodes = this.gridApi.getSelectedNodes();
    // let selectedData = selectedNodes.map((node: any) => node.data);
    //let customerGrpCd = selectedData[0].customerGrpCd;
    let customerGrpCd = this.selectedCustomer.customerGrpCd;
    let customerName = this.selectedCustomer.customerLegalNm;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    dialogConfig.height = '40%';
    dialogConfig.width = '60%';
    dialogConfig.data = {
      customerGrpCd: customerGrpCd,
      curRowData:curRowData,
      customerName :  customerName
    };
    const modalDialog = this.dialog.open(AddSubgroupComponent, dialogConfig);
    modalDialog.afterClosed().subscribe((res: any) => {
      if (res.msg == "success") {
        this.selectionTrigger()
        this.toastr.success('', 'Customer AP Sub Group Module : Success AP Sub Group Inserted', {
          timeOut: 5000, closeButton: true
        });

      }else if(res.errorMsg){
        this.toastr.error('', 'Customer AP Sub Group Module : Error!!', {
          timeOut: 5000, closeButton: true
        });
      }
    },
      (error: any) => {
        if(error.error.errorMsg=='Please select the necessary inputs'){
        this.toastr.error('', error.error.errorMsg, {
          timeOut: 5000, closeButton: true
        });
      }
      }
      );
  }


delRecord:any={}
  deleteRecord(curRowData:any){
    console.log(curRowData);
    this.delRecord.apSubGroupName = curRowData.apSubGrpName;
    this.delRecord.groupDesc = curRowData.apSubGrpDesc;
    this.delRecord.customerGrpCd = curRowData.customerGrpCd;
    this.delRecord.function = 'D';
    this.maintenance.apSubGroupUpdate(this.delRecord).subscribe((data: any) => {
      if (data.MESSAGE == "success") {
        this.selectionTrigger()
        this.toastr.success('', 'Customer AP Sub Group Module : Success AP Sub Group Deleted', {
          timeOut: 5000, closeButton: true
        });

      }else if(data.errorMsg){
        this.toastr.error('', 'Customer AP Sub Group Module : Error!!', {
          timeOut: 5000, closeButton: true
        });
      }
    },
      (error: any) => {
        if(error.error.errorMsg=='Please select the necessary inputs'){
        this.toastr.error('', error.error.errorMsg, {
          timeOut: 5000, closeButton: true
        });
      }
      });


  }


helpUrl:any;

ngAfterViewInit(): void {
  let userData:any;
let data = localStorage.getItem('userInfo');
if (!data) {
  return;
}
userData = JSON.parse(data ? data : '');
this.helpUrl = userData.helpUrl;
}


RedirectToHelp() {
    window.open(this.helpUrl, '_blank');
}


overlayLoadingTemplate =
  `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
overlayNoRowsTemplate =
  `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

 clearGrid(){
this.rowData=[];
this.showGrid=false;
 }

}

const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

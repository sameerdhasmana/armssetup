import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { MaintenanceService } from 'src/app/services/maintenance.service';

@Component({
  selector: 'app-add-subgroup',
  templateUrl: './add-subgroup.component.html',
  styleUrls: ['./add-subgroup.component.scss']
})
export class AddSubgroupComponent implements OnInit {


customerGrpCd:any;
apSubGrpName:any;
apSubGrpDesc:any;
customerName:any;
  constructor(public dialogRef: MatDialogRef<AddSubgroupComponent>,
    private toastr: ToastrService,
    private primengConfig: PrimeNGConfig,
    private maintenance : MaintenanceService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.customerGrpCd = data.customerGrpCd;
    this.customerName = data.customerName;
  }

  ngOnInit(): void {
  }
  validateAddRecord(){
    let strMsg: string = "";
    if (this.form.controls['subGroupName'].value == "" || this.form.controls['subGroupName'].value == undefined ||
    this.form.controls['subGroupName'].value == null) {
      strMsg = "AP Sub Group Name Can not be Empty";
    }
    return strMsg;  }

  form: any = new FormGroup({
    subGroupName: new FormControl(),
    subGroupDesc: new FormControl(),
  })

  onSubmit() {
    debugger;
    console.log(this.form, 'Add New AP Sub Group Form');
  }
  addRec:any={}
  addRecord(){
    let errMsg: string = this.validateAddRecord();
    if (errMsg != "") {
      this.toastr.error('', errMsg, {
        timeOut: 5000, closeButton: true
      });
    }
    else {

    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    this.addRec.apSubGroupName = this.apSubGrpName;
    this.addRec.groupDesc = this.apSubGrpDesc;
    this.addRec.customerGrpCd = this.customerGrpCd;
    this.addRec.insertLoginCd = userData.globalLogonUsers.user_login_cd;
    this.addRec.function = 'I';
    this.maintenance.apSubGroupUpdate(this.addRec).subscribe((data: any) => {
      if (data.MESSAGE == "success") {
        this.dialogRef.close({ msg: 'success' });
      }
    },
      (error: any) => {
        if(error.error.errorMsg=='Please select the necessary inputs'){
        this.toastr.error('', error.error.errorMsg, {
          timeOut: 5000, closeButton: true
        });
      }
      });
  }
  }

  closeModal() {
    this.dialogRef.close({ msg:"cancelled" });
  }


}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustApsubGroupComponent } from './cust-apsub-group.component';

describe('CustApsubGroupComponent', () => {
  let component: CustApsubGroupComponent;
  let fixture: ComponentFixture<CustApsubGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustApsubGroupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustApsubGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

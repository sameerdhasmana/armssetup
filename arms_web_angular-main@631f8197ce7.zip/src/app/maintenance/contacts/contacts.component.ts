import { Component, OnInit, ViewChild } from '@angular/core';
import { MaintenanceService } from 'src/app/services/maintenance.service';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, MenuItemDef } from 'ag-grid-enterprise';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AddModifyContactsComponent } from '../add-modify-contacts/add-modify-contacts.component';
import { PrimeNGConfig } from 'primeng/api';
import { CellDoubleClickedEvent, FirstDataRenderedEvent, GridApi, GridOptions, GridReadyEvent, ITooltipParams } from 'ag-grid-community';
import { HoveringHeadersComponent } from 'src/app/ContextMenuItems/hovering-headers/hovering-headers.component';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.scss']
})

export class ContactsComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  constructor(
    private maintenance: MaintenanceService,
    private toastr: ToastrService,
    public matDialog: MatDialog,
    private primengConfig: PrimeNGConfig
  ) { }

  gridOptions: GridOptions ={
    onCellDoubleClicked : (
      event: CellDoubleClickedEvent
  ) =>    this.addModifyContact("Modify",this.currRowData)
  }

  customers: any = [];
  selectedCustomer: any;
  rowData: any;
  columnDefs: any;
  showContactsGrid: boolean = false;
  pageSize: number = 30;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true
  }
  selectAll() {
    this.gridApi.selectAll()
  }
  onRowSelected(params:any){

    console.log(params,+"onRowSelected")
  }

onSelectionChanged(params:any){
  console.log(params,+"onSelectionChanged")
}

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.maintenance.allContacts('').subscribe((data: any) => {
      this.customers = data.CustomerInfo;

    });
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [
      {
        name: 'Add Contact',
        action: () => {
          this.addModifyContact("Add", this.currRowData)
        }
      }, {
        name: 'Modify Contact',
        action: () => {
          this.addModifyContact("Modify",this.currRowData);
        }
      }, {
        name: 'Delete Contact',
        action: () => {
          this.deleteACustomer();
        },
      },
      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
  }

  onFirstDataRendered(params: FirstDataRenderedEvent) {
    params.api.expandAll();
  }
  columnDefsMC: ColDef[] = [
   // { headerName: 'Sequence', field: 'sequence' },
    { headerName: 'Priority', field: 'priority',checkboxSelection: true,width:120,  resizable: true },
    { headerName: 'First Name', field: 'first_name' },
    { headerName: 'Last Name', field: 'last_name' },
    { headerName: 'Title', field: 'title' },
    { headerName: 'Phone#', field: 'phone' },
    { headerName: 'Ext', field: 'extension' },
    { headerName: 'Fax#', field: 'fax_number' },
    { headerName: 'Email Address', field: 'email' },
    { headerName: 'Address', field: 'address' },
    { headerName: 'City', field: 'city' },
    { headerName: 'State', field: 'state' },
    { headerName: 'Zip', field: 'zip' },
    { headerName: 'Notes', field: 'notes',resizable:true,
    tooltipComponent: HoveringHeadersComponent,
    tooltipValueGetter: toolTipValueGetter
  },
    { headerName: 'ContactsID', field: 'contacts_id' },
    { headerName: 'Customer ID', field: 'customer_grp_cd' },
  ];

  inputData: any = {};
  seletedCustomerID :any;

  selectionTrigger() {
    this.inputData.customerGrpCd = this.selectedCustomer.customer_grp_cd;
   // this.inputData.customerGrpCd = event.value.customer_grp_cd;
   // this.seletedCustomerID = event.value.customer_grp_cd;
    this.maintenance.populateContacts(this.inputData).subscribe((data: any) => {
      this.showContactsGrid = true;
      this.rowData = data.MaintenanceContactDetails;
      this.columnDefs = this.columnDefsMC;
    });
  }

  deleteContactJson :any={};

  deleteACustomer(){
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    if (selectedData[0]) {
      this.deleteContactJson.customerGrpCd = selectedData[0].customer_grp_cd;
      this.deleteContactJson.sequence = selectedData[0].sequence;
      this.maintenance.deleteContacts(this.deleteContactJson).subscribe((data: any) => {
        if (data.msg == "success") {
          //debugger;
          this.toastr.success('', 'Contacts : Seleted Contact is Succesfully Deleted!', {
            timeOut: 5000, closeButton: true
          });
          this.selectionTrigger();
        }
      },
        (error: any) => {

        }
      );
    } else {
      this.toastr.error('', 'Contacts : Error!! Please select a Contact to Delete', {
        timeOut: 5000, closeButton: true
      });
    }

  }

  addModifyContact(Mode: string, currRD: any){
let customer_grp_cd = this.selectedCustomer.customer_grp_cd;
    if (Mode == "Add") {
      const dialogConfig = new MatDialogConfig();
      // The user can't close the dialog by clicking outside its body
      dialogConfig.disableClose = true;
      dialogConfig.id = "modal-component";
      dialogConfig.height = "90%";
      dialogConfig.width = "65%";
      dialogConfig.data = {
        Mode: Mode,
        currRowData: currRD,
        customerGrpCd : customer_grp_cd
      }
      const modalDialog = this.matDialog.open(AddModifyContactsComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {
        if (res.msg == "success") {
          debugger;
          this.selectionTrigger();
          this.currRowData = null;
        }
        else if(res.msg=="cancelled"){
          this.selectionTrigger();
          this.currRowData = null;
        }
      })
    }
    else {
      if (currRD != undefined && currRD != null && currRD != "") {
        const dialogConfig = new MatDialogConfig();
        // The user can't close the dialog by clicking outside its body
        dialogConfig.disableClose = true;
        dialogConfig.id = "modal-component";
        dialogConfig.height = "90%";
        dialogConfig.width = "65%";
        dialogConfig.data = {
          Mode: Mode,
          currRowData: currRD,
          customerGrpCd : customer_grp_cd
        }
        const modalDialog = this.matDialog.open(AddModifyContactsComponent, dialogConfig);
        modalDialog.afterClosed().subscribe((res: any) => {
          if (res.msg == "success") {
            debugger;
            this.selectionTrigger();
            this.currRowData = null;
          }
          else if(res.msg=="cancelled"){
            this.selectionTrigger();
            this.currRowData = null;
          }
        })
      }
      else {
        this.toastr.error('', 'Contacts : Please Select a Note to ' + Mode + '!', {
          timeOut: 5000, closeButton: true
        });
      }
    }



  }

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

   onBtPrint() {
     debugger;
    const api = this.gridApi!;
    setPrinterFriendly(api);
    setTimeout(function () {
      print();
      // setNormal(api);
    }, 2000);
  }

}

function setPrinterFriendly(api: GridApi) {
  const eGridDiv = document.querySelector<HTMLElement>('#myGrid')! as any;
  eGridDiv.style.height = '';
  api.setDomLayout('print');
}
// function setNormal(api: GridApi) {
//   const eGridDiv = document.querySelector<HTMLElement>('#myGrid')! as any;
//   eGridDiv.style.width = '700px';
//   eGridDiv.style.height = '200px';
//   api.setDomLayout();
// }
const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

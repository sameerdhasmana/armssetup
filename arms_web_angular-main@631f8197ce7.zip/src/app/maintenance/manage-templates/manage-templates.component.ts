import {
  Component,
  OnInit,
  ViewChild,
  AfterViewInit,
} from '@angular/core';
import { MaintenanceService } from 'src/app/services/maintenance.service';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import {
  ColDef,
  GetContextMenuItemsParams,
  MenuItemDef,
} from 'ag-grid-enterprise';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PrimeNGConfig } from 'primeng/api';
import { CellDoubleClickedEvent, GridOptions } from 'ag-grid-community';




@Component({
  selector: 'app-manage-templates',
  templateUrl: './manage-templates.component.html',
  styleUrls: ['./manage-templates.component.scss'],
})
export class ManageTemplatesComponent implements OnInit, AfterViewInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  showTemplateGrid: boolean = true;
  rowData: any;
  columnDefs: any;
  selectedTemplate: any = 'New';
  templatesArray: any;
  templateNotes: any;//[{"template_name":"New"}]
  newTemplateName: any;
  viewTemplateName: any;
  userIDsArray: any = [];
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
  };

  gridOptions: GridOptions = {
    onCellDoubleClicked: (event: CellDoubleClickedEvent) => console.log('Test'),
  };

  constructor(
    private maintenance: MaintenanceService,
    private toastr: ToastrService,
    public matDialog: MatDialog,
    private primengConfig: PrimeNGConfig
  ) { }

  ngAfterViewInit(): void { }

  centerTempState !: boolean;

  inputData: any = {};

  ngOnInit(): void {
    this.selectedTemplate = {};
    this.selectedTemplate.template_name = '';
    this.primengConfig.ripple = true;
    this.maintenance
      .manageTemplateNotes(this.inputData)
      .subscribe((data: any) => {
        //console.log(data);
        this.rowData = data.AllUsers;
        this.columnDefs = this.columnDefsMC;
        this.templatesArray = data.NoteTemplate;
      });
  }

  viewTemplateInputs: any = {};

  viewTemplate() {
    if (this.selectedTemplate.template_name == "" || this.selectedTemplate.template_name == null || this.selectedTemplate.template_name == undefined) {
      this.toastr.error('', 'Template Name Can not be empty', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    this.viewTemplateInputs.templateName = this.selectedTemplate.template_name;
    this.viewTemplateInputs.templateType = this.selectedTemplate.template_type;
    this.maintenance
      .viewTemplate(this.viewTemplateInputs)
      .subscribe((data: any) => {
        this.userIDsArray = [];
        this.templateNotes = data.NoteDetails[0].nttmplt_tmplt;
        this.viewTemplateName = data.NoteDetails[0].nttmplt_name;
        this.centerTempState = data.NoteDetails[0].nttmplt_type == 'C' ? true : false;
        let userIDTxt = data.NoteDetails[0].nttmplt_h1_logins;
        let user_ids = data.NoteDetails[0].nttmplt_h1_logins.split(",")
        this.userIDsArray = [...this.userIDsArray, ...user_ids];
        //this.rowData = data.AllUsers;
        this.columnDefs = this.columnDefsMCFilters;
        //console.log(this.userIDsArray);
        let arrLen = this.userIDsArray.length;
        let UidArr = this.userIDsArray;
        if (UidArr.length > 0) {
          this.gridApi.forEachNode(function (node: any) {
            node.setSelected(false);
          });
          this.gridApi.forEachNode(function (node: any) {
            for (let i = 0; i < arrLen; i++) {
              if (node.data.user_id === UidArr[i]) {
                node.setSelected(node.data.user_id === UidArr[i]);
                //console.log(node.data);
              }
            }
          });
        }
      });

  }
  deleteTemplateInputs: any = {};

  deleteTemplate() {
    if (this.selectedTemplate.template_name == "" || this.selectedTemplate.template_name == null || this.selectedTemplate.template_name == undefined) {
      this.toastr.error('', 'Please check Template Notes Name/Template Notes Selected you want to delete and try again', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    this.deleteTemplateInputs.templateName = this.selectedTemplate.template_name;
    this.deleteTemplateInputs.templateType = this.selectedTemplate.template_type;

    this.maintenance
      .deleteTemplate(this.deleteTemplateInputs)
      .subscribe((data: any) => {
        this.toastr.success('', 'Template deleted successfully', {
          timeOut: 5000, closeButton: true
        });
      },
        (error: any) => {
          if (error.error.errorMsg == "Please select the necessary inputs") {
            this.toastr.error('', 'Please select the necessary inputs', {
              timeOut: 5000, closeButton: true
            });
          }
          else {
            this.toastr.error('', 'Unable to Save! Please try again later', {
              timeOut: 5000, closeButton: true
            });
          }
        });

    this.maintenance
      .manageTemplateNotes(this.inputData)
      .subscribe((data: any) => {
        console.log(data);
        this.rowData = data.AllUsers;
        this.columnDefs = this.columnDefsMC;
        this.templatesArray = data.NoteTemplate;
      });
    this.viewTemplateName = '';
    this.templateNotes = '';
    this.centerTempState = false;
  }

  saveTemplateInputs: any = {};

  saveTemplate() {
    if (this.viewTemplateName == "" || this.viewTemplateName == null || this.viewTemplateName == undefined) {
      this.toastr.error('', 'Template name can not be empty', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    this.saveTemplateInputs.templateName = this.viewTemplateName;
    this.saveTemplateInputs.templateType = this.centerTempState == true ? 'C' : 'U';
    this.saveTemplateInputs.templateOwner = '';
    this.saveTemplateInputs.templateNote = this.templateNotes;
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let selectedUserIDArray = selectedData.map((e: any) => {
      return e.user_id;
    });
    this.saveTemplateInputs.templateH1Logins = selectedUserIDArray;
    this.maintenance
      .saveTemplate(this.saveTemplateInputs)
      .subscribe((data: any) => {
        //console.log(data);
        this.toastr.success('', 'Template saved successfully', {
          timeOut: 5000, closeButton: true
        });
      },
        (error: any) => {
          if (error.error.errorMsg == "Please select the necessary inputs") {
            this.toastr.error('', 'Please select the necessary inputs', {
              timeOut: 5000, closeButton: true
            });
          }
          else {
            this.toastr.error('', 'Unable to Save! Please try again later', {
              timeOut: 5000, closeButton: true
            });
          }
        });

    this.maintenance
      .manageTemplateNotes(this.inputData)
      .subscribe((data: any) => {
        console.log(data);
        this.rowData = data.AllUsers;
        this.columnDefs = this.columnDefsMC;
        this.templatesArray = data.NoteTemplate;
      });

    this.viewTemplateName = '';
    this.templateNotes = '';
    this.centerTempState = false;

  }

  changeDetection() {
    this.viewTemplateName = '';
    this.templateNotes = '';
    this.centerTempState = false;
    if (this.selectedTemplate == "" || this.selectedTemplate == null || this.selectedTemplate == undefined) {
      this.selectedTemplate = {};
      this.selectedTemplate.template_name = '';
      this.primengConfig.ripple = true;
      this.maintenance
        .manageTemplateNotes(this.inputData)
        .subscribe((data: any) => {
          //console.log(data);
          this.rowData = data.AllUsers;
          this.columnDefs = this.columnDefsMC;
          this.templatesArray = data.NoteTemplate;


        });
    }
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [
      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  };

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  gridApi: any;

  onGridReady(params: any) {
    this.gridApi = params.api;
    // const filterModel = {
    //   UserID: {
    //     type: "contains",
    //     filter: "r",
    //     filterType: "text"
    //   }
    // };
    // params.api.setFilterModel(filterModel);
  }

  columnDefsMC: ColDef[] = [
    {
      headerName: 'User',
      field: 'user_id',
      checkboxSelection: true, headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      width: 120,
      resizable: true,
    },
    { headerName: 'Last', field: 'last_name' },
    { headerName: 'First', field: 'first_name' },
    { headerName: 'S1L', field: 's1_l_name' },
    { headerName: 'S1F', field: 's1_f_name' },
    { headerName: 'S2L', field: 's2_l_name' },
    { headerName: 'S2F', field: 's2_f_name' },
  ];

  columnDefsMCFilters: ColDef[] = [
    {
      headerName: 'UserID',
      field: 'user_id',
      checkboxSelection: true, headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      width: 120,
      resizable: true,
      filter: 'agSetColumnFilter',
      filterParams: {
        // values: this.CustomFilterParams
      }
    },
    { headerName: 'Last', field: 'last_name' },
    { headerName: 'First', field: 'first_name' },
    { headerName: 'S1L', field: 's1_l_name' },
    { headerName: 'S1F', field: 's1_f_name' },
    { headerName: 'S2L', field: 's2_l_name' },
    { headerName: 'S2F', field: 's2_f_name' },
  ];





  overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
  overlayNoRowsTemplate = `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;
}

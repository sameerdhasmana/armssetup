import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactsComponent } from './contacts/contacts.component';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MultiSelectModule} from 'primeng/multiselect';
import { MaterialModule } from '../material/material.module';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { AddModifyContactsComponent } from './add-modify-contacts/add-modify-contacts.component';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { AcctAPSubGroupComponent } from './acct-apsub-group/acct-apsub-group.component';
import {RouterModule} from '@angular/router';
import { ManageTemplatesComponent } from './manage-templates/manage-templates.component';
import { SubgroupDropdownComponent } from './acct-apsub-group/subgroup-dropdown/subgroup-dropdown.component';
import { DropdownIconRendererComponent } from './acct-apsub-group/dropdown-icon-renderer/dropdown-icon-renderer.component';
import { CustApsubGroupComponent } from './cust-apsub-group/cust-apsub-group.component';
import { HoveringHeadersComponent } from './hovering-headers.component';
import { AddSubgroupComponent } from './cust-apsub-group/add-subgroup/add-subgroup.component';

@NgModule({
  declarations: [
    ContactsComponent,
    AddModifyContactsComponent,
    AcctAPSubGroupComponent,
    ManageTemplatesComponent,
    SubgroupDropdownComponent,
    DropdownIconRendererComponent,
    CustApsubGroupComponent,
    HoveringHeadersComponent,
    AddSubgroupComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],

  imports: [
    CommonModule,
    MaterialModule,
    DropdownModule,RouterModule,
    FormsModule,ReactiveFormsModule,
    BrowserAnimationsModule,
    MultiSelectModule,
    AgGridModule,
    ButtonModule,
    RippleModule
  ],
  exports: []
})
export class MaintenanceModule { }

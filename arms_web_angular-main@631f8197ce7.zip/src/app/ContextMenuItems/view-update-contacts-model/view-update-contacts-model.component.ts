import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, MenuItemDef, GridOptions } from 'ag-grid-enterprise';
import { PrimeNGConfig } from 'primeng/api';
import { CellDoubleClickedEvent } from 'ag-grid-community';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

import { ViewUpdateContactsService } from 'src/app/services/view-update-contacts.service';
import { ContactsUpdateComponent } from './contacts-update/contacts-update.component';


@Component({
  selector: 'app-view-update-contacts-model',
  templateUrl: './view-update-contacts-model.component.html',
  styleUrls: ['./view-update-contacts-model.component.scss']
})
export class ViewUpdateContactsModelComponent implements OnInit {

  @ViewChild('agGrid1', { static: true }) agGrid1!: AgGridAngular;
  @ViewChild('agGrid2', { static: true }) agGrid2!: AgGridAngular;

  rowDatafromParent: any = [];
  rowData: any = [];
  columnDefs: any;
  rowDataGrid1: any = [];
  columnDefsGrid1: any;

  account_number: any;
  svid: any;
  customer_name: any;
  originating_system: any;
  fan: any;

  constructor(
    public dialogRef: MatDialogRef<ViewUpdateContactsModelComponent>,
    private toastr: ToastrService,
    public matDialog: MatDialog,
    private viewUpdateService: ViewUpdateContactsService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {

    //this.rowData.push(data.currRowData);
    this.account_number = data.account_number;
    this.svid = data.svid;
    this.customer_name = data.customer_name;
    this.fan = data.fan;
    this.rowData = data.allRows;
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.columnDefs = this.columnDefsAcc;
  }


  firstName: any = '';
  lastName: any = '';
  phoneNumber: any = '';
  email: any = '';
  headquaters: any = 'N';
  contactSearchResults: any = [];
  selectedContact: any;

  customerNameX: any = '';
  fanX: any = '';
  svidX: any = '';
  accountsX: any = '';
  origSystemsX: any = '';

  showContactsGrid: boolean = false;
  showAccountsGrid: boolean = true;

  defaultColDef2: ColDef = {
    sortable: true,
    filter: true
  }

  defaultColDef1: ColDef = {
    sortable: true,
    filter: true
  }

  pageSize = 100;

  headQuartersStatus(event: Event) {
    const isChecked = (<HTMLInputElement>event.target).checked;
    if (isChecked == true) {
      this.headquaters = 'Y';
    } else {
      this.headquaters = 'N';
    }
  }

  emaorState: any = 'N';

  emaorStatus(event: Event) {
    const isChecked = (<HTMLInputElement>event.target).checked;
    if (isChecked == true) {
      this.emaorState = 'Y';
    } else {
      this.emaorState = 'N';
    }
  }

  accountLevelState: any = 'N';
  accountLevelStatus(event: Event) {
    const isChecked = (<HTMLInputElement>event.target).checked;
    if (isChecked == true) {
      this.accountLevelState = 'Y';
    } else {
      this.accountLevelState = 'N';
    }
  }



  contactSearchData: any = {};

  searchContacts() {
    this.contactSearchData.firstName = this.firstName;
    this.contactSearchData.lastName = this.lastName;
    this.contactSearchData.phoneNumber = this.phoneNumber;
    this.contactSearchData.email = this.email;
    this.contactSearchData.headquaters = this.headquaters;
    if (this.firstName.trim() == "" && this.lastName.trim() == "" && this.phoneNumber.trim() == "" && this.email.trim() == "") {
      this.toastr.error('', 'Please populate any one of the search field!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    //console.log(this.contactSearchData);
    this.viewUpdateService.searchContacts(this.contactSearchData).subscribe((data: any) => {
      //console.log(data);
      this.contactSearchResults = data.searchContacts;
      this.columnDefsGrid1 = this.columnDefsGrid2;
      this.rowDataGrid1 = data.searchContacts;
      this.showContactsGrid = true;
    });
  }

  accountSearchData: any = {};


  searchAccounts() {
    this.accountSearchData.customerName = this.customerNameX;
    this.accountSearchData.acctInvFan = this.fanX;
    this.accountSearchData.serviceId = this.svidX;
    this.accountSearchData.accountNumber = this.accountsX;
    this.accountSearchData.acntNoteOrgSys = this.origSystemsX;
    this.accountSearchData.emaor = this.emaorState;
    this.accountSearchData.accountDetailIndia = this.accountLevelState;
    if (this.customerNameX.trim() == "" && this.fanX.trim() == "" && this.svidX.trim() == "" && this.accountsX.trim() == "" && this.origSystemsX.trim() == "") {
      this.toastr.error('', 'Please populate any one of the search field!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    this.viewUpdateService.searchAccount(this.accountSearchData).subscribe((data: any) => {
      this.rowData = data.searchAccounts;
      this.columnDefs = this.columnDefsAcc;
      this.showAccountsGrid = true;



    });
  }

  gridOptions: GridOptions = {
    onCellDoubleClicked: (
      event: CellDoubleClickedEvent
    ) => this.addModifyContact("Modify", this.gridRowData1)
  }

  getContextMenuItems1 = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [
      {
        name: 'Add Contact',
        action: () => {
          this.addModifyContact("Add", this.gridRowData1);
        }
      }, {
        name: 'Modify Contact',
        action: () => {
          this.addModifyContact("Modify", this.gridRowData1)
        }
      }, {
        name: 'Delete Contact',
        action: () => {
          this.deleteACustomer();
        },
      },
      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  getContextMenuItems2 = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [
      //       {
      //         name: 'Add Contact',
      //         action: () => {
      // //          this.addModifyContact("Add", this.currRowData);
      //         }
      //       }, {
      //         name: 'Modify Contact',
      //         action: () => {
      //   //        this.addModifyContact("Modify",this.currRowData)
      //         }
      //       }, {
      //         name: 'Delete Contact',
      //         action: () => {
      //     //      this.deleteACustomer();
      //         },
      //       },
      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  gridRowData2: any;
  onRowClicked2(event: any) {
    this.gridRowData2 = event.data;
  }

  gridApi2: any;
  onGridReady2(params: any) {
    this.gridApi2 = params.api;
  }

  gridRowData1: any;
  onRowClicked1(event: any) {
    this.gridRowData1 = event.data;
  }

  gridApi1: any;
  onGridReady1(params: any) {
    this.gridApi1 = params.api;
  }


  columnDefsAcc: ColDef[] = [

    {
      headerName: 'AcctNmbr', field: 'account_number',
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      checkboxSelection: true, width: 150, resizable: true
    },
    { headerName: 'FAN', field: 'zbu', resizable: true, width: 100 },
    { headerName: 'SVID', field: 'svid', resizable: true, width: 100 },
    { headerName: 'Customer', field: 'customer_name', resizable: true, width: 150 },
    { headerName: 'System', field: 'originating_system', resizable: true, width: 100 },
    { headerName: 'CustomerID', field: 'customer_grp_cd', resizable: true, width: 100 },
  ];

  columnDefsGrid2: ColDef[] = [
    {
      headerName: 'Contact', field: 'contact',
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      checkboxSelection: true, width: 350, resizable: true
    },
    { headerName: 'ID', field: 'contacts_id', width: 100, resizable: true },
  ];

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;


  closeModal() {
    this.dialogRef.close({ msg: "cancelled" });
  }

  chkHQ: boolean = false;
  chkES: boolean = false;
  chkALS: boolean = false;
  clearSearch() {
    this.firstName = "";
    this.lastName = "";
    this.phoneNumber = "";
    this.email = "";
    this.chkHQ = false;
    this.customerNameX = "";
    this.fanX = "";
    this.svidX = "";
    this.accountsX = "";
    this.origSystemsX = "";
    this.chkES = false;
    this.chkALS = false;
    this.columnDefsGrid1 = this.columnDefsGrid2;
    this.rowDataGrid1 = [];
    this.showContactsGrid = true;
    this.rowData = [];
    this.columnDefs = this.columnDefsAcc;
    this.showAccountsGrid = true;
    //this.searchContacts();
    //this.searchAccounts();
  }

  inputAssignContact: any = {};
  assignContact() {

    if (this.gridApi1 == undefined || this.gridApi1 == null || this.gridApi1 == "") {
      this.toastr.error('', 'Contacts : Please select the contact/contacts to be assigned!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedNodes1 = this.gridApi1.getSelectedNodes();
    let selectedData1 = selectedNodes1.map((node: any) => node.data);
    if (!selectedData1[0]) {
      this.toastr.error('', 'Contacts : Please select the contact/contacts to be assigned!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedContactID = selectedData1[0].contacts_id;
    let selectedContactIDArray = selectedData1.map((e: any) => { return e.contacts_id });

    let selectedNodes2 = this.gridApi2.getSelectedNodes();
    let selectedData2 = selectedNodes2.map((node: any) => node.data);
    if (!selectedData2[0]) {
      this.toastr.error('', 'Accounts : Please select the Account/Accounts to assigned!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedAccNumber = selectedData2[0].account_number;
    let selectedAccNumberArray = selectedData2.map((e: any) => { return e.account_number });

    let selectedFan = selectedData2[0].zbu;
    let selectedFanArray = selectedData2.map((e: any) => { return e.zbu });


    let selectedSVID = selectedData2[0].svid;
    let selectedSVIDArray = selectedData2.map((e: any) => { return e.svid });


    let selectedcustomerGrpCd = selectedData2[0].customer_grp_cd;
    let selectedcustomerGrpCdArray = selectedData2.map((e: any) => { return e.customer_grp_cd });


    let selectedAcntNoteOrgSys = selectedData2[0].originating_system;
    let selectedAcntNoteOrgSysArray = selectedData2.map((e: any) => { return e.originating_system });

    this.inputAssignContact.contacts_id_lst = selectedContactID;
    this.inputAssignContact.accountNumber = selectedAccNumber;
    this.inputAssignContact.fan = selectedFan;
    this.inputAssignContact.svid = selectedSVID;
    this.inputAssignContact.customerGrpCd = selectedcustomerGrpCd;
    this.inputAssignContact.acntNoteOrgSys = selectedAcntNoteOrgSys;
    //console.log(this.inputAssignContact)
    this.viewUpdateService.contactAssign(this.inputAssignContact).subscribe((data: any) => {
      //console.log(data.contactAssign[0][0]);
      if (data.contactAssign[0][0] == "Assignment Completed") {
        this.inputAssignContact = {};
        this.searchContacts();
        this.toastr.success('', 'Contacts : Assignment Completed!', {
          timeOut: 5000, closeButton: true
        });
      }
    },
      (error: any) => {
        console.log(error);
        this.toastr.error('', 'Contacts : Assignment Failed! Please try again later', {
          timeOut: 5000, closeButton: true
        });
      });
  }


  inputUnAssignContact: any = {};
  UnAssignContact() {
    if (this.gridApi1 == undefined || this.gridApi1 == null || this.gridApi1 == "") {
      this.toastr.error('', 'Contacts : Please select the contact/contacts to be assigned!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedNodes1 = this.gridApi1.getSelectedNodes();
    let selectedData1 = selectedNodes1.map((node: any) => node.data);
    if (!selectedData1[0]) {
      this.toastr.error('', 'Contacts : Please select the contact/contacts to be assigned!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedContactID = selectedData1[0].contacts_id;
    let selectedContactIDArray = selectedData1.map((e: any) => { return e.contacts_id });

    let selectedNodes2 = this.gridApi2.getSelectedNodes();
    let selectedData2 = selectedNodes2.map((node: any) => node.data);
    if (!selectedData2[0]) {
      this.toastr.error('', 'Accounts : Please select the Account/Accounts to assigned!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedAccNumber = selectedData2[0].account_number;
    let selectedAccNumberArray = selectedData2.map((e: any) => { return e.account_number });

    let selectedFan = selectedData2[0].zbu;
    let selectedFanArray = selectedData2.map((e: any) => { return e.zbu });


    let selectedSVID = selectedData2[0].svid;
    let selectedSVIDArray = selectedData2.map((e: any) => { return e.svid });


    let selectedcustomerGrpCd = selectedData2[0].customer_grp_cd;
    let selectedcustomerGrpCdArray = selectedData2.map((e: any) => { return e.customer_grp_cd });


    let selectedAcntNoteOrgSys = selectedData2[0].originating_system;
    let selectedAcntNoteOrgSysArray = selectedData2.map((e: any) => { return e.originating_system });

    this.inputUnAssignContact.contacts_id_lst = selectedContactID;
    this.inputUnAssignContact.accountNumber = selectedAccNumber;
    this.inputUnAssignContact.fan = selectedFan;
    this.inputUnAssignContact.svid = selectedSVID;
    this.inputUnAssignContact.customerGrpCd = selectedcustomerGrpCd;
    this.inputUnAssignContact.acntNoteOrgSys = selectedAcntNoteOrgSys;
    //console.log(this.inputUnAssignContact)
    this.viewUpdateService.contactUnAssign(this.inputUnAssignContact).subscribe((data: any) => {
      //console.log(data.contactUnAssign[0][0]);
      if (data.contactUnAssign[0][0] == "Unassign Completed") {
        this.inputUnAssignContact = {};
        this.searchContacts();
        this.toastr.success('', 'Contacts : Unassign Completed!', {
          timeOut: 5000, closeButton: true
        });
      }
    },
      (error: any) => {
        console.log(error);
        this.toastr.error('', 'Contacts : Unassign Failed! Please try again later', {
          timeOut: 5000, closeButton: true
        });
      });
  }


  addModifyContact(Mode: string, currRD: any) {

    let selectedNodes1 = this.gridApi1.getSelectedNodes();
    let selectedData1 = selectedNodes1.map((node: any) => node.data);
    if (!selectedData1[0]) {
      this.toastr.error('', 'Contacts : Please select the contact/contacts!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedContactID = selectedData1[0].contacts_id;

    let selectedNodes2 = this.gridApi2.getSelectedNodes();
    let selectedData2 = selectedNodes2.map((node: any) => node.data);
    if (!selectedData2[0]) {
      this.toastr.error('', 'Accounts : Please select the Account/Accounts!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedAccNumber = selectedData2[0].account_number;
    let selectedFan = selectedData2[0].zbu;
    let selectedSVID = selectedData2[0].svid;
    let selectedcustomerGrpCd = selectedData2[0].customer_grp_cd;
    let selectedAcntNoteOrgSys = selectedData2[0].originating_system;
    let confirmNum = '';


    if (Mode == "Add") {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.id = "Update-Contacts";
      dialogConfig.height = "90%";
      dialogConfig.width = "100%";
      dialogConfig.data = {
        Mode: Mode,
        currRD: this.gridRowData1,
        contacts_id_lst: selectedContactID,
        confirmNum: confirmNum,
        accountNumber: selectedAccNumber,
        svid: selectedSVID,
        fan: selectedFan,
        customerGrpCd: selectedcustomerGrpCd,
        acntNoteOrgSys: selectedAcntNoteOrgSys
      }
      const modalDialog = this.matDialog.open(ContactsUpdateComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {
        if (res.msg == "success") {
          this.searchContacts();
        }
        else if (res.msg == "cancelled") {
          this.searchContacts();
        }
      })
    }
    else {
      if (currRD != undefined && currRD != null && currRD != "") {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.id = "Update-Contacts";
        dialogConfig.height = "90%";
        dialogConfig.width = "100%";
        dialogConfig.data = {
          Mode: Mode,
          currRD: this.gridRowData1,
          contacts_id_lst: selectedContactID,
          confirmNum: '',
          accountNumber: selectedAccNumber,
          svid: selectedSVID,
          fan: selectedFan,
          customerGrpCd: selectedcustomerGrpCd,
          acntNoteOrgSys: selectedAcntNoteOrgSys
        }
        const modalDialog = this.matDialog.open(ContactsUpdateComponent, dialogConfig);
        modalDialog.afterClosed().subscribe((res: any) => {
          if (res.msg == "success") {
            this.searchContacts();
          }
          else if (res.msg == "cancelled") {
            this.searchContacts();
          }
        })
      }
      else {
        this.toastr.error('', 'Contacts : Please Select a Note to ' + Mode + '!', {
          timeOut: 5000, closeButton: true
        });
      }
    }
  }

  deleteContactJson: any = {};

  deleteACustomer() {
    let selectedNodes1 = this.gridApi1.getSelectedNodes();
    let selectedData1 = selectedNodes1.map((node: any) => node.data);
    if (!selectedData1[0]) {
      this.toastr.error('', 'Contacts : Please select the contact/contacts to be deleted!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    this.deleteContactJson.contactid = selectedData1[0].contacts_id;
    this.viewUpdateService.deleteViewUpdateContact(this.deleteContactJson).subscribe((data: any) => {
      if (data.msg == "success") {
        this.deleteContactJson = {};
        this.searchContacts();
        this.toastr.success('', 'Contacts : Selected contact deleted!', {
          timeOut: 5000, closeButton: true
        });
      }
    },
      (error: any) => {
        console.log(error);
        this.toastr.error('', 'Contacts : Unable to delete contact! Please try again later', {
          timeOut: 5000, closeButton: true
        });
      });
  }

  displayAcc: any = {};
  displayCntct: any = {};
  selectedCntct: any = [];
  selectedAccnt: any = [];
  svidArr: any = [];
  fanArr: any = [];
  CGLArr: any = [];
  OSArr: any = [];
  DisplayWhereContactsAssigned() {
    this.displayAcc = {};
    this.selectedCntct = [];
    if (this.gridApi1 == undefined || this.gridApi1 == null || this.gridApi1 == "") {
      this.toastr.error('', 'Please select the contact/contacts!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedNodes1 = this.gridApi1.getSelectedNodes();
    let selectedData1 = selectedNodes1.map((node: any) => node.data);
    if (!selectedData1[0]) {
      this.toastr.error('', 'Please select the contact/contacts!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    //console.log(selectedData1[0].contacts_id)
    for (let i = 0; i < selectedData1.length; i++) {
      this.selectedCntct.push(selectedData1[i].contacts_id.toString());
    }
    //console.log(this.selectedCntct)
    this.displayAcc.contactsIdLst = this.selectedCntct;
    this.displayAcc.emaor = "N";
    this.viewUpdateService.DisplayAccounts(this.displayAcc).subscribe((data: any) => {
      this.rowData = data.accountDisplay;
      this.columnDefs = this.columnDefsAcc;
      this.showAccountsGrid = true;
      this.displayAcc = {};
      this.selectedCntct = [];
    },
      (error: any) => {
        console.log(error);
        this.displayAcc = {};
        this.selectedCntct = [];
        this.toastr.error('', 'Unable to display accounts! Please try again later', {
          timeOut: 5000, closeButton: true
        });
      });
  }

  chkAcctsOnly: boolean = false;
  DisplayAssociatedContacts() {
    this.displayCntct = {};
    this.selectedAccnt = [];
    this.svidArr = [];
    this.fanArr = [];
    this.CGLArr = [];
    this.OSArr = [];
    let selectedNodes2 = this.gridApi2.getSelectedNodes();
    let selectedData2 = selectedNodes2.map((node: any) => node.data);
    if (!selectedData2[0]) {
      this.toastr.error('', 'Please select the account/accounts!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    //console.log(selectedData2[0].account_number)
    for (let i = 0; i < selectedData2.length; i++) {
      this.selectedAccnt.push(selectedData2[i].account_number.toString());
    }
    for (let i = 0; i < selectedData2.length; i++) {
      if (selectedData2[i].svid) {
        this.svidArr.push(selectedData2[i].svid.toString());
      }
    }
    for (let i = 0; i < selectedData2.length; i++) {
      if (selectedData2[i].zbu) {
        this.fanArr.push(selectedData2[i].zbu.toString());
      }
    }
    for (let i = 0; i < selectedData2.length; i++) {
      if (selectedData2[i].customer_grp_cd) {
        this.CGLArr.push(selectedData2[i].customer_grp_cd.toString());
      }
    }
    for (let i = 0; i < selectedData2.length; i++) {
      if (selectedData2[i].originating_system) {
        this.OSArr.push(selectedData2[i].originating_system.toString());
      }
    }
    //console.log(this.selectedCntct)
    this.displayCntct.selectedAccountNumbers = this.selectedAccnt;
    this.displayCntct.fan = this.fanArr;
    this.displayCntct.svid = this.svidArr;
    this.displayCntct.customerGroupList = this.CGLArr;
    this.displayCntct.originatingSystem = this.OSArr;
    this.displayCntct.acctLvl = this.chkAcctsOnly == true ? "Y" : "N";
    this.displayCntct.emaor = "N"
    this.viewUpdateService.DisplayContacts(this.displayCntct).subscribe((data: any) => {
      this.columnDefsGrid1 = this.columnDefsGrid2;
      this.rowDataGrid1 = data.displayContacts;
      this.showContactsGrid = true;
      this.displayCntct = {};
      this.selectedAccnt = [];
      this.svidArr = [];
      this.fanArr = [];
      this.CGLArr = [];
      this.OSArr = [];
    },
      (error: any) => {
        this.displayCntct = {};
        this.selectedAccnt = [];
        this.svidArr = [];
        this.fanArr = [];
        this.CGLArr = [];
        this.OSArr = [];
        console.log(error);
        this.toastr.error('', 'Unable to display associated contacts! Please try again later', {
          timeOut: 5000, closeButton: true
        });
      });
  }

  DisplayWhereEMAORAssigned() {
    this.displayAcc = {};
    this.selectedCntct = [];
    if (this.gridApi1 == undefined || this.gridApi1 == null || this.gridApi1 == "") {
      this.toastr.error('', 'Please select the contact/contacts!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    let selectedNodes1 = this.gridApi1.getSelectedNodes();
    let selectedData1 = selectedNodes1.map((node: any) => node.data);
    if (!selectedData1[0]) {
      this.toastr.error('', 'Please select the contact/contacts!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    //console.log(selectedData1[0].contacts_id)
    for (let i = 0; i < selectedData1.length; i++) {
      this.selectedCntct.push(selectedData1[i].contacts_id.toString());
    }
    //console.log(this.selectedCntct)
    this.displayAcc.contactsIdLst = this.selectedCntct;
    this.displayAcc.emaor = "Y";
    this.viewUpdateService.DisplayAccounts(this.displayAcc).subscribe((data: any) => {
      this.rowData = data.accountDisplay;
      this.columnDefs = this.columnDefsAcc;
      this.showAccountsGrid = true;
      this.displayAcc = {};
      this.selectedCntct = [];
    },
      (error: any) => {
        console.log(error);
        this.displayAcc = {};
        this.selectedCntct = [];
        this.toastr.error('', 'Unable to display EMAORs! Please try again later', {
          timeOut: 5000, closeButton: true
        });
      });
  }

  DisplayAssociatedEMAORs() {
    this.displayCntct = {};
    this.selectedAccnt = [];
    this.svidArr = [];
    this.fanArr = [];
    this.CGLArr = [];
    this.OSArr = [];
    let selectedNodes2 = this.gridApi2.getSelectedNodes();
    let selectedData2 = selectedNodes2.map((node: any) => node.data);
    if (!selectedData2[0]) {
      this.toastr.error('', 'Please select the account/accounts!', {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    //console.log(selectedData2[0].account_number)
    for (let i = 0; i < selectedData2.length; i++) {
      this.selectedAccnt.push(selectedData2[i].account_number.toString());
    }
    for (let i = 0; i < selectedData2.length; i++) {
      if (selectedData2[i].svid) {
        this.svidArr.push(selectedData2[i].svid.toString());
      }
    }
    for (let i = 0; i < selectedData2.length; i++) {
      if (selectedData2[i].zbu) {
        this.fanArr.push(selectedData2[i].zbu.toString());
      }
    }
    for (let i = 0; i < selectedData2.length; i++) {
      if (selectedData2[i].customer_grp_cd) {
        this.CGLArr.push(selectedData2[i].customer_grp_cd.toString());
      }
    }
    for (let i = 0; i < selectedData2.length; i++) {
      if (selectedData2[i].originating_system) {
        this.OSArr.push(selectedData2[i].originating_system.toString());
      }
    }
    //console.log(this.selectedCntct)
    this.displayCntct.selectedAccountNumbers = this.selectedAccnt;
    this.displayCntct.fan = this.fanArr;
    this.displayCntct.svid = this.svidArr;
    this.displayCntct.customerGroupList = this.CGLArr;
    this.displayCntct.originatingSystem = this.OSArr;
    this.displayCntct.acctLvl = ""
    this.displayCntct.emaor = "Y"
    this.viewUpdateService.DisplayContacts(this.displayCntct).subscribe((data: any) => {
      this.columnDefsGrid1 = this.columnDefsGrid2;
      this.rowDataGrid1 = data.displayContacts;
      this.showContactsGrid = true;
      this.displayCntct = {};
      this.selectedAccnt = [];
      this.svidArr = [];
      this.fanArr = [];
      this.CGLArr = [];
      this.OSArr = [];
    },
      (error: any) => {
        this.displayCntct = {};
        this.selectedAccnt = [];
        this.svidArr = [];
        this.fanArr = [];
        this.CGLArr = [];
        this.OSArr = [];
        console.log(error);
        this.toastr.error('', 'Unable to display associated contacts! Please try again later', {
          timeOut: 5000, closeButton: true
        });
      });
  }

}

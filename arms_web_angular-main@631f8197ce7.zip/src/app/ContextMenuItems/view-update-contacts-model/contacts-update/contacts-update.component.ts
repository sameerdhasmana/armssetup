import { AfterViewInit, Component, Inject, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ViewUpdateContactsService } from 'src/app/services/view-update-contacts.service';
import { GeneralUiFunctionsService } from 'src/app/services/general-ui-functions.service';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-contacts-update',
  templateUrl: './contacts-update.component.html',
  styleUrls: ['./contacts-update.component.scss']
})
export class ContactsUpdateComponent implements OnInit {

  CtctInfFirstName: any;
  CtctInfLastName: any;
  CtctInfTitle: any;
  CtctInfPhone: any;
  CtctInfPhoneExt: any;
  CtctInfSecondaryTN: any;
  CtctInfAddress: any;
  CtctInfFax: any;
  CtctInfExt: any;
  CtctInfEmail: any;
  CtctInfSecEmail: any;
  CtctInfCity: any;
  CtctInfState: any;
  CtctInfZip: any;
  CntctInfNotes: any;
  CtctInfEMAORDt: any;
  EMAORDt: any;
  chkheadquarter: any;

  form: any = new FormGroup({
    CtctInfFirstName: new FormControl({ value: "", disabled: false }),
    CtctInfLastName: new FormControl({ value: "", disabled: false }),
    CtctInfTitle: new FormControl({ value: "", disabled: false }),
    CtctInfPhone: new FormControl({ value: "", disabled: false }),
    CtctInfSecondaryTN: new FormControl({ value: "", disabled: false }),
    CtctInfAddress: new FormControl({ value: "", disabled: false }),
    CtctInfCity: new FormControl({ value: "", disabled: false }),
    CtctInfState: new FormControl({ value: "", disabled: false }),
    CtctInfZip: new FormControl({ value: "", disabled: false }),
    CtctInfFax: new FormControl({ value: "", disabled: false }),
    CtctInfExt: new FormControl({ value: "", disabled: false }),
    CtctInfPhoneExt: new FormControl({ value: "", disabled: false }),
    rdbCntctInfEMAOR: new FormControl({ value: "", disabled: false }),
    rdbCntctInfPrimary: new FormControl({ value: "", disabled: false }),
    CtctInfEmail: new FormControl({ value: "", disabled: false }),
    CtctInfSecEmail: new FormControl({ value: "", disabled: false }),
    CntctInfNotes: new FormControl({ value: "", disabled: false }),
    CtctInfEMAORDt: new FormControl({ value: "", disabled: false }),
    headquarter: new FormControl({ value: "", disabled: false })
  })


  Mode: any;
  currRD: any;
  contacts_id_lst: any;
  confirmNum: any;
  accountNumber: any;
  svid: any;
  fan: any;
  customerGrpCd: any;
  acntNoteOrgSys: any;

  constructor(
    public dialogRef: MatDialogRef<ContactsUpdateComponent>,
    private toastr: ToastrService,
    private viewUpdateService: ViewUpdateContactsService,
    private _generalUiFnService: GeneralUiFunctionsService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.Mode = data.Mode,
      this.currRD = data.currRD,
      this.contacts_id_lst = data.contacts_id_lst,
      this.confirmNum = data.confirmNum,
      this.accountNumber = data.accountNumber,
      this.svid = data.svid,
      this.fan = data.fan,
      this.customerGrpCd = data.customerGrpCd,
      this.acntNoteOrgSys = data.acntNoteOrgSys
  }
  fetchContactData: any;
  inputFetchData: any = {};
  contactIdArr: any = [];
  svidArr: any = [];
  FanArr: any = [];
  ngOnInit(): void {

    if (this.Mode != "Add") {
      this.contactIdArr.push(this.contacts_id_lst.toString());
      this.svidArr.push(this.svid);
      this.FanArr.push(this.fan);
      this.inputFetchData.contactsIdLst = this.contactIdArr;
      this.inputFetchData.confirmNum = this.confirmNum;
      this.inputFetchData.accountNumber = this.accountNumber;
      this.inputFetchData.svid = this.svidArr;
      this.inputFetchData.fan = this.FanArr;
      this.inputFetchData.customerGrpCd = this.customerGrpCd;
      this.inputFetchData.acntNoteOrgSys = this.acntNoteOrgSys;
      //console.log(this.inputFetchData);
      this.viewUpdateService.fetchContact(this.inputFetchData).subscribe((data: any) => {
        //console.log(data.fetchContact[0]);
        this.fetchContactData = data.fetchContact[0];
        this.fnFetchData(data.fetchContact[0]);
      });

    }
  }

  fnFetchData(fetchData: any) {
    if (this.Mode != "Add") {
      this.CtctInfFirstName = fetchData.firstName
      this.CtctInfLastName = fetchData.lastName
      this.CtctInfTitle = fetchData.title
      this.CtctInfPhone = fetchData.phone
      this.CtctInfPhoneExt = fetchData.extension
      this.CtctInfSecondaryTN = fetchData.phone2
      this.CtctInfAddress = fetchData.address
      this.CtctInfFax = fetchData.faxNumber
      this.CtctInfExt = fetchData.extension2
      this.CtctInfEmail = fetchData.email
      this.CtctInfSecEmail = fetchData.email2
      this.CtctInfCity = fetchData.city
      this.CtctInfState = fetchData.state
      this.CtctInfZip = fetchData.zip
      this.CntctInfNotes = fetchData.notes
      this.chkheadquarter = fetchData.headQtrs == null || fetchData.headQtrs == undefined || fetchData.headQtrs == "N" ? "" : fetchData.headQtrs
    }
  }

  ngAfterViewInit(): void { }

  saveAccountNotes: any = {}
  customerGrpList: any = [];
  saveModal() {

    const datepipe: DatePipe = new DatePipe('en-US')
    let EmaorEffDate = datepipe.transform(this.CtctInfEMAORDt, 'MM/dd/YYYY');

    this.saveAccountNotes.firstName = this.CtctInfFirstName;
    this.saveAccountNotes.lastName = this.CtctInfLastName;
    this.saveAccountNotes.address = this.CtctInfAddress;
    this.saveAccountNotes.city = this.CtctInfCity;
    this.saveAccountNotes.state = this.CtctInfState;
    this.saveAccountNotes.zip = this.CtctInfZip;
    this.saveAccountNotes.title = this.CtctInfTitle;
    this.saveAccountNotes.phoneNumber = this.CtctInfPhone;
    this.saveAccountNotes.extension = this.CtctInfPhoneExt;
    this.saveAccountNotes.phoneNumber2 = this.CtctInfSecondaryTN;
    this.saveAccountNotes.extension2 = this.CtctInfExt;
    this.saveAccountNotes.faxNumber = this.CtctInfFax;
    this.saveAccountNotes.email = this.CtctInfEmail;
    this.saveAccountNotes.email2 = this.CtctInfSecEmail;
    this.saveAccountNotes.notes = this.CntctInfNotes;
    this.saveAccountNotes.contacts_id_lst = this.contacts_id_lst;
    this.saveAccountNotes.headquaters = this.form.controls['headquarter'].value == true ? "Y" : "N";
    this.saveAccountNotes.emaor = this.form.controls['rdbCntctInfEMAOR'].value;
    this.saveAccountNotes.emaorPrimary = this.form.controls['rdbCntctInfPrimary'].value;
    this.saveAccountNotes.emaorEffDate = EmaorEffDate?.toString();
    this.saveAccountNotes.columnid = this.confirmNum;
    this.saveAccountNotes.accountNumber = this.accountNumber;
    this.saveAccountNotes.acctInvFan = this.fan;
    this.saveAccountNotes.serviceId = this.svid;
    this.customerGrpList = [];
    this.customerGrpList.push(this.customerGrpCd);
    this.saveAccountNotes.customerGroupList = this.customerGrpList;
    this.saveAccountNotes.acntNoteOrgSys = this.acntNoteOrgSys;
    //console.log(this.saveAccountNotes);
    this.viewUpdateService.saveViewUpdateContact(this.saveAccountNotes).subscribe((data: any) => {
      if (data.msg == "success") {
        this.saveAccountNotes = {};
        this.toastr.success('', 'Contact Saved Succesfully!', {
          timeOut: 5000, closeButton: true
        });
        this.dialogRef.close({ msg: 'success' });
      }
    }, (error: any) => {
      if (error.error.errorMsg == "Please select the necessary inputs") {
        this.saveAccountNotes = {};
        this.toastr.error('', 'Contact : ' + error.error.errorMsg, {
          timeOut: 5000, closeButton: true
        });
      }
      else {
        console.log(error);
        this.saveAccountNotes = {};
        this.toastr.error('', 'Contact : Unable to save the Note. Please try again later!', {
          timeOut: 5000, closeButton: true
        });
      }
    });
  }

  closeModal() {
    this.dialogRef.close({ msg: 'cancelled' });
  }

  allowOnlyNumbersWithSlash(event: any) {
    return this._generalUiFnService.allowOnlyNumbersWithSlash(event);
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewUpdateContactsModelComponent } from './view-update-contacts-model.component';

describe('ViewUpdateContactsModelComponent', () => {
  let component: ViewUpdateContactsModelComponent;
  let fixture: ComponentFixture<ViewUpdateContactsModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewUpdateContactsModelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewUpdateContactsModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

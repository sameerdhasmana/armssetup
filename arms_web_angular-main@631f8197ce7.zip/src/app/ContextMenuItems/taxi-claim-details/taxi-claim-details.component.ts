import { Component, Inject, OnInit,ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams,  MenuItemDef } from 'ag-grid-enterprise';
import { PrimeNGConfig } from 'primeng/api';
import { SearchService } from 'src/app/services/search.service';

@Component({
  selector: 'app-taxi-claim-details',
  templateUrl: './taxi-claim-details.component.html',
  styleUrls: ['./taxi-claim-details.component.scss']
})
export class TaxiClaimDetailsComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  accountNumberGrid:any;
  acntNoteOrgSys :any;
  defaultExcelExportParams: any;
  rowData: any =[];
  columnDefs: any;
  pageSize: number = 30;
  defaultColDef: ColDef = {
    resizable: true,

  };

  constructor(
    public dialogRef: MatDialogRef<TaxiClaimDetailsComponent>,
    private searchService :SearchService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.accountNumberGrid = data.accountNumber;
    this.acntNoteOrgSys = data.acntNoteOrgSys;
  }


  inputData:any={};
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }
  ngOnInit(): void {
    this.defaultExcelExportParams = {
      fileName:
        'AllClaimsAccountDetails-' + this.accountNumberGrid + '-' + Date(),
    };
    this.inputData.accountNumber = this.accountNumberGrid;
    this.inputData.acntNoteOrgSys =  this.acntNoteOrgSys;
    this.primengConfig.ripple = true;
    this.searchService.taxiClaimDetails(this.inputData).subscribe((data: any) => {
      this.columnDefs = this.columnDefsTC;
      this.rowData = data.taxiClaimDetails;
    });
  }
  columnDefsTC: ColDef[] = [
     { headerName: 'AT&T Claim #', field: 'attClaim'},
     { headerName: 'WorkedBy', field: 'workedBy'},
     { headerName: 'Bill Date', field: 'billDate'},
     { headerName: 'CustClaim', field: 'custClaimNo'},
     { headerName: 'Input', field: 'input'},
     { headerName: 'Received', field: 'received'},
     { headerName: 'Acknowledge', field: 'acknowledge'},
     { headerName: 'FollowUp', field: 'followUp'},
     { headerName: 'Referred', field: 'referred'},
     { headerName: 'Referred To', field: 'referredTo'},
     { headerName: '$Claimed', field: 'claimed',aggFunc: 'sum',type: 'rightAligned',},
     { headerName: '$dj Non SO', field: 'adjNonSO',aggFunc: 'sum',type: 'rightAligned'},
     { headerName: '$Adj SO', field: 'adjSO',aggFunc: 'sum',type: 'rightAligned'},
     { headerName: '$Paid Back', field: 'paidBack',aggFunc: 'sum',type: 'rightAligned'},
     { headerName: '$Denied', field: 'denied',aggFunc: 'sum',type: 'rightAligned'},
     { headerName: '$Short Paid', field: 'shortPaid',aggFunc: 'sum',type: 'rightAligned'},
     { headerName: '$Balance', field: 'balance',aggFunc: 'sum',type: 'rightAligned'},
     { headerName: 'Reject', field: 'rejectInd'},
     { headerName: 'Jeopord', field: 'jeopardyInd'},
     { headerName: 'PM', field: 'pmProjectInd'},
     { headerName: 'Audit #', field: 'audit'},
     { headerName: 'Ticket #', field: 'ticket'}

  ];
  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  overlayLoadingTemplate =
  `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
overlayNoRowsTemplate =
  `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

 closeModal(){
  this.dialogRef.close({ msg: 'success' });
 }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxiClaimDetailsComponent } from './taxi-claim-details.component';

describe('TaxiClaimDetailsComponent', () => {
  let component: TaxiClaimDetailsComponent;
  let fixture: ComponentFixture<TaxiClaimDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TaxiClaimDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxiClaimDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountNotesHistoryComponent } from './account-notes-history.component';

describe('AccountNotesHistoryComponent', () => {
  let component: AccountNotesHistoryComponent;
  let fixture: ComponentFixture<AccountNotesHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountNotesHistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountNotesHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

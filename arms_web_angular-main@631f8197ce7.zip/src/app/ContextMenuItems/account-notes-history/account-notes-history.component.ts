import {  Component, Inject, OnInit,ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams, ITooltipParams, MenuItemDef, ValueFormatterParams } from 'ag-grid-enterprise';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PrimeNGConfig } from 'primeng/api';
import { AccountNotesService } from 'src/app/services/accountNotes.service';
import { HoveringHeadersComponent } from '../hovering-headers/hovering-headers.component';


@Component({
  selector: 'app-account-notes-history',
  templateUrl: './account-notes-history.component.html',
  styleUrls: ['./account-notes-history.component.scss']
})
export class AccountNotesHistoryComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  parentRowData :any;
  selectedAccountNumber:any;
  originatingSystem :any;
  rowData: any;
  columnDefs: any;
  shwNotesGrid: boolean = false;
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
   // flex: 1,
    //minWidth: 100,
    resizable: true,
  }


  constructor(
    public dialogRef: MatDialogRef<AccountNotesHistoryComponent>,
    private toastr: ToastrService,
    private accountNotes :AccountNotesService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.parentRowData = data.currRowData;
    this.selectedAccountNumber = data.selectedAccountNumber;
    this.originatingSystem = data.originatingSystem;
  }

  inputData:any={};
  defaultExcelExportParams:any;
  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.inputData.accountNumber =  this.selectedAccountNumber;
    this.inputData.acntNoteOrgSys =  this.originatingSystem;
    this.accountNotes.accountNoteHistory(this.inputData).subscribe((data: any) => {
      this.rowData = data.AccountNotesHistory;
      this.columnDefs = this.columnDefsANH;
    });
    this.defaultExcelExportParams = {
      fileName:
        'AccountNotesHistory-' + this.selectedAccountNumber + '-' + Date(),
    };
  }
  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  columnDefsANH: ColDef[] = [
    { headerName: 'Resolved', field: 'resolved', editable:false,
    cellRenderer: (params:any) => {
      return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;}
    },
     { headerName: 'Note ID', field: 'notesId'},
     { headerName: 'Account Nbr', field: 'acctNbr'},
     { headerName: 'Billing Period', field: 'billingPeriod'},
     { headerName: 'Commitment Amt', field: 'commitmentAmount',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }
    },
     { headerName: 'Talked To', field: 'talkedTo'},
     { headerName: 'Notes', field: 'notes',resizable:true,
     tooltipComponent: HoveringHeadersComponent,
     tooltipValueGetter: toolTipValueGetter
   },
     { headerName: 'BringUp Dt', field: 'bringUpDate'},
     { headerName: 'UserID', field: 'userLoginCd'},
     { headerName: 'Logged By', field: 'loggedBy'},
     { headerName: 'Inserted', field: 'insertDate'},
     { headerName: 'System', field: 'system'}
    ];

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

   closeModal(){
     this.dialogRef.close();
   }

}

const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});
function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AifModalComponent } from './aif-modal.component';

describe('AifModalComponent', () => {
  let component: AifModalComponent;
  let fixture: ComponentFixture<AifModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AifModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AifModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

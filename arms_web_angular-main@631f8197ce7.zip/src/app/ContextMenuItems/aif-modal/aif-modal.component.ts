import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SharedService } from 'src/app/services/shared.service';
import { ToastrService } from 'ngx-toastr';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import {
  ColDef,
  GetContextMenuItemsParams,
  MenuItemDef,
} from 'ag-grid-enterprise';
import { filter } from 'rxjs';

@Component({
  selector: 'app-aif-modal',
  templateUrl: './aif-modal.component.html',
  styleUrls: ['./aif-modal.component.scss'],
})
export class AifModalComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  rowData: any;
  columnDefs: any;
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    flex: 1,
    minWidth: 100,
    width: 200,
    resizable: true,
  };
  selectedDropdown:any;
  selectedDropdownText:any;

  constructor(
    public dialogRef: MatDialogRef<AifModalComponent>,
    private sharedService: SharedService,
    private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.rowData = this.data.dialogResult;
    this.columnDefs = this.columnDefsAIF;
    this.selectedDropdown = this.data.selectedDropdown;
    if(this.data.selectedDropdown  === 'account'){
    this.selectedDropdownText = 'The Account Number '
    } else if(this.data.selectedDropdown  === 'invoice'){
      this.selectedDropdownText = 'The Invoice Number '
    } else if(this.data.selectedDropdown  === 'FAN'){
      this.selectedDropdownText = 'The Foundation Account Number '
    }
  }

  ngOnInit(): void {}

  doubleClickEvent(event:any){
    console.log("DoubleClicked Event---AIF Modal"+event);
    this.submit()
  }

  submit() {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let group = selectedData[0].group;
    let billingPeriod = selectedData[0].billing_period;
    let originatingSystem = '';
    let filters: any = {};
    filters.billingPeriod = billingPeriod;
    filters.groupSelected = group;
    filters.originatingSystem = originatingSystem;
    this.sharedService.setModalData(filters);
    this.dialogRef.close({ msg: 'success' });
    this.toastr.success('', 'Business Group and Billing Period were Modified Successfully!', {
      timeOut: 5000, closeButton: true
    });

  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = ['copy', 'copyWithHeaders', 'export'];
    return result;
  };

  columnDefsAIF: ColDef[] = [
    { headerName: 'Group', field: 'group' },
    { headerName: 'Billing Period', field: 'billing_period' },
    { headerName: 'System', field: 'originating_system' },
  ];

  overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
  overlayNoRowsTemplate = `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

  closeModal() {
    this.dialogRef.close({ msg: "cancelled" });
  }
}

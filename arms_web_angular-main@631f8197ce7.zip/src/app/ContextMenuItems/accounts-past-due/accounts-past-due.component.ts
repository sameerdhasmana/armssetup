import { Component, Inject, OnInit,ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams,  MenuItemDef, ValueFormatterParams } from 'ag-grid-enterprise';
import { PrimeNGConfig } from 'primeng/api';
import { SearchService } from 'src/app/services/search.service';


@Component({
  selector: 'app-accounts-past-due',
  templateUrl: './accounts-past-due.component.html',
  styleUrls: ['./accounts-past-due.component.scss']
})
export class AccountsPastDueComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  accountNumberGrid:any;
  acntNoteOrgSys :any;
  defaultExcelExportParams: any;
  rowData: any =[];
  columnDefs: any;
  pageSize: number = 30;
  defaultColDef: ColDef = {
    resizable: true,
  };

  pastDueDetails:any = []

  constructor(
    public dialogRef: MatDialogRef<AccountsPastDueComponent>,
    private searchService :SearchService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.accountNumberGrid = data.accountNumber;
    this.acntNoteOrgSys = data.acntNoteOrgSys;
  }


  inputData:any={};
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }
  ngOnInit(): void {
    this.defaultExcelExportParams = {
      fileName:
        'AccountPastDue-' + this.accountNumberGrid + '-' + Date(),
    };
    this.inputData.accountNumber = this.accountNumberGrid;
    this.inputData.acntNoteOrgSys =  this.acntNoteOrgSys;
    this.primengConfig.ripple = true;
    this.searchService.accountPastDue(this.inputData).subscribe((data: any) => {
      this.pastDueDetails = data.pastDueDetails;
      this.columnDefs = this.columnDefsAPD;
      this.rowData = data.pastDueAmountDetails;
    });
  }
  columnDefsAPD: ColDef[] = [
     { headerName: 'Account Number', field: 'account_number'},
     { headerName: 'Billing Period', field: 'billing_period'},
     { headerName: 'Current Billing', field: 'sumOfCurrentBillingAmt',valueFormatter: this.currencyFormatter,type: 'rightAligned',},
     { headerName: 'Current Balance', field: 'sumOfPastDue0Amt',valueFormatter: this.currencyFormatter,type: 'rightAligned',},
     { headerName: 'Past Due', field: 'sumOfPastDueAmt',valueFormatter: this.currencyFormatter,type: 'rightAligned',}
  ];

  currencyFormatter(params: ValueFormatterParams) {
    return '$'+ params.value;
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  overlayLoadingTemplate =
  `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
overlayNoRowsTemplate =
  `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

 closeModal(){
  this.dialogRef.close({ msg: 'success' });
 }



}

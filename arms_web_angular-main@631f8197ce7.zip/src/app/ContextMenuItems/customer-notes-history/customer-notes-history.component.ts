import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, GetContextMenuItemsParams, ITooltipParams, MenuItemDef, ValueFormatterParams } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { CustomerNotesModalService } from 'src/app/services/customer-notes-modal.service';
import { HoveringHeadersComponent } from '../hovering-headers/hovering-headers.component';

@Component({
  selector: 'app-customer-notes-history',
  templateUrl: './customer-notes-history.component.html',
  styleUrls: ['./customer-notes-history.component.scss']
})
export class CustomerNotesHistoryComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;
  rowData: any;
  columnDefs: any;
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    // flex: 1,
    //minWidth: 100,
    resizable: true,
  }

  customerGrpCd: string = "";

  constructor(
    public dialogRef: MatDialogRef<CustomerNotesHistoryComponent>,
    private toastr: ToastrService,
    private customerNotesService: CustomerNotesModalService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.customerGrpCd = data.customerGrpCd;
  }
  defaultExcelExportParams:any;
  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.customerNotesService.customerNotesHistory({ customerGrpCd: this.customerGrpCd }).subscribe((data: any) => {
      this.rowData = data.CustomerNotesHistory;
      this.columnDefs = this.columnDefsANH;
    },
      (error: any) => {
        console.log(error);
      });
      this.defaultExcelExportParams = {
        fileName:
          'CustomerNotesHistory-' + this.customerGrpCd + '-' + Date(),
      };
  }
  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  columnDefsANH: ColDef[] = [
    {
      headerName: 'Resolved', field: 'resolved',editable:false,
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      }
    },
    { headerName: 'Note ID', field: 'notesId' },
    { headerName: 'Billing Period', field: 'billingPeriod' },
    { headerName: 'Commitment Amt', field: 'commitmentAmount',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
  }
   },
    { headerName: 'Talked To', field: 'talkedTo' },
    { headerName: 'Notes', field: 'notes',resizable:true,
    tooltipComponent: HoveringHeadersComponent,
    tooltipValueGetter: toolTipValueGetter
  },
    { headerName: 'BringUp Dt', field: 'bringUpDate' },
    { headerName: 'UserID', field: 'userLoginCd' },
    { headerName: 'Logged By', field: 'loggedBy' },
    { headerName: 'Inserted', field: 'insertDate' }
  ];

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

  closeModal() {
    this.dialogRef.close({ msg: 'success' });
  }

}
const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerNotesHistoryComponent } from './customer-notes-history.component';

describe('CustomerNotesHistoryComponent', () => {
  let component: CustomerNotesHistoryComponent;
  let fixture: ComponentFixture<CustomerNotesHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerNotesHistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerNotesHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

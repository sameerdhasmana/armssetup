import { DatePipe } from '@angular/common';
import { AfterViewInit, Component, Inject, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { AccountNotesService } from 'src/app/services/accountNotes.service';
import { GeneralUiFunctionsService } from 'src/app/services/general-ui-functions.service';

@Component({
  selector: 'app-modify-account-notes',
  templateUrl: './modify-account-notes.component.html',
  styleUrls: ['./modify-account-notes.component.scss']
})
export class ModifyAccountNotesComponent implements OnInit, AfterViewInit {


  autoResolved: boolean = false;
  commitmentAmtTxt: any;
  commitDueDateTxt: any;
  commitDueDtPipe: any;
  bringUpDateTxt: any;
  bringUpDatePipe: any;
  // copyToBiller :boolean = false;
  dBCallTalkedTo: any;
  //myBringUp:boolean= false;
  //sendToAdopt :boolean = false;
  contestedAmtTxt: any;
  //phone:any;
  //email:any;
  // attuid:any;
  inTreatmentStatus: any = "";
  //dBTemplateNotes:any;
  subActivity: any;
  rootCause: any;
  nextAction: any;
  longNotes: any;
  //callType:any;
  //paymentMethod:any;
  //extn:any;
  exLongNotes: any;

  model: any;
  Mode: string = "";
  //radioInps = ['Perm Note', 'No Action', 'Bankruptcy', 'Credit Information', 'In Treatment'];
  form: any = new FormGroup({
    Resolved: new FormControl(),
    //premTemp : new FormControl(),
    //extn : new FormControl(),
    // PermNote: new FormControl(),
    //NoAction: new FormControl(),
    //Bankruptcy: new FormControl(),
    //CreditInformation: new FormControl(),
    //InTreatment: new FormControl(),
    radioNotes: new FormControl(),
    CommitDueDate: new FormControl(),
    commitmentAmt: new FormControl(),
    BringUpDt: new FormControl(),
    TalkedTo: new FormControl(),
    contestedAmt: new FormControl(),
    //templateNotes : new FormControl(),
    SubActivity: new FormControl(),
    RootCause: new FormControl(),
    NextAction: new FormControl(),
    Notes: new FormControl(),
    exNotes: new FormControl(),
    //BUTUNConditional : new FormControl(),
    //BUTConditional :new FormControl(),
    bringupType: new FormControl(),
    // copyToBiller : new FormControl(),
    //callType : new FormControl(),
    //paymentMethod : new FormControl(),
    //myBringUp : new FormControl(),
    //sendToAdopt :  new FormControl(),
    //phone:new FormControl(),
    //email:new FormControl('',[Validators.required,Validators.email]),
    //  attuid:new FormControl(),
  })
  accountNumber: any;
  acntNoteOrgSys: any;
  customerGrpCd: any;
  billingPeriod: any;
  originatingSystemArray: any[] = [];
  selectedAccountNumbersArray: any[] = [];
  groupSeleted: any[] = [];
  inputData: any = {};
  rowData: any;

  constructor(public dialogRef: MatDialogRef<ModifyAccountNotesComponent>,
    private _generalUiFnService: GeneralUiFunctionsService,
    private accounts: AccountNotesService,
    private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.Mode = data.Mode;
    this.accountNumber = this.data.selectedAccountNumbers;
    this.acntNoteOrgSys = this.data.originatingSystem;
    this.customerGrpCd = this.data.customerGrpCd;
    this.billingPeriod = this.data.billingPeriod;
    this.originatingSystemArray = this.data.originatingSystemArray;
    this.selectedAccountNumbersArray = this.data.selectedAccountNumbersArray;
    this.groupSeleted = this.data.groupSeleted;
    this.rowData = data.currRowData;
    //console.log('Row Data',  this.rowData);
  }

  addAccNotesdB: any = {};
  inTreatmentdB: any = {};

  ngOnInit(): any {
    this.inputData.accountNumber = this.accountNumber;
    this.inputData.acntNoteOrgSys = this.acntNoteOrgSys;
    this.inputData.customerGrpCd = this.customerGrpCd;

    this.accounts.addAccountNotes(this.inputData).subscribe((data: any) => {
      // console.log(data);
      this.addAccNotesdB = data;
      this.fillTalkedToValues();
      // this.contestedAmtTxt = data.ContestedAmt[0].contested_amt;
    });

    this.inputData.selectedAccountNumbers = this.selectedAccountNumbersArray;
    this.inputData.originatingSystem = this.originatingSystemArray;
    this.inputData.customerGrpCd = this.customerGrpCd;

    this.accounts.populateInTreatment(this.inputData).subscribe((data: any) => {
      // console.log(data);
      this.inTreatmentdB = data;
      this.fillInTreatmentValues();
    });

  }
  fillTalkedToValues() {
    if (this.rowData.talked_to == '' || this.rowData.talked_to == null || this.rowData.talked_to == undefined) { }
    else {
      this.dBCallTalkedTo = (this.addAccNotesdB.AccountNoteTalkedTo.find((e: any) => {
        if (e.contact == this.rowData.talked_to) {
          return e.contact;
        }
      })).contact;
    }
  }

  fillInTreatmentValues() {
    if (this.rowData.activity_cd == "I") {
      this.form.controls['radioNotes'].setValue('I');
      if (this.rowData.subdesc == "" || this.rowData.subdesc == null || this.rowData.subdesc == undefined) { }
      else {
        this.subActivity = (this.inTreatmentdB.subActivityList.find((e: any) => {
          if (e.sub_activity_short_description == this.rowData.subdesc) {
            return e.sub_activity_cd;
          }
        })).sub_activity_cd;
      }
      if (this.rowData.root_cause == "" || this.rowData.root_cause == null || this.rowData.root_cause == undefined) { }
      else {
        this.rootCause = (this.inTreatmentdB.rootCauseList.find((e: any) => {
          if (e.rc_desc == this.rowData.root_cause) {
            return e.rc_cd;
          }
        })).rc_cd;
      }
      if (this.rowData.next_action == "" || this.rowData.next_action == null || this.rowData.next_action == undefined) { }
      else {
        this.nextAction = (this.inTreatmentdB.nextActionList.find((e: any) => {
          if (e.nxtact_desc == this.rowData.next_action) {
            return e.nxtact_cd;
          }
        })).nxtact_cd;
      }
    }
  }

  ngAfterViewInit(): void {
    //console.log(this.rowData);
    this.autoResolved = !!this.rowData.resolved
    this.longNotes = this.rowData.notes;
    this.exLongNotes = this.rowData.notes;
    this.contestedAmtTxt = parseFloat(this.rowData.contested_amt).toFixed(2);
    this.commitmentAmtTxt = this.rowData.commitment_amt;
    // this.dBCallTalkedTo = this.rowData.talked_to; //Check.
    this.bringUpDateTxt = this.rowData.next_call_back_date.trim() == "" ? this.bringUpDateTxt : (this.rowData.next_call_back_date).trim();
    this.commitDueDateTxt = (this.rowData.commitment_date).trim() == "" ? this.commitDueDateTxt : (this.rowData.commitment_date).trim();


    if (this.rowData.bring_up_type == "U") {
      this.form.controls['bringupType'].setValue('U');
    } else {
      this.form.controls['bringupType'].setValue('C');
    }

    if (this.rowData.activity_cd == "I") {
      this.form.controls['radioNotes'].setValue('I');
    } else if (this.rowData.activity_cd == "C") {
      this.form.controls['radioNotes'].setValue('C');
    } else if (this.rowData.activity_cd == "N") {
      this.form.controls['radioNotes'].setValue('N');
    } else if (this.rowData.activity_cd == "B") {
      this.form.controls['radioNotes'].setValue('B');
    } else if (this.rowData.activity_cd == "P") {
      this.form.controls['radioNotes'].setValue('P');
    }




  }

  templateTextData: any = {};


  allowOnlyNumbersWithSlash(event: any) {
    return this._generalUiFnService.allowOnlyNumbersWithSlash(event);
  }


  saveAccountNotes: any = {};
  Filters: any;


  saveModifiedAccNotes() {
    let errMsg: string = this.validateSave();
    if (errMsg != "") {
      this.toastr.error('', errMsg, {
        timeOut: 5000, closeButton: true
      });
    }
    else {
      //   let data = localStorage.getItem("userInfo");
      // this.Filters = JSON.parse(data ? data : "");
      const datepipe: DatePipe = new DatePipe('en-US')
      let BringUpDt = datepipe.transform(this.bringUpDateTxt, 'MM/dd/YYYY');
      let CommitDueDt = datepipe.transform(this.commitDueDateTxt, 'MM/dd/YYYY');

      this.saveAccountNotes.modeType = 2;
      this.saveAccountNotes.accountNumber = this.accountNumber;
      this.saveAccountNotes.acntNoteOrgSys = this.acntNoteOrgSys;
      this.saveAccountNotes.nextCallBackDate = BringUpDt?.toString();;
      this.saveAccountNotes.noteId = this.rowData.notes_id;
      this.saveAccountNotes.billingPeriod = this.billingPeriod;
      this.saveAccountNotes.groupSelected = this.groupSeleted;
      this.saveAccountNotes.resolved = this.form.controls['Resolved'].value == true ? 1 : 0;
      this.saveAccountNotes.activityCode = this.form.controls['radioNotes'].value;
      this.saveAccountNotes.commitmentAmt = this.commitmentAmtTxt;
      this.saveAccountNotes.bringupDate = BringUpDt?.toString();; // Note Required
      this.saveAccountNotes.subActivity = this.subActivity;
      this.saveAccountNotes.talkedTo = this.dBCallTalkedTo;
      this.saveAccountNotes.notes = this.longNotes;
      this.saveAccountNotes.contestedAmt = this.contestedAmtTxt;
      //this.saveAccountNotes.copyToBiller = this.copyToBiller  == true ? 1 : 0;
      //this.saveAccountNotes.billerNotePerm= this.form.controls['premTemp'].value ;
      //this.saveAccountNotes.callType =this.callType;
      //this.saveAccountNotes.paymentMethod = this.paymentMethod;
      //this.saveAccountNotes.customerPhoneNumber = this.phone;
      //this.saveAccountNotes.customerPhoneNumberExtn = this.extn;
      //this.saveAccountNotes.customerEmail= this.email;
      //this.saveAccountNotes.attuid = this.attuid;
      this.saveAccountNotes.bringupType = this.form.controls['bringupType'].value;
      //this.saveAccountNotes.sendToAdapt = this.form.controls['sendToAdopt'].value == true ? 1 : 0;
      this.saveAccountNotes.rcCode = this.rootCause;
      this.saveAccountNotes.nxtactCode = this.nextAction;
      this.saveAccountNotes.commitmentDate = CommitDueDt?.toString();
      //this.saveAccountNotes.myBringUp = this.form.controls['myBringUp'].value == true ? 1 : 0;

      //  console.log(this.saveAccountNotes);
      this.accounts.saveAccountNotes(this.saveAccountNotes).subscribe((data: any) => {
        //  console.log('Data from the Save API', data);
        if (data.msg == "success") {
          this.saveAccountNotes = null;
          this.dialogRef.close({ msg: 'success' });
          this.toastr.success('', 'Account Notes : Note Modified Succesfully!', {
            timeOut: 5000, closeButton: true
          });
        }
      }, (error: any) => {
        this.toastr.error('', 'Account Notes : Unable to Modify the Note. Please try again later!', {
          timeOut: 5000, closeButton: true
        });
      });

    }
  }

  validateSave() {
    let strMsg: string = "";
    if (this.form.controls['BringUpDt'].status == "INVALID" || this.form.controls['CommitDueDate'].status == "INVALID") {
      strMsg = "Please select a valid date";
      return strMsg;
    }
    const datepipe: DatePipe = new DatePipe('en-US')
    let newBringUpDt: any = datepipe.transform(this.bringUpDateTxt, 'MM/dd/YYYY');
    let newCommitDueDt: any = datepipe.transform(this.commitDueDateTxt, 'MM/dd/YYYY');
    let CurrentDt = new Date();
    let Crrdt: any = datepipe.transform(CurrentDt, 'MM/dd/YYYY');
    var newCrrdt = new Date(Crrdt?.toString());

    if (newBringUpDt != "" && newBringUpDt != null && newBringUpDt != undefined) {
      var BUdt = new Date(newBringUpDt?.toString());
      if (BUdt.getDay() == 0 || BUdt.getDay() == 6) {
        strMsg = "Bring Up Date: Weekends are not allowed!";
      }
      if (BUdt.getFullYear() == newCrrdt.getFullYear()) {
        if (BUdt.getMonth() == newCrrdt.getMonth()) {
          if (BUdt.getDate() < newCrrdt.getDate()) {
            strMsg = "Bring Up Date: Past Dates are not allowed!";
          }
        }
        if (BUdt.getMonth() < newCrrdt.getMonth()) {
          strMsg = "Bring Up Date: Past Dates are not allowed!";
        }
      }
      else if (BUdt.getFullYear() < newCrrdt.getFullYear()) {
        strMsg = "Bring Up Date: Past Dates are not allowed!";
      }
    }
    if (newCommitDueDt != "" && newCommitDueDt != null && newCommitDueDt != undefined) {
      var CDdt = new Date(newCommitDueDt?.toString());
      if (CDdt.getDay() == 0 || CDdt.getDay() == 6) {
        strMsg = "Commit Due Date: Weekends are not allowed!";
      }
      if (CDdt.getFullYear() == newCrrdt.getFullYear()) {
        if (CDdt.getMonth() == newCrrdt.getMonth()) {
          if (CDdt.getDate() < newCrrdt.getDate()) {
            strMsg = "Commit Due Date: Past Dates are not allowed!";
          }
        }
        if (CDdt.getMonth() < newCrrdt.getMonth()) {
          strMsg = "Commit Due  Date: Past Dates are not allowed!";
        }
      }
      else if (CDdt.getFullYear() < newCrrdt.getFullYear()) {
        strMsg = "Commit Due Date: Past Dates are not allowed!";
      }
    }
    else if (this.form.controls['radioNotes'].value == null || this.form.controls['radioNotes'].value == undefined || this.form.controls['radioNotes'].value == "") {
      if (this.form.controls['Resolved'].value == true) {
        strMsg = "Please select at least one check box for activity";
      }
      else {
        strMsg = "Notes can not be added or modified without at least one status. Please select one or more status check boxes!";
      }
    }
    else {
      if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "I") {
        if (this.form.controls['SubActivity'].value == null || this.form.controls['SubActivity'].value == undefined || this.form.controls['SubActivity'].value == "") {
          strMsg = "Please select subactivity";
        }
        else if (this.form.controls['Notes'].value == "" || this.form.controls['Notes'].value == undefined || this.form.controls['Notes'].value == null) {
          strMsg = "Please type some notes";
        }
      }
      else if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "C") {
        if (this.form.controls['Notes'].value == "" || this.form.controls['Notes'].value == undefined || this.form.controls['Notes'].value == null) {
          strMsg = "Please add/modify notes to reflect credit information";
        }
      }
    }
    return strMsg;
  }

  closeModal() {
    this.dialogRef.close({ msg: "cancelled" });
  }


}

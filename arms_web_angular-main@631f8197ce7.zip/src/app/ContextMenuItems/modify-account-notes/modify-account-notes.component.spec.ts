import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyAccountNotesComponent } from './modify-account-notes.component';

describe('ModifyAccountNotesComponent', () => {
  let component: ModifyAccountNotesComponent;
  let fixture: ComponentFixture<ModifyAccountNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModifyAccountNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyAccountNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

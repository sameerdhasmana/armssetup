import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { DoubleCellDataType } from '../../hovering-headers/double-type-cell.component';

@Component({
  selector: 'app-multiple-contested-amt',
  templateUrl: './multiple-contested-amt.component.html',
  styleUrls: ['./multiple-contested-amt.component.scss']
})
export class MultipleContestedAmtComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;
  rowData: any;
  columnDefs: any;
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    // flex: 1,
    //minWidth: 100,
    resizable: true,
  }
  columnDefsCA: ColDef[] = [
    { headerName: 'Account Number', field: 'account_number' },
    { headerName: 'Contested', field: 'contested', editable: true, cellEditor: DoubleCellDataType },
    { headerName: 'Originating System', field: 'originating_system' }
  ];

  rowDataAC: any = [];

  selectedAccountNumbersArray: any;
  originatingSystemArray: any;
  constructor(
    public dialogRef: MatDialogRef<MultipleContestedAmtComponent>,
    private toastr: ToastrService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.selectedAccountNumbersArray = data.selectedAccountNumbersArray;
    this.originatingSystemArray = data.originatingSystemArray;
  }

  ngOnInit(): void {
    for (let i = 0; i < this.selectedAccountNumbersArray.length; i++) {
      this.rowDataAC.push(
        {
          "account_number": this.selectedAccountNumbersArray[i],
          "contested": 0,
          "originating_system": this.originatingSystemArray[i]
        }
      );
    }
    this.primengConfig.ripple = true;
    this.columnDefs = this.columnDefsCA;
    this.rowData = this.rowDataAC;
  }

  SaveGridData() {
    this.gridApi.stopEditing();
    this.gridApi.selectAll();
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let contestedList = selectedData.map((e: any) => {
      return e.contested == null || e.contested == undefined ? 0 : parseFloat(e.contested);
    });
    console.log(contestedList);
    this.dialogRef.close({ contestedData: contestedList });
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  onCellKeyDown(e: any) {
    //console.log(e);
    let event = e.event;
    let KEY_A = 65;
    // If Ctrl + A pressed, select all nodes
    if (event.ctrlKey && event.which === KEY_A) {
      e.api.selectAll();
    }
  }

  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  closeModal() {
    this.gridApi.selectAll();
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let contestedList = selectedData.map((e: any) => {
      return 0;
    });
    console.log(contestedList);
    this.dialogRef.close({ contestedData: contestedList });
  }

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleContestedAmtComponent } from './multiple-contested-amt.component';

describe('MultipleContestedAmtComponent', () => {
  let component: MultipleContestedAmtComponent;
  let fixture: ComponentFixture<MultipleContestedAmtComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultipleContestedAmtComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleContestedAmtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit, AfterViewInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AccountNotesService } from 'src/app/services/accountNotes.service';
import { GeneralUiFunctionsService } from 'src/app/services/general-ui-functions.service';
import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/api';
import { PrimeNGConfig } from 'primeng/api';
import { MultipleCommitmentAmtComponent } from './multiple-commitment-amt/multiple-commitment-amt.component';
import { MultipleContestedAmtComponent } from './multiple-contested-amt/multiple-contested-amt.component';


@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.scss'],
  providers: [ConfirmationService]
})
export class AccountDetailsComponent implements OnInit, AfterViewInit {
  btnAdd: boolean = true;
  btnAbort: boolean = true;
  btnModify: boolean = true;
  btnUnassign: boolean = true;
  btnMode: string = "";
  msgs: Message[] = [];
  chkAddAccNotes: boolean = false;
  chkApSubGroup: boolean = false;
  chkHotNote: boolean = false;
  chkContactInfo: boolean = false;
  // autoResolved :boolean = false;
  selection: any = {};
  commitmentAmtTxt: any;
  commitDueDateTxt: any;
  commitDueDtPipe: any;
  bringUpDateTxt: any;
  bringUpDatePipe: any;
  copyToBiller: boolean = false;
  dBCallTalkedTo: any;
  //myBringUp:boolean= false;
  //sendToAdopt :boolean = false;
  contestedAmtTxt: string="0.00";
  phone: any;
  email: any;
  attuid: any;
  inTreatmentStatus: any = "";
  dBTemplateNotes: any;
  subActivity: any;
  rootCause: any;
  nextAction: any;
  longNotes: any;
  callType: any;
  paymentMethod: any;
  extn: any;
  ddAPSubGroup: any;
  txtArHotNote: any;
  CtctInfFirstName: any;
  CtctInfLastName: any;
  CtctInfTitle: any;
  CtctInfPhone: any;
  CtctInfSecondaryTN: any;
  CtctInfAddress: any;
  CtctInfFax: any;
  CtctInfExt: any;
  CtctInfEmail: any;
  CtctInfSecEmail: any;
  CtctInfCity: any;
  CtctInfState: any;
  CtctInfZip: any;
  CntctInfNotes: any;
  CtctInfEMAORDt: any;
  CtctInfSelectContacts: any;
  EMAORDt: any;

  model: any;
  Mode: string = "";
  //radioInps = ['Perm Note', 'No Action', 'Bankruptcy', 'Credit Information', 'In Treatment'];
  form: any = new FormGroup({
    Resolved: new FormControl({ value: "", disabled: true }),
    premTemp: new FormControl({ value: "", disabled: true }),
    extn: new FormControl({ value: "", disabled: true }),
    // PermNote: new FormControl(),
    //NoAction: new FormControl(),
    //Bankruptcy: new FormControl(),
    //CreditInformation: new FormControl(),
    //InTreatment: new FormControl(),
    radioNotes: new FormControl({ value: "", disabled: true }),
    CommitDueDate: new FormControl({ value: "", disabled: true }),
    commitmentAmt: new FormControl({ value: "", disabled: true }),
    BringUpDt: new FormControl({ value: "", disabled: true }),
    TalkedTo: new FormControl({ value: "", disabled: true }),
    contestedAmt: new FormControl({ value: "", disabled: true }),
    templateNotes: new FormControl({ value: "", disabled: true }),
    SubActivity: new FormControl(),
    RootCause: new FormControl(),
    NextAction: new FormControl(),
    Notes: new FormControl({ value: "", disabled: true }),
    //BUTUNConditional : new FormControl(),
    //BUTConditional :new FormControl(),
    bringupType: new FormControl({ value: "", disabled: true }),
    copyToBiller: new FormControl({ value: "", disabled: true }),
    callType: new FormControl({ value: "", disabled: true }),
    paymentMethod: new FormControl({ value: "", disabled: true }),
    myBringUp: new FormControl({ value: "", disabled: true }),
    sendToAdopt: new FormControl({ value: "", disabled: true }),
    phone: new FormControl({ value: "", disabled: true }),//(null, [Validators.pattern("[0-9]{0-10}")]),
    email: new FormControl({ value: "", disabled: true }),//('',[Validators.required,Validators.email]),
    attuid: new FormControl({ value: "", disabled: true }),
    AddAccountNotes: new FormControl(),
    AddAPSubGroup: new FormControl(),
    AddHotNote: new FormControl(),
    AddContactInfo: new FormControl(),
    APSubGroup: new FormControl({ value: "", disabled: true }),
    HotNote: new FormControl({ value: "", disabled: true }),
    CtctInfFirstName: new FormControl({ value: "", disabled: true }),
    CtctInfLastName: new FormControl({ value: "", disabled: true }),
    CtctInfTitle: new FormControl({ value: "", disabled: true }),
    CtctInfPhone: new FormControl({ value: "", disabled: true }),
    CtctInfSecondaryTN: new FormControl({ value: "", disabled: true }),
    CtctInfAddress: new FormControl({ value: "", disabled: true }),
    CtctInfCity: new FormControl({ value: "", disabled: true }),
    CtctInfState: new FormControl({ value: "", disabled: true }),
    CtctInfZip: new FormControl({ value: "", disabled: true }),
    CtctInfFax: new FormControl({ value: "", disabled: true }),
    CtctInfExt: new FormControl({ value: "", disabled: true }),
    rdbCntctInfEMAOR: new FormControl({ value: "", disabled: true }),
    rdbCntctInfPrimary: new FormControl({ value: "", disabled: true }),
    CtctInfEmail: new FormControl({ value: "", disabled: true }),
    CtctInfSecEmail: new FormControl({ value: "", disabled: true }),
    CntctInfNotes: new FormControl({ value: "", disabled: true }),
    CtctInfEMAORDt: new FormControl({ value: "", disabled: true }),
    CtctInfSelectContacts: new FormControl({ value: "", disabled: true }),
  })
  accountNumber: any;
  acntNoteOrgSys: any;
  customerGrpCd: any;
  billingPeriod: any;
  originatingSystemArray: any[] = [];
  selectedAccountNumbersArray: any[] = [];
  groupSeleted: any[] = [];
  inputData: any = {};
  populateContactInp: any = {};

  constructor(public dialogRef: MatDialogRef<AccountDetailsComponent>,
    private _generalUiFnService: GeneralUiFunctionsService,
    private accounts: AccountNotesService,
    private primengConfig: PrimeNGConfig,
    private confirmationService: ConfirmationService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.Mode = data.Mode;
    this.accountNumber = this.data.selectedAccountNumbers;
    this.acntNoteOrgSys = this.data.originatingSystem;
    this.customerGrpCd = this.data.customerGrpCd;
    this.billingPeriod = this.data.billingPeriod;
    this.originatingSystemArray = this.data.originatingSystemArray;
    this.selectedAccountNumbersArray = this.data.selectedAccountNumbersArray;
    this.groupSeleted = this.data.groupSeleted;
  }

  addAccNotesdB: any = {};
  inTreatmentdB: any = {};
  populateContactdB: any = {};
  commitAmt: any = "";
  contestAmt: any = "";
  ngOnInit(): any {
    this.inputData.selectedAccountNumbers = this.selectedAccountNumbersArray;
    this.inputData.originatingSystem = this.originatingSystemArray;
    this.inputData.customerGrpCd = this.customerGrpCd;
    this.populateContactInp.customerGrpCd = this.customerGrpCd;
    this.primengConfig.ripple = true;
    this.accounts.addAccountDetails(this.inputData).subscribe((data: any) => {
      //console.log(data);
      this.addAccNotesdB = data;
      if (this.selectedAccountNumbersArray.length == 1) {
        if ('ContestedAmt' in data) {
          this.contestedAmtTxt = data.ContestedAmt[0].contested_amt;
        }
        else {
          this.contestedAmtTxt = "0.00";
        }
      }
      else {
        this.commitAmt = "Click here to enter Multiple Commitment Amount";
        this.contestAmt = "Click here to enter Multiple Contested Amount";
      }
    });
  }

  commitmentAmtArr: any = [];
  dueDateArr: any = [];
  commitmentAmtClick() {
    if (this.selectedAccountNumbersArray.length > 1) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = false;
      dialogConfig.id = 'multiple-commitment-amt-component';
      dialogConfig.height = '72%';
      dialogConfig.width = '63%';
      dialogConfig.data = {
        selectedAccountNumbersArray: this.selectedAccountNumbersArray,
        originatingSystemArray: this.originatingSystemArray
      };
      const modalDialog = this.dialog.open(MultipleCommitmentAmtComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {
        console.log(res.commitmentData);
        console.log(res.dueDateData);
        this.commitmentAmtArr = res.commitmentData;
        this.dueDateArr = res.dueDateData;
      });
    }
  }
  contestedAmtArr: any = [];
  contestedAmtClick() {
    if (this.selectedAccountNumbersArray.length > 1) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = false;
      dialogConfig.id = 'multiple-contested-amt-component';
      dialogConfig.height = '70%';
      dialogConfig.width = '50%';
      dialogConfig.data = {
        selectedAccountNumbersArray: this.selectedAccountNumbersArray,
        originatingSystemArray: this.originatingSystemArray
      };
      const modalDialog = this.dialog.open(MultipleContestedAmtComponent, dialogConfig);
      modalDialog.afterClosed().subscribe((res: any) => {
        console.log(res.contestedData);
        this.contestedAmtArr = res.contestedData;
      });
    }
  }

  ngAfterViewInit(): void {

  }

  inTreatement() {
    this.inputData.selectedAccountNumbers = this.selectedAccountNumbersArray;
    this.inputData.originatingSystem = this.originatingSystemArray;
    this.inputData.customerGrpCd = this.customerGrpCd;
    this.accounts.populateInTreatment(this.inputData).subscribe((data: any) => {
      this.inTreatmentdB = data;
    });
  }

  templateTextData: any = {};

  templateText() {
    this.templateTextData.templateName = this.addAccNotesdB.NoteTemplate[0].template_name;
    this.templateTextData.templateType = this.addAccNotesdB.NoteTemplate[0].template_type;
    this.accounts.accountNoteText(this.templateTextData).subscribe((data: any) => {
      //console.log(data);
      //debugger;
      this.longNotes = data.AccountNoteText;

    })
  }
  allowOnlyNumbersWithSlash(event: any) {
    return this._generalUiFnService.allowOnlyNumbersWithSlash(event);
  }

  allowOnlyNumbers(event: any) {
    return this._generalUiFnService.allowOnlyNumbers(event);
  }

  saveAccountNotes: any = {};
  Filters: any;

  closeModal() {
    this.dialogRef.close({ msg: 'cancelled' });
  }

  validateSave() {
    let strMsg: string = "";
    if (this.chkAddAccNotes == false && this.chkApSubGroup == false && this.chkHotNote == false && this.chkContactInfo == false) {
      strMsg = "Please select the necessary inputs";
    }
    if (this.chkAddAccNotes == true) {
      if (this.form.controls['BringUpDt'].status == "INVALID" || this.form.controls['CommitDueDate'].status == "INVALID") {
        strMsg = "Please select a valid date";
        return strMsg;
      }
      const datepipe: DatePipe = new DatePipe('en-US')
      let newBringUpDt: any = datepipe.transform(this.bringUpDateTxt, 'MM/dd/YYYY');
      let newCommitDueDt: any = datepipe.transform(this.commitDueDateTxt, 'MM/dd/YYYY');
      let CurrentDt = new Date();
      let Crrdt: any = datepipe.transform(CurrentDt, 'MM/dd/YYYY');
      var newCrrdt = new Date(Crrdt?.toString());

      if (newBringUpDt != "" && newBringUpDt != null && newBringUpDt != undefined) {
        var BUdt = new Date(newBringUpDt?.toString());
        if (BUdt.getDay() == 0 || BUdt.getDay() == 6) {
          strMsg = "Bring Up Date: Weekends are not allowed!";
        }
        if (BUdt.getFullYear() == newCrrdt.getFullYear()) {
          if (BUdt.getMonth() == newCrrdt.getMonth()) {
            if (BUdt.getDate() < newCrrdt.getDate()) {
              strMsg = "Bring Up Date: Past Dates are not allowed!";
            }
          }
          if (BUdt.getMonth() < newCrrdt.getMonth()) {
            strMsg = "Bring Up Date: Past Dates are not allowed!";
          }
        }
        else if (BUdt.getFullYear() < newCrrdt.getFullYear()) {
          strMsg = "Bring Up Date: Past Dates are not allowed!";
        }
      }
      if (newCommitDueDt != "" && newCommitDueDt != null && newCommitDueDt != undefined) {
        var CDdt = new Date(newCommitDueDt?.toString());
        if (CDdt.getDay() == 0 || CDdt.getDay() == 6) {
          strMsg = "Commit Due Date: Weekends are not allowed!";
        }
        if (CDdt.getFullYear() == newCrrdt.getFullYear()) {
          if (CDdt.getMonth() == newCrrdt.getMonth()) {
            if (CDdt.getDate() < newCrrdt.getDate()) {
              strMsg = "Commit Due Date: Past Dates are not allowed!";
            }
          }
          if (CDdt.getMonth() < newCrrdt.getMonth()) {
            strMsg = "Commit Due  Date: Past Dates are not allowed!";
          }
        }
        else if (CDdt.getFullYear() < newCrrdt.getFullYear()) {
          strMsg = "Commit Due Date: Past Dates are not allowed!";
        }
      }
      else if (this.form.controls['radioNotes'].value == null || this.form.controls['radioNotes'].value == undefined || this.form.controls['radioNotes'].value == "") {
        if (this.form.controls['Resolved'].value == true) {
          strMsg = "Please select at least one check box for activity";
        }
        else {
          strMsg = "Notes can not be added or modified without at least one status. Please select one or more status check boxes!";
        }
      }
      else {
        if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "I") {
          if (this.form.controls['callType'].value == null || this.form.controls['callType'].value == undefined || this.form.controls['callType'].value == "") {
            strMsg = "Call type must be designated";
          }
          else if (this.form.controls['SubActivity'].value == null || this.form.controls['SubActivity'].value == undefined || this.form.controls['SubActivity'].value == "") {
            strMsg = "Please select subactivity";
          }
          else if (this.form.controls['Notes'].value == "" || this.form.controls['Notes'].value == undefined || this.form.controls['Notes'].value == null) {
            strMsg = "Please type some notes";
          }
        }
        else if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "C") {
          if (this.form.controls['callType'].value == null || this.form.controls['callType'].value == undefined || this.form.controls['callType'].value == "") {
            strMsg = "Call type must be designated";
          }
          else if (this.form.controls['Notes'].value == "" || this.form.controls['Notes'].value == undefined || this.form.controls['Notes'].value == null) {
            strMsg = "Please add/modify notes to reflect credit information";
          }
        }
        else if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "P" || (this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "B" || (this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "N") {
          if (this.form.controls['callType'].value == null || this.form.controls['callType'].value == undefined || this.form.controls['callType'].value == "") {
            strMsg = "Call type must be designated";
          }
        }
      }
    }
    if (this.chkApSubGroup == true) {
      //this.saveAccountNotes.hotNote = this.txtArHotNote;
      if (this.form.controls['APSubGroup'].value == null || this.form.controls['APSubGroup'].value == undefined || this.form.controls['APSubGroup'].value == "") {
        strMsg = "Select the AP Sub Group";
      }
    }
    if (this.chkHotNote == true) {
      //this.saveAccountNotes.hotNote = this.txtArHotNote;
      if (this.form.controls['HotNote'].value == null || this.form.controls['HotNote'].value == undefined || this.form.controls['HotNote'].value == "") {
        strMsg = "Enter Hot Notes";
      }
    }
    if (this.chkContactInfo == true) {
      if (this.btnMode == "") {
        strMsg = "Contact Information: Please add / modify the contact information to save!";
      }
      if (this.btnMode == "A") {
        if (this.CtctInfFirstName == null || this.CtctInfFirstName == undefined || this.CtctInfFirstName == "") {
          strMsg = "Enter First Name!";
        }
      }
    }
    return strMsg;
  }

  optionList: any = [];
  contestedAmtTxtArr: any = [];
  commitmentAmtTxtArr: any = [];
  CommitDueDtArr: any = [];
  saveNewAccDetails() {
    let errMsg: string = this.validateSave();
    if (errMsg != "") {
      this.toastr.error('', errMsg, {
        timeOut: 5000, closeButton: true
      });
      return;
    }
    else {
      const datepipe: DatePipe = new DatePipe('en-US')
      let BringUpDt = datepipe.transform(this.bringUpDateTxt, 'MM/dd/YYYY');
      let CommitDueDt = datepipe.transform(this.commitDueDateTxt, 'MM/dd/YYYY');
      let EmaorEffDate = datepipe.transform(this.CtctInfEMAORDt, 'MM/dd/YYYY');
      if (this.selectedAccountNumbersArray.length == 1) {
        if (this.contestedAmtTxt == null || this.contestedAmtTxt == undefined || this.contestedAmtTxt == "") {
          this.contestedAmtTxtArr.push(0);
        }
        else {
          this.contestedAmtTxtArr.push(parseFloat(this.contestedAmtTxt));
        }
        if (this.commitmentAmtTxt == null || this.commitmentAmtTxt == undefined || this.commitmentAmtTxt == "") {
          this.commitmentAmtTxtArr.push(0);
        }
        else {
          this.commitmentAmtTxtArr.push(parseFloat(this.commitmentAmtTxt));
        }
        if (CommitDueDt == null || CommitDueDt == undefined) {
          this.CommitDueDtArr.push("");
        }
        else {
          this.CommitDueDtArr.push(CommitDueDt?.toString());
        }
      }

      this.saveAccountNotes.selectedAccountNumbers = this.selectedAccountNumbersArray;
      this.saveAccountNotes.originatingSystem = this.originatingSystemArray;
      this.saveAccountNotes.nextCallBackDate = BringUpDt?.toString();;
      this.saveAccountNotes.noteId = 0;  // Always 0 for Adding New Notes
      this.saveAccountNotes.billingPeriod = this.billingPeriod;
      this.saveAccountNotes.groupSelected = this.groupSeleted;
      this.saveAccountNotes.resolved = this.form.controls['Resolved'].value == true ? 1 : 0;
      this.saveAccountNotes.activityCode = this.form.controls['radioNotes'].value;
      this.saveAccountNotes.commitmentAmtList = this.selectedAccountNumbersArray.length == 1 ? this.commitmentAmtTxtArr : this.commitmentAmtArr;
      this.saveAccountNotes.bringupDate = BringUpDt?.toString();; // Note Required
      this.saveAccountNotes.subActivity = this.subActivity;
      this.saveAccountNotes.talkedTo = this.dBCallTalkedTo;
      this.saveAccountNotes.notes = this.longNotes;
      this.saveAccountNotes.contestedAmtList = this.selectedAccountNumbersArray.length == 1 ? this.contestedAmtTxtArr : this.contestedAmtArr;
      this.saveAccountNotes.copyToBiller = this.copyToBiller == true ? 1 : 0;
      this.saveAccountNotes.billerNotePerm = this.form.controls['premTemp'].value;
      this.saveAccountNotes.callType = this.callType;
      this.saveAccountNotes.paymentMethod = this.paymentMethod;
      this.saveAccountNotes.customerPhoneNumber = this.phone;
      this.saveAccountNotes.customerPhoneNumberExtn = this.extn;
      this.saveAccountNotes.customerEmail = this.email;
      this.saveAccountNotes.attuid = this.attuid;
      this.saveAccountNotes.bringupType = this.form.controls['bringupType'].value;
      this.saveAccountNotes.sendToAdapt = this.form.controls['sendToAdopt'].value == true ? 1 : 0;
      this.saveAccountNotes.rcCode = this.rootCause;
      this.saveAccountNotes.nxtactCode = this.nextAction;
      this.saveAccountNotes.commitmentDateList = this.selectedAccountNumbersArray.length == 1 ? this.CommitDueDtArr : this.dueDateArr;
      this.saveAccountNotes.myBringUp = this.form.controls['myBringUp'].value == true ? 1 : 0;
      this.saveAccountNotes.apSubGroupName = this.ddAPSubGroup;
      this.saveAccountNotes.hotNote = this.txtArHotNote;
      this.optionList = [];
      if (this.chkAddAccNotes == true) {
        this.optionList.push(1);
      }
      if (this.chkApSubGroup == true) {
        this.optionList.push(2);
      }
      if (this.chkHotNote == true) {
        this.optionList.push(3);
      }
      if (this.chkContactInfo == true) {
        this.optionList.push(4);
      }
      this.saveAccountNotes.saveOptionList = this.optionList;
      this.saveAccountNotes.contactInfoFlag = this.btnMode == "" ? "A" : this.btnMode;
      this.saveAccountNotes.firstName = this.CtctInfFirstName;
      this.saveAccountNotes.lastName = this.CtctInfLastName;
      this.saveAccountNotes.address = this.CtctInfAddress;
      this.saveAccountNotes.city = this.CtctInfCity;
      this.saveAccountNotes.state = this.CtctInfState;
      this.saveAccountNotes.zip = this.CtctInfZip;
      this.saveAccountNotes.title = this.CtctInfTitle;
      this.saveAccountNotes.phoneNumber = this.CtctInfPhone;
      this.saveAccountNotes.phoneNumberExtn = this.CtctInfExt;
      this.saveAccountNotes.faxNumber = this.CtctInfFax;
      this.saveAccountNotes.email = this.CtctInfEmail;
      this.saveAccountNotes.phoneNumber2 = this.CtctInfSecondaryTN;
      this.saveAccountNotes.email2 = this.CtctInfSecEmail;
      this.saveAccountNotes.emaor = this.form.controls['rdbCntctInfEMAOR'].value;
      this.saveAccountNotes.emaorPrimary = this.form.controls['rdbCntctInfPrimary'].value;
      this.saveAccountNotes.emaorEffDate = EmaorEffDate?.toString();
      this.saveAccountNotes.contactNote = this.CntctInfNotes;
      if (this.CtctInfSelectContacts == null || this.CtctInfSelectContacts == undefined || this.CtctInfSelectContacts == "") {
        this.saveAccountNotes.sequence = 0;
      }
      else {
        this.saveAccountNotes.sequence = (this.addAccNotesdB.AccountContactList.find((e: any) => {
          if (e.contact == this.CtctInfSelectContacts) {
            return e.contact;
          }
        })).sequence;
      }
      this.saveAccountNotes.customerGrpCd = this.customerGrpCd;
      //console.log(this.saveAccountNotes);

      this.accounts.saveAccountDetails(this.saveAccountNotes).subscribe((data: any) => {
        //console.log('Data from the Save API', data);
        if (data.msg == "success") {
          this.saveAccountNotes = {};
          this.toastr.success('', 'Account Details Updated Succesfully!', {
            timeOut: 5000, closeButton: true
          });
          this.dialogRef.close({ msg: 'success' });
        }
      }, (error: any) => {
        if (error.error.errorMsg == "Please select the necessary inputs") {
          this.saveAccountNotes = {};
          this.toastr.error('', 'Account Details : ' + error.error.errorMsg, {
            timeOut: 5000, closeButton: true
          });
        }
        else {
          this.saveAccountNotes = {};
          this.toastr.error('', 'Account Details : Unable to save the Account Details. Please try again later!', {
            timeOut: 5000, closeButton: true
          });
        }
      });
    }
  }

  EnableDisableControls() {
    if (this.chkAddAccNotes == true) {
      this.form.controls['Resolved'].enable();
      this.form.controls['premTemp'].enable();
      //this.form.controls['extn'].enable();
      this.form.controls['radioNotes'].enable();
      this.form.controls['CommitDueDate'].enable();
      this.form.controls['commitmentAmt'].enable();
      this.form.controls['BringUpDt'].enable();
      this.form.controls['TalkedTo'].enable();
      this.form.controls['contestedAmt'].enable();
      this.form.controls['templateNotes'].enable();
      this.form.controls['Notes'].enable();
      this.form.controls['bringupType'].enable();
      this.form.controls['copyToBiller'].enable();
      this.form.controls['callType'].enable();
      this.form.controls['paymentMethod'].enable();
      this.form.controls['myBringUp'].enable();
      this.form.controls['sendToAdopt'].enable();
      this.form.controls['phone'].enable();
      this.form.controls['email'].enable();
      this.form.controls['attuid'].enable();
      this.enableDisableExtn();
      if (this.selectedAccountNumbersArray.length > 1) {
        this.form.controls['CommitDueDate'].disable();
      }
    }
    else {
      this.form.controls['radioNotes'].setValue("");
      this.form.controls['Resolved'].disable();
      this.form.controls['premTemp'].disable();
      this.form.controls['extn'].disable();
      this.form.controls['radioNotes'].disable();
      this.form.controls['CommitDueDate'].disable();
      this.form.controls['commitmentAmt'].disable();
      this.form.controls['BringUpDt'].disable();
      this.form.controls['TalkedTo'].disable();
      this.form.controls['contestedAmt'].disable();
      this.form.controls['templateNotes'].disable();
      this.form.controls['Notes'].disable();
      this.form.controls['bringupType'].disable();
      this.form.controls['copyToBiller'].disable();
      this.form.controls['callType'].disable();
      this.form.controls['paymentMethod'].disable();
      this.form.controls['myBringUp'].disable();
      this.form.controls['sendToAdopt'].disable();
      this.form.controls['phone'].disable();
      this.form.controls['email'].disable();
      this.form.controls['attuid'].disable();
    }
    if (this.chkApSubGroup == true) {
      this.form.controls['APSubGroup'].enable();
    }
    else {
      this.form.controls['APSubGroup'].disable();
    }
    if (this.chkHotNote == true) {
      this.form.controls['HotNote'].enable();
    }
    else {
      this.form.controls['HotNote'].disable();
    }
    if (this.chkContactInfo == true) {
      this.form.controls['CtctInfSelectContacts'].enable();
      this.btnAdd = false;
      this.btnModify = false;
      this.btnUnassign = false;
      this.btnAbort = true;
    }
    else {
      this.form.controls['CtctInfFirstName'].disable();
      this.form.controls['CtctInfLastName'].disable();
      this.form.controls['CtctInfTitle'].disable();
      this.form.controls['CtctInfPhone'].disable();
      this.form.controls['CtctInfSecondaryTN'].disable();
      this.form.controls['CtctInfAddress'].disable();
      this.form.controls['CtctInfCity'].disable();
      this.form.controls['CtctInfState'].disable();
      this.form.controls['CtctInfZip'].disable();
      this.form.controls['CtctInfFax'].disable();
      this.form.controls['CtctInfExt'].disable();
      this.form.controls['rdbCntctInfEMAOR'].disable();
      this.form.controls['rdbCntctInfPrimary'].disable();
      this.form.controls['CtctInfEmail'].disable();
      this.form.controls['CtctInfSecEmail'].disable();
      this.form.controls['CntctInfNotes'].disable();
      this.form.controls['CtctInfEMAORDt'].disable();
      this.form.controls['CtctInfSelectContacts'].disable();
      this.btnAdd = true;
      this.btnModify = true;
      this.btnUnassign = true;
      this.btnAbort = true;
      this.btnMode = "";
      this.clearValues();
    }
  }

  clearValues() {
    this.form.controls['CtctInfFirstName'].setValue("");
    this.form.controls['CtctInfLastName'].setValue("");
    this.form.controls['CtctInfTitle'].setValue("");
    this.form.controls['CtctInfPhone'].setValue("");
    this.form.controls['CtctInfSecondaryTN'].setValue("");
    this.form.controls['CtctInfAddress'].setValue("");
    this.form.controls['CtctInfCity'].setValue("");
    this.form.controls['CtctInfState'].setValue("");
    this.form.controls['CtctInfZip'].setValue("");
    this.form.controls['CtctInfFax'].setValue("");
    this.form.controls['CtctInfExt'].setValue("");
    this.form.controls['rdbCntctInfEMAOR'].setValue("");
    this.form.controls['rdbCntctInfPrimary'].setValue("");
    this.form.controls['CtctInfEmail'].setValue("");
    this.form.controls['CtctInfSecEmail'].setValue("");
    this.form.controls['CntctInfNotes'].setValue("");
    this.form.controls['CtctInfEMAORDt'].setValue("");
    this.form.controls['CtctInfSelectContacts'].setValue("");
  }

  btnAddClick() {
    this.form.controls['CtctInfFirstName'].enable();
    this.form.controls['CtctInfLastName'].enable();
    this.form.controls['CtctInfTitle'].enable();
    this.form.controls['CtctInfPhone'].enable();
    this.form.controls['CtctInfSecondaryTN'].enable();
    this.form.controls['CtctInfAddress'].enable();
    this.form.controls['CtctInfCity'].enable();
    this.form.controls['CtctInfState'].enable();
    this.form.controls['CtctInfZip'].enable();
    this.form.controls['CtctInfFax'].enable();
    //this.form.controls['CtctInfExt'].enable();
    this.form.controls['rdbCntctInfEMAOR'].enable();
    this.form.controls['rdbCntctInfPrimary'].enable();
    this.form.controls['CtctInfEmail'].enable();
    this.form.controls['CtctInfSecEmail'].enable();
    this.form.controls['CntctInfNotes'].enable();
    this.form.controls['CtctInfEMAORDt'].enable();
    this.btnAdd = true;
    this.btnModify = true;
    this.btnUnassign = true;
    this.btnAbort = false;
    this.btnMode = "A";
    this.clearValues();
  }

  btnModifyClick() {
    if (this.form.controls['CtctInfSelectContacts'].value == "" || this.form.controls['CtctInfSelectContacts'].value == null || this.form.controls['CtctInfSelectContacts'].value == undefined) {
      this.toastr.error('', 'Account Details : Select a contact to modify!', {
        timeOut: 5000, closeButton: true
      });
    }
    else {
      this.form.controls['CtctInfFirstName'].enable();
      this.form.controls['CtctInfLastName'].enable();
      this.form.controls['CtctInfTitle'].enable();
      this.form.controls['CtctInfPhone'].enable();
      this.form.controls['CtctInfSecondaryTN'].enable();
      this.form.controls['CtctInfAddress'].enable();
      this.form.controls['CtctInfCity'].enable();
      this.form.controls['CtctInfState'].enable();
      this.form.controls['CtctInfZip'].enable();
      this.form.controls['CtctInfFax'].enable();
      //this.form.controls['CtctInfExt'].enable();
      this.form.controls['rdbCntctInfEMAOR'].enable();
      this.form.controls['rdbCntctInfPrimary'].enable();
      this.form.controls['CtctInfEmail'].enable();
      this.form.controls['CtctInfSecEmail'].enable();
      this.form.controls['CntctInfNotes'].enable();
      this.form.controls['CtctInfEMAORDt'].enable();
      this.btnAdd = true;
      this.btnModify = true;
      this.btnUnassign = true;
      this.btnAbort = false;
      this.btnMode = "M";
      this.enableDisableContactInfoExtn();
    }
  }

  btnAbortClick() {
    this.form.controls['CtctInfFirstName'].disable();
    this.form.controls['CtctInfLastName'].disable();
    this.form.controls['CtctInfTitle'].disable();
    this.form.controls['CtctInfPhone'].disable();
    this.form.controls['CtctInfSecondaryTN'].disable();
    this.form.controls['CtctInfAddress'].disable();
    this.form.controls['CtctInfCity'].disable();
    this.form.controls['CtctInfState'].disable();
    this.form.controls['CtctInfZip'].disable();
    this.form.controls['CtctInfFax'].disable();
    this.form.controls['CtctInfExt'].disable();
    this.form.controls['rdbCntctInfEMAOR'].disable();
    this.form.controls['rdbCntctInfPrimary'].disable();
    this.form.controls['CtctInfEmail'].disable();
    this.form.controls['CtctInfSecEmail'].disable();
    this.form.controls['CntctInfNotes'].disable();
    this.form.controls['CtctInfEMAORDt'].disable();
    this.btnAdd = false;
    this.btnModify = false;
    this.btnUnassign = false;
    this.btnAbort = true;
    this.btnMode = "";
  }
  unassignData: any = {}
  btnUnassignClick() {
    if (this.form.controls['CtctInfSelectContacts'].value == "" || this.form.controls['CtctInfSelectContacts'].value == null || this.form.controls['CtctInfSelectContacts'].value == undefined) {
      this.toastr.error('', 'Account Details : Select a contact to unassign!', {
        timeOut: 5000, closeButton: true
      });
    }
    else {
      this.unassignData.customerGrpCd = this.customerGrpCd;
      this.unassignData.selectedAccountNumbers = this.selectedAccountNumbersArray;
      this.unassignData.originatingSystem = this.originatingSystemArray;
      this.unassignData.sequence = (this.addAccNotesdB.AccountContactList.find((e: any) => {
        if (e.contact == this.CtctInfSelectContacts) {
          return e.contact;
        }
      })).sequence;
      this.unassignData.contactid = (this.addAccNotesdB.AccountContactList.find((e: any) => {
        if (e.contact == this.CtctInfSelectContacts) {
          return e.contact;
        }
      })).contacts_id.toString();
      //console.log(this.unassignData);
      this.accounts.deleteAccountContacts(this.unassignData).subscribe((data: any) => {
        if (data.msg == "success") {
          this.toastr.success('', 'Account Details : Contact has been unassigned!', {
            timeOut: 5000, closeButton: true
          });
          this.clearValues();
        }
      });
    }
  }

  selectedContactData: any = {};
  onContactChange(event: any) {
    //console.log(event.target.value);
    this.selectedContactData = (this.addAccNotesdB.AccountContactList.find((e: any) => {
      if (e.contact == event.target.value) {
        return e.contact;
      }
    }));
    //console.log(this.selectedContactData);
    this.CtctInfFirstName = this.selectedContactData.first_name;
    this.CtctInfLastName = this.selectedContactData.last_name;
    this.CtctInfTitle = this.selectedContactData.title;
    this.CtctInfPhone = this.selectedContactData.phone;
    this.CtctInfSecondaryTN = this.selectedContactData.phone2;
    this.CtctInfAddress = this.selectedContactData.address;
    this.CtctInfCity = this.selectedContactData.city;
    this.CtctInfState = this.selectedContactData.state;
    this.CtctInfZip = this.selectedContactData.zip;
    this.CtctInfFax = this.selectedContactData.fax_number;
    this.CtctInfExt = this.selectedContactData.extension;
    this.form.controls['rdbCntctInfEMAOR'].setValue(this.selectedContactData.emaor);
    this.form.controls['rdbCntctInfPrimary'].setValue(this.selectedContactData.primary);
    this.CtctInfEmail = this.selectedContactData.email;
    this.CtctInfSecEmail = this.selectedContactData.email2;
    this.CntctInfNotes = this.selectedContactData.notes;
    this.CtctInfEMAORDt = this.selectedContactData.effective == null ? "" : this.selectedContactData.effective;
    if (this.btnMode == "M") {
      this.enableDisableContactInfoExtn();
    }
  }

  enableDisableExtn() {
    if (this.phone == "" || this.phone == null || this.phone == undefined) {
      this.form.controls["extn"].disable();
    }
    else {
      if (this.phone.length == 10) {
        this.form.controls["extn"].enable();
      }
      else {
        this.form.controls["extn"].disable();
      }
    }
  }

  enableDisableContactInfoExtn() {
    if (this.CtctInfPhone == "" || this.CtctInfPhone == null || this.CtctInfPhone == undefined) {
      this.form.controls["CtctInfExt"].disable();
    }
    else {
      if (this.CtctInfPhone.length == 10) {
        this.form.controls["CtctInfExt"].enable();
      }
      else {
        this.form.controls["CtctInfExt"].disable();
      }
    }
  }

  confirm() {
    let data1 = localStorage.getItem("userInfo");
    let userData = JSON.parse(data1 ? data1 : "")
    let userLoginCd = userData.globalLogonUsers.user_login_cd;
    debugger
    if (this.form.controls['Resolved'].value === true) {
      this.confirmationService.confirm({
        message: "By Selecting 'Auto Resolve', all other Bring-ups entered by " + userLoginCd + " will be Resolved. Are you Sure?",
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
          this.msgs = [{ severity: 'info', summary: 'Confirmed', detail: 'You have accepted' }];
          this.saveNewAccDetails()
        },
        reject: () => {
          this.msgs = [{ severity: 'info', summary: 'Rejected', detail: 'You have rejected' }];
        }
      });
    }
    else {
      this.saveNewAccDetails();
    }
  }

  commitContestedAmtKeyPress() {
    if (this.selectedAccountNumbersArray.length == 1) { 
      return true;
    }
    else {
      return false;
    }
  }


}

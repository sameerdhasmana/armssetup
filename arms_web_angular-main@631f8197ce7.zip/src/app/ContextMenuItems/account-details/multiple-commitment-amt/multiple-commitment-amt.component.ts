import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, ICellEditorComp, ICellEditorParams } from 'ag-grid-community';
import { format } from 'date-fns';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { GeneralUiFunctionsService } from 'src/app/services/general-ui-functions.service';
import { MyDateEditorComponent } from '../../hovering-headers/date-picker.component';
import { DoubleCellDataType } from '../../hovering-headers/double-type-cell.component';

@Component({
  selector: 'app-multiple-commitment-amt',
  templateUrl: './multiple-commitment-amt.component.html',
  styleUrls: ['./multiple-commitment-amt.component.scss']
})
export class MultipleCommitmentAmtComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;
  rowData: any;
  columnDefs: any;
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    // flex: 1,
    //minWidth: 100,
    resizable: true,
  }
  columnDefsCA: ColDef[] = [
    { headerName: 'Account Number', field: 'account_number' },
    { headerName: 'Commitment', field: 'commitment', editable: true, cellEditor: DoubleCellDataType },
    {
      headerName: 'Due Date', field: 'due_date', editable: true,
      cellEditor: MyDateEditorComponent,
    }
  ];

  rowDataAC: any = [];
  selectedDate: any = '';
  selectedAccountNumbersArray: any;
  originatingSystemArray: any;
  SelectAllDate: boolean = false;
  constructor(
    public dialogRef: MatDialogRef<MultipleCommitmentAmtComponent>,
    private toastr: ToastrService,
    private _generalUiFnService: GeneralUiFunctionsService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.selectedAccountNumbersArray = data.selectedAccountNumbersArray;
    this.originatingSystemArray = data.originatingSystemArray;
  }

  ngOnInit(): void {
    for (let i = 0; i < this.selectedAccountNumbersArray.length; i++) {
      this.rowDataAC.push(
        {
          "account_number": this.selectedAccountNumbersArray[i],
          "commitment": "0",
          "due_date": ""
        }
      );
    }
    this.primengConfig.ripple = true;
    this.columnDefs = this.columnDefsCA;
    this.rowData = this.rowDataAC;
  }

  validateSaveGridData(selectedData: any) {
    let rsp: string = "";
    selectedData.map((e: any) => {
      if (e.commitment == "-") {
        rsp = "Commitment Amount field can only accept numeric characters (0-9). Characters like ',' is not allowed but only single '.' is allowed.";
      }
      if (e.commitment != "" && e.commitment != "0") {
        if (e.due_date == "") {
          rsp = 'You must select Due Date for Accounts where Commitment Amount is not 0';
        }
        else {
          const datepipe: DatePipe = new DatePipe('en-US')
          let CurrentDt = new Date();
          let Crrdt: any = datepipe.transform(CurrentDt, 'MM/dd/YYYY');
          var newCrrdt = new Date(Crrdt?.toString());
          if (e.due_date != "" && e.due_date != null && e.due_date != undefined) {
            var CDdt = new Date(e.due_date?.toString());
            if (CDdt.getDay() == 0 || CDdt.getDay() == 6) {
              rsp = "Due Date: Weekends are not allowed!";
            }
            if (CDdt.getFullYear() == newCrrdt.getFullYear()) {
              if (CDdt.getMonth() == newCrrdt.getMonth()) {
                if (CDdt.getDate() < newCrrdt.getDate()) {
                  rsp = "Due Date: Past Dates are not allowed!";
                }
              }
              if (CDdt.getMonth() < newCrrdt.getMonth()) {
                rsp = "Due  Date: Past Dates are not allowed!";
              }
            }
            else if (CDdt.getFullYear() < newCrrdt.getFullYear()) {
              rsp = "Due Date: Past Dates are not allowed!";
            }
          }
        }
      }
    });
    return rsp;
  }

  SaveGridData() {
    this.gridApi.stopEditing();
    this.gridApi.selectAll();
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let validateRsp: string = this.validateSaveGridData(selectedData);
    if (validateRsp != "") {
      this.toastr.error('', validateRsp, {
        timeOut: 5000, closeButton: true
      });
      this.gridApi.deselectAll();
      return;
    }
    let commitmentList = selectedData.map((e: any) => {
      return e.commitment == null || e.commitment == undefined ? 0 : parseFloat(e.commitment);
    });
    let dueDateList = selectedData.map((e: any) => {
      return e.due_date == null || e.due_date == undefined ? "" : e.due_date;
    });
    console.log(commitmentList);
    console.log(dueDateList);
    this.dialogRef.close({ commitmentData: commitmentList, dueDateData: dueDateList });
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  onCellKeyDown(e: any) {
    //console.log(e);
    let event = e.event;
    let KEY_A = 65;
    // If Ctrl + A pressed, select all nodes
    if (event.ctrlKey && event.which === KEY_A) {
      e.api.selectAll();
    }
  }

  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  closeModal() {
    this.gridApi.selectAll();
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let commitmentList = selectedData.map((e: any) => {
      return 0;
    });
    let dueDateList = selectedData.map((e: any) => {
      return "";
    });
    console.log(commitmentList);
    console.log(dueDateList);
    this.dialogRef.close({ commitmentData: commitmentList, dueDateData: dueDateList });
  }

  disableSelectAllBtn: boolean = true;
  EnableDisableSelectAll() {
    if (this.SelectAllDate) {
      this.disableSelectAllBtn = false;
    }
    else {
      this.disableSelectAllBtn = true;
    }
  }
  onDateChanged = (event: any) => {
    let date = event.value;
    if (date) {
      date.setHours(0, 0, 0, 0);
    }
    this.selectedDate = date;
    console.log(format(this.selectedDate, "MM/dd/yyyy"));
    if (this.SelectAllDate) {
      let rowDataACN: any = [];
      this.gridApi.selectAll();
      let selectedNodes = this.gridApi.getSelectedNodes();
      let selectedData = selectedNodes.map((node: any) => node.data);
      let commitmentList = selectedData.map((e: any) => {
        return e.commitment == null || e.commitment == undefined ? 0 : parseFloat(e.commitment);
      });
      for (let i = 0; i < this.selectedAccountNumbersArray.length; i++) {
        rowDataACN.push(
          {
            "account_number": this.selectedAccountNumbersArray[i],
            "commitment": commitmentList[i],
            "due_date": format(this.selectedDate, "MM/dd/yyyy")
          }
        );
      }
      this.primengConfig.ripple = true;
      this.columnDefs = this.columnDefsCA;
      this.rowData = rowDataACN;
    }
  }

  allowOnlyNumbersWithSlash(event: any) {
    return this._generalUiFnService.allowOnlyNumbersWithSlash(event);
  }

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

}


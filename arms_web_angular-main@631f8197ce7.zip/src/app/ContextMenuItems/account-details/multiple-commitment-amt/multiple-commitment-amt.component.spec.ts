import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleCommitmentAmtComponent } from './multiple-commitment-amt.component';

describe('MultipleCommitmentAmtComponent', () => {
  let component: MultipleCommitmentAmtComponent;
  let fixture: ComponentFixture<MultipleCommitmentAmtComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultipleCommitmentAmtComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleCommitmentAmtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

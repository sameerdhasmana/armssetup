import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerNotesModalComponent } from './customer-notes-modal.component';

describe('CustomerNotesModalComponent', () => {
  let component: CustomerNotesModalComponent;
  let fixture: ComponentFixture<CustomerNotesModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerNotesModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerNotesModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CashDataDetailsComponent } from './cash-data-details.component';

describe('CashDataDetailsComponent', () => {
  let component: CashDataDetailsComponent;
  let fixture: ComponentFixture<CashDataDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CashDataDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CashDataDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

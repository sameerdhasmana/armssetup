import { Component, Inject, OnInit,ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams,  MenuItemDef, ValueFormatterParams } from 'ag-grid-enterprise';
import { PrimeNGConfig } from 'primeng/api';
import { SearchService } from 'src/app/services/search.service';

@Component({
  selector: 'app-cash-data-details',
  templateUrl: './cash-data-details.component.html',
  styleUrls: ['./cash-data-details.component.scss']
})
export class CashDataDetailsComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  accountNumberGrid:any;
  acntNoteOrgSys :any;
  byPayment: any;
  byAdjustment : any;
  defaultExcelExportParams: any;
  rowData: any =[];
  columnDefs: any;
  pageSize: number = 30;
  defaultColDef: ColDef = {
    resizable: true
  };

  constructor(
    public dialogRef: MatDialogRef<CashDataDetailsComponent>,
    private searchService :SearchService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.accountNumberGrid = data.accountNumber;
    this.acntNoteOrgSys = data.acntNoteOrgSys;
    this.byPayment = data.byPayment;
    this.byAdjustment = data.byAdjustment;
  }


  inputData:any={};
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }
  ngOnInit(): void {
    this.defaultExcelExportParams = {
      fileName:
        'QuarterlyTransactionsReport-' + this.accountNumberGrid + '-' + Date(),
    };
    this.inputData.accountNumber = this.accountNumberGrid;
    this.inputData.acntNoteOrgSys =  this.acntNoteOrgSys;
    this.inputData.byPayment = this.byPayment
    this.inputData.byAdjustment = this.byAdjustment;
    this.primengConfig.ripple = true;
    this.searchService.cashDataDetails(this.inputData).subscribe((data: any) => {
      this.columnDefs = this.columnDefsCDD;
      this.rowData = data.cashDataDetails;
    });
  }
  columnDefsCDD: ColDef[] = [
     { headerName: 'Billing Period', field: 'billingPeriod'},
     { headerName: 'Billing Date', field: 'lastBillingDate'},
     { headerName: 'Transaction Dt', field: 'transactionDate'},
     { headerName: 'Transaction Amt', field: 'transactionAmount', aggFunc:'sum',type: 'rightAligned',
     valueFormatter: currencyFormatter,
     cellStyle: params => {
       if (params.value < 0) {
           return {color: 'red'};//,backgroundColor: 'green'
       }
       return null;
   }
    },
     { headerName: 'Transaction Type', field: 'transactionType'},
     { headerName: 'Insert Date', field: 'insertDate'},
     { headerName: 'Pymt', field: 'payment',
     cellRenderer: (params:any) => {
      return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;}
    },
     { headerName: 'Adj', field: 'adjustment',
     cellRenderer: (params:any) => {
      return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;}
    },
     { headerName: 'Account Nbr', field: 'accountNumber'},
     { headerName: 'System', field: 'originatingSystem'}

  ];
  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  overlayLoadingTemplate =
  `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
overlayNoRowsTemplate =
  `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

 closeModal(){
  this.dialogRef.close({ msg: 'success' });
 }

}
function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

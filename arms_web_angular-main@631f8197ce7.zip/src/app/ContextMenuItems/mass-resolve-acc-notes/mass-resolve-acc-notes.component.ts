import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import {
  CheckboxSelectionCallbackParams,
  ColDef,
  GetContextMenuItemsParams,
  GridOptions,
  HeaderCheckboxSelectionCallbackParams,
  ITooltipParams,
  MenuItemDef,
  ValueFormatterParams,
} from 'ag-grid-enterprise';
import { PrimeNGConfig } from 'primeng/api';
import { AccountNotesService } from 'src/app/services/accountNotes.service';
import {ConfirmationService} from 'primeng/api';
import {Message} from 'primeng/api';
import { HoveringHeadersComponent } from '../hovering-headers/hovering-headers.component';



@Component({
  selector: 'app-mass-resolve-acc-notes',
  templateUrl: './mass-resolve-acc-notes.component.html',
  styleUrls: ['./mass-resolve-acc-notes.component.scss'],
  providers: [ConfirmationService]
})
export class MassResolveAccNotesComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  parentRowData: any;
  selectedAccountNumber: any;
  originatingSystem: any;
  msgs: Message[] = [];
  rowData: any;
  columnDefs: any;
  shwNotesGrid: boolean = false;
  pageSize: number = 30;
  defaultColDef: ColDef = {
    resizable: true,
    headerCheckboxSelection: this.isFirstColumn,
    checkboxSelection: this.isFirstColumn,
  };

  isFirstColumn(
    params:
      | CheckboxSelectionCallbackParams
      | HeaderCheckboxSelectionCallbackParams
  ) {
    let displayedColumns = params.columnApi.getAllDisplayedColumns();
    let thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  }

  constructor(
    public dialogRef: MatDialogRef<MassResolveAccNotesComponent>,
    private toastr: ToastrService,
    private accountNotes: AccountNotesService,
    private primengConfig: PrimeNGConfig,
    private confirmationService: ConfirmationService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.parentRowData = data.currRowData;
    this.selectedAccountNumber = data.selectedAccountNumber;
    this.originatingSystem = data.originatingSystem;
  }

  inputData: any = {};

  ngOnInit(): void {
    this.inputData.selectedAccountNumbers = this.selectedAccountNumber;
    this.inputData.originatingSystem = this.originatingSystem;

    this.primengConfig.ripple = true;
    this.accountNotes
      .massResolveAccountNotes(this.inputData)
      .subscribe((data: any) => {
        this.columnDefs = this.columnDefsAN;
        this.rowData = data.AccountNotes;
        this.gridApi.showLoadingOverlay();
      });
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(
      (document.getElementById('quickFilter') as HTMLInputElement).value
    );
  }

  selectAll() {
    this.gridApi.selectAll();
  }
  onRowSelected(params: any) {
    this.selectedRowCount=this.gridApi.getSelectedNodes()?.length
  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [
      {
        name: 'Resolve Notes',
        action: () => {
          this.resolveNotes();
        },
      },
      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  };

  overlayLoadingTemplate = `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate = `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

  closeModal() {
    this.dialogRef.close();
  }
selectedRowCount:any;
  confirm() {
    if (this.selectedRowCount > 0) {
      this.confirmationService.confirm({
        message: "You are about to resolve "+this.selectedRowCount+" record(s). If you click Yes, You won't be able to undo this Resolve Operation.Are you sure you want to resolve these records?",
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.msgs = [{severity:'info', summary:'Confirmed', detail:'You have accepted'}];
            this.resolveNotes()
        },
        reject: () => {
            this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
        }
    });
    } else {
      this.toastr.error(
        '',
        'Mass Resolve Account Notes:  Please select atleast 1 Account Number to Resolve',
        {
          timeOut: 5000,
          closeButton: true,
        }
      );
    }
}

onCellKeyDown(e:any){
  console.log(e);
  let event = e.event;

  let KEY_A = 65;

  // If Ctrl + A pressed, select all nodes
  if (event.ctrlKey && event.which === KEY_A) {
      e.api.selectAll();
  }
}

  resolveInputData: any = {};
  resolveNotes() {
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map((node: any) => node.data);
    let noteIdList = selectedData.map((e: any) => {
      return e.notes_id;
    });
    let notesList = selectedData.map((e: any) => {
      return e.notes;
    });
    this.resolveInputData.noteIdList = noteIdList;
    this.resolveInputData.notesList = notesList;
    this.accountNotes
      .saveMassResolveAccountNotes(this.resolveInputData)
      .subscribe(
        (data: any) => {
          if (data.msg == 'success') {
            this.resolveInputData = null;
            this.dialogRef.close({ msg: 'success' });
            this.toastr.success(
              '',
              'Success : Selected Notes Resolved Successfully',
              {
                timeOut: 5000,
                closeButton: true,
              }
            );
          } else if (data.errorMsg) {
            this.toastr.error(
              '',
              'Failure : Error!! Please select the necessary inputs',
              {
                timeOut: 5000,
                closeButton: true,
              }
            );
          }
        },
        (error: any) => {}
      );
  }

  columnDefsAN: ColDef[] = [
    { headerName: 'Notes ID', field: 'notes_id' },
    { headerName: 'Customer ID', field: 'customer_grp_cd' },
    { headerName: 'Billing Period', field: 'billing_period' },
    {
      headerName: 'Resolved',
      field: 'resolved',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      },
    },
    { headerName: 'Next Call Back Dt', field: 'next_call_back_date' },
    {
      headerName: 'Commitment Amt',
      field: 'commitment_amt',type: 'rightAligned',
      valueFormatter: currencyFormatter,
      cellStyle: (params) => {
        if (params.value < 0) {
          return { color: 'red' }; //,backgroundColor: 'green'
        }
        return null;
      },
    },
    { headerName: 'Talked to', field: 'talked_to' },
    { headerName: 'Notes', field: 'notes',resizable:true,
    tooltipComponent: HoveringHeadersComponent,
    tooltipValueGetter: toolTipValueGetter
  },
    { headerName: 'Activity CD', field: 'activity_cd' },
    {
      headerName: 'In Treatment',
      field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${
          params.value == 'I' ? 'checked' : ''
        } />`;
      },
    },
    {
      headerName: 'Perm Note',
      field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${
          params.value == 'P' ? 'checked' : ''
        } />`;
      },
    },
    {
      headerName: 'Credit Information',
      field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${
          params.value == 'C' ? 'checked' : ''
        } />`;
      },
    },
    {
      headerName: 'Bankruptcy',
      field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${
          params.value == 'B' ? 'checked' : ''
        } />`;
      },
    },
    {
      headerName: 'No Action',
      field: 'activity_cd',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${
          params.value == 'N' ? 'checked' : ''
        } />`;
      },
    },

    {
      headerName: 'Copy to Biller',
      field: 'copy_to_biller',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      },
    },
    { headerName: 'Copy Biller Value', field: 'copy_biller_value' },
    { headerName: 'Biller Note Prem', field: 'biller_note_perm' },
    { headerName: 'SubDesc', field: 'subdesc' },
    { headerName: 'Bring Up Type', field: 'bring_up_type' },
    {
      headerName: 'Send to Adapt',
      field: 'send_to_adapt',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      },
    },
    {
      headerName: 'My Bring Up',
      field: 'my_bring_up',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      },
    },
    { headerName: 'System', field: 'originating_system' },
    {
      headerName: 'Contested Amt',
      field: 'contested_amt',
      valueFormatter: currencyFormatter,type: 'rightAligned',
      cellStyle: (params) => {
        if (params.value < 0) {
          return { color: 'red' }; //,backgroundColor: 'green'
        }
        return null;
      },
    },
    { headerName: 'Root Cause', field: 'root_cause' },
    { headerName: 'Next Action', field: 'next_action' },
    { headerName: 'Commitment Date', field: 'commitment_date' },
    { headerName: 'User ID', field: 'user_login_cd' },
    { headerName: 'Call Type', field: 'call_type' },
    { headerName: 'Payment Method', field: 'payment_method' },
    { headerName: 'Phone#', field: 'customer_phone_number' },
    { headerName: 'Ext', field: 'customer_phone_number_extn' },
    { headerName: 'Email', field: 'customer_email' },
    { headerName: 'ATTUID/CACS', field: 'contact_attuid' },
    { headerName: 'Account No', field: 'account_number' },
    { headerName: 'Insert Data', field: 'insert_date' },
    { headerName: 'Logged By', field: 'logged_by' },
  ];
}
function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MassResolveAccNotesComponent } from './mass-resolve-acc-notes.component';

describe('MassResolveAccNotesComponent', () => {
  let component: MassResolveAccNotesComponent;
  let fixture: ComponentFixture<MassResolveAccNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MassResolveAccNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MassResolveAccNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

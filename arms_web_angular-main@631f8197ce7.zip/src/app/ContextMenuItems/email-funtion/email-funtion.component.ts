import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GeneralUiFunctionsService } from 'src/app/services/general-ui-functions.service';
import { EmailService } from 'src/app/services/email.service';

@Component({
  selector: 'app-email-funtion',
  templateUrl: './email-funtion.component.html',
  styleUrls: ['./email-funtion.component.scss']

})
export class EmailFuntionComponent implements OnInit {
  parentData: any = {}; //Optional Data from the parent Component
  dueDateTxt: any;
  dueDatePipe: any;
  amountPaidTxt: any;
  paDeadLineTxt: any;
  paDatePipe: any;
  datePaidTxt: any;
  paidDatePipe: any;
  pastDueTxt: any;
  confirmationTxt: any;
  totalTxt: any;
  pcfAmountTxt: any;
  payArrmtDateTxt: any;
  payArrmtDatePipe: any;
  confirmDateTxt: any;
  confirmDatePipe: any;
  amountX1Txt: any;
  amountX2Txt: any;
  amountX3Txt: any;
  amountX4Txt: any;
  amountX5Txt: any;
  amountX6Txt: any;
  amountX7Txt: any;
  amountX8Txt: any;
  amountX9Txt: any;
  amountX10Txt: any;
  amountDateX1: any;
  amountDateX2: any;
  amountDateX3: any;
  amountDateX4: any;
  amountDateX5: any;
  amountDateX6: any;
  amountDateX7: any;
  amountDateX8: any;
  amountDateX9: any;
  amountDateX10: any;
  amountDateX1Pipe: any;
  amountDateX2Pipe: any;
  amountDateX3Pipe: any;
  amountDateX4Pipe: any;
  amountDateX5Pipe: any;
  amountDateX6Pipe: any;
  amountDateX7Pipe: any;
  amountDateX8Pipe: any;
  amountDateX9Pipe: any;
  amountDateX10Pipe: any;

  emailForm: any = new FormGroup({
    SeletecdTempleteName: new FormControl(),
    seletedTemplateText: new FormControl(),
    DueDate: new FormControl(),
    AmountPaid: new FormControl(),
    PaDeadLine: new FormControl(),
    DatePaid: new FormControl(),
    PastDue: new FormControl(),
    ConfirmationAmt: new FormControl(),
    TotalAmt: new FormControl(),
    PcfAmount: new FormControl(),
    PayArrmtDate: new FormControl(),
    PaymentAddress: new FormControl(),
    ConfirmationDate: new FormControl(),
    AmountX1: new FormControl(),
    AmountX2: new FormControl(),
    AmountX3: new FormControl(),
    AmountX4: new FormControl(),
    AmountX5: new FormControl(),
    AmountX6: new FormControl(),
    AmountX7: new FormControl(),
    AmountX8: new FormControl(),
    AmountX9: new FormControl(),
    AmountX10: new FormControl(),
    DateX1: new FormControl(),
    DateX2: new FormControl(),
    DateX3: new FormControl(),
    DateX4: new FormControl(),
    DateX5: new FormControl(),
    DateX6: new FormControl(),
    DateX7: new FormControl(),
    DateX8: new FormControl(),
    DateX9: new FormControl(),
    DateX10: new FormControl(),
  });

  accountNumber: any;
  originatingSystem: any;
  emailSubmitData: any;


  constructor(
    public dialogRef: MatDialogRef<EmailFuntionComponent>,
    private _generalUiFnService: GeneralUiFunctionsService,
    private emailService: EmailService,
    private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.accountNumber = this.data.selectedAccountNumber;
    this.originatingSystem = this.data.originatingSystem;
  }

  templateList: any;

  selectedTemplate: any;
  templateTxt: any;

  ngOnInit(): void {
    this.emailService.emailTmpltList(this.parentData).subscribe((data: any) => {
      this.templateList = data;
    });
  }

  inputData: any = {};

  getTemplate() {
    this.inputData.strTmpltName = this.selectedTemplate;
    this.emailService.emailTmpltName(this.inputData).subscribe((data: any) => {
      this.templateTxt = data.tmpltName;
      //console.log(this.templateTxt);
    });
  }

  sendEmailData: any = {};

  sendMail() {
    const datepipe: DatePipe = new DatePipe('en-US');
    let DueDateED = datepipe.transform(this.dueDateTxt, 'MM/dd/YYYY');
    let PADeadLineED = datepipe.transform(this.paDeadLineTxt, 'MM/dd/YYYY');
    let DatePaidED = datepipe.transform(this.datePaidTxt, 'MM/dd/YYYY');
    let PayArrmtDateED = datepipe.transform(this.payArrmtDateTxt, 'MM/dd/YYYY');
    let ConfirmByDateED = datepipe.transform(this.confirmDateTxt, 'MM/dd/YYYY');
    let DateX1ED = datepipe.transform(this.amountDateX1, 'MM/dd/YYYY');
    let DateX2ED = datepipe.transform(this.amountDateX2, 'MM/dd/YYYY');
    let DateX3ED = datepipe.transform(this.amountDateX3, 'MM/dd/YYYY');
    let DateX4ED = datepipe.transform(this.amountDateX4, 'MM/dd/YYYY');
    let DateX5ED = datepipe.transform(this.amountDateX5, 'MM/dd/YYYY');
    let DateX6ED = datepipe.transform(this.amountDateX6, 'MM/dd/YYYY');
    let DateX7ED = datepipe.transform(this.amountDateX7, 'MM/dd/YYYY');
    let DateX8ED = datepipe.transform(this.amountDateX8, 'MM/dd/YYYY');
    let DateX9ED = datepipe.transform(this.amountDateX9, 'MM/dd/YYYY');
    let DateX10ED = datepipe.transform(this.amountDateX10, 'MM/dd/YYYY');
    let amtList = [];
    amtList.push(
      this.amountX1Txt,
      this.amountX2Txt,
      this.amountX3Txt,
      this.amountX4Txt,
      this.amountX5Txt,
      this.amountX6Txt,
      this.amountX7Txt,
      this.amountX8Txt,
      this.amountX9Txt,
      this.amountX10Txt
    );
    let dateList = [];
    dateList.push(
      DateX1ED?.toString(),
      DateX2ED?.toString(),
      DateX3ED?.toString(),
      DateX4ED?.toString(),
      DateX5ED?.toString(),
      DateX6ED?.toString(),
      DateX7ED?.toString(),
      DateX8ED?.toString(),
      DateX9ED?.toString(),
      DateX10ED?.toString()
    );
    dateList = dateList.filter((e:any)=>{return e!=null})
    amtList = amtList.filter((e:any)=>{return e!=null})
    this.sendEmailData.selectedAccountNumbers = this.accountNumber;
    this.sendEmailData.originatingSystem = this.originatingSystem;
    this.sendEmailData.tmpltdesc = this.selectedTemplate;
    this.sendEmailData.duedate = DueDateED?.toString();
    this.sendEmailData.padeadline = PADeadLineED?.toString();
    this.sendEmailData.pastDue = this.pastDueTxt;
    this.sendEmailData.total_amt = this.totalTxt;
    this.sendEmailData.payArrangeDate = PayArrmtDateED?.toString();
    this.sendEmailData.ConfirmByDate = ConfirmByDateED?.toString();
    this.sendEmailData.amountPaid = this.amountPaidTxt;
    this.sendEmailData.datePaid = DatePaidED?.toString();
    this.sendEmailData.confirmNum = this.confirmationTxt;
    this.sendEmailData.pcfAmount = this.pcfAmountTxt;
    this.sendEmailData.payAddrInd =
    this.emailForm.controls['PaymentAddress'].value;
    this.sendEmailData.amountlist = amtList;
    this.sendEmailData.datelist = dateList;

    //console.log(this.sendEmailData ,'logging email data before Submit');

    this.emailService.sendEmail(this.sendEmailData).subscribe((data: any) => {

      if (data.tmpltName) {
        this.emailSubmitData = data.tmpltName;
        this.toastr.error('', 'Email Service : Error in Sending Email'+this.emailSubmitData, {
          timeOut: 5000, closeButton: true
        });
        this.dialogRef.close({ msg: this.emailSubmitData });
      }else{
        this.emailSubmitData = data.tmpltName;
        this.dialogRef.close({ msg: this.emailSubmitData });
        this.toastr.success('', 'Email Service : Success in Sending Email'+this.emailSubmitData, {
          timeOut: 5000, closeButton: true
        });
      }
    }, (error: any) => {
      this.toastr.error('', 'Email Service : Error in Sending Email', {
        timeOut: 5000, closeButton: true
      });
    });

  }

  closeModal() {
    this.dialogRef.close({msg:'cancelled'});
  }
  allowOnlyNumbersWithSlash(event: any) {
    return this._generalUiFnService.allowOnlyNumbersWithSlash(event);
  }



}


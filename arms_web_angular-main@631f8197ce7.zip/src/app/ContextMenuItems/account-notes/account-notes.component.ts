import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AccountNotesService } from 'src/app/services/accountNotes.service';
import { GeneralUiFunctionsService } from 'src/app/services/general-ui-functions.service';
import {ConfirmationService} from 'primeng/api';
import {Message} from 'primeng/api';
import { PrimeNGConfig } from 'primeng/api';


@Component({
  selector: 'app-account-notes',
  templateUrl: './account-notes.component.html',
  styleUrls: ['./account-notes.component.scss'],
  providers: [ConfirmationService]
})
export class AccountNotesComponent implements OnInit {

  // autoResolved :boolean = false;
  msgs: Message[] = [];
  selection: any = {};
  commitmentAmtTxt: any;
  commitDueDateTxt: any;
  commitDueDtPipe: any;
  bringUpDateTxt: any;
  bringUpDatePipe: any;
  copyToBiller: boolean = false;
  dBCallTalkedTo: any;
  //myBringUp:boolean= false;
  //sendToAdopt :boolean = false;
  contestedAmtTxt: any;
  phone: any;
  email: any;
  attuid: any;
  inTreatmentStatus: any = "";
  dBTemplateNotes: any;
  subActivity: any;
  rootCause: any;
  nextAction: any;
  longNotes: any;
  callType: any;
  paymentMethod: any;
  extn: any;

  model: any;
  Mode: string = "";
  //radioInps = ['Perm Note', 'No Action', 'Bankruptcy', 'Credit Information', 'In Treatment'];
  form: any = new FormGroup({
    Resolved: new FormControl(),
    premTemp: new FormControl(),
    extn: new FormControl(),
    // PermNote: new FormControl(),
    //NoAction: new FormControl(),
    //Bankruptcy: new FormControl(),
    //CreditInformation: new FormControl(),
    //InTreatment: new FormControl(),
    radioNotes: new FormControl(),
    CommitDueDate: new FormControl(),
    commitmentAmt: new FormControl(),
    BringUpDt: new FormControl(),
    TalkedTo: new FormControl(),
    contestedAmt: new FormControl(),
    templateNotes: new FormControl(),
    SubActivity: new FormControl(),
    RootCause: new FormControl(),
    NextAction: new FormControl(),
    Notes: new FormControl(),
    //BUTUNConditional : new FormControl(),
    //BUTConditional :new FormControl(),
    bringupType: new FormControl(),
    copyToBiller: new FormControl(),
    callType: new FormControl(),
    paymentMethod: new FormControl(),
    myBringUp: new FormControl(),
    sendToAdopt: new FormControl(),
    phone: new FormControl(),//(null, [Validators.pattern("[0-9]{0-10}")]),
    email: new FormControl(),//('',[Validators.required,Validators.email]),
    attuid: new FormControl(),
  })
  accountNumber: any;
  acntNoteOrgSys: any;
  customerGrpCd: any;
  billingPeriod: any;
  originatingSystemArray: any[] = [];
  selectedAccountNumbersArray: any[] = [];
  groupSeleted: any[] = [];
  inputData: any = {};

  constructor(public dialogRef: MatDialogRef<AccountNotesComponent>,
    private _generalUiFnService: GeneralUiFunctionsService,
    private accounts: AccountNotesService,
    private toastr: ToastrService,
    private primengConfig: PrimeNGConfig,
    private confirmationService: ConfirmationService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.Mode = data.Mode;
    this.accountNumber = this.data.selectedAccountNumbers;
    this.acntNoteOrgSys = this.data.originatingSystem;
    this.customerGrpCd = this.data.customerGrpCd;
    this.billingPeriod = this.data.billingPeriod;
    this.originatingSystemArray = this.data.originatingSystemArray;
    this.selectedAccountNumbersArray = this.data.selectedAccountNumbersArray;
    this.groupSeleted = this.data.groupSeleted;
  }

  addAccNotesdB: any = {};

  ngOnInit(): any {
    // this.inputData.accountNumber = this.data.selectedAccountNumbers;
    //this.inputData.acntNoteOrgSys = this.data.originatingSystem;
    //this.inputData.customerGrpCd = this.data.customerGrpCd;
    this.primengConfig.ripple = true;
    this.form.controls["extn"].disable();
    this.inputData.accountNumber = this.accountNumber;
    this.inputData.acntNoteOrgSys = this.acntNoteOrgSys;
    this.inputData.customerGrpCd = this.customerGrpCd;

    this.accounts.addAccountNotes(this.inputData).subscribe((data: any) => {
      //console.log(data);
      this.addAccNotesdB = data;
      if('ContestedAmt' in data){
        this.contestedAmtTxt = parseFloat(data.ContestedAmt[0].contested_amt).toFixed(2);
      }



    });
  }
  inTreatmentdB: any = {};
  inTreatement() {
    // this.inputData.accountNumber = this.data.selectedAccountNumbers;
    // this.inputData.originatingSystem = this.data.originatingSystem;
    // this.inputData.customerGrpCd = this.data.customerGrpCd;

    this.inputData.selectedAccountNumbers = this.selectedAccountNumbersArray;
    this.inputData.originatingSystem = this.originatingSystemArray;
    this.inputData.customerGrpCd = this.customerGrpCd;

    this.accounts.populateInTreatment(this.inputData).subscribe((data: any) => {
      //console.log(data);
      this.inTreatmentdB = data;

    });

  }

  templateTextData: any = {};

  templateText() {
    this.templateTextData.templateName = this.addAccNotesdB.NoteTemplate[0].template_name;
    this.templateTextData.templateType = this.addAccNotesdB.NoteTemplate[0].template_type;
    this.accounts.accountNoteText(this.templateTextData).subscribe((data: any) => {
      //console.log(data);
      //debugger;
      this.longNotes = data.AccountNoteText;

    })
  }
  allowOnlyNumbersWithSlash(event: any) {
    return this._generalUiFnService.allowOnlyNumbersWithSlash(event);
  }


  // actionFunction() {
  //   alert("Save");
  //   this.closeModal();
  // }

  saveAccountNotes: any = {};
  Filters: any;
  //defaultGroup: any = [];
  //ddGroup: string = "";

  confirm() {
    let data1 =localStorage.getItem("userInfo");
    let userData = JSON.parse(data1?data1:"")
    let userLoginCd=userData.globalLogonUsers.user_login_cd;

    if (this.form.controls['Resolved'].value === true) {
      this.confirmationService.confirm({
        message: "By Selecting 'Auto Resolve', all other Bring-ups entered by "+userLoginCd+" will be Resolved. Are you Sure?",
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.msgs = [{severity:'info', summary:'Confirmed', detail:'You have accepted'}];
            this.saveNewAccNotes()
        },
        reject: () => {
            this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
        }
    });
    }
    else{
      this.saveNewAccNotes();
    }
}


  saveNewAccNotes() {
    let errMsg: string = this.validateSave();
    if (errMsg != "") {
      this.toastr.error('', errMsg, {
        timeOut: 5000, closeButton: true
      });
    }
    else {
      const datepipe: DatePipe = new DatePipe('en-US')
      let BringUpDt = datepipe.transform(this.bringUpDateTxt, 'MM/dd/YYYY');
      let CommitDueDt = datepipe.transform(this.commitDueDateTxt, 'MM/dd/YYYY');
      this.saveAccountNotes.modeType = 1; // Always 1 for Adding New Notes
      this.saveAccountNotes.accountNumber = this.accountNumber;
      this.saveAccountNotes.acntNoteOrgSys = this.acntNoteOrgSys;
      this.saveAccountNotes.nextCallBackDate = BringUpDt == undefined || BringUpDt == null ? "" : BringUpDt?.toString();
      this.saveAccountNotes.noteId = 0;  // Always 0 for Adding New Notes
      this.saveAccountNotes.billingPeriod = this.billingPeriod;
      this.saveAccountNotes.groupSelected = this.groupSeleted;
      this.saveAccountNotes.resolved = this.form.controls['Resolved'].value == true ? 1 : 0;
      this.saveAccountNotes.activityCode = this.form.controls['radioNotes'].value;
      this.saveAccountNotes.commitmentAmt = this.commitmentAmtTxt == null || this.commitmentAmtTxt == undefined || this.commitmentAmtTxt == "" ? 0 : parseInt(this.commitmentAmtTxt);
      this.saveAccountNotes.bringupDate = BringUpDt == undefined || BringUpDt == null ? "" : BringUpDt?.toString();; // Note Required
      this.saveAccountNotes.subActivity = this.subActivity;
      this.saveAccountNotes.talkedTo = this.dBCallTalkedTo == null || this.dBCallTalkedTo == undefined ? "" : this.dBCallTalkedTo;
      this.saveAccountNotes.notes = this.longNotes;
      this.saveAccountNotes.contestedAmt = this.contestedAmtTxt;
      this.saveAccountNotes.copyToBiller = this.copyToBiller == true ? 1 : 0;
      this.saveAccountNotes.billerNotePerm = this.form.controls['premTemp'].value == null || this.form.controls['premTemp'].value == undefined || this.form.controls['premTemp'].value == "" ? 0 : parseInt(this.form.controls['premTemp'].value);
      this.saveAccountNotes.callType = this.callType;
      this.saveAccountNotes.paymentMethod = this.paymentMethod == null || this.paymentMethod == undefined ? "" : this.paymentMethod;
      this.saveAccountNotes.customerPhoneNumber = this.phone == null || this.phone == undefined ? "" : this.phone;
      this.saveAccountNotes.customerPhoneNumberExtn = this.extn == null || this.extn == undefined ? "" : this.extn;
      this.saveAccountNotes.customerEmail = this.email == null || this.email == undefined ? "" : this.email;
      //this.saveAccountNotes.attuid = this.attuid;
      this.saveAccountNotes.bringupType = this.form.controls['bringupType'].value == null || this.form.controls['bringupType'].value == undefined ? "" : this.form.controls['bringupType'].value;
      this.saveAccountNotes.sendToAdapt = this.form.controls['sendToAdopt'].value == true ? 1 : 0;
      this.saveAccountNotes.rcCode = this.rootCause;
      this.saveAccountNotes.nxtactCode = this.nextAction;
      this.saveAccountNotes.commitmentDate = CommitDueDt == undefined || CommitDueDt == null ? "" : CommitDueDt?.toString();
      this.saveAccountNotes.myBringUp = this.form.controls['myBringUp'].value == true ? 1 : 0;

      //console.log(this.saveAccountNotes);
      this.accounts.saveAccountNotes(this.saveAccountNotes).subscribe((data: any) => {
        //console.log('Data from the Save API', data);
        if (data.msg == "success") {
          this.saveAccountNotes = null;
          this.toastr.success('', 'Account Notes : Note Saved Succesfully!', {
            timeOut: 5000, closeButton: true
          });
          this.dialogRef.close({ msg: 'success' });
        }
      }, (error: any) => {
        this.toastr.error('', 'Account Notes : Unable to save the Note. Please try again later!', {
          timeOut: 5000, closeButton: true
        });
      });
    }

  }



  validateSave() {
    let strMsg: string = "";
    if (this.form.controls['BringUpDt'].status == "INVALID" || this.form.controls['CommitDueDate'].status == "INVALID") {
      strMsg = "Please select a valid date";
      return strMsg;
    }
    const datepipe: DatePipe = new DatePipe('en-US')
    let newBringUpDt: any = datepipe.transform(this.bringUpDateTxt, 'MM/dd/YYYY');
    let newCommitDueDt: any = datepipe.transform(this.commitDueDateTxt, 'MM/dd/YYYY');
    let CurrentDt = new Date();
    let Crrdt: any = datepipe.transform(CurrentDt, 'MM/dd/YYYY');
    var newCrrdt = new Date(Crrdt?.toString());

    if (newBringUpDt != "" && newBringUpDt != null && newBringUpDt != undefined) {
      var BUdt = new Date(newBringUpDt?.toString());
      if (BUdt.getDay() == 0 || BUdt.getDay() == 6) {
        strMsg = "Bring Up Date: Weekends are not allowed!";
      }
      if (BUdt.getFullYear() == newCrrdt.getFullYear()) {
        if (BUdt.getMonth() == newCrrdt.getMonth()) {
          if (BUdt.getDate() < newCrrdt.getDate()) {
            strMsg = "Bring Up Date: Past Dates are not allowed!";
          }
        }
        if (BUdt.getMonth() < newCrrdt.getMonth()) {
          strMsg = "Bring Up Date: Past Dates are not allowed!";
        }
      }
      else if (BUdt.getFullYear() < newCrrdt.getFullYear()) {
        strMsg = "Bring Up Date: Past Dates are not allowed!";
      }
    }
    if (newCommitDueDt != "" && newCommitDueDt != null && newCommitDueDt != undefined) {
      var CDdt = new Date(newCommitDueDt?.toString());
      if (CDdt.getDay() == 0 || CDdt.getDay() == 6) {
        strMsg = "Commit Due Date: Weekends are not allowed!";
      }
      if (CDdt.getFullYear() == newCrrdt.getFullYear()) {
        if (CDdt.getMonth() == newCrrdt.getMonth()) {
          if (CDdt.getDate() < newCrrdt.getDate()) {
            strMsg = "Commit Due Date: Past Dates are not allowed!";
          }
        }
        if (CDdt.getMonth() < newCrrdt.getMonth()) {
          strMsg = "Commit Due  Date: Past Dates are not allowed!";
        }
      }
      else if (CDdt.getFullYear() < newCrrdt.getFullYear()) {
        strMsg = "Commit Due Date: Past Dates are not allowed!";
      }
    }
    else if (this.form.controls['radioNotes'].value == null || this.form.controls['radioNotes'].value == undefined || this.form.controls['radioNotes'].value == "") {
      if (this.form.controls['Resolved'].value == true) {
        strMsg = "Please select at least one check box for activity";
      }
      else {
        strMsg = "Notes can not be added or modified without at least one status. Please select one or more status check boxes!";
      }
    }
    else {
      if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "I") {
        if (this.form.controls['callType'].value == null || this.form.controls['callType'].value == undefined || this.form.controls['callType'].value == "") {
          strMsg = "Call type must be designated";
        }
        else if (this.form.controls['SubActivity'].value == null || this.form.controls['SubActivity'].value == undefined || this.form.controls['SubActivity'].value == "") {
          strMsg = "Please select subactivity";
        }
        else if (this.form.controls['Notes'].value == "" || this.form.controls['Notes'].value == undefined || this.form.controls['Notes'].value == null) {
          strMsg = "Please type some notes";
        }
      }
      else if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "C") {
        if (this.form.controls['callType'].value == null || this.form.controls['callType'].value == undefined || this.form.controls['callType'].value == "") {
          strMsg = "Call type must be designated";
        }
        else if (this.form.controls['Notes'].value == "" || this.form.controls['Notes'].value == undefined || this.form.controls['Notes'].value == null) {
          strMsg = "Please add/modify notes to reflect credit information";
        }
      }
      else if ((this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "P" || (this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "B" || (this.form.controls['radioNotes'].value.toString()).substring(0, 1) == "N") {
        if (this.form.controls['callType'].value == null || this.form.controls['callType'].value == undefined || this.form.controls['callType'].value == "") {
          strMsg = "Call type must be designated";
        }
      }
    }
    return strMsg;
  }

  closeModal() {
    this.dialogRef.close({ msg:"cancelled" });
  }

  onSubmit() {
    debugger;
    console.log(this.form, 'Add New Account notes Form');
  }

  enableDisableExtn() {
    if (this.phone == "" || this.phone == null || this.phone == undefined) {
      this.form.controls["extn"].disable();
    }
    else {
      if (this.phone.length == 10) {
        this.form.controls["extn"].enable();
      }
      else {
        this.form.controls["extn"].disable();
      }
    }
  }

  allowOnlyNumbers(event: any) {
    return this._generalUiFnService.allowOnlyNumbers(event);
  }

}

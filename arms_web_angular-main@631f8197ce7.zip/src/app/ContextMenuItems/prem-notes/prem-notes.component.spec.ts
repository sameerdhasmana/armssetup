import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PremNotesComponent } from './prem-notes.component';

describe('PremNotesComponent', () => {
  let component: PremNotesComponent;
  let fixture: ComponentFixture<PremNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PremNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PremNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { ITooltipParams } from '@ag-grid-community/core';
import { ITooltipAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-hovering-headers',
  template: `
<div class="custom-tooltip">
    <p><span>Note:</span></p>
    <p style="">{{valueToDisplay}}</p>
  </div>  `,
    styles: [
      `
        :host {
          position: absolute;
          width: 400px;
          border: 1px solid black;
          pointer-events: none;
          background : lightgrey;
        }

        :host.ag-tooltip-hiding {
          opacity: 0;
        }

        .custom-tooltip p {
          margin: 5px;
          white-space: wrap;
        }

        .custom-tooltip p:first-of-type {
          font-weight: bold;
        }
      `,
    ],
})
export class HoveringHeadersComponent implements ITooltipAngularComp  {

  private params!: ITooltipParams;
  public valueToDisplay!: string;

  agInit(params: any): void {
    this.params = params;
    this.valueToDisplay = this.params.value.value
      ? this.params.value.value
      : '- Missing -';
  }
}

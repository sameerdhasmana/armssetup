import { ITooltipAngularComp } from 'ag-grid-angular';
import { ITooltipParams } from '@ag-grid-community/core';
import { Component } from '@angular/core';

@Component({
  selector: 'tooltip-component',
  template: ` <div class="custom-tooltip" >
    <p><span>Double Click to add Account Notes</span></p>
    <p><span>Account Number: {{ data.account_number }}</span></p>
    <p><span>System: </span>{{ data.originating_system }}</p>
  </div>`,
  styles: [
    `
      :host {
        position: absolute;
        width: 200px;
        height: 100px;
        pointer-events: none;
        border: 1px solid black;
        background : lightgrey;
      }

      :host.ag-tooltip-hiding {
        opacity: 0;
      }

      .custom-tooltip p {
        white-space: wrap;
      }

      .custom-tooltip p:first-of-type {
        font-weight: bold;
      }
    `,
  ],
})
export class SystemTooltipComponent implements ITooltipAngularComp  {

  private params!: { color: string } & ITooltipParams;
  public data!: any;
  public color!: string;

  agInit(params:any): void {
    this.params = params;

    this.data = params.api!.getDisplayedRowAtIndex(params.rowIndex!)!.data;
    this.color = this.params.color || 'white';
  }
}

import {
  AfterViewInit,
  Component,
  ViewChild,
  ViewContainerRef
} from "@angular/core";
import { ICellEditorAngularComp } from 'ag-grid-angular';
import { format } from "date-fns";
import { GeneralUiFunctionsService } from "src/app/services/general-ui-functions.service";

@Component({
  selector: "date-cell",
  template: `
    <mat-form-field>
      <input
        matInput
        [matDatepicker]="picker"
        [value]="selectedDate"
        (dateChange)="onDateChanged($event)" (keypress)="allowOnlyNumbersWithSlash($event)" maxlength=10 />
      <mat-datepicker-toggle matSuffix [for]="picker"></mat-datepicker-toggle>
      <mat-datepicker #picker></mat-datepicker>
    </mat-form-field>
  `
})
export class MyDateEditorComponent implements ICellEditorAngularComp {
  params: any;
  selectedDate: any = '';

  constructor(private _generalUiFnService: GeneralUiFunctionsService) { }

  agInit(params: any): void {
    this.params = params;
  }

  allowOnlyNumbersWithSlash(event: any) {
    return this._generalUiFnService.allowOnlyNumbersWithSlash(event);
  }

  getValue = () => {
    let dateString = null;
    if (this.selectedDate) {
      dateString = format(this.selectedDate, "MM/dd/yyyy");
    }
    return dateString;
  };

  afterGuiAttached = () => {
    if (!this.params.value) {
      return;
    }
    const [_, day, month, year] = this.params.value.match(
      /^(\d{2})\/(\d{2})\/(\d{4})$/
    );
    let selectedDate = new Date(year, month - 1, day);
    this.selectedDate = selectedDate;

  };

  onDateChanged = (event: any) => {
    let date = event.value;
    if (date) {
      date.setHours(0, 0, 0, 0);
    }
    this.selectedDate = date;
  }
}

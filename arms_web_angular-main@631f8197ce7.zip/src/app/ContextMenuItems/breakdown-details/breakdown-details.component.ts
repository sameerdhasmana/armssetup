import { Component, Inject, OnInit,ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ColDef, GetContextMenuItemsParams,  MenuItemDef } from 'ag-grid-enterprise';
import { PrimeNGConfig } from 'primeng/api';
import { SearchService } from 'src/app/services/search.service';


@Component({
  selector: 'app-breakdown-details',
  templateUrl: './breakdown-details.component.html',
  styleUrls: ['./breakdown-details.component.scss']
})
export class BreakdownDetailsComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  accountNumberGrid:any;
  acntNoteOrgSys :any;
  defaultExcelExportParams: any;
  rowData: any =[];
  columnDefs: any;
  pageSize: number = 30;
  defaultColDef: ColDef = {
    resizable: true,
    flex:1
  };

  constructor(
    public dialogRef: MatDialogRef<BreakdownDetailsComponent>,
    private searchService :SearchService,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.accountNumberGrid = data.accountNumber;
    this.acntNoteOrgSys = data.acntNoteOrgSys;
  }


  inputData:any={};
  gridApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
  }
  ngOnInit(): void {
    this.defaultExcelExportParams = {
      fileName:
        'AccountBreakdownDetails-' + this.accountNumberGrid + '-' + Date(),
    };
    this.inputData.accountNumber = this.accountNumberGrid;
    this.inputData.acntNoteOrgSys =  this.acntNoteOrgSys;
    this.primengConfig.ripple = true;
    this.searchService.breakdownDetails(this.inputData).subscribe((data: any) => {
      this.columnDefs = this.columnDefsBD;
      this.rowData = data.breakdownDetails;
    });
  }
  columnDefsBD: ColDef[] = [
     { headerName: 'Billing Period', field: 'billingPeriod'},
     { headerName: 'OCC', field: 'occ'},
     { headerName: 'Usage', field: 'usge'},
     { headerName: 'LPC', field: 'lpc'},
     { headerName: 'RC', field: 'rc'},
     { headerName: 'NRC', field: 'nrc'},
     { headerName: 'Taxes', field: 'taxes'},
     { headerName: 'Other', field: 'other'},
  ];
  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  currRowData: any;
  onRowClicked(event: any) {
    this.currRowData = event.data;
  }

  overlayLoadingTemplate =
  `<span class="ag-overlay-loading-center">
Please wait while your Data is loading
</span>`;
overlayNoRowsTemplate =
  `<span style="padding: 10px;
 border: 2px solid #444;
 background: lightgoldenrodyellow;">
 No Data Found in the System
 </span>`;

 closeModal(){
  this.dialogRef.close({ msg: 'success' });
 }

}

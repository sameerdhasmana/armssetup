import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BreakdownDetailsComponent } from './breakdown-details.component';

describe('BreakdownDetailsComponent', () => {
  let component: BreakdownDetailsComponent;
  let fixture: ComponentFixture<BreakdownDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BreakdownDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BreakdownDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

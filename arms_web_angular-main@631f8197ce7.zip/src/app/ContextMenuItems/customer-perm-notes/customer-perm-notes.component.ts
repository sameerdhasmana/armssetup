import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, GetContextMenuItemsParams, ITooltipParams, MenuItemDef, ValueFormatterParams } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { PrimeNGConfig } from 'primeng/api';
import { CustomerNotesModalService } from 'src/app/services/customer-notes-modal.service';
import { NgxSpinnerService } from "ngx-spinner";
import {saveAs} from 'file-saver';
import { HoveringHeadersComponent } from '../hovering-headers/hovering-headers.component';

@Component({
  selector: 'app-customer-perm-notes',
  templateUrl: './customer-perm-notes.component.html',
  styleUrls: ['./customer-perm-notes.component.scss']
})
export class CustomerPermNotesComponent implements OnInit {
  @ViewChild('agGrid') agGrid!: AgGridAngular;

  rowData: any;
  columnDefs: any;
  pageSize: number = 300;
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    // flex: 1,
    //minWidth: 100,
    resizable: true,
  }

  customerGrpCd: string = "";

  constructor(
    public dialogRef: MatDialogRef<CustomerPermNotesComponent>,
    private toastr: ToastrService,
    private customerNotesService: CustomerNotesModalService,
    private primengConfig: PrimeNGConfig,
    private pdfSpinner: NgxSpinnerService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.customerGrpCd = data.customerGrpCd;
  }
  defaultExcelExportParams:any;
  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.customerNotesService.customerPermNotes({ customerGrpCd: this.customerGrpCd }).subscribe((data: any) => {
      if(data.PermNotes.length === 0){
        this.toastr.error('', 'Customer Perm Notes : No Data Available- Customer Perm Notes- '+this.customerGrpCd, {
          timeOut: 5000, closeButton: true
        });
      }
      this.rowData = data.PermNotes;
      this.columnDefs = this.columnDefsPN;
    },
      (error: any) => {
        console.log(error);
      });
      this.defaultExcelExportParams = {
        fileName:
          'CustomerPermNotes-' + this.customerGrpCd + '-' + Date(),
      };

  }

  getContextMenuItems = (
    params: GetContextMenuItemsParams
  ): (string | MenuItemDef)[] => {
    var result: (string | any)[] = [

      'copy',
      'copyWithHeaders',
      'export',
    ];
    return result;
  }

  columnDefsPN: ColDef[] = [
    { headerName: 'Note ID', field: 'notesId' },
    {
      headerName: 'Resolved', field: 'resolved',
      cellRenderer: (params: any) => {
        return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
      }
    },
    { headerName: 'Billing Period', field: 'billingPeriod' },
    { headerName: 'Commitment Amt', field: 'commitmentAmount',type: 'rightAligned',
    valueFormatter: currencyFormatter,
    cellStyle: params => {
      if (params.value < 0) {
          return {color: 'red'};//,backgroundColor: 'green'
      }
      return null;
    }
   },
    { headerName: 'Talked To', field: 'talkedTo' },
    { headerName: 'Notes', field: 'notes',resizable:true,
    tooltipComponent: HoveringHeadersComponent,
    tooltipValueGetter: toolTipValueGetter
  },
    { headerName: 'BringUp Dt', field: 'bringUpDate' },
    { headerName: 'UserID', field: 'userLoginCd' },
    { headerName: 'Logged By', field: 'loggedBy' },
    { headerName: 'Inserted', field: 'insertDate'}
  ];

  overlayLoadingTemplate =
    `<span class="ag-overlay-loading-center">
  Please wait while your Data is loading
  </span>`;
  overlayNoRowsTemplate =
    `<span style="padding: 10px;
   border: 2px solid #444;
   background: lightgoldenrodyellow;">
   No Data Found in the System
   </span>`;

  closeModal() {
    this.dialogRef.close({ msg: 'success' });
  }
  pdfReport(){
    this.pdfSpinner.show();
    this.customerNotesService.generatePermNoteReport({ customerGrpCd: this.customerGrpCd }).subscribe((blob: any) => {
      saveAs(blob, 'Customer-PermNotes.pdf')
      this.pdfSpinner.hide();
    },(error:any)=>{
      let message = error.message;
      this.toastr.error(message, 'Customer Perm Notes : Error in Downloading Customer Perm Notes ', {
        timeOut: 5000, closeButton: true
      });
      this.pdfSpinner.hide();
    });
    //this.pdfSpinner.hide();
 }
}


function currencyFormatter(params: ValueFormatterParams) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number: number) {
  // this puts commas into the number eg 1000 goes to 1,000,
  // i pulled this from stack overflow, i have no idea how it works
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}
function dateFormatter(params:any) {
  var dateAsString = params.data.date;
  var dateParts = dateAsString.split('-');
  return `${dateParts[0]} - ${dateParts[1]} - ${dateParts[2]}`;
}
const toolTipValueGetter = (params: ITooltipParams) => ({
  value: params.value,
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerPermNotesComponent } from './customer-perm-notes.component';

describe('CustomerPermNotesComponent', () => {
  let component: CustomerPermNotesComponent;
  let fixture: ComponentFixture<CustomerPermNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerPermNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerPermNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

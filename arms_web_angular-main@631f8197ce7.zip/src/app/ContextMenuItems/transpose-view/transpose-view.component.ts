import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PrimeNGConfig } from 'primeng/api';

@Component({
  selector: 'app-transpose-view',
  templateUrl: './transpose-view.component.html',
  styleUrls: ['./transpose-view.component.scss']
})
export class TransposeViewComponent implements OnInit {

  parentRowData:any;

  constructor(
    public dialogRef: MatDialogRef<TransposeViewComponent>,
    private primengConfig: PrimeNGConfig,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.parentRowData = data.currRowData;
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
  }

  closeModal(){
    this.dialogRef.close({ msg: 'success' });
   }

}


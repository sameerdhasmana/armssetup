import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransposeViewComponent } from './transpose-view.component';

describe('TransposeViewComponent', () => {
  let component: TransposeViewComponent;
  let fixture: ComponentFixture<TransposeViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransposeViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransposeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
